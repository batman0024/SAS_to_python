# core/define_helper.py  v12 — complete rewrite
"""
Define Helper — correct logic based on actual spec structure (Images 1,5,6,7):

SPEC STRUCTURE (Image 5):
  A=IDVAR, B=QEVAL, C=Dataset, D=Variable, E=Label, F=SAS_Type, G=SAS_Length,
  H=Key_Seq, I=Display_Order, J=Run_Order, K=Input_Variables, L=Mapping_Action,
  ...further columns..., U=Codelist (zero-indexed col 20)

  spec_loader normalises column names → lowercase. So:
    variable      = col D → "variable"
    label         = col E → "label"
    sas_type      = col F → "sas_type" or "sas_typ"
    sas_length    = col G → "sas_length"
    mapping_action= col L → "mapping_action"
    codelist      = col U → "codelist" (index 20) OR named column

TOC SHEET (Image 6):
  Active, Active_SUPPxx, Dataset, Label, Class, Structure, ...
  → filter domains where active == "Y"

CODELIST TAB (Image 7):
  Active, Codelist_Name, Codelist_Label, Codelist_Code, Codelist_Value_Code,
  Codelist_Value, Codelist_Value_Decode, Synonym, Codelist_Extensible,
  Codelist_Source, Standard

  CRITICAL: Active column is at CODELIST level (is this codelist used at all),
  NOT at value level. All values within a codelist are always valid CT terms
  regardless of the Active flag. Do NOT filter values by Active=Y.

KEY FIXES:
  1. Domain filter: only domains with TOC Active=Y AND mapping_action not in (DROP, "")
  2. Codelist Active flag = codelist-level, NOT per-value — include ALL values
  3. CT comparison: 50 unique value cap per variable (not thousands)
  4. Value level (TESTCD/PARAMCD): proper where-clause generation
  5. Variable metadata: correct 4-pass SAS reader, never raises
"""
import io
import logging
import re
import warnings
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import pandas as pd
import numpy as np

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)

EXCLUDE_DOMAIN_PREFIXES = ("_",)
MAX_CT_UNIQUE_VALUES = 50   # cap per variable in CT comparison
MAX_SAMPLE_VALUES    = 20   # cap for sample_values display


# ─────────────────────────────────────────────────────────────────────────────
# SAS / CSV file loading
# ─────────────────────────────────────────────────────────────────────────────

def _load_sas_df(
    fdata: bytes,
    domain: str,
    usecols: Optional[List[str]] = None,
) -> Tuple[pd.DataFrame, Optional[Any], str]:
    """
    Load a SAS7BDAT file from bytes.  Returns (df, meta, error_string).
    Tries pyreadstat (3 strategies) then pandas.read_sas as fallback.
    Never raises — always returns a tuple.
    """
    if not fdata:
        return pd.DataFrame(), None, f"[{domain}] file bytes are empty"

    errors = []

    try:
        import pyreadstat

        # Strategy 1: metadataonly → then full read
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), metadataonly=True)
            col_names = _extract_col_names(meta)
            if col_names:
                kw = {"usecols": usecols} if usecols else {}
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
                df.columns = [c.upper() for c in df.columns]
                return df, meta, ""
            errors.append("strategy1: metadataonly gave 0 columns")
        except Exception as e1:
            errors.append(f"strategy1: {type(e1).__name__}: {e1}")

        # Strategy 2: row_limit=1 then full read
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df1, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), row_limit=1)
            if len(df1.columns) > 0:
                kw = {"usecols": usecols} if usecols else {}
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
                df.columns = [c.upper() for c in df.columns]
                return df, meta, ""
            errors.append("strategy2: row_limit=1 gave 0 columns")
        except Exception as e2:
            errors.append(f"strategy2: {type(e2).__name__}: {e2}")

        # Strategy 3: direct full read
        try:
            kw = {"usecols": usecols} if usecols else {}
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
            if len(df.columns) > 0:
                df.columns = [c.upper() for c in df.columns]
                return df, meta, ""
            errors.append("strategy3: full read gave 0 columns")
        except Exception as e3:
            errors.append(f"strategy3: {type(e3).__name__}: {e3}")

    except ImportError:
        errors.append("pyreadstat not installed")

    # Strategy 4: pandas.read_sas
    try:
        df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
        if usecols:
            uc = [c.upper() for c in usecols]
            df.columns = [c.upper() for c in df.columns]
            df = df[[c for c in uc if c in df.columns]]
        else:
            df.columns = [c.upper() for c in df.columns]
        if len(df.columns) > 0:
            return df, None, ""
        errors.append("strategy4 (pandas): 0 columns")
    except Exception as e4:
        errors.append(f"strategy4 (pandas): {type(e4).__name__}: {e4}")

    return pd.DataFrame(), None, f"[{domain}] all strategies failed: {'; '.join(errors)}"


def _extract_col_names(meta) -> List[str]:
    for attr in ("column_names", "column_names_to_labels",
                 "readstat_variable_names", "variable_names"):
        val = getattr(meta, attr, None)
        if isinstance(val, list) and val:
            return val
        if isinstance(val, dict) and val:
            return list(val.keys())
    return []


# ─────────────────────────────────────────────────────────────────────────────
# Variable metadata from datasets
# ─────────────────────────────────────────────────────────────────────────────

def _meta_from_sas_bytes(fdata: bytes, domain: str) -> Tuple[list, str]:
    """Read variable metadata rows from SAS bytes. Returns (rows, error)."""
    if not fdata:
        return [], f"[{domain}] File bytes empty — upload failed or use .getvalue()"

    df, meta, err = _load_sas_df(fdata, domain)
    if df.empty and err:
        return [], err
    if df.empty:
        return [], f"[{domain}] loaded but 0 columns"

    col_labels = getattr(meta, "column_labels", []) or [] if meta else []
    var_fmts   = getattr(meta, "variable_formats", {}) or {} if meta else {}
    var_types  = (getattr(meta, "original_variable_types", []) or
                  getattr(meta, "readstat_variable_types", []) or []) if meta else []
    var_widths = getattr(meta, "variable_storage_width", {}) or {} if meta else {}

    rows = []
    for idx, col in enumerate(df.columns):
        col_up = col.upper()
        label  = str(col_labels[idx]) if idx < len(col_labels) and col_labels[idx] else ""
        fmt    = (var_fmts.get(col, "") or var_fmts.get(col_up, "")) if isinstance(var_fmts, dict) else ""
        t_raw  = str(var_types[idx]) if idx < len(var_types) and var_types[idx] else ""
        lgth   = (str(var_widths.get(col, "") or var_widths.get(col_up, ""))
                  if isinstance(var_widths, dict) else "")
        pd_dt  = str(df[col].dtype)
        if "char" in t_raw.lower() and "date" in label.lower():  dtype = "datetime"
        elif "char" in t_raw.lower():                             dtype = "text"
        elif any(h in str(fmt).upper() for h in ("DATE","TIME","MMDD","YYMMDD")): dtype = "datetime"
        elif "float" in pd_dt or "int" in pd_dt:                  dtype = "integer"
        else:                                                      dtype = "text"
        rows.append({"domain": domain, "variable": col_up, "label": label,
                     "data_type": dtype, "length": lgth, "format": fmt})
    return rows, ""


def _meta_from_csv_bytes(fdata: bytes, domain: str) -> Tuple[list, str]:
    if not fdata:
        return [], f"[{domain}] CSV empty bytes"
    try:
        df = pd.read_csv(io.BytesIO(fdata), nrows=0)
        return [{"domain": domain, "variable": c.upper(), "label": "",
                 "data_type": "text", "length": "", "format": ""} for c in df.columns], ""
    except Exception as exc:
        return [], f"[{domain}] CSV: {exc}"


def get_column_metadata_from_store(
    files_store: Dict[str, bytes],
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Read variable metadata from files_store {filename: bytes}.
    Always returns (DataFrame, list_of_errors) — never raises.
    """
    rows = []; errors = []
    for fname, fdata in sorted(files_store.items()):
        dom = Path(fname).stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES):
            continue
        fl = fname.lower()
        if fl.endswith(".sas7bdat"):
            r, e = _meta_from_sas_bytes(fdata, dom)
            if e: errors.append(e)
            rows.extend(r)
        elif fl.endswith(".csv"):
            r, e = _meta_from_csv_bytes(fdata, dom)
            if e: errors.append(e)
            rows.extend(r)
    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["domain","variable","label","data_type","length","format"]), errors
    return df.drop_duplicates(subset=["domain","variable"]).reset_index(drop=True), errors


def get_column_metadata(lib_path: str) -> pd.DataFrame:
    store = {}
    lib = Path(lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")): store[fp.name] = fp.read_bytes()
    for fp in sorted(lib.glob("*.csv")):      store[fp.name] = fp.read_bytes()
    df, _ = get_column_metadata_from_store(store)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Spec parsing helpers
# ─────────────────────────────────────────────────────────────────────────────

def _find_codelist_tab(spec: Dict[str, pd.DataFrame]) -> Optional[pd.DataFrame]:
    """Find the Codelist sheet case-insensitively."""
    if not spec:
        return None
    for key in spec:
        kl = str(key).strip().lower().replace(" ", "").replace("_", "")
        if kl in ("codelist", "codelists", "codlst", "codes"):
            return spec[key]
    return None


def _get_active_domains_from_toc(spec: Dict[str, pd.DataFrame]) -> List[str]:
    """
    Return domain names where TOC Active == "Y".
    Image 6 shows TOC has: Active, Active_SUPPxx, Dataset, Label, Class, Structure...
    """
    toc = None
    for key in spec:
        if str(key).strip().lower() == "toc":
            toc = spec[key]
            break
    if toc is None or toc.empty:
        return []

    toc = toc.copy()
    toc.columns = [str(c).strip().lower().replace(" ", "_") for c in toc.columns]

    ds_col = next((c for c in toc.columns if c in ("dataset", "domain", "ds")), None)
    if ds_col is None:
        return []

    act_col = next((c for c in toc.columns if c == "active"), None)
    if act_col:
        mask = toc[act_col].astype(str).str.strip().str.upper() == "Y"
        return toc[mask][ds_col].dropna().str.strip().str.upper().tolist()
    # No active column — return all
    return toc[ds_col].dropna().str.strip().str.upper().tolist()


def _parse_codelist_tab(spec: Dict[str, pd.DataFrame]) -> Dict[str, List[dict]]:
    """
    Parse Codelist tab → {CODELIST_NAME_UPPER: [list of value entries]}.

    CRITICAL FIX (Image 7):
    The 'Active' column in the Codelist tab is at CODELIST level — it indicates
    whether this codelist is used in the study (N = not used in study but still
    a valid CDISC codelist). It does NOT mean the values are invalid.
    ALL values within any codelist are valid CT terms regardless of Active flag.
    We include ALL rows — Active=N values are still permissible CT values.
    """
    cl_df = _find_codelist_tab(spec)
    if cl_df is None or cl_df.empty:
        return {}

    cl_df = cl_df.copy()
    cl_df.columns = [str(c).strip().lower().replace(" ", "_") for c in cl_df.columns]

    # Locate columns — Image 7:
    # A=Active, B=Codelist_Name, C=Codelist_Label, D=Codelist_Code,
    # E=Codelist_Value_Code, F=Codelist_Value, G=Codelist_Value_Decode,
    # H=Synonym, I=Codelist_Extensible, J=Codelist_Source, K=Standard
    name_col   = next((c for c in cl_df.columns if "codelist_name" in c), None)
    value_col  = next((c for c in cl_df.columns
                       if c == "codelist_value" or
                       ("codelist_value" in c and "decode" not in c and "code" not in c.replace("codelist_value",""))), None)
    decode_col = next((c for c in cl_df.columns if "decode" in c), None)
    vcode_col  = next((c for c in cl_df.columns if "codelist_value_code" in c), None)
    ext_col    = next((c for c in cl_df.columns if "extensible" in c), None)
    source_col = next((c for c in cl_df.columns
                       if "source" in c and c not in ("codelist_source_is_redundant",)), None)
    std_col    = next((c for c in cl_df.columns if "standard" in c), None)
    # active_col at codelist level — keep for metadata, NOT for filtering values
    active_col = next((c for c in cl_df.columns if c == "active"), None)

    if not name_col or not value_col:
        return {}

    result: Dict[str, List[dict]] = {}
    for _, row in cl_df.iterrows():
        cl_name = str(row.get(name_col, "")).strip().upper()
        val     = str(row.get(value_col, "")).strip()
        if not cl_name or not val or val.lower() == "nan":
            continue
        # Note: we do NOT filter by active — all values are valid CT terms
        entry = {
            "value":       val,
            "decode":      str(row.get(decode_col, "")).strip() if decode_col else "",
            "vcode":       str(row.get(vcode_col,  "")).strip() if vcode_col  else "",
            "cl_active":   str(row.get(active_col, "")).strip().upper() if active_col else "",
            "extensible":  str(row.get(ext_col,    "")).strip() if ext_col    else "",
            "source":      str(row.get(source_col, "")).strip() if source_col else "",
            "standard":    str(row.get(std_col,    "")).strip() if std_col    else "",
        }
        result.setdefault(cl_name, []).append(entry)
    return result


def _get_codelist_map_from_spec(spec: Dict[str, pd.DataFrame]) -> Dict[tuple, str]:
    """
    Build {(DOMAIN_UPPER, VARIABLE_UPPER) -> CODELIST_NAME_UPPER}.

    Rules (Images 5, 6):
    1. Only domains where TOC Active == "Y"
    2. Only variables where mapping_action (col L) not in ("DROP", "")
    3. Codelist comes from column U (index 20) or named 'codelist' column

    Column U is the 21st column (0-indexed = 20). The spec_loader normalises
    column names to lowercase, so we look for the named column first, then
    fall back to positional index 20.
    """
    if not spec:
        return {}

    # Get active domains from TOC
    active_domains = set(_get_active_domains_from_toc(spec))

    # Reference sheet names to skip
    SKIP_SHEETS = {
        "toc", "codelist", "codelists", "computation", "valuelist",
        "maintenance", "study", "standard", "ig", "valuelist",
        "ts-data", "td-data", "tv-data", "ti-data",
    }
    # Domain names to always exclude (trial design domains)
    try:
        from core.spec_loader import EXCLUDE_DOMAINS
        EXCLUDE = set(EXCLUDE_DOMAINS)
    except ImportError:
        EXCLUDE = {"TA", "TE", "TI", "TV", "TS", "TD", "TM"}

    result = {}
    for sheet, df in spec.items():
        sheet_lower = sheet.strip().lower()
        if sheet_lower in SKIP_SHEETS:
            continue
        if not isinstance(df, pd.DataFrame) or df.empty:
            continue

        dom = sheet.upper()

        # Skip if not in active domains (when we have TOC data)
        if active_domains and dom not in active_domains:
            continue
        if dom in EXCLUDE:
            continue

        # Find variable column (normalised to lowercase by spec_loader)
        var_col = next((c for c in df.columns if c.lower() == "variable"), None)
        if var_col is None:
            continue

        # Find mapping_action column
        ma_col = next((c for c in df.columns
                       if c.lower() in ("mapping_action", "mappingaction", "action")), None)

        # Find codelist column — named first, then positional index 20
        cl_col = next((c for c in df.columns
                       if c.lower() in ("codelist", "codelist_name", "codelist_ref",
                                         "hasnodet", "hasnodeterministic")), None)
        if cl_col is None and len(df.columns) > 20:
            cl_col = df.columns[20]  # column U (0-indexed)

        if cl_col is None:
            continue

        for _, row in df.iterrows():
            var = str(row.get(var_col, "")).strip().upper()
            cl  = str(row.get(cl_col,  "")).strip()

            if not var or not cl or cl.lower() in ("nan", "", "none"):
                continue

            # Skip DROP and blank mapping actions
            if ma_col:
                ma = str(row.get(ma_col, "")).strip().upper()
                if ma in ("DROP", ""):
                    continue

            result[(dom, var)] = cl.upper()

    return result


def _get_spec_variable_metadata(spec: Dict[str, pd.DataFrame]) -> Dict[tuple, dict]:
    """Extract label/type/length for each (domain, variable) from spec sheets."""
    SKIP = {"toc","codelist","codelists","computation","valuelist","maintenance","study","standard","ig"}
    result = {}
    for sheet, df in spec.items():
        if sheet.strip().lower() in SKIP: continue
        if not isinstance(df, pd.DataFrame) or df.empty: continue
        dom = sheet.upper()
        var_col   = next((c for c in df.columns if c.lower() == "variable"), None)
        label_col = next((c for c in df.columns if c.lower() in ("label","variable_label")), None)
        type_col  = next((c for c in df.columns if c.lower() in ("sas_type","sastype","sas_typ","f","type")), None)
        len_col   = next((c for c in df.columns if c.lower() in ("sas_length","saslength","sas_len","g","length")), None)
        if not var_col: continue
        for _, row in df.iterrows():
            var = str(row.get(var_col,"")).strip().upper()
            if not var: continue
            result[(dom,var)] = {
                "label":      str(row.get(label_col,"")).strip() if label_col else "",
                "sas_type":   str(row.get(type_col, "")).strip() if type_col  else "",
                "sas_length": str(row.get(len_col,  "")).strip() if len_col   else "",
            }
    return result


# ─────────────────────────────────────────────────────────────────────────────
# CT Comparison — actual SDTM values vs Codelist tab
# ─────────────────────────────────────────────────────────────────────────────

def compare_data_vs_codelist(
    files_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
    max_unique_per_var: int = MAX_CT_UNIQUE_VALUES,
) -> pd.DataFrame:
    """
    For every variable with a codelist reference (from spec col U / mapping_action != DROP):
      1. Load the SDTM dataset
      2. Get up to max_unique_per_var distinct values
      3. Compare each against Codelist tab column F (Codelist_Value)
      4. Return PASS/MISMATCH with n_obs, ct_decode, ct_vcode, standard

    FIXES:
    - Active=N in codelist tab does NOT mean values are invalid — include ALL values
    - max_unique_per_var=50 prevents LBSTRESC (thousands of numeric values) from
      flooding the output
    - Only processes domains in TOC with Active=Y
    - Only processes variables with mapping_action != DROP/blank
    """
    if not spec or not files_store:
        return pd.DataFrame()

    cl_map    = _get_codelist_map_from_spec(spec)
    cl_lookup = _parse_codelist_tab(spec)

    if not cl_map:
        return pd.DataFrame()

    dom_to_bytes = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".sas7bdat")}
    dom_to_csv   = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".csv")}

    # Group variables by domain for one load per domain
    domain_vars: Dict[str, List[str]] = defaultdict(list)
    for (dom, var) in cl_map:
        domain_vars[dom].append(var)

    rows = []
    for dom, vars_list in sorted(domain_vars.items()):
        fdata = dom_to_bytes.get(dom) or dom_to_csv.get(dom)
        if not fdata:
            continue

        try:
            if dom in dom_to_bytes:
                df_dom, _, load_err = _load_sas_df(fdata, dom)
                if df_dom.empty and load_err:
                    log.debug("CT compare: %s", load_err)
                    continue
            else:
                df_dom = pd.read_csv(io.BytesIO(fdata))
                df_dom.columns = [c.upper() for c in df_dom.columns]
        except Exception as exc:
            log.debug("CT compare load error %s: %s", dom, exc)
            continue

        for var in vars_list:
            if var not in df_dom.columns:
                continue

            cl_name  = cl_map.get((dom, var), "")
            ct_entries = cl_lookup.get(cl_name, [])

            # Build lookup from all entries (NOT filtered by Active)
            allowed: Dict[str, dict] = {e["value"].upper(): e for e in ct_entries}

            col_data = (df_dom[var]
                        .dropna()
                        .astype(str)
                        .str.strip())
            col_data = col_data[col_data.str.lower() != "nan"]

            if col_data.empty:
                continue

            # Get unique values — cap at max_unique_per_var
            unique_vals = sorted(col_data.unique())
            truncated   = len(unique_vals) > max_unique_per_var
            if truncated:
                unique_vals = unique_vals[:max_unique_per_var]

            for val in unique_vals:
                val_upper = val.upper()
                in_ct     = val_upper in allowed
                entry     = allowed.get(val_upper, {})
                n_obs     = int((col_data == val).sum())

                rows.append({
                    "domain":       dom,
                    "variable":     var,
                    "codelist":     cl_name,
                    "value":        val,
                    "n_obs":        n_obs,
                    "in_ct":        "YES" if in_ct else "NO",
                    "ct_decode":    entry.get("decode", ""),
                    "ct_vcode":     entry.get("vcode", ""),
                    "ct_standard":  entry.get("standard", ""),
                    "ct_source":    entry.get("source", ""),
                    "status":       "PASS" if in_ct else "MISMATCH",
                    "note":         f"Showing first {max_unique_per_var} of {col_data.nunique()} unique values" if truncated else "",
                })

    if not rows:
        return pd.DataFrame()
    return (pd.DataFrame(rows)
            .sort_values(["domain","variable","status","value"])
            .reset_index(drop=True))


# ─────────────────────────────────────────────────────────────────────────────
# VLM — Variable Level Metadata with codelist stats
# ─────────────────────────────────────────────────────────────────────────────

def build_vlm_from_spec_and_data(
    files_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """
    Build VLM combining spec codelist reference + actual data statistics.
    One row per (domain, variable) that has a codelist in the spec.

    Columns:
      domain, variable, label, sas_type, sas_length, spec_codelist,
      actual_data_type, actual_max_length, n_distinct_values,
      has_decimals, sample_values (≤20 listed, else first 5 + count),
      ct_values_allowed (≤20 listed, else first 20 + count),
      n_ct_values, ct_extensible, ct_source, ct_standard,
      ct_mismatch_values, ct_mismatch_count, ct_status
    """
    if not spec:
        return pd.DataFrame()

    cl_map      = _get_codelist_map_from_spec(spec)
    cl_lookup   = _parse_codelist_tab(spec)
    spec_meta   = _get_spec_variable_metadata(spec)

    if not cl_map:
        return pd.DataFrame()

    dom_to_bytes = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".sas7bdat")}
    dom_to_csv   = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".csv")}

    # Load each domain once
    domain_vars: Dict[str, List[str]] = defaultdict(list)
    for (dom, var) in cl_map:
        domain_vars[dom].append(var)

    domain_data: Dict[str, pd.DataFrame] = {}
    for dom in domain_vars:
        fdata = dom_to_bytes.get(dom) or dom_to_csv.get(dom)
        if not fdata:
            continue
        try:
            if dom in dom_to_bytes:
                df_d, _, _ = _load_sas_df(fdata, dom)
            else:
                df_d = pd.read_csv(io.BytesIO(fdata))
                df_d.columns = [c.upper() for c in df_d.columns]
            if not df_d.empty:
                domain_data[dom] = df_d
        except Exception:
            pass

    rows = []
    for (dom, var), cl_name in sorted(cl_map.items()):
        sm         = spec_meta.get((dom, var), {})
        label      = sm.get("label", "")
        sas_type   = sm.get("sas_type", "")
        sas_length = sm.get("sas_length", "")

        # ALL ct entries regardless of Active flag
        ct_entries      = cl_lookup.get(cl_name, [])
        ct_vals_all     = sorted({e["value"] for e in ct_entries})
        ct_extensible   = ct_entries[0]["extensible"] if ct_entries else ""
        ct_source       = ct_entries[0]["source"]     if ct_entries else ""
        ct_standard     = ct_entries[0]["standard"]   if ct_entries else ""

        # Format ct_values_allowed display
        if len(ct_vals_all) <= MAX_SAMPLE_VALUES:
            ct_vals_display = "; ".join(ct_vals_all)
        else:
            ct_vals_display = "; ".join(ct_vals_all[:MAX_SAMPLE_VALUES]) + f" ... (+{len(ct_vals_all)-MAX_SAMPLE_VALUES} more)"

        # Actual data stats
        actual_max_len = ""; n_distinct = ""; has_decimals = ""
        sample_vals = ""; mismatch_vals = ""; mismatch_count = ""
        ct_status = "NO DATA"; actual_data_type = "text"

        df_dom = domain_data.get(dom)
        if df_dom is not None and var in df_dom.columns:
            col_data = df_dom[var].dropna()
            col_str  = col_data.astype(str).str.strip()
            col_str  = col_str[col_str.str.lower() != "nan"]

            n_uniq   = col_str.nunique()
            n_distinct = str(n_uniq)

            uniq_vals = sorted(col_str.unique())
            if n_uniq <= MAX_SAMPLE_VALUES:
                sample_vals = "; ".join(uniq_vals)
            else:
                sample_vals = "; ".join(uniq_vals[:5]) + f" ... (+{n_uniq-5} more)"

            if sas_type.upper() in ("CHAR", "C", "CHARACTER", "TEXT"):
                actual_max_len   = str(col_str.str.len().max()) if not col_str.empty else "0"
                has_decimals     = "N/A"
                actual_data_type = "text"
            else:
                try:
                    numeric = pd.to_numeric(col_data, errors="coerce").dropna()
                    if not numeric.empty:
                        actual_max_len = str(int(numeric.abs().max()))
                        dec = numeric[numeric != numeric.round()]
                        if len(dec) > 0:
                            max_dp = int(numeric.apply(
                                lambda x: len(str(x).split(".")[-1]) if "." in str(x) else 0
                            ).max())
                            has_decimals     = f"Y (max {max_dp} dp)"
                            actual_data_type = "float"
                        else:
                            has_decimals     = "N"
                            actual_data_type = "integer"
                except Exception:
                    pass

            # CT comparison (capped at MAX_CT_UNIQUE_VALUES)
            if ct_entries:
                allowed_upper = {e["value"].upper() for e in ct_entries}
                check_vals    = uniq_vals[:MAX_CT_UNIQUE_VALUES]
                mismatches    = [v for v in check_vals if v.upper() not in allowed_upper]
                mismatch_count = str(len(mismatches))
                mismatch_vals  = "; ".join(mismatches[:10])
                if not mismatches:
                    ct_status = "PASS"
                else:
                    suffix = f" (checking first {MAX_CT_UNIQUE_VALUES})" if n_uniq > MAX_CT_UNIQUE_VALUES else ""
                    ct_status = f"MISMATCH ({len(mismatches)} values){suffix}"
            else:
                ct_status = "NO CT VALUES IN SPEC"

        rows.append({
            "domain":             dom,
            "variable":           var,
            "label":              label,
            "sas_type":           sas_type,
            "sas_length":         sas_length,
            "spec_codelist":      cl_name,
            "actual_data_type":   actual_data_type,
            "actual_max_length":  actual_max_len,
            "n_distinct_values":  n_distinct,
            "has_decimals":       has_decimals,
            "sample_values":      sample_vals,
            "ct_values_allowed":  ct_vals_display,
            "n_ct_values":        str(len(ct_vals_all)),
            "ct_extensible":      ct_extensible,
            "ct_source":          ct_source,
            "ct_standard":        ct_standard,
            "ct_mismatch_values": mismatch_vals,
            "ct_mismatch_count":  mismatch_count,
            "ct_status":          ct_status,
        })

    return pd.DataFrame(rows)


# ─────────────────────────────────────────────────────────────────────────────
# Value-level (TESTCD/PARAMCD) with proper where-clause
# ─────────────────────────────────────────────────────────────────────────────

def get_value_level_from_store(
    files_store: Dict[str, bytes],
    columns_df: pd.DataFrame,
    mode: str = "SDTM",
) -> pd.DataFrame:
    """
    Extract value-level entries for TESTCD/QNAM (SDTM) or PARAMCD (ADaM).
    Returns one row per distinct value with where-clause ready for Define-XML.
    """
    mode = mode.upper()

    if columns_df.empty:
        return pd.DataFrame(columns=["dataset","variable","result_variable","value","where_clause","data_type"])

    if mode == "ADAM":
        cands = columns_df[columns_df["variable"].str.upper().isin(["PARAMCD"])][
            ["domain","variable"]].copy().reset_index(drop=True)
        cands["orres"]        = "AVAL"
        cands["where_prefix"] = (cands["domain"] + ".PARAMCD.").values
    else:
        pat   = re.compile(r"TESTCD|QNAM|PARMCD", re.IGNORECASE)
        cands = columns_df[columns_df["variable"].str.contains(pat, na=False)][
            ["domain","variable"]].copy().reset_index(drop=True)
        cands["orres"]        = cands["variable"].apply(
            lambda v: "" if "TESTCD" in v.upper() else "QVAL")
        cands["where_prefix"] = (cands["domain"] + "." + cands["variable"] + ".").values

    if cands.empty:
        return pd.DataFrame(columns=["dataset","variable","result_variable","value","where_clause","data_type"])

    dom_to_bytes = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".sas7bdat")}
    dom_to_csv   = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".csv")}

    rows = []
    for _, cand in cands.iterrows():
        dom  = str(cand["domain"]).upper()
        var  = str(cand["variable"]).upper()
        fdata = dom_to_bytes.get(dom) or dom_to_csv.get(dom)
        if not fdata:
            continue
        try:
            if dom in dom_to_bytes:
                df, _, _ = _load_sas_df(fdata, dom, usecols=[var])
            else:
                df = pd.read_csv(io.BytesIO(fdata), usecols=[var])
            df.columns = [c.upper() for c in df.columns]
            if var not in df.columns:
                continue
            orres = str(cand["orres"]) or dom + "ORRES"
            for val in df[var].dropna().unique():
                vs = str(val).strip()
                if not vs or vs.lower() == "nan":
                    continue
                rows.append({
                    "dataset":         dom,
                    "variable":        var,
                    "result_variable": orres,
                    "value":           vs,
                    "where_clause":    str(cand["where_prefix"]) + vs,
                    "data_type":       _infer_dtype(vs),
                })
        except Exception as exc:
            log.debug("VL error %s.%s: %s", dom, var, exc)

    if not rows:
        return pd.DataFrame(columns=["dataset","variable","result_variable","value","where_clause","data_type"])
    return (pd.DataFrame(rows)
            .drop_duplicates(subset=["dataset","variable","value"])
            .reset_index(drop=True))


def get_value_level(lib_path: str, columns_df: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    store = {}
    lib = Path(lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")): store[fp.name] = fp.read_bytes()
    for fp in sorted(lib.glob("*.csv")):      store[fp.name] = fp.read_bytes()
    return get_value_level_from_store(store, columns_df, mode)


def build_where_clause_table(value_level: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    """Build Define-XML where-clause dataset from value-level."""
    if value_level is None or value_level.empty:
        return pd.DataFrame(columns=["id","dataset","variable","comparator","value","where_clause"])
    wh = value_level[["dataset","variable","value","where_clause"]].copy()
    wh["comparator"] = "EQ"
    wh["id"]         = wh["where_clause"]
    # result_variable if present
    if "result_variable" in value_level.columns:
        wh["result_variable"] = value_level["result_variable"].values
    return wh[["id","dataset","variable","comparator","value","where_clause"]].reset_index(drop=True)


def _infer_dtype(val: str) -> str:
    try:
        n = float(val)
        return "integer" if n == int(n) else "float"
    except (ValueError, TypeError):
        pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T", val): return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$",  val): return "Date"
    return "text"


# ─────────────────────────────────────────────────────────────────────────────
# Legacy validate_ct_values (kept for backward compat)
# ─────────────────────────────────────────────────────────────────────────────

def validate_ct_values(value_level: pd.DataFrame, spec: Dict) -> pd.DataFrame:
    if value_level is None or value_level.empty:
        return pd.DataFrame()
    cl_lookup = _parse_codelist_tab(spec)
    cl_map    = _get_codelist_map_from_spec(spec)
    rows = []
    for _, vrow in value_level.iterrows():
        ds  = str(vrow["dataset"]).upper()
        var = str(vrow["variable"]).upper()
        val = str(vrow["value"]).strip()
        cl_name = cl_map.get((ds, var))
        if not cl_name:
            continue
        allowed = {e["value"].upper() for e in cl_lookup.get(cl_name, [])}
        if not allowed:
            continue
        in_ct = val.upper() in allowed
        rows.append({"dataset":ds,"variable":var,"value":val,"codelist":cl_name,
                     "in_ct":"YES" if in_ct else "NO",
                     "status":"PASS" if in_ct else "MISMATCH"})
    return pd.DataFrame(rows).reset_index(drop=True)
