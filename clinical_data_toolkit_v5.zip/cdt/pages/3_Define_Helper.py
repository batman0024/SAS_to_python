# pages/3_Define_Helper.py
import sys, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

from config.theme import BASE_CSS, C, render_table
from core.define_helper import (
    get_column_metadata_from_store, get_value_level_from_store,
    build_where_clause_table, validate_ct_values,
)
from core.excel_export import export_define_results

st.set_page_config(page_title="Define Helper", layout="wide")
st.markdown(BASE_CSS, unsafe_allow_html=True)
st.title("Define Helper")
st.caption("Extracts variable list, value-level, where-clause, and CT validation from SDTM/ADaM datasets.")

if "sdtm_files_store" not in st.session_state:
    st.warning("Upload SDTM or ADaM .sas7bdat files in the sidebar first.")
    st.stop()

sdtm_store = st.session_state["sdtm_files_store"]
spec       = st.session_state.get("spec")
n_files    = len(sdtm_store)

ds_names = ", ".join(Path(k).stem.upper() for k in sorted(sdtm_store.keys()))
st.info(f"Using {n_files} dataset(s): {ds_names[:150]}{'...' if len(ds_names)>150 else ''}")

col1, col2 = st.columns([2,1])
with col1:
    mode = st.radio("Mode", ["SDTM","ADaM"], horizontal=True)
with col2:
    run_vl = st.checkbox("Extract value-level (loads data rows)", value=True)
    run_ct = st.checkbox("Validate CT values against spec Codelist tab", value=bool(spec))

if st.button("Generate", type="primary", use_container_width=True):
    # Step 1: metadata
    with st.spinner("Reading variable metadata..."):
        try:
            columns_df = get_column_metadata_from_store(sdtm_store)
            if columns_df.empty:
                st.error("No variables found.\n\n"
                         "This can happen when pyreadstat cannot read metadata from the files on your OS. "
                         "The tool will automatically retry by reading 1 data row per file. "
                         "If you still see this message, verify the files are valid .sas7bdat datasets.")
                st.stop()
            st.session_state["define_columns"] = columns_df
            st.session_state["define_mode"]    = mode
        except Exception as exc:
            st.error(f"Metadata error: {exc}"); st.exception(exc); st.stop()

    vl_df, wh_df, ct_df = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    if run_vl and not columns_df.empty:
        with st.spinner("Extracting value-level..."):
            try:
                vl_df = get_value_level_from_store(sdtm_store, columns_df, mode)
                wh_df = build_where_clause_table(vl_df, mode)
            except Exception as exc:
                st.warning(f"Value-level error: {exc}")

    if run_ct and not (vl_df is None or vl_df.empty) and spec:
        with st.spinner("Validating CT values..."):
            try:
                ct_df = validate_ct_values(vl_df, spec)
            except Exception as exc:
                st.warning(f"CT validation error: {exc}")

    st.session_state.update({
        "define_value_level": vl_df,
        "define_where_clause": wh_df,
        "define_ct": ct_df,
    })

if "define_columns" not in st.session_state:
    st.info("Click 'Generate' to extract metadata."); st.stop()

columns_df = st.session_state["define_columns"]
vl_df      = st.session_state.get("define_value_level", pd.DataFrame())
wh_df      = st.session_state.get("define_where_clause", pd.DataFrame())
ct_df      = st.session_state.get("define_ct", pd.DataFrame())
mode       = st.session_state.get("define_mode","SDTM")

n_doms   = columns_df["domain"].nunique() if "domain" in columns_df.columns else 0
n_vars   = len(columns_df)
n_vl     = len(vl_df) if vl_df is not None and not vl_df.empty else 0
n_ct_miss= int((ct_df["status"]=="MISMATCH").sum()) if ct_df is not None and not ct_df.empty else 0

st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">Domains</div><div class="value" style="color:{C["text_main"]};">{n_doms}</div></div>'
    f'<div class="metric-item"><div class="label">Variables</div><div class="value" style="color:{C["text_main"]};">{n_vars}</div></div>'
    f'<div class="metric-item"><div class="label">Value-level rows</div><div class="value" style="color:{C["text_main"]};">{n_vl:,}</div></div>'
    f'<div class="metric-item"><div class="label">CT Mismatches</div><div class="value" style="color:{C["unmap_fg"]};">{n_ct_miss:,}</div></div>'
    f'</div>', unsafe_allow_html=True
)

excel_bytes = export_define_results(
    columns_df,
    vl_df  if vl_df  is not None else pd.DataFrame(),
    wh_df  if wh_df  is not None else pd.DataFrame(),
)
st.download_button("⬇ Download Define Helper (.xlsx)", data=excel_bytes,
    file_name=f"Define_{mode}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

st.divider()
tab1, tab2, tab3, tab4 = st.tabs(["Variable","Value Level","Where Clause","CT Validation"])

with tab1:
    dom_opts = ["All"] + sorted(columns_df["domain"].unique().tolist()) if "domain" in columns_df.columns else ["All"]
    dom_sel  = st.selectbox("Domain", dom_opts, key="def_dom")
    disp = columns_df if dom_sel=="All" else columns_df[columns_df["domain"]==dom_sel]
    st.dataframe(disp, use_container_width=True, height=450)

with tab2:
    if vl_df is None or vl_df.empty:
        st.info("Value-level not extracted.")
    else:
        dom2 = ["All"] + sorted(vl_df["dataset"].unique().tolist()) if "dataset" in vl_df.columns else ["All"]
        d2   = st.selectbox("Domain", dom2, key="def_vl")
        disp2= vl_df if d2=="All" else vl_df[vl_df["dataset"]==d2]
        st.dataframe(disp2, use_container_width=True, height=450)

with tab3:
    if wh_df is None or wh_df.empty:
        st.info("Where-clause not generated.")
    else:
        st.dataframe(wh_df, use_container_width=True, height=450)

with tab4:
    if ct_df is None or ct_df.empty:
        if not spec:
            st.info("Load a mapping spec in the sidebar, then re-generate.")
        else:
            st.info("No CT validation results. Ensure the spec has a Codelist tab with values.")
    else:
        n_miss = int((ct_df["status"]=="MISMATCH").sum())
        n_pass = int((ct_df["status"]=="PASS").sum())
        ca,cb  = st.columns(2)
        ca.metric("Values checked", len(ct_df))
        cb.metric("CT Mismatches", n_miss)

        show_miss = st.checkbox("Show mismatches only", value=True, key="ct_miss_only")
        dom_ct = st.selectbox("Domain", ["All"]+sorted(ct_df["dataset"].unique().tolist()), key="ct_dom")
        disp_ct = ct_df[ct_df["status"]=="MISMATCH"] if show_miss else ct_df
        if dom_ct != "All": disp_ct = disp_ct[disp_ct["dataset"]==dom_ct]

        csv_bytes = disp_ct.to_csv(index=False).encode()
        st.download_button("⬇ Download CT Validation (.csv)", data=csv_bytes,
            file_name=f"CT_Validation_{datetime.now():%Y%m%d_%H%M}.csv", mime="text/csv")

        def _ct_rc(row): return "row-miss" if row.get("status","")=="MISMATCH" else "row-pass"
        st.markdown(render_table(disp_ct, row_class_fn=_ct_rc), unsafe_allow_html=True)
