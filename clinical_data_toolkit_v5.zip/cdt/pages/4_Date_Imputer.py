# pages/4_Date_Imputer.py
"""
Date Imputer — fixes:
- Original ASTDT showing as SAS numeric (23489.0): now converted using same
  _conv_sas_date() applied to input before display
- Dark theme table rendering
- ADAE comparison: original values converted before comparison
- Performance: @st.cache_data on file loading
"""
import sys, warnings, io
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime, date
import pandas as pd
import numpy as np
import streamlit as st

from config.theme import BASE_CSS, C
from core.date_imputer import impute_ae_dates, build_imputation_summary, RULE_LABELS

st.set_page_config(page_title="Date Imputer", layout="wide")
st.markdown(BASE_CSS, unsafe_allow_html=True)

# ── Dark-theme imputation table style ─────────────────────────────────────
st.markdown("""
<style>
.imp-table{width:100%;border-collapse:collapse;font-size:12px;
           font-family:'Courier New',monospace;color:#f1f5f9}
.imp-table th{background:#1e293b;color:#94a3b8;padding:7px 10px;
              text-align:left;font-size:10px;font-weight:700;
              text-transform:uppercase;letter-spacing:.05em;
              position:sticky;top:0;z-index:2;
              border-bottom:2px solid rgba(148,163,184,.2)}
.imp-table td{padding:5px 10px;border-bottom:1px solid rgba(148,163,184,.1);white-space:nowrap}
.imp-table tr.pass td{background:rgba(4,120,87,.15)}
.imp-table tr.part td{background:rgba(146,64,14,.25);color:#fcd34d}
.imp-table tr.miss td{background:rgba(127,29,29,.25);color:#fca5a5}
.imp-table tr.dt  td{background:rgba(30,58,138,.35);color:#93c5fd}
.imp-table tr.even td{background:rgba(30,41,59,.5)}
.imp-table tr:hover td{filter:brightness(1.2)}
.imp-scroll{max-height:450px;overflow:auto;
            border:1px solid rgba(148,163,184,.15);border-radius:8px}
</style>
""", unsafe_allow_html=True)

st.title("AE Date Imputer")
st.caption("Imputes partial/missing AE dates. ADSL merged automatically for TRTSDT.")

SAS_EP = pd.Timestamp("1960-01-01")

def _conv_sas_date(v):
    """Convert SAS numeric date, string date, or Timestamp to pd.Timestamp."""
    if pd.isna(v): return pd.NaT
    if isinstance(v, (pd.Timestamp, datetime, date)): return pd.Timestamp(v)
    s = str(v).strip()
    if "-" in s or "/" in s:
        try: return pd.Timestamp(s)
        except: pass
    try:
        n = float(s)
        if -5000 <= n <= 50000:
            return SAS_EP + pd.Timedelta(days=int(n))
    except: pass
    return pd.NaT

@st.cache_data(show_spinner=False)
def _load_df(fdata: bytes, fname: str) -> pd.DataFrame:
    """Load AE/ADAE/ADSL dataset from bytes. Cached per file content."""
    if fname.lower().endswith(".sas7bdat"):
        try:
            import pyreadstat
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df, _ = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
            df.columns = [c.upper() for c in df.columns]
            return df
        except Exception as exc:
            raise ValueError(f"Cannot read {fname}: {exc}")
    df = pd.read_csv(io.BytesIO(fdata))
    df.columns = [c.upper() for c in df.columns]
    return df

# ── Run toggle ─────────────────────────────────────────────────────────────
run_imp = st.toggle("Enable imputation", value=True)
st.divider()

ae_bytes   = st.session_state.get("ae_file_bytes")
ae_name    = st.session_state.get("ae_file_name","")
adsl_bytes = st.session_state.get("adsl_file_bytes")
adsl_name  = st.session_state.get("adsl_file_name","")

if not ae_bytes:
    st.warning("Upload an AE or ADAE dataset in the sidebar first."); st.stop()

col1, col2 = st.columns([2,1])
with col1:
    msg = f"AE: **{ae_name}**"
    if adsl_bytes: msg += f"  |  ADSL: **{adsl_name}**"
    st.info(msg)
with col2:
    startc = st.text_input("Start DTC",      value="AESTDTC")
    stopc  = st.text_input("Stop DTC",        value="AEENDTC")
    trtsdt = st.text_input("First dose date", value="TRTSDT",
        help="Auto-merged from ADSL if not in AE. SAS numeric dates auto-converted.")
    prefix = st.text_input("Output prefix",   value="AE")
    skip_dt= st.checkbox("Pass datetime strings through", value=True)
    is_adae= st.checkbox("Input is ADAE (comparison mode)",
        value="ADAE" in ae_name.upper())

# ── Load AE ───────────────────────────────────────────────────────────────
try:
    ae_df = _load_df(ae_bytes, ae_name)
except Exception as exc:
    st.error(str(exc)); st.stop()

st.success(f"Loaded {ae_name}: {len(ae_df):,} rows")

# ── Merge ADSL for TRTSDT ─────────────────────────────────────────────────
if trtsdt not in ae_df.columns and adsl_bytes:
    try:
        adsl_df = _load_df(adsl_bytes, adsl_name)
        merge_cols = [c for c in ["USUBJID", trtsdt, "TRTSDTM"] if c in adsl_df.columns]
        if "USUBJID" in adsl_df.columns and trtsdt in adsl_df.columns:
            ae_df = ae_df.merge(
                adsl_df[merge_cols].drop_duplicates("USUBJID"),
                on="USUBJID", how="left")
            st.info(f"Merged {trtsdt} from ADSL.")
        else:
            st.warning(f"ADSL does not contain USUBJID + {trtsdt}.")
    except Exception as exc:
        st.warning(f"Cannot load ADSL: {exc}")

# ── Column checks ─────────────────────────────────────────────────────────
missing = [c for c in [startc, stopc] if c not in ae_df.columns]
if missing:
    st.error(f"Columns not found: {missing}. Available: {sorted(ae_df.columns[:30].tolist())}")
    st.stop()
if trtsdt not in ae_df.columns:
    st.error(f"'{trtsdt}' not available. Upload ADSL in the sidebar for auto-merge."); st.stop()

# Convert TRTSDT from SAS numeric to Timestamp
ae_df[trtsdt] = ae_df[trtsdt].apply(_conv_sas_date)

with st.expander("Input preview (10 rows)", expanded=False):
    id_c  = [c for c in ["USUBJID","SUBJID","AESEQ"] if c in ae_df.columns]
    prev  = [c for c in [startc, stopc, trtsdt] if c in ae_df.columns]
    st.dataframe(ae_df[id_c+prev].head(10), use_container_width=True)

st.divider()

if st.button("Run Imputation" if run_imp else "Parse Dates Only", type="primary", use_container_width=True):
    with st.spinner("Processing..."):
        try:
            result = impute_ae_dates(ae_df, startc=startc, stopc=stopc,
                                     trtsdt=trtsdt, prefix=prefix, skip_if_has_time=skip_dt)
            if not run_imp:
                rc_col = f"{prefix}_START_RULE"
                if rc_col in result.columns:
                    result[rc_col] = result[rc_col].apply(lambda r: r if r in (-1,0) else np.nan)
            st.session_state.update({
                "imputer_result":  result,
                "imputer_prefix":  prefix,
                "imputer_startc":  startc,
                "imputer_stopc":   stopc,
                "imputer_trtsdt":  trtsdt,
                "imputer_is_adae": is_adae,
                # Store original AE df for comparison (only date columns, minimised)
                "imputer_ae_orig": ae_df[[c for c in ae_df.columns
                                          if any(x in c.upper() for x in ["DTC","DT","USUBJID","SEQ"])]].copy(),
            })
        except Exception as exc:
            st.error(f"Failed: {exc}"); st.exception(exc)

if "imputer_result" not in st.session_state:
    st.info("Click the button to process."); st.stop()

result   = st.session_state["imputer_result"]
p        = st.session_state.get("imputer_prefix","AE")
startc   = st.session_state.get("imputer_startc","AESTDTC")
stopc    = st.session_state.get("imputer_stopc","AEENDTC")
trtsdt   = st.session_state.get("imputer_trtsdt","TRTSDT")
is_adae  = st.session_state.get("imputer_is_adae",False)
ae_orig  = st.session_state.get("imputer_ae_orig", pd.DataFrame())

# ── Summary ────────────────────────────────────────────────────────────────
rsumm = build_imputation_summary(result, prefix=p)
st.subheader("Imputation Summary")
items = [(l,c) for l,c in rsumm.items() if c>0]
if items:
    scols = st.columns(min(len(items),4))
    for sc,(lbl,cnt) in zip(scols,items):
        sc.metric(lbl[:38]+"..." if len(lbl)>38 else lbl, cnt)

st.markdown(
    f'<div class="legend-row">'
    f'<span class="legend-chip" style="background:rgba(30,58,138,.4);color:#93c5fd;border:1px solid #3b82f644;">Blue = datetime passthrough</span>'
    f'<span class="legend-chip" style="background:rgba(4,120,87,.2);color:#4ade80;border:1px solid #22c55e44;">Green = full date</span>'
    f'<span class="legend-chip" style="background:rgba(146,64,14,.3);color:#fcd34d;border:1px solid #f59e0b44;">Amber = partial imputed</span>'
    f'<span class="legend-chip" style="background:rgba(127,29,29,.3);color:#fca5a5;border:1px solid #ef444444;">Red = missing imputed</span>'
    f'</div>', unsafe_allow_html=True
)
st.divider()

# ── Output column list ─────────────────────────────────────────────────────
id_disp   = [c for c in ["USUBJID","SUBJID","AESEQ"] if c in result.columns]
inp_cols  = [c for c in [startc, stopc, trtsdt] if c in result.columns]
start_out = [c for c in ["ASTDT","ASTDTC","ASTDTF","ASTTM","ASTDTM"] if c in result.columns]
stop_out  = [c for c in ["AENDT","AENDTC","AENDTF","AENTM","AENDTM"] if c in result.columns]
flag_cols = [c for c in [f"{p}_START_RULE",f"{p}_STOP_IMPFL",
                          f"{p}_STOP_ONGOING",f"{p}_REL_STOP_TO_TRT"] if c in result.columns]

all_out = id_disp + inp_cols + start_out + stop_out + flag_cols
rc_col  = f"{p}_START_RULE"
if rc_col in result.columns:
    result["_rule_label"] = result[rc_col].map(RULE_LABELS).fillna("")
    all_out.append("_rule_label")
all_out = [c for c in all_out if c in result.columns]

def _row_cls(rv):
    try:    r = float(rv) if pd.notna(rv) else 0
    except: r = 0
    if r==-1: return "dt"
    if r==0:  return "pass"
    if r in (1.,2.): return "part"
    return "miss"

def _fmt_val(v) -> str:
    if v is None or (isinstance(v,float) and v!=v): return ""
    if isinstance(v, pd.Timestamp):
        return v.strftime("%Y-%m-%d %H:%M") if (v.hour or v.minute) else v.strftime("%Y-%m-%d")
    return str(v)

def _render_imp(df, max_rows=500):
    cols    = [c for c in all_out if c in df.columns]
    header  = "".join(f"<th>{c}</th>" for c in cols)
    rows_ht = []
    for i,(_,row) in enumerate(df.head(max_rows).iterrows()):
        rv  = row.get(rc_col, np.nan)
        cls = _row_cls(rv)
        if cls=="pass" and i%2==0: cls="even"
        cells = "".join(f"<td>{_fmt_val(row.get(c,''))}</td>" for c in cols)
        rows_ht.append(f'<tr class="{cls}">{cells}</tr>')
    if len(df)>max_rows:
        rows_ht.append(f'<tr><td colspan="{len(cols)}" style="text-align:center;color:#64748b;padding:8px;">'
                       f'… {len(df)-max_rows:,} more rows in download</td></tr>')
    return (f'<div class="imp-scroll"><table class="imp-table">'
            f'<thead><tr>{header}</tr></thead><tbody>{"".join(rows_ht)}</tbody></table></div>')

# ── Tabs ──────────────────────────────────────────────────────────────────
tab_labels = [f"All ({len(result):,})", "Imputed Only"]
if is_adae: tab_labels.append("ADAE Comparison")
tabs = st.tabs(tab_labels)

with tabs[0]:
    st.markdown(_render_imp(result), unsafe_allow_html=True)

with tabs[1]:
    imp_only = result[result[rc_col].notna() & (~result[rc_col].isin([0,-1]))] if rc_col in result.columns else result.head(0)
    st.caption(f"{len(imp_only):,} records had imputation applied")
    st.markdown(_render_imp(imp_only) if not imp_only.empty else "<p style='color:#94a3b8;'>No records required imputation.</p>", unsafe_allow_html=True)

if is_adae and len(tabs)>2:
    with tabs[2]:
        st.markdown("**ADAE Comparison — new imputed values vs existing ADAE variables**")
        # FIX: convert original ADAE date columns from SAS numeric before comparing
        existing_start = [c for c in ["ASTDT","ASTDTC","ASTDTF"] if c in ae_orig.columns]
        existing_stop  = [c for c in ["AENDT","AENDTC","AENDTF"] if c in ae_orig.columns]
        if not existing_start and not existing_stop:
            st.info("No existing ASTDT/AENDT columns found in the input dataset.")
        else:
            comp_rows = []
            for col in existing_start + existing_stop:
                if col not in result.columns or col not in ae_orig.columns:
                    continue
                # Convert SAS numeric originals to date strings for fair comparison
                orig_series = ae_orig[col].apply(lambda v:
                    _conv_sas_date(v).strftime("%Y-%m-%d") if pd.notna(_conv_sas_date(v)) else ""
                    if not isinstance(v, str) else str(v).strip())
                new_series  = result[col].apply(_fmt_val)
                match_mask  = orig_series == new_series
                comp_rows.append({"Variable": col,
                                   "Matches":     int(match_mask.sum()),
                                   "Differences": int((~match_mask).sum()),
                                   "Total":       len(orig_series)})
            if comp_rows:
                st.dataframe(pd.DataFrame(comp_rows), use_container_width=True)
                diff_vars = [r["Variable"] for r in comp_rows if r["Differences"]>0]
                if diff_vars:
                    sel = st.selectbox("Show differing records for:", diff_vars)
                    if sel and sel in result.columns and sel in ae_orig.columns:
                        orig_s = ae_orig[sel].apply(lambda v:
                            _conv_sas_date(v).strftime("%Y-%m-%d") if pd.notna(_conv_sas_date(v)) else ""
                            if not isinstance(v, str) else str(v).strip())
                        new_s  = result[sel].apply(_fmt_val)
                        diff_i = orig_s.index[orig_s != new_s]
                        diff_df = pd.DataFrame({
                            "USUBJID": ae_orig.get("USUBJID", pd.Series(dtype=str)).reindex(diff_i),
                            f"Original_{sel}": orig_s[diff_i],
                            f"New_{sel}":      new_s[diff_i],
                        })
                        st.dataframe(diff_df, use_container_width=True, height=350)

# ── Downloads ─────────────────────────────────────────────────────────────
st.divider()
dl1,dl2 = st.columns(2)

def _prep_csv(df):
    out = df[all_out].copy()
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = out[col].dt.strftime("%Y-%m-%dT%H:%M:%S").fillna("")
    return out.to_csv(index=False).encode("utf-8")

with dl1:
    st.download_button("⬇ Download All Records (.csv)", data=_prep_csv(result),
        file_name=f"AE_imputed_{datetime.now():%Y%m%d_%H%M}.csv", mime="text/csv",
        use_container_width=True)
with dl2:
    if not imp_only.empty:
        st.download_button("⬇ Download Imputed Only (.csv)", data=_prep_csv(imp_only),
            file_name=f"AE_imputed_only_{datetime.now():%Y%m%d_%H%M}.csv", mime="text/csv",
            use_container_width=True)
