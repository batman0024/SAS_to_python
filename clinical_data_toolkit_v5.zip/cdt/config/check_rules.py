# config/check_rules.py
# Central registry of every QC check.
# severity: ERROR = must fix before sponsor review
#           WARNING = should review before sponsor review
# scope: "both" applies to SDTM and ADaM specs

CHECK_RULES = {
    "required_dropped": {
        "severity": "ERROR",
        "description": (
            "Variable is marked REQUIRED in gilead_core but mapping_action is DROP."
        ),
        "suggestion": (
            "Change mapping_action to ASSIGN/DERIVE or update gilead_core."
        ),
        "scope": "both",
        "active": True,
    },
    "gilead_r_dropped": {
        "severity": "ERROR",
        "description": (
            "Variable has gilead_core='R' (required abbreviation) but mapping_action is DROP."
        ),
        "suggestion": (
            "Check whether this variable is truly required for this domain."
        ),
        "scope": "both",
        "active": True,
    },
    "missing_input_var": {
        "severity": "ERROR",
        "description": (
            "mapping_action is not blank/DROP but input_variables is empty "
            "(not a quoted literal, not SEQ)."
        ),
        "suggestion": (
            "Populate input_variables with the source variable reference "
            "(e.g. RAW.DATASET.VARIABLE or SDTM.DOMAIN.VARIABLE)."
        ),
        "scope": "both",
        "active": True,
    },
    "missing_sas_code": {
        "severity": "ERROR",
        "description": (
            "mapping_action is not blank/DROP but implemented_sas_code is empty."
        ),
        "suggestion": (
            "Add the SAS code or transformation logic for this variable."
        ),
        "scope": "both",
        "active": True,
    },
    "missing_origin": {
        "severity": "ERROR",
        "description": (
            "Variable has a mapping_action but origin column is blank."
        ),
        "suggestion": (
            "Set origin to one of: CRF, ASSIGNED|SPONSOR, DERIVED|SPONSOR, "
            "PREDECESSOR, PROTOCOL."
        ),
        "scope": "both",
        "active": True,
    },
    "assigned_no_comment": {
        "severity": "ERROR",
        "description": (
            "Origin is ASSIGNED|SPONSOR but comment column is blank."
        ),
        "suggestion": (
            "Add a comment explaining the assigned value and its justification. "
            "End with a full stop."
        ),
        "scope": "both",
        "active": True,
    },
    "assigned_has_compmethod": {
        "severity": "WARNING",
        "description": (
            "Origin is ASSIGNED|SPONSOR but compmethod_id is also populated. "
            "ASSIGNED origin should use comment, not compmethod_id."
        ),
        "suggestion": (
            "Move the description to the comment column and clear compmethod_id."
        ),
        "scope": "both",
        "active": True,
    },
    "derived_no_compmethod": {
        "severity": "ERROR",
        "description": (
            "Origin is DERIVED|SPONSOR but compmethod_id is blank."
        ),
        "suggestion": (
            "Add a compmethod_id referencing the Computation tab entry "
            "that describes this derivation."
        ),
        "scope": "both",
        "active": True,
    },
    "derived_has_comment": {
        "severity": "WARNING",
        "description": (
            "Origin is DERIVED|SPONSOR but compmethod_id is missing and "
            "comment is present. Derivation logic belongs in compmethod_id."
        ),
        "suggestion": (
            "Move derivation text to the Computation tab and reference via "
            "compmethod_id. Clear the comment for this variable."
        ),
        "scope": "both",
        "active": True,
    },
    "comment_has_comp": {
        "severity": "WARNING",
        "description": (
            "Comment field contains the string 'COMP:' which indicates "
            "derivation text placed in wrong column."
        ),
        "suggestion": (
            "Move the COMP: text to the Computation tab and reference via "
            "compmethod_id."
        ),
        "scope": "both",
        "active": True,
    },
    "double_space_comment": {
        "severity": "WARNING",
        "description": "Comment contains consecutive double spaces.",
        "suggestion": "Remove the extra space.",
        "scope": "both",
        "active": True,
    },
    "comment_no_fullstop": {
        "severity": "WARNING",
        "description": "Comment does not end with a full stop (.).",
        "suggestion": "Add a period at the end of the comment.",
        "scope": "both",
        "active": True,
    },
    "placeholder_compmethod": {
        "severity": "ERROR",
        "description": (
            "compmethod_id still contains the template placeholder text "
            "'<Programmer should specify computation method on study level>'."
        ),
        "suggestion": (
            "Replace with a proper COMP: entry in the Computation tab and "
            "update the compmethod_id reference."
        ),
        "scope": "both",
        "active": True,
    },
}

# Computation tab text quality checks
COMP_TEXT_CHECKS = {
    "comp_no_fullstop": {
        "severity": "WARNING",
        "description": "Algorithm text does not end with a full stop.",
        "suggestion": "Add a period at the end of the algorithm text.",
    },
    "comp_comma_end": {
        "severity": "WARNING",
        "description": "Algorithm text ends with a comma.",
        "suggestion": "Remove trailing comma.",
    },
    "comp_double_space": {
        "severity": "WARNING",
        "description": "Algorithm text contains consecutive double spaces.",
        "suggestion": "Remove the extra space.",
    },
    "comp_bracket_text": {
        "severity": "WARNING",
        "description": "Algorithm text contains bracketed placeholder text (<I...).",
        "suggestion": "Remove or replace the bracketed placeholder.",
    },
    "comp_double_quote": {
        "severity": "WARNING",
        "description": "Algorithm text contains double quotes.",
        "suggestion": "Replace double quotes with single quotes.",
    },
}

SEVERITY_ORDER = {"ERROR": 0, "WARNING": 1, "INFO": 2}
EXCLUDE_DOMAINS = {"TA", "TE", "TI", "TV", "TS", "TD", "TM"}
PLACEHOLDER_COMP = "<Programmer should specify computation method on study level>"
