# config/theme.py
"""
Shared dark-mode-compatible CSS and HTML table renderer for all pages.
Uses OKLCH-based colours that maintain contrast on both dark and light Streamlit themes.
"""

# Palette — works in both light and dark Streamlit themes
C = {
    "bg_dark":    "#0f172a",   # deep navy — page background in dark mode
    "bg_card":    "#1e293b",   # card / metric panels
    "bg_row_alt": "#1e293b",   # alternating table rows (dark)
    "border":     "rgba(148,163,184,.2)",
    # Status colours — vivid enough to read on dark AND light backgrounds
    "exact_bg":   "#052e16",  "exact_fg":   "#4ade80",
    "partial_bg": "#422006",  "partial_fg": "#fbbf24",
    "unmap_bg":   "#450a0a",  "unmap_fg":   "#f87171",
    "error_bg":   "#450a0a",  "error_fg":   "#fca5a5",
    "warn_bg":    "#451a03",  "warn_fg":    "#fcd34d",
    "pass_bg":    "#052e16",  "pass_fg":    "#4ade80",
    "miss_bg":    "#450a0a",  "miss_fg":    "#fca5a5",
    "dt_bg":      "#0c1a3a",  "dt_fg":      "#93c5fd",
    "inline_bg":  "#0c2340",  "inline_fg":  "#7dd3fc",
    # Header
    "hdr_bg":     "#1e293b",  "hdr_fg":     "#f1f5f9",
    # Text
    "text_main":  "#f1f5f9",
    "text_muted": "#94a3b8",
    "badge_error_bg":  "#dc2626", "badge_error_fg":   "#fff",
    "badge_warn_bg":   "#d97706", "badge_warn_fg":    "#fff",
    "badge_inline_bg": "#0369a1", "badge_inline_fg":  "#fff",
}

BASE_CSS = f"""
<style>
/* ── Shared table styles ─────────────────────────────────────────────────── */
.cdt-table {{
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    font-family: 'Segoe UI', system-ui, sans-serif;
    color: {C['text_main']};
}}
.cdt-table th {{
    background: {C['hdr_bg']};
    color: {C['hdr_fg']};
    padding: 9px 12px;
    text-align: left;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .05em;
    text-transform: uppercase;
    position: sticky;
    top: 0;
    z-index: 2;
    border-bottom: 2px solid {C['border']};
}}
.cdt-table td {{
    padding: 7px 12px;
    border-bottom: 1px solid {C['border']};
    vertical-align: top;
    line-height: 1.45;
}}
/* Status rows */
.cdt-table tr.row-exact    td {{ background: {C['exact_bg']};   color: {C['exact_fg']}; }}
.cdt-table tr.row-partial  td {{ background: {C['partial_bg']}; color: {C['partial_fg']}; }}
.cdt-table tr.row-unmapped td {{ background: {C['unmap_bg']};   color: {C['unmap_fg']}; }}
.cdt-table tr.row-error    td {{ background: {C['error_bg']};   color: {C['error_fg']}; }}
.cdt-table tr.row-warning  td {{ background: {C['warn_bg']};    color: {C['warn_fg']}; }}
.cdt-table tr.row-pass     td {{ background: {C['pass_bg']};    color: {C['pass_fg']}; }}
.cdt-table tr.row-miss     td {{ background: {C['miss_bg']};    color: {C['miss_fg']}; }}
.cdt-table tr.row-dt       td {{ background: {C['dt_bg']};      color: {C['dt_fg']}; }}
.cdt-table tr.row-inline   td {{ background: {C['inline_bg']};  color: {C['inline_fg']}; }}
.cdt-table tr.row-alt      td {{ background: {C['bg_row_alt']}; }}
.cdt-table tr:hover        td {{ filter: brightness(1.15); }}
/* Monospace cells */
.cdt-table .mono {{ font-family: 'Courier New', monospace; font-size: 12px; }}
/* Scroll wrapper */
.cdt-scroll {{
    max-height: 500px;
    overflow-y: auto;
    border: 1px solid {C['border']};
    border-radius: 8px;
}}
/* Status badges */
.badge {{
    display: inline-block;
    padding: 2px 9px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .04em;
}}
.badge-error   {{ background: {C['badge_error_bg']};  color: {C['badge_error_fg']}; }}
.badge-warning {{ background: {C['badge_warn_bg']};   color: {C['badge_warn_fg']}; }}
.badge-exact   {{ background: {C['exact_bg']};  color: {C['exact_fg']}; border: 1px solid {C['exact_fg']}33; }}
.badge-partial {{ background: {C['partial_bg']}; color: {C['partial_fg']}; border: 1px solid {C['partial_fg']}33; }}
.badge-unmapped{{ background: {C['unmap_bg']};  color: {C['unmap_fg']}; border: 1px solid {C['unmap_fg']}33; }}
.badge-pass    {{ background: {C['pass_bg']};   color: {C['pass_fg']}; border: 1px solid {C['pass_fg']}33; }}
.badge-miss    {{ background: {C['miss_bg']};   color: {C['miss_fg']}; border: 1px solid {C['miss_fg']}33; }}
.badge-inline  {{ background: {C['inline_bg']}; color: {C['inline_fg']}; border: 1px solid {C['inline_fg']}33; }}
/* Metric banner */
.metric-bar {{
    background: {C['bg_card']};
    border-radius: 10px;
    padding: 14px 24px;
    display: flex;
    gap: 32px;
    flex-wrap: wrap;
    align-items: center;
    margin-bottom: 8px;
}}
.metric-item .label {{
    font-size: 11px;
    color: {C['text_muted']};
    text-transform: uppercase;
    letter-spacing: .06em;
}}
.metric-item .value {{
    font-size: 24px;
    font-weight: 800;
}}
.score-banner {{
    border-radius: 10px;
    padding: 14px 20px;
    margin-bottom: 4px;
    display: flex;
    align-items: center;
    gap: 32px;
    flex-wrap: wrap;
}}
/* Legend row */
.legend-row {{
    display: flex;
    gap: 12px;
    font-size: 12px;
    margin: 6px 0;
    align-items: center;
    flex-wrap: wrap;
    color: {C['text_muted']};
}}
.legend-chip {{
    padding: 2px 10px;
    border-radius: 4px;
    font-size: 12px;
}}
</style>
"""


def render_table(
    df,
    row_class_fn=None,
    cell_fn=None,
    max_rows: int = 1000,
    id_str: str = "",
) -> str:
    """
    Render a DataFrame as a dark-mode-compatible HTML table.
    row_class_fn(row_dict) -> CSS class string (e.g. 'row-error')
    cell_fn(col, val, row_dict) -> HTML string for cell content
    """
    if df is None or df.empty:
        return "<p style='color:#94a3b8;font-style:italic;padding:8px;'>No data.</p>"

    cols = list(df.columns)
    header = "".join(f"<th>{c.replace('_',' ').title()}</th>" for c in cols)

    rows_html = []
    for i, (_, row) in enumerate(df.head(max_rows).iterrows()):
        row_d = row.to_dict()
        if row_class_fn:
            rc = row_class_fn(row_d)
        else:
            rc = "row-alt" if i % 2 == 0 else ""

        cells = []
        for col in cols:
            val = row_d.get(col, "")
            if val is None or (isinstance(val, float) and val != val):
                val = ""
            if cell_fn:
                cell_content = cell_fn(col, str(val), row_d)
                cells.append(f"<td>{cell_content}</td>")
            else:
                mono = "mono" if col.lower() in ("variable","raw_variable","mapped_to","compmethod_id","where_clause","raw_dataset") else ""
                cells.append(f'<td class="{mono}">{val}</td>')

        rows_html.append(f'<tr class="{rc}">{"".join(cells)}</tr>')

    if len(df) > max_rows:
        rows_html.append(
            f'<tr><td colspan="{len(cols)}" style="text-align:center;'
            f'color:#64748b;padding:10px;font-style:italic;">'
            f'Showing {max_rows:,} of {len(df):,} rows — download Excel for full list'
            f'</td></tr>'
        )

    return (
        f'<div class="cdt-scroll" id="{id_str}">'
        f'<table class="cdt-table"><thead><tr>{header}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table></div>'
    )
