# tests/test_spec_validator.py
"""
Unit tests for spec_validator.py
Each test targets one check rule with a minimal DataFrame fixture.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import pandas as pd

from core.spec_validator import (
    _check_domain,
    _validate_codelist_tab,
    _validate_compmethod_tab,
    build_domain_summary,
    run_spec_validation,
)
from config.check_rules import CHECK_RULES


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _row(**kwargs):
    """Build a single-row domain DataFrame with sensible defaults."""
    defaults = {
        "variable": "TESTVR",
        "mapping_action": "ASSIGN",
        "origin": "CRF",
        "input_variables": "RAW.AE.AETERM",
        "implemented_sas_code": "AETERM",
        "gilead_core": "",
        "comment": "Source is CRF.",
        "compmethod_id": "",
        "codelist": "",
        "label": "Test Variable",
    }
    defaults.update(kwargs)
    return pd.DataFrame([defaults])


def _checks_in(issues: pd.DataFrame, check_key: str) -> bool:
    if issues.empty:
        return False
    return check_key in issues["check"].values


ALL_CHECKS = set(CHECK_RULES.keys())


# ---------------------------------------------------------------------------
# Positive cases - checks should fire
# ---------------------------------------------------------------------------

class TestRequiredDropped:
    def test_required_with_drop_triggers_error(self):
        df = _row(gilead_core="REQUIRED", mapping_action="DROP")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "required_dropped")
        assert issues.loc[issues["check"] == "required_dropped", "severity"].iloc[0] == "ERROR"

    def test_gilead_r_with_drop_triggers_error(self):
        df = _row(gilead_core="R", mapping_action="DROP")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "gilead_r_dropped")

    def test_required_assigned_no_drop(self):
        df = _row(gilead_core="REQUIRED", mapping_action="ASSIGN")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "required_dropped")


class TestMissingInputVar:
    def test_missing_input_triggers(self):
        df = _row(input_variables="", implemented_sas_code="AETERM")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "missing_input_var")

    def test_literal_in_code_skips_check(self):
        # implemented_sas_code contains a quote = literal assignment
        df = _row(input_variables="", implemented_sas_code='"ADVERSE EVENT"')
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "missing_input_var")

    def test_seq_skips_check(self):
        df = _row(input_variables="", implemented_sas_code="SEQ")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "missing_input_var")

    def test_drop_action_skips_all_checks(self):
        df = _row(input_variables="", mapping_action="DROP")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "missing_input_var")

    def test_blank_action_skips_all_checks(self):
        df = _row(input_variables="", mapping_action="")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "missing_input_var")


class TestMissingSASCode:
    def test_missing_code_triggers(self):
        df = _row(implemented_sas_code="")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "missing_sas_code")

    def test_code_present_no_trigger(self):
        df = _row(implemented_sas_code="AETERM")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "missing_sas_code")


class TestMissingOrigin:
    def test_blank_origin_triggers(self):
        df = _row(origin="")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "missing_origin")

    def test_origin_present_no_trigger(self):
        df = _row(origin="CRF")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "missing_origin")


class TestAssignedOriginChecks:
    def test_assigned_no_comment_triggers(self):
        df = _row(origin="ASSIGNED|SPONSOR", comment="")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "assigned_no_comment")

    def test_assigned_with_comment_no_trigger(self):
        df = _row(origin="ASSIGNED|SPONSOR", comment="Assigned per protocol.")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "assigned_no_comment")

    def test_assigned_no_comment_but_has_comp_triggers_both(self):
        df = _row(origin="ASSIGNED|SPONSOR", comment="", compmethod_id="COMP001")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "assigned_no_comment")
        assert _checks_in(issues, "assigned_has_compmethod")


class TestDerivedOriginChecks:
    def test_derived_no_comp_triggers(self):
        df = _row(origin="DERIVED|SPONSOR", compmethod_id="")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "derived_no_compmethod")

    def test_derived_with_comp_no_trigger(self):
        df = _row(origin="DERIVED|SPONSOR", compmethod_id="COMP001")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "derived_no_compmethod")

    def test_derived_no_comp_but_has_comment_triggers_warning(self):
        df = _row(origin="DERIVED|SPONSOR", compmethod_id="",
                  comment="Derived from AE dates.")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "derived_no_compmethod")
        assert _checks_in(issues, "derived_has_comment")


class TestCommentChecks:
    def test_comment_with_comp_keyword_triggers(self):
        df = _row(comment="COMP: see algorithm.")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "comment_has_comp")

    def test_comment_comp_case_insensitive(self):
        df = _row(comment="comp: algorithm text here.")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "comment_has_comp")

    def test_double_space_triggers(self):
        # This is the FIXED check (was broken in SAS with findw)
        df = _row(comment="Source is  CRF data.")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "double_space_comment")

    def test_single_space_no_trigger(self):
        df = _row(comment="Source is CRF data.")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "double_space_comment")

    def test_no_fullstop_triggers(self):
        df = _row(comment="Source is CRF data")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "comment_no_fullstop")

    def test_fullstop_present_no_trigger(self):
        df = _row(comment="Source is CRF data.")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "comment_no_fullstop")

    def test_empty_comment_no_fullstop_trigger(self):
        # Empty comment should not trigger fullstop check
        df = _row(origin="CRF", comment="")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "comment_no_fullstop")


class TestPlaceholderCompmethod:
    def test_placeholder_text_triggers(self):
        df = _row(
            origin="DERIVED|SPONSOR",
            compmethod_id="<Programmer should specify computation method on study level>"
        )
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert _checks_in(issues, "placeholder_compmethod")

    def test_real_comp_id_no_trigger(self):
        df = _row(origin="DERIVED|SPONSOR", compmethod_id="COMP001")
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "placeholder_compmethod")


# ---------------------------------------------------------------------------
# Negative cases - clean row should produce zero issues
# ---------------------------------------------------------------------------

class TestCleanRow:
    def test_fully_populated_crf_row_no_issues(self):
        df = _row(
            variable="AESTDTC",
            mapping_action="ASSIGN",
            origin="CRF",
            input_variables="RAW.AE.AESTDAT",
            implemented_sas_code="AESTDAT",
            gilead_core="REQUIRED",
            comment="",
            compmethod_id="",
        )
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert issues.empty, f"Expected no issues, got: {issues['check'].tolist()}"

    def test_derived_with_compmethod_no_issues(self):
        df = _row(
            variable="AEDECOD",
            mapping_action="ASSIGN",
            origin="DERIVED|SPONSOR",
            input_variables="RAW.AE.AETERM",
            implemented_sas_code="AETERM",
            comment="",
            compmethod_id="COMP001",
        )
        issues = _check_domain(df, "AE", ALL_CHECKS)
        assert not _checks_in(issues, "derived_no_compmethod")

    def test_assigned_with_comment_no_issues(self):
        df = _row(
            variable="DOMAIN",
            mapping_action="ASSIGN",
            origin="ASSIGNED|SPONSOR",
            input_variables="",
            implemented_sas_code='"AE"',
            comment="Domain is hardcoded as AE per CDISC standard.",
        )
        issues = _check_domain(df, "AE", ALL_CHECKS)
        # Should not trigger assigned_no_comment (comment present)
        # Should not trigger missing_input_var (code has a quote = literal)
        assert not _checks_in(issues, "assigned_no_comment")
        assert not _checks_in(issues, "missing_input_var")


# ---------------------------------------------------------------------------
# Disabled checks are skipped
# ---------------------------------------------------------------------------

class TestDisabledChecks:
    def test_disabled_check_not_reported(self):
        df = _row(comment="Source is  CRF.")   # double space
        # Run with double_space check disabled
        issues = _check_domain(df, "AE", ALL_CHECKS - {"double_space_comment"})
        assert not _checks_in(issues, "double_space_comment")

    def test_empty_enabled_set_produces_no_issues(self):
        df = _row(origin="", comment="", implemented_sas_code="")
        issues = _check_domain(df, "AE", set())
        assert issues.empty


# ---------------------------------------------------------------------------
# Severity levels
# ---------------------------------------------------------------------------

class TestSeverityLevels:
    def test_errors_have_error_severity(self):
        error_checks = [k for k, v in CHECK_RULES.items() if v["severity"] == "ERROR"]
        for key in error_checks:
            assert CHECK_RULES[key]["severity"] == "ERROR"

    def test_warnings_have_warning_severity(self):
        warning_checks = [k for k, v in CHECK_RULES.items() if v["severity"] == "WARNING"]
        for key in warning_checks:
            assert CHECK_RULES[key]["severity"] == "WARNING"


# ---------------------------------------------------------------------------
# Codelist validation
# ---------------------------------------------------------------------------

class TestCodelistValidation:
    def _make_spec(self, codelist_rows):
        codelist_df = pd.DataFrame(codelist_rows)
        return {"Codelist": codelist_df}

    def test_codelist_found_in_tab(self):
        usage = pd.DataFrame([{"dataset": "AE", "variable": "AESEV", "codelist": "AESEVERITY"}])
        spec = self._make_spec([{"codelist_name": "AESEVERITY", "active": "Y"}])
        result = _validate_codelist_tab(usage, spec)
        assert result.iloc[0]["in_codelist_tab"] == "YES"

    def test_codelist_missing_from_tab(self):
        usage = pd.DataFrame([{"dataset": "AE", "variable": "AESEV", "codelist": "GHOST"}])
        spec = self._make_spec([{"codelist_name": "AESEVERITY", "active": "Y"}])
        result = _validate_codelist_tab(usage, spec)
        assert result.iloc[0]["in_codelist_tab"].startswith("NO")

    def test_empty_codelist_tab(self):
        usage = pd.DataFrame([{"dataset": "AE", "variable": "AESEV", "codelist": "RACE"}])
        result = _validate_codelist_tab(usage, {})
        assert "missing" in result.iloc[0]["in_codelist_tab"].lower()

    def test_empty_usage_returns_empty(self):
        result = _validate_codelist_tab(pd.DataFrame(), {})
        assert result.empty


# ---------------------------------------------------------------------------
# CompMethod validation
# ---------------------------------------------------------------------------

class TestCompmethodValidation:
    def _make_spec_with_comp(self, comp_rows):
        comp_df = pd.DataFrame(comp_rows)
        return {"Computation": comp_df}

    def test_comp_found_with_good_text(self):
        usage = pd.DataFrame([{"dataset": "ADSL", "variable": "TRT01P", "compmethod_id": "COMP001"}])
        spec = self._make_spec_with_comp([{
            "compmethod_id": "COMP001",
            "algorithm": "COMP: Treatment derived from ADSL. Value assigned per randomisation.",
            "active": "Y",
        }])
        result = _validate_compmethod_tab(usage, spec)
        assert result.iloc[0]["in_computation_tab"] == "YES"
        assert result.iloc[0]["comp_no_fullstop"] == "PASS"

    def test_comp_missing_fullstop_fails(self):
        usage = pd.DataFrame([{"dataset": "ADSL", "variable": "TRT01P", "compmethod_id": "COMP001"}])
        spec = self._make_spec_with_comp([{
            "compmethod_id": "COMP001",
            "algorithm": "COMP: Treatment derived from ADSL",
            "active": "Y",
        }])
        result = _validate_compmethod_tab(usage, spec)
        assert result.iloc[0]["comp_no_fullstop"].startswith("FAIL")

    def test_comp_double_space_fails(self):
        usage = pd.DataFrame([{"dataset": "ADSL", "variable": "TRT01P", "compmethod_id": "COMP001"}])
        spec = self._make_spec_with_comp([{
            "compmethod_id": "COMP001",
            "algorithm": "COMP: Treatment  derived from ADSL.",
            "active": "Y",
        }])
        result = _validate_compmethod_tab(usage, spec)
        assert result.iloc[0]["comp_double_space"].startswith("FAIL")

    def test_comp_not_in_tab(self):
        usage = pd.DataFrame([{"dataset": "ADSL", "variable": "TRT01P", "compmethod_id": "GHOSTCOMP"}])
        spec = self._make_spec_with_comp([{"compmethod_id": "COMP001", "algorithm": "X.", "active": "Y"}])
        result = _validate_compmethod_tab(usage, spec)
        assert result.iloc[0]["in_computation_tab"].startswith("NO")


# ---------------------------------------------------------------------------
# Domain summary
# ---------------------------------------------------------------------------

class TestDomainSummary:
    def test_summary_counts_correct(self):
        issues = pd.DataFrame([
            {"domain": "AE", "severity": "ERROR", "variable": "V1", "check": "c1"},
            {"domain": "AE", "severity": "ERROR", "variable": "V2", "check": "c2"},
            {"domain": "AE", "severity": "WARNING", "variable": "V3", "check": "c3"},
            {"domain": "ADSL", "severity": "WARNING", "variable": "V4", "check": "c4"},
        ])
        summary = build_domain_summary(issues)
        ae_row = summary[summary["domain"] == "AE"].iloc[0]
        adsl_row = summary[summary["domain"] == "ADSL"].iloc[0]
        assert ae_row["errors"] == 2
        assert ae_row["warnings"] == 1
        assert ae_row["total"] == 3
        assert adsl_row["warnings"] == 1

    def test_empty_issues_returns_empty(self):
        result = build_domain_summary(pd.DataFrame())
        assert result.empty


# ---------------------------------------------------------------------------
# run_spec_validation integration
# ---------------------------------------------------------------------------

class TestRunSpecValidation:
    def _make_minimal_spec(self):
        toc = pd.DataFrame([
            {"dataset": "AE", "active": "Y"},
            {"dataset": "TA", "active": "Y"},   # should be excluded
        ])
        ae_sheet = pd.DataFrame([
            {
                "variable": "USUBJID",
                "mapping_action": "ASSIGN",
                "origin": "CRF",
                "input_variables": "RAW.AE.SUBJID",
                "implemented_sas_code": "SUBJID",
                "gilead_core": "REQUIRED",
                "comment": "",
                "compmethod_id": "",
                "codelist": "",
                "label": "Unique Subject ID",
            },
            {
                "variable": "AESTDTC",
                "mapping_action": "ASSIGN",
                "origin": "",
                "input_variables": "",
                "implemented_sas_code": "",
                "gilead_core": "REQUIRED",
                "comment": "",
                "compmethod_id": "",
                "codelist": "",
                "label": "Start Date",
            },
        ])
        return {"toc": toc, "AE": ae_sheet}

    def test_excluded_domains_not_checked(self):
        spec = self._make_minimal_spec()
        results = run_spec_validation(spec)
        if not results["issues"].empty:
            assert "TA" not in results["issues"]["domain"].values

    def test_summary_has_required_keys(self):
        spec = self._make_minimal_spec()
        results = run_spec_validation(spec)
        for key in ["errors", "warnings", "health_score", "grade", "total_issues"]:
            assert key in results["summary"]

    def test_issues_includes_errors_for_bad_row(self):
        spec = self._make_minimal_spec()
        results = run_spec_validation(spec)
        issues = results["issues"]
        # AESTDTC row has blank origin + blank input_variables + blank sas_code
        assert not issues.empty
        assert (issues["severity"] == "ERROR").any()

    def test_health_score_is_capped_at_zero(self):
        # Create a spec with many errors
        rows = []
        for i in range(30):
            rows.append({
                "variable": f"VAR{i}",
                "mapping_action": "ASSIGN",
                "origin": "",
                "input_variables": "",
                "implemented_sas_code": "",
                "gilead_core": "REQUIRED",
                "comment": "",
                "compmethod_id": "",
                "codelist": "",
                "label": "",
            })
        spec = {
            "toc": pd.DataFrame([{"dataset": "ADSL", "active": "Y"}]),
            "ADSL": pd.DataFrame(rows),
        }
        results = run_spec_validation(spec)
        assert results["summary"]["health_score"] >= 0

    def test_explicit_datasets_override_active_filter(self):
        spec = self._make_minimal_spec()
        # Only check AE explicitly (TA is excluded anyway but this tests the override)
        results = run_spec_validation(spec, explicit_datasets=["AE"])
        if not results["issues"].empty:
            assert set(results["issues"]["domain"].unique()).issubset({"AE"})
