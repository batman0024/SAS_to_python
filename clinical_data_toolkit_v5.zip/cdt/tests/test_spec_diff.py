# tests/test_spec_diff.py
"""Unit tests for spec_diff.py"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
import pytest

from core.spec_diff import compare_specs, diff_summary, STATUS_CHANGED, STATUS_SAME, STATUS_ONLY_A, STATUS_ONLY_B


def _make_spec(domain_rows, domain_name="AE"):
    toc = pd.DataFrame([{"dataset": domain_name, "active": "Y"}])
    return {
        "toc": toc,
        domain_name: pd.DataFrame(domain_rows),
    }


class TestCompareSpecs:
    def test_identical_specs_all_same(self):
        rows = [{"variable": "USUBJID", "label": "Subject ID", "origin": "CRF"}]
        spec_a = _make_spec(rows)
        spec_b = _make_spec(rows)
        diff = compare_specs(spec_a, spec_b)
        assert (diff["status"] == STATUS_SAME).all()

    def test_changed_label_detected(self):
        spec_a = _make_spec([{"variable": "USUBJID", "label": "Subject ID", "origin": "CRF"}])
        spec_b = _make_spec([{"variable": "USUBJID", "label": "Unique Subject ID", "origin": "CRF"}])
        diff = compare_specs(spec_a, spec_b, compare_fields=["label"])
        changed = diff[diff["status"] == STATUS_CHANGED]
        assert len(changed) == 1
        assert changed.iloc[0]["field"] == "label"

    def test_variable_only_in_a(self):
        spec_a = _make_spec([
            {"variable": "USUBJID", "label": "A", "origin": "CRF"},
            {"variable": "AESTDTC", "label": "B", "origin": "CRF"},
        ])
        spec_b = _make_spec([
            {"variable": "USUBJID", "label": "A", "origin": "CRF"},
        ])
        diff = compare_specs(spec_a, spec_b, compare_fields=["label"])
        only_a = diff[diff["status"] == STATUS_ONLY_A]
        assert len(only_a) == 1
        assert only_a.iloc[0]["variable"] == "AESTDTC"

    def test_variable_only_in_b(self):
        spec_a = _make_spec([{"variable": "USUBJID", "label": "A", "origin": "CRF"}])
        spec_b = _make_spec([
            {"variable": "USUBJID", "label": "A", "origin": "CRF"},
            {"variable": "AESTDTC", "label": "B", "origin": "CRF"},
        ])
        diff = compare_specs(spec_a, spec_b, compare_fields=["label"])
        only_b = diff[diff["status"] == STATUS_ONLY_B]
        assert len(only_b) == 1
        assert only_b.iloc[0]["variable"] == "AESTDTC"

    def test_domain_only_in_a(self):
        spec_a = {
            "toc": pd.DataFrame([{"dataset": "AE", "active": "Y"}]),
            "AE": pd.DataFrame([{"variable": "USUBJID", "label": "A"}]),
        }
        spec_b = {"toc": pd.DataFrame([{"dataset": "LB", "active": "Y"}]),
                  "LB": pd.DataFrame([{"variable": "USUBJID", "label": "A"}])}
        diff = compare_specs(spec_a, spec_b, compare_fields=["label"])
        assert not diff.empty

    def test_empty_specs_return_empty_df(self):
        diff = compare_specs({}, {})
        assert diff.empty

    def test_multiple_fields_compared(self):
        spec_a = _make_spec([{"variable": "USUBJID", "label": "A", "origin": "CRF", "codelist": ""}])
        spec_b = _make_spec([{"variable": "USUBJID", "label": "B", "origin": "DERIVED|SPONSOR", "codelist": ""}])
        diff = compare_specs(spec_a, spec_b, compare_fields=["label", "origin"])
        changed = diff[diff["status"] == STATUS_CHANGED]
        changed_fields = set(changed["field"].tolist())
        assert "label" in changed_fields
        assert "origin" in changed_fields


class TestDiffSummary:
    def test_summary_counts(self):
        diff = pd.DataFrame([
            {"status": STATUS_SAME},
            {"status": STATUS_SAME},
            {"status": STATUS_CHANGED},
            {"status": STATUS_ONLY_A},
            {"status": STATUS_ONLY_B},
        ])
        s = diff_summary(diff)
        assert s["same"] == 2
        assert s["changed"] == 1
        assert s["only_a"] == 1
        assert s["only_b"] == 1
        assert s["total"] == 5

    def test_empty_df_returns_zeros(self):
        s = diff_summary(pd.DataFrame())
        assert s["same"] == 0
        assert s["total"] == 0
