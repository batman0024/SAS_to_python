# tests/test_date_imputer.py
"""
Unit tests for date_imputer.py
Covers every imputation rule, the datetime passthrough toggle,
and edge cases for partial dates.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import pandas as pd
import numpy as np

from core.date_imputer import impute_ae_dates, build_imputation_summary, RULE_LABELS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_ae(start, stop, trtsdt):
    """Build a single-row AE DataFrame."""
    trt = pd.Timestamp(trtsdt) if trtsdt else pd.NaT
    return pd.DataFrame([{
        "AESTDTC": start,
        "AEENDTC": stop,
        "TRTSDT": trt,
    }])


def _run(start, stop, trtsdt="2023-01-15", skip_time=True):
    df = _make_ae(start, stop, trtsdt)
    return impute_ae_dates(df, skip_if_has_time=skip_time).iloc[0]


# ---------------------------------------------------------------------------
# Rule 0: Full date (YYYY-MM-DD) - used as-is
# ---------------------------------------------------------------------------

class TestRule0FullDate:
    def test_full_start_date_used_as_is(self):
        row = _run("2023-04-12", "2023-04-15")
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2023-04-12")
        assert row["ASTDTC"] == "2023-04-12"
        assert row["ASTDTF"] == ""
        assert row["AE_START_RULE"] == 0

    def test_full_stop_date_used_as_is(self):
        row = _run("2023-04-12", "2023-04-15")
        assert pd.Timestamp(row["AENDT"]) == pd.Timestamp("2023-04-15")
        assert row["AENDTF"] == ""

    def test_stop_ongoing_when_stop_missing(self):
        row = _run("2023-04-12", "")
        assert row["AE_STOP_ONGOING"] == "Y"
        assert row["AENDTC"] == ""


# ---------------------------------------------------------------------------
# Rule -1: Datetime passthrough (YYYY-MM-DDTHH:MM:SS)
# ---------------------------------------------------------------------------

class TestDatetimePassthrough:
    def test_datetime_string_passthrough_enabled(self):
        row = _run("2023-04-12T08:30:00", "2023-04-15T17:00:00", skip_time=True)
        assert row["AE_START_RULE"] == -1
        assert row["ASTDTC"] == "2023-04-12"
        assert row["ASTDTF"] == ""

    def test_datetime_string_passthrough_disabled(self):
        # With skip_if_has_time=False the datetime goes through normal imputation
        row = _run("2023-04-12T08:30:00", "2023-04-15", skip_time=False)
        # Should be treated as FULL (matches ISO_FULL via the DATETIME level)
        assert row["AE_START_RULE"] in (0, -1)   # depends on branch
        assert row["ASTDTC"] == "2023-04-12"

    def test_datetime_astdtf_blank(self):
        row = _run("2023-04-12T08:30:00", "", skip_time=True)
        assert row["ASTDTF"] == ""

    def test_datetime_stop_also_passthrough(self):
        row = _run("2023-04-12T08:30:00", "2023-04-15T17:00:00", skip_time=True)
        assert row["AENDTC"] == "2023-04-15"


# ---------------------------------------------------------------------------
# Rule 1: Partial YYYY-MM same month/year as TRTSDT - use TRTSDT
# ---------------------------------------------------------------------------

class TestRule1SameMonthAsTRT:
    def test_ym_same_month_uses_trtsdt(self):
        row = _run("2023-01", "2023-04-15", trtsdt="2023-01-15")
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2023-01-15")
        assert row["AE_START_RULE"] == 1
        assert row["ASTDTF"] == "D"

    def test_ym_same_year_different_month_does_not_use_rule1(self):
        row = _run("2023-03", "2023-04-15", trtsdt="2023-01-15")
        # Different month from TRT - should use Rule 2 (1st of month)
        assert row["AE_START_RULE"] == 2

    def test_year_only_same_year_uses_trtsdt(self):
        row = _run("2023", "2023-04-15", trtsdt="2023-01-15")
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2023-01-15")
        assert row["AE_START_RULE"] == 1
        assert row["ASTDTF"] == "M"


# ---------------------------------------------------------------------------
# Rule 2: Partial YYYY-MM, different month - use 1st of month
# ---------------------------------------------------------------------------

class TestRule2FirstOfMonth:
    def test_ym_different_month_uses_first_of_month(self):
        row = _run("2023-03", "2023-04-15", trtsdt="2023-01-15")
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2023-03-01")
        assert row["AE_START_RULE"] == 2
        assert row["ASTDTF"] == "D"

    def test_ym_no_trtsdt_uses_first_of_month(self):
        row = _run("2023-03", "2023-04-15", trtsdt=None)
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2023-03-01")
        assert row["AE_START_RULE"] == 2


# ---------------------------------------------------------------------------
# Rule 3: Year only, different year - use Jan 1
# ---------------------------------------------------------------------------

class TestRule3YearOnly:
    def test_year_different_from_trt_uses_jan1(self):
        row = _run("2022", "2022-04-15", trtsdt="2023-01-15")
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2022-01-01")
        assert row["AE_START_RULE"] == 3
        assert row["ASTDTF"] == "M"

    def test_year_no_trtsdt_uses_jan1(self):
        row = _run("2022", "2022-04-15", trtsdt=None)
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2022-01-01")


# ---------------------------------------------------------------------------
# Rule 4: Start missing, pre-treatment stop - use Jan 1 of stop year
# ---------------------------------------------------------------------------

class TestRule4PreTreatmentStop:
    def test_missing_start_pretreatment_stop_uses_jan1_of_stop_year(self):
        # Stop is before TRTSDT -> rel = LT -> rule 4
        row = _run("", "2022-06-01", trtsdt="2023-01-15")
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2022-01-01")
        assert row["AE_START_RULE"] == 4
        assert row["ASTDTF"] == "Y"


# ---------------------------------------------------------------------------
# Rule 5: Start missing, no pre-treatment stop - use TRTSDT
# ---------------------------------------------------------------------------

class TestRule5MissingStartUsesTRT:
    def test_missing_start_posttreatment_stop_uses_trtsdt(self):
        row = _run("", "2023-04-15", trtsdt="2023-01-15")
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2023-01-15")
        assert row["AE_START_RULE"] == 5
        assert row["ASTDTF"] == "Y"

    def test_missing_start_missing_stop_uses_trtsdt(self):
        row = _run("", "", trtsdt="2023-01-15")
        assert pd.Timestamp(row["ASTDT"]) == pd.Timestamp("2023-01-15")
        assert row["AE_START_RULE"] == 5


# ---------------------------------------------------------------------------
# Stop imputation flags
# ---------------------------------------------------------------------------

class TestStopImputation:
    def test_ym_stop_imputed_end_of_month(self):
        row = _run("2023-04-12", "2023-06")
        assert pd.Timestamp(row["AENDT"]) == pd.Timestamp("2023-06-30")
        assert row["AE_STOP_IMPFL"] == "M"
        assert row["AENDTF"] == "D"

    def test_year_only_stop_imputed_dec31(self):
        row = _run("2023-04-12", "2023")
        assert pd.Timestamp(row["AENDT"]) == pd.Timestamp("2023-12-31")
        assert row["AE_STOP_IMPFL"] == "Y"
        assert row["AENDTF"] == "M"

    def test_missing_stop_is_ongoing(self):
        row = _run("2023-04-12", "")
        assert row["AE_STOP_ONGOING"] == "Y"
        assert pd.isna(row["AENDT"])
        assert row["AENDTC"] == ""


# ---------------------------------------------------------------------------
# REL_STOP_TO_TRT
# ---------------------------------------------------------------------------

class TestRelStopToTRT:
    def test_stop_before_trt_is_lt(self):
        row = _run("2022-06-01", "2022-12-31", trtsdt="2023-01-15")
        assert row["AE_REL_STOP_TO_TRT"] == "LT"

    def test_stop_after_trt_is_ge(self):
        row = _run("2023-02-01", "2023-04-15", trtsdt="2023-01-15")
        assert row["AE_REL_STOP_TO_TRT"] == "GE"

    def test_stop_missing_is_miss(self):
        row = _run("2023-02-01", "", trtsdt="2023-01-15")
        assert row["AE_REL_STOP_TO_TRT"] == "MISS"


# ---------------------------------------------------------------------------
# Custom prefix
# ---------------------------------------------------------------------------

class TestCustomPrefix:
    def test_custom_prefix_used(self):
        df = _make_ae("2023-04", "2023-04-15", "2023-04-01")
        result = impute_ae_dates(df, prefix="CM").iloc[0]
        assert "CM_START_RULE" in result.index
        assert "AE_START_RULE" not in result.index


# ---------------------------------------------------------------------------
# Missing required columns raises
# ---------------------------------------------------------------------------

class TestInputValidation:
    def test_missing_startc_raises(self):
        df = pd.DataFrame([{"AEENDTC": "2023-04-15", "TRTSDT": pd.Timestamp("2023-01-01")}])
        with pytest.raises(ValueError, match="Missing required columns"):
            impute_ae_dates(df)

    def test_missing_trtsdt_raises(self):
        df = pd.DataFrame([{"AESTDTC": "2023-04-12", "AEENDTC": "2023-04-15"}])
        with pytest.raises(ValueError, match="Missing required columns"):
            impute_ae_dates(df)


# ---------------------------------------------------------------------------
# Multi-row dataset
# ---------------------------------------------------------------------------

class TestMultiRow:
    def test_multiple_rows_processed_independently(self):
        df = pd.DataFrame([
            {"AESTDTC": "2023-04-12", "AEENDTC": "2023-04-15",
             "TRTSDT": pd.Timestamp("2023-01-15")},
            {"AESTDTC": "2023-01",    "AEENDTC": "2023-04-15",
             "TRTSDT": pd.Timestamp("2023-01-15")},
            {"AESTDTC": "",            "AEENDTC": "",
             "TRTSDT": pd.Timestamp("2023-01-15")},
        ])
        result = impute_ae_dates(df)
        assert len(result) == 3
        assert result.iloc[0]["AE_START_RULE"] == 0    # full date
        assert result.iloc[1]["AE_START_RULE"] == 1    # ym same month
        assert result.iloc[2]["AE_START_RULE"] == 5    # missing -> TRT


# ---------------------------------------------------------------------------
# Summary function
# ---------------------------------------------------------------------------

class TestBuildSummary:
    def test_summary_keys_match_rules(self):
        df = _make_ae("2023-04-12", "2023-04-15", "2023-01-15")
        result = impute_ae_dates(df)
        summary = build_imputation_summary(result, prefix="AE")
        for label in RULE_LABELS.values():
            assert label in summary

    def test_summary_counts_correct(self):
        df = pd.DataFrame([
            {"AESTDTC": "2023-04-12", "AEENDTC": "2023-04-15",
             "TRTSDT": pd.Timestamp("2023-01-15")},
            {"AESTDTC": "2023-04-12", "AEENDTC": "2023-04-15",
             "TRTSDT": pd.Timestamp("2023-01-15")},
        ])
        result = impute_ae_dates(df)
        summary = build_imputation_summary(result, prefix="AE")
        full_label = RULE_LABELS[0]
        assert summary[full_label] == 2
