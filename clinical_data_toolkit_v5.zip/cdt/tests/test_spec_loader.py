# tests/test_spec_loader.py
"""
Unit tests for spec_loader.py
Tests TOC parsing, active domain extraction, and metadata detection.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import io
import pytest
import pandas as pd

from core.spec_loader import (
    get_toc,
    get_active_domains,
    get_spec_metadata,
    _normalise_columns,
)
from config.check_rules import EXCLUDE_DOMAINS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_spec(toc_rows, extra_sheets=None):
    spec = {
        "toc": pd.DataFrame(toc_rows).rename(
            columns=lambda c: c.strip().lower()
        ).fillna(""),
    }
    if extra_sheets:
        spec.update(extra_sheets)
    return spec


# ---------------------------------------------------------------------------
# _normalise_columns
# ---------------------------------------------------------------------------

class TestNormaliseColumns:
    def test_lowercases_columns(self):
        df = pd.DataFrame({"Dataset": [1], "Active": [2], "IG Version": [3]})
        result = _normalise_columns(df)
        assert list(result.columns) == ["dataset", "active", "ig_version"]

    def test_strips_whitespace(self):
        df = pd.DataFrame({" Variable ": [1], "  Label  ": [2]})
        result = _normalise_columns(df)
        assert "variable" in result.columns
        assert "label" in result.columns


# ---------------------------------------------------------------------------
# get_toc
# ---------------------------------------------------------------------------

class TestGetToc:
    def test_returns_toc_sheet(self):
        spec = _make_spec([{"dataset": "AE", "active": "Y"}])
        toc = get_toc(spec)
        assert "dataset" in toc.columns

    def test_raises_if_no_toc(self):
        with pytest.raises(KeyError):
            get_toc({"AE": pd.DataFrame()})

    def test_case_insensitive_toc_key(self):
        spec = {"TOC": pd.DataFrame([{"dataset": "AE"}])}
        toc = get_toc(spec)
        assert not toc.empty


# ---------------------------------------------------------------------------
# get_active_domains
# ---------------------------------------------------------------------------

class TestGetActiveDomains:
    def test_returns_active_domains_only(self):
        spec = _make_spec([
            {"dataset": "AE", "active": "Y"},
            {"dataset": "LB", "active": "N"},
            {"dataset": "VS", "active": "Y"},
        ])
        domains = get_active_domains(spec)
        assert "AE" in domains
        assert "VS" in domains
        assert "LB" not in domains

    def test_excludes_standard_domains(self):
        rows = [{"dataset": d, "active": "Y"} for d in EXCLUDE_DOMAINS | {"AE"}]
        spec = _make_spec(rows)
        domains = get_active_domains(spec)
        for excl in EXCLUDE_DOMAINS:
            assert excl not in domains
        assert "AE" in domains

    def test_explicit_datasets_override_active_filter(self):
        spec = _make_spec([
            {"dataset": "AE", "active": "N"},
            {"dataset": "LB", "active": "N"},
        ])
        domains = get_active_domains(spec, explicit_datasets=["AE", "LB"])
        assert "AE" in domains
        assert "LB" in domains

    def test_explicit_datasets_still_excludes_standard_domains(self):
        spec = _make_spec([{"dataset": "AE", "active": "Y"}])
        domains = get_active_domains(spec, explicit_datasets=["AE", "TA", "TS"])
        assert "AE" in domains
        assert "TA" not in domains
        assert "TS" not in domains

    def test_no_active_column_treats_all_as_active(self):
        spec = {"toc": pd.DataFrame([{"dataset": "AE"}, {"dataset": "LB"}])}
        domains = get_active_domains(spec)
        assert "AE" in domains
        assert "LB" in domains

    def test_custom_active_filter(self):
        spec = _make_spec([
            {"dataset": "AE", "active": "YES"},
            {"dataset": "LB", "active": "Y"},
        ])
        domains = get_active_domains(spec, active_filter="YES")
        assert "AE" in domains
        assert "LB" not in domains

    def test_empty_dataset_names_excluded(self):
        spec = _make_spec([
            {"dataset": "AE", "active": "Y"},
            {"dataset": "", "active": "Y"},
            {"dataset": "   ", "active": "Y"},
        ])
        domains = get_active_domains(spec)
        assert "" not in domains
        assert "   " not in domains

    def test_uppercase_normalisation(self):
        spec = _make_spec([{"dataset": "ae", "active": "Y"}])
        domains = get_active_domains(spec)
        assert "AE" in domains


# ---------------------------------------------------------------------------
# get_spec_metadata
# ---------------------------------------------------------------------------

class TestGetSpecMetadata:
    def test_spec_type_sdtm_detected(self):
        spec = _make_spec([
            {"dataset": "AE", "active": "Y"},
            {"dataset": "LB", "active": "Y"},
            {"dataset": "VS", "active": "Y"},
        ])
        meta = get_spec_metadata(spec)
        assert meta["spec_type"] == "SDTM"

    def test_spec_type_adam_detected(self):
        spec = _make_spec([
            {"dataset": "ADSL", "active": "Y"},
            {"dataset": "ADAE", "active": "Y"},
            {"dataset": "ADLB", "active": "Y"},
        ])
        meta = get_spec_metadata(spec)
        assert meta["spec_type"] == "ADaM"

    def test_returns_empty_strings_when_no_version_cols(self):
        spec = _make_spec([{"dataset": "AE", "active": "Y"}])
        meta = get_spec_metadata(spec)
        assert "ig_version" in meta
        assert "ct_version" in meta
