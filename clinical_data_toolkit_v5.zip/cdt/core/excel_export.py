import warnings
warnings.filterwarnings("ignore")
# core/excel_export.py
"""
Excel export — proper text wrapping, auto row heights, capped column widths.
All long-text columns wrap inside cells with auto-height rows.
"""
import io
import logging
from typing import Dict, List, Optional

import pandas as pd

log = logging.getLogger(__name__)

# ── Colour palette (print-safe, light-mode readable) ─────────────────────────
HEADER_BG   = "#1E3A5F"
HEADER_FG   = "#FFFFFF"
ALT_ROW_BG  = "#F5F8FA"
ERR_BG      = "#FFD0D0"
WARN_BG     = "#FFF3CC"
PASS_BG     = "#D4F5DC"
MISS_BG     = "#FFD0D0"
INLINE_BG   = "#E8F4FD"
DOMAIN_HDR  = "#D0E4FF"

# Max column width in characters — prevents runaway wide columns
MAX_COL_W   = 45
WRAP_COLS   = {"description","suggestion","algorithm","comment","label",
               "mapped_to","algorithm_preview","used_by_domains",
               "sdtm_domains","active_flag_check"}


def _base_formats(wb):
    wrap = {"text_wrap": True, "valign": "top", "font_size": 10, "border": 1}
    nowrap = {"text_wrap": False, "valign": "top", "font_size": 10, "border": 1}
    return {
        "hdr":    wb.add_format({"bold": True, "font_color": HEADER_FG,
                                  "bg_color": HEADER_BG, "valign": "vcenter",
                                  "font_size": 10, "border": 1, "text_wrap": True}),
        "norm":   wb.add_format(wrap),
        "norm_nw":wb.add_format(nowrap),
        "alt":    wb.add_format({**wrap, "bg_color": ALT_ROW_BG}),
        "alt_nw": wb.add_format({**nowrap, "bg_color": ALT_ROW_BG}),
        "err":    wb.add_format({**wrap, "bg_color": ERR_BG}),
        "warn":   wb.add_format({**wrap, "bg_color": WARN_BG}),
        "pass":   wb.add_format({**wrap, "bg_color": PASS_BG}),
        "miss":   wb.add_format({**wrap, "bg_color": MISS_BG}),
        "inline": wb.add_format({**nowrap, "bg_color": INLINE_BG}),
        "title":  wb.add_format({"bold": True, "font_size": 13,
                                  "font_color": HEADER_BG}),
        "dom_hdr":wb.add_format({"bold": True, "font_size": 11,
                                  "bg_color": DOMAIN_HDR, "border": 1,
                                  "text_wrap": False}),
    }


def _col_width(col: str, series: pd.Series) -> int:
    """Calculate capped column width."""
    header_w = len(col.replace("_"," ").title()) + 2
    if col.lower() in WRAP_COLS:
        # For wrap columns, cap at MAX_COL_W — text wraps vertically
        data_w = min(int(series.astype(str).str.len().max() or 0) + 2, MAX_COL_W)
    else:
        data_w = min(int(series.astype(str).str.len().max() or 0) + 2, MAX_COL_W)
    return max(header_w, min(data_w, MAX_COL_W))


def _estimate_row_height(row_vals: list, col_names: list, col_widths: list) -> int:
    """Estimate row height in points based on longest wrapped cell."""
    max_lines = 1
    for val, col, w in zip(row_vals, col_names, col_widths):
        if col.lower() not in WRAP_COLS:
            continue
        s = str(val) if val and str(val).lower() != "nan" else ""
        if not s:
            continue
        # Estimate lines = ceil(len / col_width) + newlines
        lines = max(1, -(-len(s) // max(w, 1))) + s.count("\n")
        max_lines = max(max_lines, lines)
    return max(15, min(max_lines * 14, 150))


def _write_sheet(wb, ws, df: pd.DataFrame, fmts: dict,
                 severity_col: Optional[str] = None,
                 highlight_col: Optional[str] = None,
                 highlight_neg: Optional[str] = "NO"):
    """Write DataFrame to worksheet with wrapping, row heights, and colours."""
    if df is None or df.empty:
        ws.write(0, 0, "(no data)", fmts["norm"])
        return

    cols = list(df.columns)
    col_widths = [_col_width(c, df[c]) for c in cols]

    # Header
    ws.set_row(0, 20)
    for ci, (col, w) in enumerate(zip(cols, col_widths)):
        ws.set_column(ci, ci, w)
        ws.write(0, ci, col.replace("_"," ").title(), fmts["hdr"])

    # Freeze panes
    ws.freeze_panes(1, 0)
    ws.autofilter(0, 0, len(df), len(cols)-1)

    for ri, (_, row) in enumerate(df.iterrows(), start=1):
        sev = str(row.get(severity_col,"")).upper() if severity_col else ""
        hl  = str(row.get(highlight_col,"")) if highlight_col else ""
        src = str(row.get("comp_source","")).lower() if "comp_source" in df.columns else ""

        # Row format
        if sev == "ERROR":
            base = fmts["err"]
        elif sev == "WARNING":
            base = fmts["warn"]
        elif highlight_col and hl.startswith(highlight_neg):
            base = fmts["miss"]
        elif src == "inline":
            base = fmts["inline"]
        elif ri % 2 == 0:
            base = fmts["alt"]
        else:
            base = fmts["norm"]

        row_vals = [row.get(c,"") for c in cols]
        h = _estimate_row_height(row_vals, cols, col_widths)
        ws.set_row(ri, h)

        for ci, (col, val) in enumerate(zip(cols, row_vals)):
            v = "" if (val is None or (isinstance(val, float) and val != val)) else val
            if col.lower() in WRAP_COLS:
                # Use wrap format with same colour as base
                fmt = base
            else:
                fmt = base
            try:
                ws.write(ri, ci, str(v) if v != "" else "", fmt)
            except Exception:
                ws.write(ri, ci, str(v)[:32767], fmt)  # Excel cell limit


def export_validation_results(results: dict, spec_name: str = "") -> bytes:
    """Export full spec validation results to xlsx."""
    import xlsxwriter
    buf = io.BytesIO()
    with xlsxwriter.Workbook(buf, {"in_memory": True, "strings_to_urls": False}) as wb:
        fmts = _base_formats(wb)
        summary = results.get("summary", {})
        issues  = results.get("issues", pd.DataFrame())
        cl_chk  = results.get("codelist_check", pd.DataFrame())
        cm_chk  = results.get("compmethod_check", pd.DataFrame())
        sdtm_s  = results.get("sdtm_source", pd.DataFrame())

        # ── Summary sheet ──────────────────────────────────────────────
        ws = wb.add_worksheet("Summary")
        ws.set_column(0, 0, 30)
        ws.set_column(1, 1, 20)
        ws.write(0, 0, f"Spec Validation: {spec_name}", fmts["title"])
        for ri, (k, v) in enumerate(summary.items(), start=2):
            ws.write(ri, 0, k.replace("_"," ").title(), fmts["norm_nw"])
            ws.write(ri, 1, str(v), fmts["norm_nw"])

        # ── Issues sheet ────────────────────────────────────────────────
        ws2 = wb.add_worksheet("Issues")
        _write_sheet(wb, ws2, issues, fmts, severity_col="severity")

        # ── Issues by Domain ─────────────────────────────────────────────
        ws3 = wb.add_worksheet("Issues_ByDomain")
        if not issues.empty:
            ri_global = 1
            display_cols = [c for c in ["domain","variable","severity","check",
                             "description","suggestion","mapping_action","origin"]
                            if c in issues.columns]
            col_widths = [_col_width(c, issues[c]) for c in display_cols]
            for ci,(col,w) in enumerate(zip(display_cols,col_widths)):
                ws3.set_column(ci,ci,w)
                ws3.write(0,ci,col.replace("_"," ").title(),fmts["hdr"])
            ws3.freeze_panes(1,0)
            for dom, grp in issues.groupby("domain"):
                ws3.merge_range(ri_global,0,ri_global,len(display_cols)-1,
                                f"Domain: {dom}  ({len(grp)} issues)",fmts["dom_hdr"])
                ws3.set_row(ri_global,18)
                ri_global += 1
                for _,(_, row) in enumerate(grp.iterrows()):
                    sev = str(row.get("severity","")).upper()
                    base = fmts["err"] if sev=="ERROR" else fmts["warn"] if sev=="WARNING" else fmts["norm"]
                    rv = [row.get(c,"") for c in display_cols]
                    h = _estimate_row_height(rv, display_cols, col_widths)
                    ws3.set_row(ri_global, h)
                    for ci,(col,v) in enumerate(zip(display_cols,rv)):
                        ws3.write(ri_global,ci,str(v) if v else "",base)
                    ri_global += 1

        # ── Codelist sheet ───────────────────────────────────────────────
        ws4 = wb.add_worksheet("Codelist")
        _write_sheet(wb, ws4, cl_chk, fmts,
                     highlight_col="in_codelist_tab", highlight_neg="NO")

        # ── CompMethod sheet ─────────────────────────────────────────────
        ws5 = wb.add_worksheet("CompMethod")
        _write_sheet(wb, ws5, cm_chk.drop(columns=["algorithm_preview"],errors="ignore"), fmts,
                     highlight_col="in_computation_tab", highlight_neg="NO")

        # ── SDTM Source sheet ────────────────────────────────────────────
        if sdtm_s is not None and not sdtm_s.empty:
            ws6 = wb.add_worksheet("SDTMSource")
            _write_sheet(wb, ws6, sdtm_s, fmts,
                         highlight_col="in_sdtm_lib", highlight_neg="NO")

    buf.seek(0)
    return buf.read()


def export_coverage_results(coverage: pd.DataFrame, summary: pd.DataFrame) -> bytes:
    import xlsxwriter
    buf = io.BytesIO()
    with xlsxwriter.Workbook(buf, {"in_memory": True, "strings_to_urls": False}) as wb:
        fmts = _base_formats(wb)

        # Variable detail
        ws1 = wb.add_worksheet("Variable_Mapping")
        _write_sheet(wb, ws1, coverage, fmts,
                     highlight_col="status", highlight_neg="UNMAPPED")

        # Summary
        ws2 = wb.add_worksheet("Summary")
        _write_sheet(wb, ws2, summary, fmts)

    buf.seek(0)
    return buf.read()


def export_define_results(columns_df, value_level, where_clause) -> bytes:
    import xlsxwriter
    buf = io.BytesIO()
    with xlsxwriter.Workbook(buf, {"in_memory": True, "strings_to_urls": False}) as wb:
        fmts = _base_formats(wb)
        ws1 = wb.add_worksheet("Variable")
        _write_sheet(wb, ws1, columns_df, fmts)
        ws2 = wb.add_worksheet("ValueLevel")
        _write_sheet(wb, ws2, value_level, fmts)
        ws3 = wb.add_worksheet("WhereClause")
        _write_sheet(wb, ws3, where_clause, fmts)
    buf.seek(0)
    return buf.read()


def export_diff_results(diff_df: pd.DataFrame) -> bytes:
    import xlsxwriter
    buf = io.BytesIO()
    with xlsxwriter.Workbook(buf, {"in_memory": True, "strings_to_urls": False}) as wb:
        fmts = _base_formats(wb)
        ws = wb.add_worksheet("SpecDiff")
        _write_sheet(wb, ws, diff_df, fmts,
                     highlight_col="status", highlight_neg="CHANGED")
    buf.seek(0)
    return buf.read()
