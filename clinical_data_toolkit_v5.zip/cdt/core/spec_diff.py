import warnings
warnings.filterwarnings("ignore")
# core/spec_diff.py
"""
Spec diff: compare two mapping spec Excel files variable by variable.
Ports read_spec_616_adam.sas - replaces PROC COMPARE with structured pandas diff.
"""

import logging
from typing import Dict, List, Optional

import pandas as pd

log = logging.getLogger(__name__)

COMPARE_FIELDS = [
    "label", "origin", "data_type", "codelist",
    "compmethod_id", "gilead_core", "mapping_action",
]

STATUS_SAME = "SAME"
STATUS_CHANGED = "CHANGED"
STATUS_ONLY_A = "ONLY_IN_A"
STATUS_ONLY_B = "ONLY_IN_B"


def compare_specs(
    spec_a: Dict[str, pd.DataFrame],
    spec_b: Dict[str, pd.DataFrame],
    label_a: str = "Spec A",
    label_b: str = "Spec B",
    compare_fields: Optional[List[str]] = None,
) -> pd.DataFrame:
    """
    Compare two specs domain by domain, variable by variable.

    Returns a DataFrame with columns:
        dataset, variable, field, value_in_a, value_in_b, status
    """
    fields = compare_fields or COMPARE_FIELDS

    # Identify all domains present in either spec (excluding reference sheets)
    ref_sheets_lower = {"toc", "codelist", "computation", "standard", "ig"}
    domains_a = {k for k in spec_a if k.lower() not in ref_sheets_lower}
    domains_b = {k for k in spec_b if k.lower() not in ref_sheets_lower}
    all_domains = domains_a | domains_b

    rows = []
    for dom in sorted(all_domains):
        df_a = spec_a.get(dom, pd.DataFrame())
        df_b = spec_b.get(dom, pd.DataFrame())

        if df_a.empty and not df_b.empty:
            for _, row in df_b.iterrows():
                var = str(row.get("variable", "")).strip()
                if var:
                    rows.append({
                        "dataset": dom, "variable": var,
                        "field": "(all)",
                        "value_in_a": "",
                        "value_in_b": "(present)",
                        "status": STATUS_ONLY_B,
                    })
            continue

        if not df_a.empty and df_b.empty:
            for _, row in df_a.iterrows():
                var = str(row.get("variable", "")).strip()
                if var:
                    rows.append({
                        "dataset": dom, "variable": var,
                        "field": "(all)",
                        "value_in_a": "(present)",
                        "value_in_b": "",
                        "status": STATUS_ONLY_A,
                    })
            continue

        if df_a.empty and df_b.empty:
            continue

        # Ensure variable column exists
        if "variable" not in df_a.columns or "variable" not in df_b.columns:
            continue

        vars_a = set(df_a["variable"].str.strip())
        vars_b = set(df_b["variable"].str.strip())
        all_vars = vars_a | vars_b

        for var in sorted(all_vars):
            row_a = df_a[df_a["variable"].str.strip() == var]
            row_b = df_b[df_b["variable"].str.strip() == var]

            if row_a.empty and not row_b.empty:
                rows.append({
                    "dataset": dom, "variable": var,
                    "field": "(all)",
                    "value_in_a": "",
                    "value_in_b": "(present)",
                    "status": STATUS_ONLY_B,
                })
                continue

            if not row_a.empty and row_b.empty:
                rows.append({
                    "dataset": dom, "variable": var,
                    "field": "(all)",
                    "value_in_a": "(present)",
                    "value_in_b": "",
                    "status": STATUS_ONLY_A,
                })
                continue

            # Compare field by field
            r_a = row_a.iloc[0]
            r_b = row_b.iloc[0]
            any_diff = False

            for field in fields:
                val_a = str(r_a.get(field, "")).strip() if field in r_a.index else ""
                val_b = str(r_b.get(field, "")).strip() if field in r_b.index else ""
                if val_a != val_b:
                    any_diff = True
                    rows.append({
                        "dataset": dom,
                        "variable": var,
                        "field": field,
                        "value_in_a": val_a,
                        "value_in_b": val_b,
                        "status": STATUS_CHANGED,
                    })

            if not any_diff:
                rows.append({
                    "dataset": dom, "variable": var,
                    "field": "(all checked fields)",
                    "value_in_a": "(same)",
                    "value_in_b": "(same)",
                    "status": STATUS_SAME,
                })

    if not rows:
        return pd.DataFrame(
            columns=["dataset", "variable", "field", "value_in_a", "value_in_b", "status"]
        )

    result = pd.DataFrame(rows)
    status_order = {STATUS_ONLY_B: 0, STATUS_ONLY_A: 1, STATUS_CHANGED: 2, STATUS_SAME: 3}
    result["_ord"] = result["status"].map(status_order)
    result = result.sort_values(["_ord", "dataset", "variable"]).drop(
        columns=["_ord"]
    ).reset_index(drop=True)
    return result


def diff_summary(diff_df: pd.DataFrame) -> dict:
    """Build a count summary from a diff DataFrame."""
    if diff_df.empty:
        return {"same": 0, "changed": 0, "only_a": 0, "only_b": 0, "total": 0}
    vc = diff_df["status"].value_counts()
    return {
        "same":    int(vc.get(STATUS_SAME, 0)),
        "changed": int(vc.get(STATUS_CHANGED, 0)),
        "only_a":  int(vc.get(STATUS_ONLY_A, 0)),
        "only_b":  int(vc.get(STATUS_ONLY_B, 0)),
        "total":   len(diff_df),
    }
