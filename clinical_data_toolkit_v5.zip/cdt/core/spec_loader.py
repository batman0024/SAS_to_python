import warnings
warnings.filterwarnings("ignore")
# core/spec_loader.py
"""
Spec loader: reads an Excel mapping specification into a dict of DataFrames.
All sheet column names are normalised to lowercase, stripped strings.
Handles both SDTM and ADaM specs transparently.
"""

import io
import logging
from typing import Dict, Optional

import pandas as pd

log = logging.getLogger(__name__)

KNOWN_REF_SHEETS = {"toc", "codelist", "computation", "standard", "ig"}
EXCLUDE_DOMAINS = {"TA", "TE", "TI", "TV", "TS", "TD", "TM"}


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Lowercase, strip whitespace from all column names."""
    df = df.copy()
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    return df


def load_spec(path: str) -> Dict[str, pd.DataFrame]:
    """Load spec from a file path."""
    with open(path, "rb") as fh:
        return load_spec_from_bytes(fh.read())


def load_spec_from_bytes(data: bytes) -> Dict[str, pd.DataFrame]:
    """
    Load all sheets from a spec Excel file (as bytes).
    Returns dict of {sheet_name: DataFrame} with normalised column names.
    """
    buf = io.BytesIO(data)
    try:
        raw = pd.read_excel(buf, sheet_name=None, engine="openpyxl",
                            dtype=str)
    except Exception as exc:
        raise ValueError(f"Cannot read spec Excel: {exc}") from exc

    result = {}
    for sheet, df in raw.items():
        df = _normalise_columns(df)
        # Replace pandas NA with empty string for string columns
        df = df.fillna("")
        result[sheet] = df
        log.debug("Loaded sheet '%s': %d rows, %d cols", sheet, len(df), len(df.columns))

    return result


def get_toc(spec: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Return the TOC sheet, trying both 'toc' and 'TOC' keys."""
    for key in ("toc", "TOC"):
        if key in spec:
            return spec[key]
    # Try case-insensitive match
    for key, df in spec.items():
        if key.strip().lower() == "toc":
            return df
    raise KeyError("No 'toc' sheet found in spec.")


def get_active_domains(
    spec: Dict[str, pd.DataFrame],
    active_filter: str = "Y",
    explicit_datasets: Optional[list] = None,
) -> list:
    """
    Return list of active domain names from the TOC sheet.
    If explicit_datasets provided, use those instead of the active filter.
    Always excludes TA/TE/TI/TV/TS/TD/TM.
    """
    toc = get_toc(spec)

    if explicit_datasets:
        domains = [d.strip().upper() for d in explicit_datasets if d.strip()]
        return [d for d in domains if d not in EXCLUDE_DOMAINS]

    if "dataset" not in toc.columns:
        raise ValueError("TOC sheet has no 'dataset' column.")

    if "active" in toc.columns:
        mask = toc["active"].str.strip().str.upper() == active_filter.strip().upper()
        active_toc = toc[mask]
    else:
        log.warning("TOC has no 'active' column; treating all rows as active.")
        active_toc = toc

    domains = active_toc["dataset"].dropna().str.strip().str.upper().tolist()
    return [d for d in domains if d not in EXCLUDE_DOMAINS and d != ""]


def get_spec_metadata(spec: Dict[str, pd.DataFrame]) -> dict:
    """
    Extract IG version, CT version, study name, and other metadata from spec.

    Reads from (in priority order):
    1. 'Study' or 'Standard' sheet in the spec
    2. TOC sheet columns (ig_version, ct_version)
    3. Codelist tab Standard column (for CT version used in the spec)

    Returns dict with keys:
        ig_version, ct_version, study_name, spec_type (SDTM/ADAM),
        ct_from_codelist (list of unique Standard values from Codelist tab)
    """
    meta = {
        "ig_version": "",
        "ct_version": "",
        "study_name": "",
        "spec_type": "",
        "ct_from_codelist": [],
    }

    # 1. Try 'Study' or 'Standard' sheet
    for sheet_name in ("Study", "study", "Standard", "standard", "IG", "ig"):
        if sheet_name in spec:
            df = spec[sheet_name]
            df_norm = df.copy()
            df_norm.columns = [c.strip().lower().replace(" ", "_") for c in df_norm.columns]
            # Look for key-value style (col A = key, col B = value)
            if len(df_norm.columns) >= 2:
                for _, row in df_norm.iterrows():
                    k = str(row.iloc[0]).strip().lower()
                    v = str(row.iloc[1]).strip() if len(row) > 1 else ""
                    if any(x in k for x in ("ig_ver", "ig ver", "sdtmig", "adamig", "version")):
                        if not meta["ig_version"] and v and v.lower() != "nan":
                            meta["ig_version"] = v
                    if any(x in k for x in ("ct_ver", "ct ver", "terminology", "cdisc ct")):
                        if not meta["ct_version"] and v and v.lower() != "nan":
                            meta["ct_version"] = v
                    if any(x in k for x in ("study", "protocol", "project")):
                        if not meta["study_name"] and v and v.lower() != "nan":
                            meta["study_name"] = v
            break

    # 2. Check TOC columns for version info
    if not (meta["ig_version"] and meta["ct_version"]):
        try:
            toc = get_toc(spec)
            for col in toc.columns:
                low = col.lower()
                if "ig" in low and "ver" in low and not meta["ig_version"]:
                    vals = toc[col].dropna().unique()
                    if len(vals):
                        meta["ig_version"] = str(vals[0]).strip()
                if "ct" in low and "ver" in low and not meta["ct_version"]:
                    vals = toc[col].dropna().unique()
                    if len(vals):
                        meta["ct_version"] = str(vals[0]).strip()
        except Exception:
            pass

    # 3. Read CT standards from Codelist tab (Standard column)
    for key in spec:
        if key.strip().lower() == "codelist":
            cl_df = spec[key].copy()
            cl_df.columns = [c.strip().lower().replace(" ", "_") for c in cl_df.columns]
            std_col = next(
                (c for c in cl_df.columns if "standard" in c and "codelist" not in c),
                None
            )
            if std_col:
                unique_stds = [
                    s for s in cl_df[std_col].dropna().unique()
                    if str(s).strip() and str(s).strip().lower() != "nan"
                ]
                meta["ct_from_codelist"] = sorted(set(unique_stds))
                # If no CT version found yet, infer from most common standard
                if not meta["ct_version"] and unique_stds:
                    from collections import Counter
                    most_common = Counter(unique_stds).most_common(1)[0][0]
                    meta["ct_version"] = most_common
            break

    # 4. Infer spec type from domain names
    try:
        domains = get_active_domains(spec)
        adam_count = sum(1 for d in domains if d.startswith("AD"))
        meta["spec_type"] = "ADaM" if adam_count > len(domains) / 2 else "SDTM"
    except Exception:
        pass

    return meta
