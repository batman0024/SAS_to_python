# core/ui_styles.py
"""
Shared dark-mode compatible CSS for all pages.
Uses ONLY opaque colours with explicit text colours — no rgba backgrounds
that become invisible in Streamlit dark theme.
"""

# Colour palette — works on dark AND light backgrounds
COLOURS = {
    "error":   {"bg": "#7F1D1D", "text": "#FECACA", "border": "#EF4444"},   # dark red
    "warning": {"bg": "#78350F", "text": "#FEF3C7", "border": "#F59E0B"},   # dark amber
    "pass":    {"bg": "#14532D", "text": "#BBF7D0", "border": "#22C55E"},   # dark green
    "info":    {"bg": "#1E3A5F", "text": "#BFDBFE", "border": "#3B82F6"},   # dark blue
    "exact":   {"bg": "#14532D", "text": "#BBF7D0", "border": "#22C55E"},
    "partial": {"bg": "#78350F", "text": "#FEF3C7", "border": "#F59E0B"},
    "unmapped":{"bg": "#7F1D1D", "text": "#FECACA", "border": "#EF4444"},
    "dt":      {"bg": "#1E3A5F", "text": "#BFDBFE", "border": "#3B82F6"},   # datetime passthrough
    "changed": {"bg": "#78350F", "text": "#FEF3C7", "border": "#F59E0B"},
    "only_a":  {"bg": "#7F1D1D", "text": "#FECACA", "border": "#EF4444"},
    "only_b":  {"bg": "#1E3A5F", "text": "#BFDBFE", "border": "#3B82F6"},
}

SHARED_CSS = """
<style>
/* ── Base table ────────────────────────────────────────────────────── */
.cdt-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    font-family: 'Segoe UI', system-ui, sans-serif;
    table-layout: fixed;
}
.cdt-table th {
    background: #0F172A;
    color: #F1F5F9;
    padding: 9px 12px;
    text-align: left;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .05em;
    text-transform: uppercase;
    position: sticky;
    top: 0;
    z-index: 2;
    white-space: nowrap;
    border-bottom: 2px solid #334155;
}
.cdt-table td {
    padding: 7px 12px;
    border-bottom: 1px solid #1E293B;
    vertical-align: top;
    word-break: break-word;
    overflow-wrap: break-word;
    color: #E2E8F0;
}
/* Row styles */
.cdt-table tr.row-error   td { background: #7F1D1D; color: #FECACA; }
.cdt-table tr.row-warning td { background: #78350F; color: #FEF3C7; }
.cdt-table tr.row-pass    td { background: #14532D; color: #BBF7D0; }
.cdt-table tr.row-info    td { background: #1E3A5F; color: #BFDBFE; }
.cdt-table tr.row-exact   td { background: #14532D; color: #BBF7D0; }
.cdt-table tr.row-partial td { background: #78350F; color: #FEF3C7; }
.cdt-table tr.row-unmapped td{ background: #7F1D1D; color: #FECACA; }
.cdt-table tr.row-changed td { background: #78350F; color: #FEF3C7; }
.cdt-table tr.row-only_a  td { background: #7F1D1D; color: #FECACA; }
.cdt-table tr.row-only_b  td { background: #1E3A5F; color: #BFDBFE; }
.cdt-table tr.row-dt      td { background: #1E3A5F; color: #BFDBFE; }
.cdt-table tr.row-even    td { background: #1E293B; color: #E2E8F0; }
.cdt-table tr.row-odd     td { background: #0F172A; color: #E2E8F0; }
.cdt-table tr:hover td { filter: brightness(1.15); }

/* Mono columns */
.cdt-table .mono { font-family: 'Courier New', monospace; font-size: 12px; }

/* Badge pills */
.badge {
    display: inline-block;
    padding: 2px 9px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .04em;
    white-space: nowrap;
}
.badge-error   { background: #7F1D1D; color: #FECACA; border: 1px solid #EF4444; }
.badge-warning { background: #78350F; color: #FEF3C7; border: 1px solid #F59E0B; }
.badge-pass    { background: #14532D; color: #BBF7D0; border: 1px solid #22C55E; }
.badge-info    { background: #1E3A5F; color: #BFDBFE; border: 1px solid #3B82F6; }
.badge-exact   { background: #14532D; color: #BBF7D0; border: 1px solid #22C55E; }
.badge-partial { background: #78350F; color: #FEF3C7; border: 1px solid #F59E0B; }
.badge-unmapped{ background: #7F1D1D; color: #FECACA; border: 1px solid #EF4444; }

/* Scrollable table container */
.cdt-scroll {
    max-height: 480px;
    overflow-y: auto;
    overflow-x: auto;
    border: 1px solid #334155;
    border-radius: 8px;
}

/* Legend row */
.legend-row {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    align-items: center;
    margin: 6px 0;
    font-size: 12px;
}
.legend-item {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}
.legend-error   { background: #7F1D1D; color: #FECACA; border: 1px solid #EF4444; }
.legend-warning { background: #78350F; color: #FEF3C7; border: 1px solid #F59E0B; }
.legend-pass    { background: #14532D; color: #BBF7D0; border: 1px solid #22C55E; }
.legend-info    { background: #1E3A5F; color: #BFDBFE; border: 1px solid #3B82F6; }
.legend-exact   { background: #14532D; color: #BBF7D0; }
.legend-partial { background: #78350F; color: #FEF3C7; }
.legend-unmapped{ background: #7F1D1D; color: #FECACA; }
.legend-dt      { background: #1E3A5F; color: #BFDBFE; }
</style>
"""


def render_table(
    df,
    row_class_fn=None,
    badge_cols: dict = None,
    mono_cols: list = None,
    max_rows: int = 1000,
    footer_msg: str = "",
) -> str:
    """
    Render a DataFrame as a dark-mode–compatible HTML table.

    row_class_fn: callable(row_dict) -> str class suffix (error/warning/pass/exact/...)
    badge_cols: {col_name: fn(val)->badge_class_suffix}
    mono_cols: list of column names to render in monospace
    """
    cols = list(df.columns)
    hdr  = "".join(f'<th style="width:{100//max(len(cols),1)}%">{c.replace("_"," ").title()}</th>' for c in cols)
    rows_html = []
    for i, (_, row) in enumerate(df.head(max_rows).iterrows()):
        # Determine row class
        if row_class_fn:
            cls = row_class_fn(row.to_dict())
        else:
            cls = "even" if i % 2 == 0 else "odd"

        cells = []
        for col in cols:
            val = row.get(col, "")
            if hasattr(val, "item"):
                val = val.item()
            val_str = "" if (val != val or val is None) else str(val)

            if badge_cols and col in badge_cols:
                bc = badge_cols[col](val_str)
                cell = f'<td><span class="badge badge-{bc}">{val_str}</span></td>'
            elif mono_cols and col in mono_cols:
                cell = f'<td class="mono">{val_str}</td>'
            else:
                cell = f"<td>{val_str}</td>"
            cells.append(cell)

        rows_html.append(f'<tr class="row-{cls}">{"".join(cells)}</tr>')

    if len(df) > max_rows or footer_msg:
        msg = footer_msg or f"Showing {max_rows} of {len(df)} rows — download Excel for full list"
        rows_html.append(
            f'<tr class="row-odd"><td colspan="{len(cols)}" '
            f'style="text-align:center;padding:10px;font-style:italic;">{msg}</td></tr>'
        )

    return (
        f'{SHARED_CSS}'
        f'<div class="cdt-scroll">'
        f'<table class="cdt-table"><thead><tr>{hdr}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table></div>'
    )
