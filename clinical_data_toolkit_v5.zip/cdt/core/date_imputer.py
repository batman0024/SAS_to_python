# core/date_imputer.py
"""
AE date imputation - Python port of impute_ae_dates.sas.

KEY DESIGN DECISIONS based on code review:
1. When the date string has length > 10 (i.e. includes a time component,
   e.g. '2023-04-12T08:30:00'), the original SAS macro had a hardcoded
   end-block patch that parsed the date/time directly without imputation.
   This behaviour is intentional per the SAP: if the date is complete
   with time, parse it as-is and skip the imputation logic entirely.
   This is now a clean toggle: skip_if_has_time=True (default).

2. Imputation rules (from SAP):
   Rule 0: Full date (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS) - use as-is
   Rule 1: Partial YYYY-MM, same month/year as TRTSDT, not pre-treatment - use TRTSDT
   Rule 2: Partial YYYY-MM, different month or pre-treatment - use 1st of month
   Rule 3: Year only YYYY, same year as TRTSDT, not pre-treatment - use TRTSDT
   Rule 4: Year only YYYY, different year or pre-treatment - use Jan 1 of year
   Rule 5: Date missing entirely - use TRTSDT (or Jan 1 of stop-year if pre-treatment)

3. ASTDTF / AENDTF flags per CDISC ADaM IG:
   '' = no imputation (full date or datetime)
   'D' = day imputed
   'M' = month imputed
   'Y' = year imputed (or date fully missing)
"""

import re
import logging
from typing import Optional, Tuple

import pandas as pd
import numpy as np

log = logging.getLogger(__name__)

# Compiled patterns
_ISO_FULL = re.compile(r"^(\d{4})-(\d{2})-(\d{2})")
_ISO_YM = re.compile(r"^(\d{4})-(\d{2})$")
_ISO_Y = re.compile(r"^(\d{4})$")
_HAS_TIME = re.compile(r"^\d{4}-\d{2}-\d{2}T")

RULE_LABELS = {
    0: "Full date - used as-is",
    1: "Partial - same period as first dose - used first dose date",
    2: "Partial YYYY-MM - used 1st of month",
    3: "Year only - different year - used Jan 1",
    4: "Start missing + pre-treatment stop - used Jan 1 of stop year",
    5: "Start missing - used first dose date",
    -1: "Not processed (datetime with time component - kept as-is)",
}


def _parse_iso_date(s: str) -> Tuple[str, Optional[pd.Timestamp],
                                     Optional[pd.Timestamp],
                                     Optional[int], Optional[int]]:
    """
    Parse an ISO date string.
    Returns: (level, min_date, max_date, year, month)
    level: 'FULL' | 'YM' | 'Y' | 'MISS' | 'DATETIME'
    """
    s = str(s).strip() if s else ""
    if not s or s.upper() in ("", ".", "NAN"):
        return ("MISS", None, None, None, None)

    # Datetime with time component - flag separately
    if _HAS_TIME.match(s):
        try:
            dt = pd.Timestamp(s[:10])
            return ("DATETIME", dt, dt, dt.year, dt.month)
        except Exception:
            return ("MISS", None, None, None, None)

    m = _ISO_FULL.match(s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            dt = pd.Timestamp(year=y, month=mo, day=d)
            return ("FULL", dt, dt, y, mo)
        except Exception:
            return ("MISS", None, None, None, None)

    m = _ISO_YM.match(s)
    if m:
        y, mo = int(m.group(1)), int(m.group(2))
        try:
            mn = pd.Timestamp(year=y, month=mo, day=1)
            mx = mn + pd.offsets.MonthEnd(0)
            return ("YM", mn, mx, y, mo)
        except Exception:
            return ("MISS", None, None, None, None)

    m = _ISO_Y.match(s)
    if m:
        y = int(m.group(1))
        try:
            return ("Y",
                    pd.Timestamp(year=y, month=1, day=1),
                    pd.Timestamp(year=y, month=12, day=31),
                    y, None)
        except Exception:
            return ("MISS", None, None, None, None)

    return ("MISS", None, None, None, None)


def impute_ae_dates(
    df: pd.DataFrame,
    startc: str = "AESTDTC",
    stopc: str = "AEENDTC",
    trtsdt: str = "TRTSDT",
    prefix: str = "AE",
    skip_if_has_time: bool = True,
) -> pd.DataFrame:
    """
    Impute partial/missing AE dates.

    Parameters
    ----------
    df               : Input DataFrame (AE dataset)
    startc           : Character start date column name
    stopc            : Character stop date column name
    trtsdt           : Numeric (or date-like) first dose date column
    prefix           : Prefix for output columns
    skip_if_has_time : If True (default), records where startc contains a
                       time component (YYYY-MM-DDTHH:MM:SS) are passed
                       through without imputation. ASTDT/ASTDTM are set
                       directly from the datetime string.
                       This preserves the intended behaviour of the
                       SAS macro's end-block patch.

    Returns
    -------
    DataFrame with added columns:
        ASTDT, ASTDTC, ASTTM, ASTDTM, ASTDTF
        AENDT, AENDTC, AENTM, AENDTM, AENDTF
        {prefix}_START_RULE, {prefix}_STOP_IMPFL, {prefix}_STOP_ONGOING
        {prefix}_REL_STOP_TO_TRT
    """
    missing_cols = [c for c in [startc, stopc, trtsdt] if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")

    out = df.copy()
    p = prefix

    # Initialise output columns
    for col in ["ASTDT", "AENDT"]:
        out[col] = pd.NaT
    for col in ["ASTDTC", "AENDTC", "ASTDTF", "AENDTF"]:
        out[col] = ""
    for col in ["ASTTM", "AENTM", "ASTDTM", "AENDTM"]:
        out[col] = pd.NaT
    out[f"{p}_START_RULE"] = np.nan
    out[f"{p}_STOP_IMPFL"] = ""
    out[f"{p}_STOP_ONGOING"] = ""
    out[f"{p}_REL_STOP_TO_TRT"] = "MISS"

    for idx, row in out.iterrows():
        # Parse treatment start date
        trt_raw = row[trtsdt]
        if pd.isna(trt_raw) or str(trt_raw).strip() in ("", ".", "NaN"):
            trt_dt = None
        else:
            try:
                trt_dt = pd.Timestamp(trt_raw)
            except Exception:
                trt_dt = None

        start_raw = str(row[startc]).strip() if pd.notna(row[startc]) else ""
        stop_raw = str(row[stopc]).strip() if pd.notna(row[stopc]) else ""

        # --- DATETIME PASSTHROUGH (skip_if_has_time) ---
        # When the raw start DTC contains a full datetime string (>10 chars),
        # parse directly and skip imputation. This matches the SAS patch intent.
        if skip_if_has_time and _HAS_TIME.match(start_raw):
            try:
                ts = pd.Timestamp(start_raw)
                out.at[idx, "ASTDT"] = ts.normalize()
                out.at[idx, "ASTDTC"] = ts.strftime("%Y-%m-%d")
                out.at[idx, "ASTTM"] = ts
                out.at[idx, "ASTDTM"] = ts
                out.at[idx, "ASTDTF"] = ""
                out.at[idx, f"{p}_START_RULE"] = -1
            except Exception:
                pass

            if skip_if_has_time and _HAS_TIME.match(stop_raw):
                try:
                    ts = pd.Timestamp(stop_raw)
                    out.at[idx, "AENDT"] = ts.normalize()
                    out.at[idx, "AENDTC"] = ts.strftime("%Y-%m-%d")
                    out.at[idx, "AENTM"] = ts
                    out.at[idx, "AENDTM"] = ts
                    out.at[idx, "AENDTF"] = ""
                except Exception:
                    pass
            continue

        # --- NORMAL IMPUTATION PATH ---
        s_lev, s_min, s_max, s_y, s_m = _parse_iso_date(start_raw)
        e_lev, e_min, e_max, e_y, e_m = _parse_iso_date(stop_raw)

        # STOP imputation
        if e_lev in ("FULL", "DATETIME"):
            out.at[idx, f"{p}_STOP_IMPFL"] = ""
            out.at[idx, f"{p}_STOP_ONGOING"] = ""
            out.at[idx, "AENDT"] = e_min
            out.at[idx, "AENDTC"] = e_min.strftime("%Y-%m-%d") if e_min else ""
            out.at[idx, "AENDTF"] = ""
        elif e_lev == "YM":
            out.at[idx, f"{p}_STOP_IMPFL"] = "M"
            out.at[idx, "AENDT"] = e_max
            out.at[idx, "AENDTC"] = e_max.strftime("%Y-%m-%d") if e_max else ""
            out.at[idx, "AENDTF"] = "D"
        elif e_lev == "Y":
            d = pd.Timestamp(year=e_y, month=12, day=31)
            out.at[idx, f"{p}_STOP_IMPFL"] = "Y"
            out.at[idx, "AENDT"] = d
            out.at[idx, "AENDTC"] = d.strftime("%Y-%m-%d")
            out.at[idx, "AENDTF"] = "M"
        else:
            out.at[idx, f"{p}_STOP_ONGOING"] = "Y"

        # STOP relation to treatment
        rel = "MISS"
        if trt_dt is not None and e_lev not in ("MISS",):
            if e_max is not None and e_max < trt_dt:
                rel = "LT"
            elif e_min is not None and e_min >= trt_dt:
                rel = "GE"
            else:
                rel = "AMB"
        out.at[idx, f"{p}_REL_STOP_TO_TRT"] = rel

        # START imputation
        same_y = (
            s_lev in ("Y", "YM", "FULL")
            and trt_dt is not None
            and s_y == trt_dt.year
        )
        same_ym = (
            s_lev in ("YM", "FULL")
            and trt_dt is not None
            and s_y == trt_dt.year
            and s_m == trt_dt.month
        )

        if s_lev in ("FULL", "DATETIME"):
            out.at[idx, "ASTDT"] = s_min
            out.at[idx, "ASTDTC"] = s_min.strftime("%Y-%m-%d") if s_min else ""
            out.at[idx, "ASTDTF"] = ""
            out.at[idx, f"{p}_START_RULE"] = 0

        elif s_lev == "YM":
            if trt_dt is not None and same_ym and rel != "LT":
                out.at[idx, "ASTDT"] = trt_dt
                out.at[idx, f"{p}_START_RULE"] = 1
                out.at[idx, "ASTDTF"] = "D"
            else:
                d = pd.Timestamp(year=s_y, month=s_m, day=1)
                out.at[idx, "ASTDT"] = d
                out.at[idx, f"{p}_START_RULE"] = 2
                out.at[idx, "ASTDTF"] = "D"
            out.at[idx, "ASTDTC"] = out.at[idx, "ASTDT"].strftime("%Y-%m-%d")

        elif s_lev == "Y":
            if trt_dt is not None and same_y and rel != "LT":
                out.at[idx, "ASTDT"] = trt_dt
                out.at[idx, f"{p}_START_RULE"] = 1
                out.at[idx, "ASTDTF"] = "M"
            else:
                d = pd.Timestamp(year=s_y, month=1, day=1)
                out.at[idx, "ASTDT"] = d
                out.at[idx, f"{p}_START_RULE"] = 3
                out.at[idx, "ASTDTF"] = "M"
            out.at[idx, "ASTDTC"] = out.at[idx, "ASTDT"].strftime("%Y-%m-%d")

        else:  # MISS
            if trt_dt is not None:
                if rel == "LT" and e_y is not None:
                    d = pd.Timestamp(year=e_y, month=1, day=1)
                    out.at[idx, "ASTDT"] = d
                    out.at[idx, f"{p}_START_RULE"] = 4
                else:
                    out.at[idx, "ASTDT"] = trt_dt
                    out.at[idx, f"{p}_START_RULE"] = 5
                out.at[idx, "ASTDTF"] = "Y"
                out.at[idx, "ASTDTC"] = out.at[idx, "ASTDT"].strftime("%Y-%m-%d")
            elif e_y is not None:
                d = pd.Timestamp(year=e_y, month=1, day=1)
                out.at[idx, "ASTDT"] = d
                out.at[idx, f"{p}_START_RULE"] = 4
                out.at[idx, "ASTDTF"] = "Y"
                out.at[idx, "ASTDTC"] = d.strftime("%Y-%m-%d")

        # Clear stop DTC if ongoing
        if out.at[idx, f"{p}_STOP_ONGOING"] == "Y":
            out.at[idx, "AENDTC"] = ""
            out.at[idx, "AENDT"] = pd.NaT

    return out


def build_imputation_summary(result: pd.DataFrame, prefix: str = "AE") -> dict:
    """Build summary counts per imputation rule."""
    col = f"{prefix}_START_RULE"
    if col not in result.columns:
        return {}
    counts = result[col].value_counts().to_dict()
    summary = {}
    for rule, label in RULE_LABELS.items():
        summary[label] = int(counts.get(rule, 0))
    return summary
