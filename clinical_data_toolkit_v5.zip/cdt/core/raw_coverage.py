# core/raw_coverage.py
"""
Raw variable coverage checker.

Enhancements vs v2:
- Validates at raw.DATASET.VARIABLE level (not just variable name)
- SUPP prefix logic: if spec domain column contains QNAM, map to SUPP<domain>
- Builds a Raw-to-SDTM domain mapping overview table
- Works from in-memory bytes dict (passed from session_state, no temp dirs needed)
"""

import io
import logging
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Set

import pandas as pd

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)
log.setLevel(logging.ERROR)

from core.spec_loader import get_active_domains

DEFAULT_EXCLUDE_VARS: Set[str] = {
    "RECORDPOSITION","INSTANCEID","INSTANCEID_NSV","INSTANCENAME_NSV",
    "INSTANCEREPEATNUMBER","INSTANCEREPEATNUMBER_NSV","MATRIX",
    "MAXUPDATED","MAXUPDATED_NSV","MINCREATED","MINCREATED_NSV",
    "PAGEREPEATNUMBER_NSV","Z_AGEU","Z_AGEU_STD","Z_AGE_REP",
    "Z_AGE_REP_RAW","Z_SUBID","DATAPAGENAME","FOLDERNAME","FOLDER",
    "X_SUBJID","SUBJID","STUDYID","RECORDID","SUBJECTID",
    "DLASTMOD","INVID","SCRNID","DATAPAGEID","PAGEREPEATNUMBER",
    "PROJECT","QUERY","STUDYENVSITENUMBER",
}


def _resolve_sdtm_domain(domain_col_val: str, variable_col_val: str) -> str:
    """
    Resolve the SDTM target domain for a spec row.
    If the spec's 'dataset' column contains QNAM (or starts with SUPP),
    the variable maps to a SUPP domain (SUPP + first 2 chars of domain or parent domain).
    Otherwise use the domain value directly.

    Image 1 shows rows where Dataset=QNAM — these map to SUPP<parent>.
    E.g. raw.pkmerge.cohort -> spec domain=QNAM -> SUPPPC (SUPP + PC parent).
    """
    d = str(domain_col_val).strip().upper()
    v = str(variable_col_val).strip().upper()

    # If dataset column literally says QNAM, the actual domain must be inferred
    # from the sheet name (passed separately). Return as-is — caller handles.
    return d


def collect_raw_vars_from_store(
    raw_store: Dict[str, bytes],
    exclude_vars: Optional[Set[str]] = None,
) -> pd.DataFrame:
    """
    Build variable inventory from in-memory dict of {filename: bytes}.
    Handles both .sas7bdat and .csv files.
    Returns: raw_dataset, raw_variable
    """
    excl_vars = {v.upper() for v in ((exclude_vars or set()) | DEFAULT_EXCLUDE_VARS)}
    rows = []
    for fname, fdata in raw_store.items():
        ds = Path(fname).stem.upper()
        fl = fname.lower()
        if fl.endswith(".sas7bdat"):
            try:
                import pyreadstat
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), metadataonly=True)
                col_names = getattr(meta, "column_names", []) or []
                for col in col_names:
                    if col.upper() not in excl_vars:
                        rows.append({"raw_dataset": ds, "raw_variable": col.upper()})
            except Exception as exc:
                log.debug("Cannot read %s: %s", fname, exc)
        elif fl.endswith(".csv"):
            try:
                tmp = pd.read_csv(io.BytesIO(fdata), nrows=0)
                for col in tmp.columns:
                    if col.upper() not in excl_vars:
                        rows.append({"raw_dataset": ds, "raw_variable": col.upper()})
            except Exception as exc:
                log.debug("Cannot read CSV %s: %s", fname, exc)
    return pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)


def collect_spec_input_refs_enhanced(
    spec: Dict[str, pd.DataFrame],
    active_filter: str = "Y",
) -> pd.DataFrame:
    """
    Parse INPUT_VARIABLES column from all active domain sheets.
    Extracts RAW.DATASET.VARIABLE triplets.
    Also resolves SUPP domain logic when dataset/QNAM indicator is present.

    Returns columns:
        sheet_domain    - the spec sheet name (e.g. PC)
        sdtm_domain     - resolved SDTM target domain (SUPPPC if QNAM, else sheet_domain)
        sdtm_variable   - the SDTM variable name
        raw_dataset     - the raw dataset name (middle part of RAW.X.Y)
        raw_variable    - the raw variable name (last part of RAW.X.Y)
        raw_triplet     - full RAW.DATASET.VARIABLE string for exact matching
        mapping_action  - DROP/ASSIGN/etc
    """
    domains = get_active_domains(spec, active_filter)
    rows = []
    for sheet_dom in domains:
        if sheet_dom not in spec:
            continue
        df = spec[sheet_dom]
        if "input_variables" not in df.columns or "variable" not in df.columns:
            continue

        # Detect if this sheet uses QNAM (SUPP domain pattern)
        # Image 1: Dataset column has values like "QNAM" meaning these are SUPP vars
        dataset_col = df.get("dataset", pd.Series(dtype=str)) if "dataset" in df.columns else None

        for _, row in df.iterrows():
            inp      = str(row.get("input_variables", "")).strip()
            sdtm_var = str(row.get("variable", "")).strip().upper()
            ma       = str(row.get("mapping_action", "")).strip().upper()
            if not inp:
                continue

            # Resolve SDTM domain — if dataset col says QNAM, target is SUPP+sheet_dom[:2]
            row_dataset = str(row.get("dataset", sheet_dom)).strip().upper()
            if row_dataset == "QNAM":
                # SUPP domain: SUPP + first 2 chars of parent domain
                sdtm_target_domain = "SUPP" + sheet_dom[:2]
            elif row_dataset.startswith("SUPP"):
                sdtm_target_domain = row_dataset
            else:
                sdtm_target_domain = sheet_dom

            for token in inp.split(","):
                token = token.strip().upper()
                if token.startswith("RAW."):
                    parts = token.split(".")
                    if len(parts) >= 3:
                        rows.append({
                            "sheet_domain":   sheet_dom,
                            "sdtm_domain":    sdtm_target_domain,
                            "sdtm_variable":  sdtm_var,
                            "raw_dataset":    parts[1],
                            "raw_variable":   parts[2],
                            "raw_triplet":    f"RAW.{parts[1]}.{parts[2]}",
                            "mapping_action": ma,
                        })
    return pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)


def run_raw_coverage_from_store(
    raw_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
    active_filter: str = "Y",
    exclude_vars: Optional[Set[str]] = None,
) -> Dict[str, pd.DataFrame]:
    """
    Main entry point. Takes in-memory file store (from session_state).
    Returns: coverage, summary, domain_mapping, unmapped
    """
    raw_vars = collect_raw_vars_from_store(raw_store, exclude_vars)
    if raw_vars.empty:
        return {"coverage": pd.DataFrame(), "summary": pd.DataFrame(),
                "domain_mapping": pd.DataFrame(), "unmapped": pd.DataFrame()}

    spec_refs = collect_spec_input_refs_enhanced(spec, active_filter)

    if spec_refs.empty:
        raw_vars["status"]    = "UNMAPPED"
        raw_vars["mapped_to"] = ""
        raw_vars["sdtm_domain"] = ""
        return {"coverage": raw_vars, "summary": pd.DataFrame(),
                "domain_mapping": pd.DataFrame(), "unmapped": raw_vars.copy()}

    # Build lookup sets for matching
    # EXACT: raw_dataset+raw_variable both match
    exact_set = set(
        zip(spec_refs["raw_dataset"].str.upper(),
            spec_refs["raw_variable"].str.upper())
    )
    # For EXACT mapped_to lookup: (raw_dataset, raw_variable) -> list of sdtm_domain.sdtm_variable
    exact_map: Dict = {}
    for _, r in spec_refs.iterrows():
        key = (r["raw_dataset"].upper(), r["raw_variable"].upper())
        label = f"{r['sdtm_domain']}.{r['sdtm_variable']}"
        exact_map.setdefault(key, []).append(label)

    # Partial fallback: just variable name substring match
    all_raw_vars_in_spec = set(spec_refs["raw_variable"].str.upper())

    def classify(row):
        rd = str(row["raw_dataset"]).upper()
        rv = str(row["raw_variable"]).upper()
        key = (rd, rv)
        if key in exact_set:
            return "EXACT"
        # Partial: variable name (without dataset) matches
        if rv in all_raw_vars_in_spec:
            return "PARTIAL"
        for ref_v in all_raw_vars_in_spec:
            if rv in ref_v or ref_v in rv:
                return "PARTIAL"
        return "UNMAPPED"

    raw_vars["status"] = raw_vars.apply(classify, axis=1)

    # Attach mapped-to info for EXACT matches
    raw_vars["mapped_to"] = raw_vars.apply(
        lambda r: "; ".join(exact_map.get(
            (r["raw_dataset"].upper(), r["raw_variable"].upper()), []
        )), axis=1
    )

    # Attach primary SDTM domain for EXACT matches
    domain_for_var: Dict = {}
    for _, r in spec_refs.iterrows():
        key = (r["raw_dataset"].upper(), r["raw_variable"].upper())
        domain_for_var.setdefault(key, set()).add(r["sdtm_domain"])

    raw_vars["sdtm_domain"] = raw_vars.apply(
        lambda r: ", ".join(sorted(domain_for_var.get(
            (r["raw_dataset"].upper(), r["raw_variable"].upper()), set()
        ))), axis=1
    )

    # Summary per raw_dataset
    summary = (
        raw_vars.groupby(["raw_dataset","status"])
        .size().unstack(fill_value=0).reset_index()
    )
    for col in ["EXACT","PARTIAL","UNMAPPED"]:
        if col not in summary.columns:
            summary[col] = 0
    summary["total"]      = summary[["EXACT","PARTIAL","UNMAPPED"]].sum(axis=1)
    summary["pct_mapped"] = (
        (summary["EXACT"] + summary["PARTIAL"]) / summary["total"] * 100
    ).round(1)

    # ── Domain mapping overview (Req 5) ──────────────────────────────────────
    # For each raw dataset: which SDTM domains does it map to?
    domain_map_rows = []
    for rd, grp in spec_refs.groupby("raw_dataset"):
        sdtm_doms = sorted(grp["sdtm_domain"].unique())
        domain_map_rows.append({
            "raw_dataset":    rd,
            "sdtm_domains":   ", ".join(sdtm_doms),
            "n_sdtm_domains": len(sdtm_doms),
            "n_variables":    len(grp),
            "sdtm_domain_list": sdtm_doms,
        })
    domain_mapping = pd.DataFrame(domain_map_rows).sort_values(
        "raw_dataset").reset_index(drop=True)

    unmapped = raw_vars[raw_vars["status"] == "UNMAPPED"].copy()

    return {
        "coverage":      raw_vars,
        "summary":       summary,
        "domain_mapping": domain_mapping,
        "unmapped":      unmapped,
        "spec_refs":     spec_refs,
    }


# ── Legacy path-based entry point (kept for backward compat) ─────────────────
def run_raw_coverage(
    raw_lib_path: str,
    spec: Dict[str, pd.DataFrame],
    active_filter: str = "Y",
    exclude_vars: Optional[Set[str]] = None,
    exclude_datasets: Optional[Set[str]] = None,
) -> Dict[str, pd.DataFrame]:
    """Path-based entry point — reads files from disk into memory store."""
    import os
    store = {}
    lib = Path(raw_lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")):
        ds = fp.stem.upper()
        if exclude_datasets and ds in {d.upper() for d in exclude_datasets}:
            continue
        store[fp.name] = fp.read_bytes()
    return run_raw_coverage_from_store(store, spec, active_filter, exclude_vars)
