# pages/6_Dataset_Compare.py
"""
Dataset Comparison — compares two datasets (raw, SDTM, or ADaM) at:
  1. Metadata level: variables added/removed/dtype changed
  2. Value level: row additions, removals, value changes per variable
"""
import sys, warnings, io
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import BASE_CSS, C, render_table
from core.dataset_compare import (
    _load_from_bytes, compare_metadata, compare_values, export_comparison_report
)

st.set_page_config(page_title="Dataset Compare", layout="wide")
st.markdown(BASE_CSS, unsafe_allow_html=True)
st.title("Dataset Comparison")
st.caption(
    "Compare two datasets (raw CRF, SDTM, or ADaM) at metadata and value level. "
    "Identifies added/removed variables, dtype changes, row differences, and value changes."
)

# ── File upload ───────────────────────────────────────────────────────────
col1, col2 = st.columns(2)
with col1:
    st.markdown("**Dataset A** (baseline / before)")
    file_a = st.file_uploader("Upload Dataset A (.sas7bdat or .csv)",
        type=["sas7bdat","csv"], key="cmp_file_a")
    if file_a:
        name_a = Path(file_a.name).stem.upper()
        st.caption(f"Dataset A: **{name_a}**")

with col2:
    st.markdown("**Dataset B** (comparison / after)")
    file_b = st.file_uploader("Upload Dataset B (.sas7bdat or .csv)",
        type=["sas7bdat","csv"], key="cmp_file_b")
    if file_b:
        name_b = Path(file_b.name).stem.upper()
        st.caption(f"Dataset B: **{name_b}**")

if not file_a or not file_b:
    st.info("Upload both datasets to begin comparison.")
    st.stop()

name_a = Path(file_a.name).stem.upper()
name_b = Path(file_b.name).stem.upper()

# ── Options ───────────────────────────────────────────────────────────────
with st.expander("Options", expanded=False):
    key_input = st.text_input(
        "Key variables for row matching (comma-separated)",
        value="",
        placeholder="USUBJID, AESEQ  — leave blank for auto-detect",
        help="Variables used to match rows between datasets. If blank, auto-detected from common ID columns."
    )
    run_values = st.checkbox("Run value-level comparison (may be slow for large datasets)", value=True)

key_cols = [k.strip().upper() for k in key_input.split(",") if k.strip()] if key_input.strip() else None

if st.button("Run Comparison", type="primary", use_container_width=True):
    with st.spinner("Loading datasets..."):
        try:
            bytes_a = file_a.getvalue()
            bytes_b = file_b.getvalue()
            df_a = _load_from_bytes(bytes_a, file_a.name)
            df_b = _load_from_bytes(bytes_b, file_b.name)
        except Exception as exc:
            st.error(f"Cannot load datasets: {exc}"); st.stop()

    st.success(f"A: {len(df_a):,} rows × {len(df_a.columns)} cols  |  "
               f"B: {len(df_b):,} rows × {len(df_b.columns)} cols")

    with st.spinner("Comparing metadata..."):
        meta_diff = compare_metadata(df_a, name_a, df_b, name_b)

    value_results = {}
    if run_values:
        with st.spinner("Comparing values (this may take a moment for large files)..."):
            value_results = compare_values(df_a, name_a, df_b, name_b, key_cols=key_cols)

    st.session_state.update({
        "cmp_meta_diff":     meta_diff,
        "cmp_value_results": value_results,
        "cmp_name_a":        name_a,
        "cmp_name_b":        name_b,
        "cmp_df_a_shape":    df_a.shape,
        "cmp_df_b_shape":    df_b.shape,
    })

if "cmp_meta_diff" not in st.session_state:
    st.stop()

meta_diff     = st.session_state["cmp_meta_diff"]
value_results = st.session_state.get("cmp_value_results", {})
name_a        = st.session_state["cmp_name_a"]
name_b        = st.session_state["cmp_name_b"]
shape_a       = st.session_state["cmp_df_a_shape"]
shape_b       = st.session_state["cmp_df_b_shape"]

# ── Summary metrics ────────────────────────────────────────────────────────
n_same     = int((meta_diff["status"]=="SAME").sum())
n_dtype    = int((meta_diff["status"]=="DTYPE_CHANGED").sum())
n_only_a   = int(meta_diff["status"].str.startswith("ONLY_IN_"+name_a[:10]).sum())
n_only_b   = int(meta_diff["status"].str.startswith("ONLY_IN_"+name_b[:10]).sum())
n_added    = value_results.get("n_added",0)
n_removed  = value_results.get("n_removed",0)
n_vchg     = value_results.get("n_vars_changed",0)

st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">{name_a} shape</div>'
    f'<div class="value" style="font-size:16px;color:{C["text_main"]};">{shape_a[0]:,} × {shape_a[1]}</div></div>'
    f'<div class="metric-item"><div class="label">{name_b} shape</div>'
    f'<div class="value" style="font-size:16px;color:{C["text_main"]};">{shape_b[0]:,} × {shape_b[1]}</div></div>'
    f'<div class="metric-item"><div class="label">Vars same</div>'
    f'<div class="value" style="color:{C["pass_fg"]};">{n_same}</div></div>'
    f'<div class="metric-item"><div class="label">Dtype changed</div>'
    f'<div class="value" style="color:{C["warn_fg"]};">{n_dtype}</div></div>'
    f'<div class="metric-item"><div class="label">Only in A</div>'
    f'<div class="value" style="color:{C["warn_fg"]};">{n_only_a}</div></div>'
    f'<div class="metric-item"><div class="label">Only in B</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{n_only_b}</div></div>'
    f'<div class="metric-item"><div class="label">Rows added</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{n_added:,}</div></div>'
    f'<div class="metric-item"><div class="label">Rows removed</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_removed:,}</div></div>'
    f'<div class="metric-item"><div class="label">Vars with diffs</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_vchg}</div></div>'
    f'</div>',
    unsafe_allow_html=True
)

# ── Download ──────────────────────────────────────────────────────────────
report_bytes = export_comparison_report(meta_diff, value_results, name_a, name_b)
st.download_button(
    "⬇ Download Comparison Report (.xlsx)",
    data=report_bytes,
    file_name=f"DatasetCompare_{name_a}_vs_{name_b}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)
st.divider()

# ── Charts ────────────────────────────────────────────────────────────────
if HAS_PLOTLY:
    c1, c2 = st.columns(2)

    with c1:
        # Metadata donut
        if not meta_diff.empty:
            status_counts = meta_diff["status"].value_counts().reset_index()
            status_counts.columns = ["status","count"]
            color_map = {
                "SAME": "#4ade80",
                "DTYPE_CHANGED": "#fbbf24",
                f"ONLY_IN_{name_a[:10]}": "#f59e0b",
                f"ONLY_IN_{name_b[:10]}": "#60a5fa",
            }
            fig_meta = px.pie(
                status_counts, names="status", values="count",
                title="Metadata Differences",
                color="status",
                color_discrete_map=color_map,
                hole=0.45,
            )
            fig_meta.update_layout(
                template="plotly_dark",
                margin=dict(l=0,r=0,t=36,b=0),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                legend=dict(font=dict(color="#94a3b8"),orientation="h"),
                height=280,
            )
            st.plotly_chart(fig_meta, use_container_width=True)

    with c2:
        # Value-level bar chart (top changed variables)
        if value_results and not value_results.get("summary",pd.DataFrame()).empty:
            summ = value_results["summary"]
            top_n = summ[summ["different"]>0].head(15)
            if not top_n.empty:
                fig_val = px.bar(
                    top_n, x="variable", y="different",
                    title=f"Top Variables by Value Differences",
                    labels={"different":"# Different Rows","variable":"Variable"},
                    color="pct_different",
                    color_continuous_scale=["#4ade80","#fbbf24","#ef4444"],
                    height=280,
                )
                fig_val.update_layout(
                    template="plotly_dark",
                    margin=dict(l=0,r=0,t=36,b=0),
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    coloraxis_showscale=False,
                )
                fig_val.update_xaxes(tickangle=-30)
                st.plotly_chart(fig_val, use_container_width=True)

# ── Tabs ──────────────────────────────────────────────────────────────────
tabs = st.tabs([
    "Metadata Diff",
    "Value Summary",
    "Changed Values",
    "Added Rows",
    "Removed Rows",
])

STATUS_COLORS = {
    "SAME": "row-pass",
    "DTYPE_CHANGED": "row-warning",
}

def _meta_rc(row):
    s = str(row.get("status",""))
    if "ONLY_IN_" + name_a[:10] in s: return "row-warning"
    if "ONLY_IN_" + name_b[:10] in s: return "row-dt"
    if "DTYPE" in s: return "row-warning"
    if s == "SAME": return "row-pass"
    return ""

def _val_rc(row):
    n = int(row.get("different",0))
    if n == 0:   return "row-pass"
    pct = float(row.get("pct_different",0))
    if pct > 10: return "row-error" if pct > 50 else "row-warning"
    return "row-warning"

with tabs[0]:
    st.caption(f"{len(meta_diff)} variables | "
               f"{n_same} same · {n_dtype} dtype changed · "
               f"{n_only_a} only in A · {n_only_b} only in B")
    sf = st.selectbox("Filter status", ["All","SAME","DTYPE_CHANGED",
        f"ONLY_IN_{name_a[:10]}", f"ONLY_IN_{name_b[:10]}"], key="meta_sf")
    disp_meta = meta_diff if sf=="All" else meta_diff[meta_diff["status"]==sf]
    st.markdown(render_table(disp_meta, row_class_fn=_meta_rc), unsafe_allow_html=True)

with tabs[1]:
    summ = value_results.get("summary", pd.DataFrame())
    if summ.empty:
        st.info("Value comparison not run or no common variables found.")
    else:
        show_diffs = st.checkbox("Show only variables with differences", value=True, key="val_diffs")
        disp_s = summ[summ["different"]>0] if show_diffs else summ
        st.caption(f"{len(disp_s)} variables shown")
        st.markdown(render_table(disp_s, row_class_fn=_val_rc), unsafe_allow_html=True)

with tabs[2]:
    chg = value_results.get("changed_values", pd.DataFrame())
    if chg is None or chg.empty:
        st.info("No value differences found, or value comparison not run.")
    else:
        var_opts = ["All"] + sorted(chg["variable"].unique().tolist()) if "variable" in chg.columns else ["All"]
        var_sel  = st.selectbox("Filter variable", var_opts, key="chg_var")
        disp_chg = chg if var_sel=="All" else chg[chg["variable"]==var_sel]
        st.caption(f"{len(disp_chg):,} differing rows")
        def _chg_rc(row): return "row-miss"
        st.markdown(render_table(disp_chg, row_class_fn=_chg_rc, max_rows=500), unsafe_allow_html=True)

with tabs[3]:
    added = value_results.get("added_rows", pd.DataFrame())
    if added is None or added.empty:
        st.success("No added rows (all rows in B exist in A).")
    else:
        st.caption(f"{len(added):,} rows in {name_b} not in {name_a}")
        def _add_rc(row): return "row-dt"
        st.markdown(render_table(added, row_class_fn=_add_rc, max_rows=500), unsafe_allow_html=True)

with tabs[4]:
    removed = value_results.get("removed_rows", pd.DataFrame())
    if removed is None or removed.empty:
        st.success("No removed rows (all rows in A exist in B).")
    else:
        st.caption(f"{len(removed):,} rows in {name_a} not in {name_b}")
        def _rem_rc(row): return "row-warning"
        st.markdown(render_table(removed, row_class_fn=_rem_rc, max_rows=500), unsafe_allow_html=True)
