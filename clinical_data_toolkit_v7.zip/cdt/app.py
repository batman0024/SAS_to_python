# app.py
"""
Clinical Data Toolkit - main entry point.
ALL file uploads live here and are shared across every page via session_state.
No page needs its own file uploader for spec or SAS datasets.
"""
import sys
import warnings
from pathlib import Path
warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).parent))

import streamlit as st

st.set_page_config(
    page_title="Clinical Data Toolkit",
    page_icon=":microscope:",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── helper: load sas7bdat bytes into DataFrame ────────────────────────────────
def _load_sas_bytes(file_bytes: bytes, filename: str):
    import io
    try:
        import pyreadstat
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            df, meta = pyreadstat.read_sas7bdat(io.BytesIO(file_bytes))
        df.columns = [c.upper() for c in df.columns]
        return df, meta
    except Exception as exc:
        return None, str(exc)


def _load_sas_meta(file_bytes: bytes, filename: str):
    import io
    try:
        import pyreadstat
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            _, meta = pyreadstat.read_sas7bdat(io.BytesIO(file_bytes), metadataonly=True)
        return meta, None
    except Exception as exc:
        return None, str(exc)


# ── SIDEBAR ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("Clinical Data Toolkit")
    st.caption("Pre-Sponsor Review QC | v1.0")

    # ── Reset button ────────────────────────────────────────────────────────
    if st.button("Reset Session", type="secondary", use_container_width=True,
                 help="Clear all uploaded files and results to start fresh for a new study."):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

    st.divider()

    # ── 1. Mapping Spec (shared everywhere) ─────────────────────────────────
    st.markdown("**Mapping Specification**")
    spec_file = st.file_uploader(
        "Upload Spec (.xlsx)",
        type=["xlsx"],
        key="sidebar_spec_upload",
        help="SDTM or ADaM mapping specification. Must contain a 'toc' sheet.",
    )
    if spec_file:
        spec_bytes = spec_file.getvalue()
        spec_key   = f"spec__{spec_file.name}__{len(spec_bytes)}"
        if st.session_state.get("_spec_key") != spec_key:
            with st.spinner("Loading spec..."):
                try:
                    from core.spec_loader import load_spec_from_bytes, get_active_domains, get_spec_metadata
                    spec  = load_spec_from_bytes(spec_bytes)
                    meta  = get_spec_metadata(spec)
                    doms  = get_active_domains(spec)
                    st.session_state.update({
                        "spec": spec, "spec_bytes": spec_bytes,
                        "spec_name": spec_file.name, "spec_meta": meta,
                        "spec_domains": doms, "_spec_key": spec_key,
                    })
                    for k in ["validation_results","run_history","cov_results",
                              "define_columns","imputer_result"]:
                        st.session_state.pop(k, None)
                except Exception as exc:
                    st.error(f"Cannot load spec: {exc}")

    if "spec" in st.session_state:
        meta  = st.session_state.get("spec_meta", {})
        doms  = st.session_state.get("spec_domains", [])
        st.success(f"Spec: {st.session_state.get('spec_name','')}")
        c1, c2 = st.columns(2)
        c1.metric("Domains", len(doms))
        c2.metric("Type", meta.get("spec_type","?"))
        if meta.get("ig_version"):
            st.caption(f"IG: {meta['ig_version']}")
        ct = meta.get("ct_version") or (meta.get("ct_from_codelist") or [""])[0]
        if ct:
            st.caption(f"CT: {ct}")
        if meta.get("study_name"):
            st.caption(f"Study: {meta['study_name']}")

    st.divider()

    # ── 2. SAS Raw datasets (shared: Raw Coverage) ─────────────────────────
    st.markdown("**Raw CRF Datasets (.sas7bdat)**")
    raw_files = st.file_uploader(
        "Upload raw datasets",
        type=["sas7bdat"],
        accept_multiple_files=True,
        key="sidebar_raw_upload",
        help="Used by Raw Coverage. Upload all raw CRF domain .sas7bdat files.",
    )
    if raw_files:
        raw_key = "_".join(f"{f.name}{f.size}" for f in raw_files)
        if st.session_state.get("_raw_key") != raw_key:
            raw_store = {}
            for uf in raw_files:
                raw_store[uf.name] = uf.getvalue()
            st.session_state["raw_files_store"] = raw_store
            st.session_state["_raw_key"] = raw_key
            st.session_state.pop("cov_results", None)
        n = len(raw_files)
        st.success(f"{n} raw file{'s' if n>1 else ''} loaded")

    st.divider()

    # ── 3. SDTM/ADaM datasets (shared: Define Helper, Spec Validator SDTM check) ──
    st.markdown("**SDTM / ADaM Datasets (.sas7bdat)**")
    sdtm_files = st.file_uploader(
        "Upload SDTM or ADaM datasets",
        type=["sas7bdat"],
        accept_multiple_files=True,
        key="sidebar_sdtm_upload",
        help="Used by Define Helper and SDTM Source check in Spec Validator.",
    )
    if sdtm_files:
        sdtm_key = "_".join(f"{f.name}{f.size}" for f in sdtm_files)
        if st.session_state.get("_sdtm_key") != sdtm_key:
            sdtm_store = {}
            for uf in sdtm_files:
                sdtm_store[uf.name] = uf.getvalue()
            st.session_state["sdtm_files_store"] = sdtm_store
            st.session_state["_sdtm_key"] = sdtm_key
            st.session_state.pop("define_columns", None)
        n = len(sdtm_files)
        st.success(f"{n} SDTM/ADaM file{'s' if n>1 else ''} loaded")

    st.divider()

    # ── 4. AE + ADSL for date imputer ──────────────────────────────────────
    st.markdown("**AE / ADAE + ADSL (Date Imputer)**")
    ae_file_sb = st.file_uploader(
        "Upload AE or ADAE dataset",
        type=["sas7bdat","csv"],
        key="sidebar_ae_upload",
        help="AE or ADAE dataset for date imputation.",
    )
    adsl_file_sb = st.file_uploader(
        "Upload ADSL (contains TRTSDT/TRTSDTM)",
        type=["sas7bdat","csv"],
        key="sidebar_adsl_upload",
        help="ADSL dataset — used to merge TRTSDT into AE when not present.",
    )
    if ae_file_sb:
        ae_key = f"{ae_file_sb.name}{ae_file_sb.size}"
        if st.session_state.get("_ae_key") != ae_key:
            st.session_state["ae_file_bytes"]  = ae_file_sb.getvalue()
            st.session_state["ae_file_name"]   = ae_file_sb.name
            st.session_state["_ae_key"]        = ae_key
            st.session_state.pop("imputer_result", None)
        st.success(f"AE: {ae_file_sb.name}")
    if adsl_file_sb:
        adsl_key = f"{adsl_file_sb.name}{adsl_file_sb.size}"
        if st.session_state.get("_adsl_key") != adsl_key:
            st.session_state["adsl_file_bytes"] = adsl_file_sb.getvalue()
            st.session_state["adsl_file_name"]  = adsl_file_sb.name
            st.session_state["_adsl_key"]       = adsl_key
        st.success(f"ADSL: {adsl_file_sb.name}")

    # ── Run history ──────────────────────────────────────────────────────────
    if st.session_state.get("run_history"):
        st.divider()
        st.caption("Recent validation runs")
        for run in reversed(st.session_state["run_history"][-5:]):
            icon = "red_circle" if run["errors"]>0 else (
                "large_yellow_circle" if run["warnings"]>0 else "large_green_circle")
            st.caption(f":{icon}: {run['time']}  {run['errors']}E / {run['warnings']}W")

# ── HOME PAGE ─────────────────────────────────────────────────────────────────
st.title("Clinical Data Toolkit")
st.caption("Pre-Sponsor Review QC | Upload files in the sidebar — shared across all pages")

st.divider()

c1,c2,c3,c4 = st.columns(4)
with c1:
    st.subheader("Spec Validator")
    st.write("Check mapping spec completeness — missing origins, compmethod IDs, comment formatting, codelist gaps. Inline and tab-referenced CompMethods handled separately.")
with c2:
    st.subheader("Raw Coverage")
    st.write("Validates at raw.dataset.variable level. Shows EXACT/PARTIAL/UNMAPPED with SUPP domain logic and a raw-to-SDTM domain mapping overview.")
with c3:
    st.subheader("Define Helper")
    st.write("Extracts variable metadata and value-level from uploaded SDTM/ADaM datasets. Includes CT validation against spec Codelist tab.")
with c4:
    st.subheader("Date Imputer")
    st.write("Imputes partial/missing AE dates. ADSL merged automatically for TRTSDT. ADAE comparison mode for re-imputation.")

st.divider()
c5,c6,_ = st.columns(3)
with c5:
    st.subheader("Spec Diff")
    st.write("Compare two spec files field-by-field. Upload the second spec on page 5.")
with c6:
    st.subheader("CT Validation")
    st.write("Compare actual SDTM variable values against Codelist tab CT terms. Domain-wise mismatch report.")

# Status summary
loaded = []
if "spec" in st.session_state:        loaded.append(f"Spec: {st.session_state.get('spec_name','')}")
if "raw_files_store" in st.session_state:  loaded.append(f"Raw: {len(st.session_state['raw_files_store'])} files")
if "sdtm_files_store" in st.session_state: loaded.append(f"SDTM: {len(st.session_state['sdtm_files_store'])} files")
if "ae_file_bytes" in st.session_state:    loaded.append(f"AE: {st.session_state.get('ae_file_name','')}")
if "adsl_file_bytes" in st.session_state:  loaded.append(f"ADSL: {st.session_state.get('adsl_file_name','')}")

if loaded:
    st.info("Loaded: " + " | ".join(loaded))
else:
    st.info("Upload files in the sidebar to begin. All tools share the same uploaded files.")
