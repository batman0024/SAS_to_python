# core/define_helper.py
"""
Define helper — extracts variable metadata and value-level from SAS datasets.

ROOT CAUSE ANALYSIS (confirmed from diagnostic screenshots):
  Error showed "Pass 1: 0 | Pass 2: 0 | Pass 3: 0" — meaning pyreadstat read
  successfully but returned 0 columns.  This only happens when fdata is empty
  bytes (b"").  Root cause: Streamlit UploadedFile.read() advances the file
  pointer; subsequent calls return b"".  FIXED in app.py by using .getvalue()
  instead of .read(), which always returns the full bytes regardless of pointer.

FOUR-PASS STRATEGY (defence in depth):
  Pass 1: pyreadstat metadataonly=True   — fastest, no data rows
  Pass 2: pyreadstat row_limit=1         — reads 1 data row
  Pass 3: pyreadstat full read           — reads entire file
  Pass 4: pandas.read_sas                — independent of pyreadstat, works on
                                           all Windows/Linux/Mac builds
  Each pass is isolated; failures surface the actual exception text.
  Empty-bytes guard fires before any pass to give a clear error.
"""
import io
import logging
import re
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)

EXCLUDE_DOMAIN_PREFIXES = ("_",)


def _safe_meta_attr(meta, attr: str, default=None):
    return getattr(meta, attr, default)


def _extract_col_names_from_meta(meta) -> List[str]:
    """Try all known pyreadstat attribute names for column names."""
    for attr in ("column_names", "column_names_to_labels",
                 "readstat_variable_names", "variable_names"):
        val = getattr(meta, attr, None)
        if val is None:
            continue
        if isinstance(val, list) and val:
            return val
        if isinstance(val, dict) and val:
            return list(val.keys())
    return []


def _build_rows_from_df(df: pd.DataFrame, domain: str, meta=None) -> list:
    """Build metadata rows from a DataFrame (used by passes 2, 3, 4)."""
    rows = []
    col_labels = []
    var_fmts   = {}
    var_widths = {}
    if meta is not None:
        col_labels = _safe_meta_attr(meta, "column_labels", []) or []
        var_fmts   = _safe_meta_attr(meta, "variable_formats", {}) or {}
        var_widths = _safe_meta_attr(meta, "variable_storage_width", {}) or {}

    for idx, col in enumerate(df.columns):
        col_up = col.upper()
        label = ""
        if idx < len(col_labels) and col_labels[idx]:
            label = str(col_labels[idx])

        fmt = (var_fmts.get(col, "") or var_fmts.get(col_up, "")) \
              if isinstance(var_fmts, dict) else ""

        # Infer dtype from pandas dtype
        pd_dtype = str(df[col].dtype)
        if pd_dtype == "object":
            dtype = "datetime" if "date" in label.lower() else "text"
        elif any(h in str(fmt).upper() for h in ("DATE","TIME","MMDD","YYMMDD")):
            dtype = "datetime"
        elif "float" in pd_dtype or "int" in pd_dtype:
            dtype = "integer"
        else:
            dtype = "text"

        lgth = (var_widths.get(col, "") or var_widths.get(col_up, "")) \
               if isinstance(var_widths, dict) else ""

        rows.append({
            "domain":    domain,
            "variable":  col_up,
            "label":     label,
            "data_type": dtype,
            "length":    lgth,
            "format":    fmt,
        })
    return rows


def _meta_from_sas_bytes(fdata: bytes, domain: str) -> Tuple[list, str]:
    """
    Read variable metadata.  Returns (rows, error_message).
    error_message is "" on success, non-empty on failure.
    """
    # ── Guard: empty bytes ────────────────────────────────────────────────
    if not fdata:
        return [], (f"[{domain}] File bytes are empty (0 bytes). "
                    "This usually means the upload was not captured correctly. "
                    "Please re-upload the file. "
                    "CAUSE: app.py used .read() instead of .getvalue() — fixed in v7.")

    errors = []

    # ── Pass 1: pyreadstat metadataonly ───────────────────────────────────
    try:
        import pyreadstat
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), metadataonly=True)
        col_names = _extract_col_names_from_meta(meta)
        if col_names:
            # Build rows using metadata
            col_labels = _safe_meta_attr(meta, "column_labels", []) or []
            var_fmts   = _safe_meta_attr(meta, "variable_formats", {}) or {}
            var_types  = (_safe_meta_attr(meta, "original_variable_types", []) or
                          _safe_meta_attr(meta, "readstat_variable_types",  []) or [])
            var_widths = _safe_meta_attr(meta, "variable_storage_width", {}) or {}
            rows = []
            for idx, col in enumerate(col_names):
                col_up = col.upper()
                label = col_labels[idx] if idx < len(col_labels) and col_labels[idx] else ""
                fmt   = (var_fmts.get(col,"") or var_fmts.get(col_up,"")) if isinstance(var_fmts,dict) else ""
                typ_raw = (str(var_types[idx]) if idx < len(var_types) and var_types[idx] else "")
                if "char" in typ_raw.lower() and "date" in str(label).lower(): dtype = "datetime"
                elif "char" in typ_raw.lower(): dtype = "text"
                elif any(h in str(fmt).upper() for h in ("DATE","TIME","MMDD","YYMMDD")): dtype = "datetime"
                else: dtype = "integer"
                lgth = (var_widths.get(col,"") or var_widths.get(col_up,"")) if isinstance(var_widths,dict) else ""
                rows.append({"domain":domain,"variable":col_up,"label":str(label),
                              "data_type":dtype,"length":lgth,"format":fmt})
            return rows, ""
        errors.append(f"Pass 1 (metadataonly): read OK but 0 columns returned")
    except ImportError:
        errors.append(f"Pass 1: pyreadstat not installed")
    except Exception as e1:
        errors.append(f"Pass 1 (metadataonly): {type(e1).__name__}: {e1}")

    # ── Pass 2: pyreadstat row_limit=1 ────────────────────────────────────
    try:
        import pyreadstat
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            df1, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), row_limit=1)
        if not df1.empty or len(df1.columns) > 0:
            rows = _build_rows_from_df(df1, domain, meta)
            if rows:
                return rows, ""
        errors.append(f"Pass 2 (row_limit=1): read OK but 0 columns returned")
    except ImportError:
        pass  # already noted in pass 1
    except Exception as e2:
        errors.append(f"Pass 2 (row_limit=1): {type(e2).__name__}: {e2}")

    # ── Pass 3: pyreadstat full read ──────────────────────────────────────
    try:
        import pyreadstat
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            df_full, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
        if len(df_full.columns) > 0:
            rows = _build_rows_from_df(df_full, domain, meta)
            if rows:
                return rows, ""
        errors.append(f"Pass 3 (full read): read OK but {len(df_full)} rows, {len(df_full.columns)} columns")
    except ImportError:
        pass
    except Exception as e3:
        errors.append(f"Pass 3 (full read): {type(e3).__name__}: {e3}")

    # ── Pass 4: pandas.read_sas (independent of pyreadstat) ──────────────
    try:
        df_pd = pd.read_sas(io.BytesIO(fdata), format="sas7bdat",
                            encoding="latin-1")
        if len(df_pd.columns) > 0:
            rows = _build_rows_from_df(df_pd, domain)
            if rows:
                return rows, ""
        errors.append(f"Pass 4 (pandas.read_sas): read OK but {len(df_pd.columns)} columns returned")
    except Exception as e4:
        errors.append(f"Pass 4 (pandas.read_sas): {type(e4).__name__}: {e4}")

    # All four passes failed
    err_msg = f"[{domain}] All strategies failed:\n  " + "\n  ".join(errors)
    return [], err_msg


def _meta_from_csv_bytes(fdata: bytes, domain: str) -> Tuple[list, str]:
    if not fdata:
        return [], f"[{domain}] CSV file bytes are empty."
    try:
        df = pd.read_csv(io.BytesIO(fdata), nrows=0)
        rows = [{"domain": domain, "variable": c.upper(),
                 "label": "", "data_type": "text", "length": "", "format": ""}
                for c in df.columns]
        return rows, ""
    except Exception as exc:
        return [], f"[{domain}] CSV read failed: {type(exc).__name__}: {exc}"


def get_column_metadata_from_store(
    files_store: Dict[str, bytes],
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Read variable metadata.  Returns (DataFrame, list_of_error_strings).
    Errors are non-fatal; the DataFrame has whatever could be read.
    """
    rows   = []
    errors = []

    for fname, fdata in sorted(files_store.items()):
        dom = Path(fname).stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES):
            continue
        fl = fname.lower()
        if fl.endswith(".sas7bdat"):
            dom_rows, err = _meta_from_sas_bytes(fdata, dom)
            if err:
                errors.append(err)
            rows.extend(dom_rows)
        elif fl.endswith(".csv"):
            dom_rows, err = _meta_from_csv_bytes(fdata, dom)
            if err:
                errors.append(err)
            rows.extend(dom_rows)

    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(
            columns=["domain","variable","label","data_type","length","format"]), errors
    return df.drop_duplicates(subset=["domain","variable"]).reset_index(drop=True), errors


def get_column_metadata(lib_path: str) -> pd.DataFrame:
    """Legacy path-based entry point."""
    store = {}
    lib = Path(lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")):
        store[fp.name] = fp.read_bytes()
    for fp in sorted(lib.glob("*.csv")):
        store[fp.name] = fp.read_bytes()
    df, _ = get_column_metadata_from_store(store)
    return df


def get_value_level_from_store(
    files_store: Dict[str, bytes],
    columns_df: pd.DataFrame,
    mode: str = "SDTM",
) -> pd.DataFrame:
    """Extract distinct TESTCD/QNAM/PARAMCD values from in-memory bytes."""
    mode = mode.upper()
    if mode == "ADAM":
        cands = columns_df[columns_df["variable"].str.upper().isin(["PARAMCD"])][
            ["domain","variable"]].copy().reset_index(drop=True)
        cands["orres"]        = "AVAL"
        cands["where_prefix"] = (cands["domain"] + ".PARAMCD.").values
    else:
        pat = re.compile(r"TESTCD|QNAM|PARMCD", re.IGNORECASE)
        cands = columns_df[columns_df["variable"].str.contains(pat, na=False)][
            ["domain","variable"]].copy().reset_index(drop=True)
        cands["orres"] = cands["variable"].apply(
            lambda v: "" if "TESTCD" in v.upper() else "QVAL")
        cands["where_prefix"] = (cands["domain"] + "." + cands["variable"] + ".").values

    if cands.empty:
        return pd.DataFrame(columns=[
            "dataset","variable","result_variable","value","where_clause","data_type"])

    dom_to_bytes = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".sas7bdat")}
    dom_to_csv   = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".csv")}

    rows = []
    for _, cand in cands.iterrows():
        dom   = str(cand["domain"]).upper()
        var   = str(cand["variable"]).upper()
        fdata = dom_to_bytes.get(dom) or dom_to_csv.get(dom)
        if not fdata:
            continue
        try:
            if dom in dom_to_bytes:
                try:
                    import pyreadstat
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        try:
                            df, _ = pyreadstat.read_sas7bdat(io.BytesIO(fdata), usecols=[var])
                        except Exception:
                            df, _ = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
                except ImportError:
                    df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
            else:
                df = pd.read_csv(io.BytesIO(fdata))
            df.columns = [c.upper() for c in df.columns]
            if var not in df.columns:
                continue
            orres = str(cand["orres"])
            if not orres and "TESTCD" in var:
                orres = dom + "ORRES"
            for val in df[var].dropna().unique():
                vs = str(val).strip()
                if not vs or vs.lower() == "nan":
                    continue
                rows.append({
                    "dataset": dom, "variable": var,
                    "result_variable": orres,
                    "value": vs,
                    "where_clause": str(cand["where_prefix"]) + vs,
                    "data_type": _infer_dtype(vs),
                })
        except Exception as exc:
            log.debug("Value-level error %s.%s: %s", dom, var, exc)

    if not rows:
        return pd.DataFrame(columns=[
            "dataset","variable","result_variable","value","where_clause","data_type"])
    return pd.DataFrame(rows).drop_duplicates(
        subset=["dataset","variable","value"]).reset_index(drop=True)


def get_value_level(lib_path: str, columns_df: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    store = {}
    lib = Path(lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")):
        store[fp.name] = fp.read_bytes()
    for fp in sorted(lib.glob("*.csv")):
        store[fp.name] = fp.read_bytes()
    return get_value_level_from_store(store, columns_df, mode)


def _infer_dtype(val: str) -> str:
    try:
        n = float(val)
        return "integer" if n == int(n) else "float"
    except (ValueError, TypeError):
        pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T", val): return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$",  val): return "Date"
    return "text"


def build_where_clause_table(value_level: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    if value_level.empty:
        return pd.DataFrame(columns=["id","dataset","var","comparator","value"])
    wh = value_level[["dataset","variable","value","where_clause"]].copy()
    wh["var"]        = "PARAMCD" if mode.upper() == "ADAM" else wh["variable"]
    wh["comparator"] = "EQ"
    wh["id"]         = wh["where_clause"]
    return wh[["id","dataset","var","comparator","value"]].reset_index(drop=True)


def validate_ct_values(
    value_level: pd.DataFrame,
    spec: Dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """Compare actual SDTM values against CT terms in the spec Codelist tab."""
    if value_level.empty:
        return pd.DataFrame()
    cl_sheet = None
    for k in spec:
        if k.strip().lower() == "codelist":
            cl_sheet = spec[k].copy()
            break
    if cl_sheet is None or cl_sheet.empty:
        return pd.DataFrame()
    cl_sheet.columns = [c.strip().lower().replace(" ","_") for c in cl_sheet.columns]
    name_col  = next((c for c in cl_sheet.columns if "codelist_name" in c or c=="codelist"), None)
    value_col = next((c for c in cl_sheet.columns
                      if "codelist_value" in c and "decode" not in c
                      and "code" not in c.replace("codelist_value","")), None)
    if not value_col:
        value_col = next((c for c in cl_sheet.columns if "value" in c and "decode" not in c), None)
    active_col = next((c for c in cl_sheet.columns if c=="active"), None)
    if not name_col or not value_col:
        return pd.DataFrame()
    allowed: Dict[str, set] = {}
    for _, row in cl_sheet.iterrows():
        act = str(row.get(active_col,"Y")).strip().upper() if active_col else "Y"
        if act not in ("Y","YES","TRUE","1",""):
            continue
        cl_name = str(row[name_col]).strip().upper()
        val     = str(row[value_col]).strip()
        if cl_name and val and val.lower() != "nan":
            allowed.setdefault(cl_name, set()).add(val)
    if not allowed:
        return pd.DataFrame()
    cl_refs: Dict = {}
    for sheet, df in spec.items():
        if isinstance(df, pd.DataFrame) and "variable" in df.columns and "codelist" in df.columns:
            for _, row in df.iterrows():
                cl = str(row.get("codelist","")).strip()
                v  = str(row.get("variable","")).strip().upper()
                if cl and v:
                    cl_refs[(sheet.upper(), v)] = cl.upper()
    rows = []
    for _, vrow in value_level.iterrows():
        ds  = str(vrow["dataset"]).upper()
        var = str(vrow["variable"]).upper()
        val = str(vrow["value"]).strip()
        cl_name = cl_refs.get((ds, var))
        if not cl_name:
            continue
        allowed_vals = allowed.get(cl_name)
        if not allowed_vals:
            continue
        in_ct = val.upper() in {v.upper() for v in allowed_vals}
        rows.append({"dataset":ds,"variable":var,"value":val,"codelist":cl_name,
                     "in_ct":"YES" if in_ct else "NO",
                     "status":"PASS" if in_ct else "MISMATCH"})
    return pd.DataFrame(rows).reset_index(drop=True)
