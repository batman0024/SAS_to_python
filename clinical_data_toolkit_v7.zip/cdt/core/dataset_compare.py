# core/dataset_compare.py
"""
Dataset comparison — compares two SAS/CSV datasets at metadata and value level.
Works with raw, SDTM, or ADaM datasets.
"""
import io
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd

warnings.filterwarnings("ignore")


def _load_from_bytes(fdata: bytes, fname: str) -> pd.DataFrame:
    """Load a dataset from bytes — tries pyreadstat then pandas.read_sas."""
    if not fdata:
        raise ValueError(f"File bytes are empty for {fname}")
    fl = fname.lower()
    if fl.endswith(".sas7bdat"):
        try:
            import pyreadstat
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df, _ = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
            df.columns = [c.upper() for c in df.columns]
            return df
        except Exception:
            pass
        # pandas fallback
        df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
        df.columns = [c.upper() for c in df.columns]
        return df
    elif fl.endswith(".csv"):
        df = pd.read_csv(io.BytesIO(fdata))
        df.columns = [c.upper() for c in df.columns]
        return df
    raise ValueError(f"Unsupported file type: {fname}")


def compare_metadata(
    df_a: pd.DataFrame, name_a: str,
    df_b: pd.DataFrame, name_b: str,
) -> pd.DataFrame:
    """
    Compare column metadata between two datasets.
    Returns DataFrame with columns:
      variable, status, dtype_a, dtype_b, in_a, in_b
    """
    cols_a = set(df_a.columns)
    cols_b = set(df_b.columns)
    all_cols = sorted(cols_a | cols_b)

    rows = []
    for col in all_cols:
        in_a = col in cols_a
        in_b = col in cols_b
        dtype_a = str(df_a[col].dtype) if in_a else ""
        dtype_b = str(df_b[col].dtype) if in_b else ""

        if not in_a:
            status = f"ONLY_IN_{name_b.upper()[:10]}"
        elif not in_b:
            status = f"ONLY_IN_{name_a.upper()[:10]}"
        elif dtype_a != dtype_b:
            status = "DTYPE_CHANGED"
        else:
            status = "SAME"

        rows.append({
            "variable":  col,
            "status":    status,
            f"dtype_{name_a[:8]}": dtype_a,
            f"dtype_{name_b[:8]}": dtype_b,
            f"in_{name_a[:8]}":    "YES" if in_a else "NO",
            f"in_{name_b[:8]}":    "YES" if in_b else "NO",
        })
    return pd.DataFrame(rows)


def compare_values(
    df_a: pd.DataFrame, name_a: str,
    df_b: pd.DataFrame, name_b: str,
    key_cols: Optional[List[str]] = None,
    max_diff_rows: int = 5000,
) -> Dict[str, pd.DataFrame]:
    """
    Compare values between two datasets.

    Returns dict with:
      summary        — per-variable summary of differences
      added_rows     — rows in B not in A (by key)
      removed_rows   — rows in A not in B (by key)
      changed_values — rows where key matches but values differ (per column)
    """
    # Find common columns
    common_cols = sorted(set(df_a.columns) & set(df_b.columns))
    if not common_cols:
        return {
            "summary":        pd.DataFrame(),
            "added_rows":     pd.DataFrame(),
            "removed_rows":   pd.DataFrame(),
            "changed_values": pd.DataFrame(),
        }

    # Auto-detect key columns if not provided
    if not key_cols:
        candidate_keys = ["USUBJID","SUBJID","STUDYID","SEQ",
                          "LBSEQ","AESEQ","CMSEQ","VSSEQ"]
        key_cols = [c for c in candidate_keys if c in common_cols]
        if not key_cols:
            # Use first column as key
            key_cols = [common_cols[0]]

    key_cols = [c for c in key_cols if c in common_cols]
    value_cols = [c for c in common_cols if c not in key_cols]

    # Coerce dtypes for comparison
    df_a2 = df_a[common_cols].copy().astype(str)
    df_b2 = df_b[common_cols].copy().astype(str)

    # ── Row-level comparison (by key) ─────────────────────────────────────
    if key_cols:
        a_keys = set(df_a2[key_cols].apply(tuple, axis=1))
        b_keys = set(df_b2[key_cols].apply(tuple, axis=1))
        added_keys   = b_keys - a_keys
        removed_keys = a_keys - b_keys
    else:
        added_keys   = set()
        removed_keys = set()

    added_rows   = df_b[df_b2[key_cols].apply(tuple, axis=1).isin(added_keys)].head(max_diff_rows)
    removed_rows = df_a[df_a2[key_cols].apply(tuple, axis=1).isin(removed_keys)].head(max_diff_rows)

    # ── Value-level comparison (matching keys) ────────────────────────────
    if key_cols and value_cols:
        common_keys = a_keys & b_keys
        a_match = df_a2[df_a2[key_cols].apply(tuple, axis=1).isin(common_keys)]
        b_match = df_b2[df_b2[key_cols].apply(tuple, axis=1).isin(common_keys)]
        a_match = a_match.sort_values(key_cols).reset_index(drop=True)
        b_match = b_match.sort_values(key_cols).reset_index(drop=True)
        min_len = min(len(a_match), len(b_match))
        a_match = a_match.head(min_len)
        b_match = b_match.head(min_len)
    else:
        min_len = min(len(df_a2), len(df_b2))
        a_match = df_a2.head(min_len).reset_index(drop=True)
        b_match = df_b2.head(min_len).reset_index(drop=True)

    # Per-column diff summary
    summary_rows = []
    changed_all  = []
    for col in value_cols:
        if col not in a_match.columns or col not in b_match.columns:
            continue
        diff_mask  = a_match[col] != b_match[col]
        n_diff     = int(diff_mask.sum())
        n_match    = int((~diff_mask).sum())
        pct        = round(n_diff / max(len(a_match), 1) * 100, 1)
        summary_rows.append({
            "variable":        col,
            "rows_compared":   len(a_match),
            "matching":        n_match,
            "different":       n_diff,
            "pct_different":   pct,
        })
        if n_diff > 0:
            diff_rows = a_match[diff_mask][[c for c in key_cols if c in a_match.columns] + [col]].copy()
            diff_rows = diff_rows.head(max_diff_rows // max(len(value_cols), 1))
            diff_rows.rename(columns={col: f"{col}_{name_a[:6]}"}, inplace=True)
            diff_rows[f"{col}_{name_b[:6]}"] = b_match[diff_mask][col].values[:len(diff_rows)]
            diff_rows["variable"] = col
            changed_all.append(diff_rows)

    summary_df  = pd.DataFrame(summary_rows).sort_values("different", ascending=False)
    changed_df  = pd.concat(changed_all, ignore_index=True) if changed_all else pd.DataFrame()

    return {
        "summary":        summary_df,
        "added_rows":     added_rows.reset_index(drop=True),
        "removed_rows":   removed_rows.reset_index(drop=True),
        "changed_values": changed_df,
        "n_common_rows":  len(a_match),
        "n_added":        len(added_rows),
        "n_removed":      len(removed_rows),
        "n_vars_changed": int(summary_df["different"].gt(0).sum()) if not summary_df.empty else 0,
    }


def export_comparison_report(
    meta_diff: pd.DataFrame,
    value_results: Dict,
    name_a: str,
    name_b: str,
) -> bytes:
    """Export full comparison report to Excel."""
    import io as _io
    import xlsxwriter

    buf = _io.BytesIO()
    with xlsxwriter.Workbook(buf, {"in_memory": True, "strings_to_urls": False}) as wb:
        hdr_fmt  = wb.add_format({"bold":True,"bg_color":"#1E3A5F","font_color":"#FFFFFF",
                                   "border":1,"text_wrap":True,"font_size":10})
        norm_fmt = wb.add_format({"border":1,"text_wrap":True,"valign":"top","font_size":10})
        diff_fmt = wb.add_format({"border":1,"text_wrap":True,"valign":"top","font_size":10,
                                   "bg_color":"#FFD0D0"})
        only_a   = wb.add_format({"border":1,"text_wrap":True,"valign":"top","font_size":10,
                                   "bg_color":"#FFF3CC"})
        only_b   = wb.add_format({"border":1,"text_wrap":True,"valign":"top","font_size":10,
                                   "bg_color":"#D0E8FF"})
        pass_fmt = wb.add_format({"border":1,"text_wrap":True,"valign":"top","font_size":10,
                                   "bg_color":"#D4F5DC"})

        def _write_df(ws, df, row_fmt_fn=None):
            if df is None or df.empty:
                ws.write(0, 0, "(no data)", norm_fmt)
                return
            cols = list(df.columns)
            ws.set_row(0, 20)
            for ci, col in enumerate(cols):
                ws.set_column(ci, ci, min(max(len(col)+2, 12), 40))
                ws.write(0, ci, col.replace("_"," ").title(), hdr_fmt)
            ws.freeze_panes(1, 0)
            for ri, (_, row) in enumerate(df.iterrows(), 1):
                fmt = row_fmt_fn(row.to_dict()) if row_fmt_fn else norm_fmt
                for ci, col in enumerate(cols):
                    v = str(row[col]) if row[col] is not None else ""
                    ws.write(ri, ci, v, fmt)

        def _meta_fmt(row):
            s = str(row.get("status",""))
            if "ONLY_IN_" + name_a.upper()[:10] in s: return only_a
            if "ONLY_IN_" + name_b.upper()[:10] in s: return only_b
            if "CHANGED" in s or "DTYPE" in s: return diff_fmt
            return pass_fmt

        # Summary sheet
        ws0 = wb.add_worksheet("Summary")
        ws0.set_column(0, 0, 35); ws0.set_column(1, 1, 20)
        ws0.write(0, 0, f"Dataset Comparison: {name_a} vs {name_b}",
                  wb.add_format({"bold":True,"font_size":13,"font_color":"#1E3A5F"}))
        info = [
            ("Dataset A", name_a), ("Dataset B", name_b),
            ("Variables in A only", int((meta_diff["status"].str.startswith("ONLY_IN_"+name_a.upper()[:10])).sum()) if not meta_diff.empty else 0),
            ("Variables in B only", int((meta_diff["status"].str.startswith("ONLY_IN_"+name_b.upper()[:10])).sum()) if not meta_diff.empty else 0),
            ("Dtype changed", int((meta_diff["status"]=="DTYPE_CHANGED").sum()) if not meta_diff.empty else 0),
            ("Same metadata", int((meta_diff["status"]=="SAME").sum()) if not meta_diff.empty else 0),
            ("Added rows (in B not A)", value_results.get("n_added",0)),
            ("Removed rows (in A not B)", value_results.get("n_removed",0)),
            ("Common rows compared", value_results.get("n_common_rows",0)),
            ("Variables with value diffs", value_results.get("n_vars_changed",0)),
        ]
        for ri, (k, v) in enumerate(info, 2):
            ws0.write(ri, 0, k, norm_fmt); ws0.write(ri, 1, str(v), norm_fmt)

        # Metadata diff
        ws1 = wb.add_worksheet("Metadata_Diff")
        _write_df(ws1, meta_diff, _meta_fmt)

        # Value summary
        ws2 = wb.add_worksheet("Value_Summary")
        _write_df(ws2, value_results.get("summary", pd.DataFrame()),
                  lambda r: diff_fmt if int(r.get("different",0))>0 else pass_fmt)

        # Changed values detail
        ws3 = wb.add_worksheet("Changed_Values")
        _write_df(ws3, value_results.get("changed_values", pd.DataFrame()),
                  lambda r: diff_fmt)

        # Added / removed rows
        ws4 = wb.add_worksheet("Added_Rows")
        _write_df(ws4, value_results.get("added_rows", pd.DataFrame()))

        ws5 = wb.add_worksheet("Removed_Rows")
        _write_df(ws5, value_results.get("removed_rows", pd.DataFrame()))

    buf.seek(0)
    return buf.read()
