
/* SAS Program with PRX Pattern Matching for Variable Mapping */
options validvarname=v7;
options mprint mlogic symbolgen;
libname raw "/biometrics/users/nborade/private/s6166291/rawdata/";
/* Step 1: Define parameters */
%let spec_path = /biometrics/users/nborade/private/s6166291/SDTM/s6166291_final_sdtm_mapping.xlsx;  /* Excel specification */
%let raw_lib = raw;                                /* Raw data library */
%let output_path = /biometrics/users/nborade/private/s6166291/Mapping_Report_%sysfunc(today(),yymmddn8.).xlsx;
%let exclude_vars =%str("RECORDPOSITION" "INSTANCEID" "INSTANCEID_NSV" "INSTANCENAME_NSV" "INSTANCEREPEATNUMBER" "INSTANCEREPEATNUMBER_NSV	MATRIX" "MAXUPDATED" "MAXUPDATED_NSV" "MINCREATED" "
MINCREATED_NSV" "PAGEREPEATNUMBER_NSV" "Z_AGEU" "Z_AGEU_STD" "Z_AGE_REP" "Z_AGE_REP_RAW" "Z_SUBID" "DATAPAGENAME" "FOLDERNAME" "FOLDER" "X_SUBJID" "SUBJID" "STUDYID" "RECORDID"
"SUBJECTID" "SUBJID" "STUDYID" "RECORDID" "DLASTMOD" "INVID" "SCRNID" "DATAPAGEID" "PAGEREPEATNUMBER" "PROJECT" "QUERY" "STUDYENVSITENUMBER");
;                /* Space-separated list of vars to exclude */

/* Step 2: Get active domains from TOC */
proc import datafile="&spec_path"
    out=toc_sheet(where=(upcase(Active)='Y'))
    dbms=xlsx
    replace;
    sheet="toc";
    getnames=yes;
run;


/* Step 3: Get all raw variables (excluding specified vars) */
proc sql;
    create table raw_vars(where=(raw_dataset not in ('BA_PK_INV_PLASMA_QPS' 'BA_PK_INV_URINE_QPS' 'ADM_SDR' 'IE_A1' 'IE_A1_2_GB' 'IE_A2' 'INV'))) as
    select memname as raw_dataset, 
           name as raw_variable
    from dictionary.columns
    where libname = "%upcase(&raw_lib)"
      and upcase(name) not in (%upcase(%sysfunc(compbl(&exclude_vars))))
    order by memname, name;
quit;

data raw_var;
	set raw_vars;
run;


proc contents data=raw._all_ noprint out=rawd;
run;
proc sql noprint;
	create table rawm as	
		select * 
			from dictionary.tables
	where libname= "%upcase(&raw_lib)";
quit;


/* Step 4: Process each active domain with PRX pattern matching */
data all_mappings;
    length domain $32 raw_dataset $32 raw_variable $32 sdtm_variable $32 match_type $20;
    stop;
run;

/* Create macro to process each domain */
%macro process_domains;
    proc sql noprint;
        select count(*) into :domain_count from toc_sheet;
        select dataset into :domain1-:domain%trim(&domain_count) from toc_sheet;
    quit;

    %do i = 1 %to &domain_count;
        %let domain = &&domain&i;
        
        /* Import domain sheet */
        proc import datafile="&spec_path"
            out=domain_data
            dbms=xlsx
            replace;
            sheet="&domain";
            getnames=yes;
        run;
        
        /* Clean input_variables column */
        data domain_data_clean;
			length clean_input $500.;
            set domain_data;
            /* Remove special characters and normalize */
            clean_input = compress(INPUT_VARIABLES, , 'kw');
            /* Convert to uppercase for case-insensitive matching */
            clean_input = upcase(clean_input);
			domain="&domain";
            keep domain variable clean_input mapping_action;
            rename variable = sdtm_variable;
        run;
	        /* Clean input_variables column */
        data domain_data_clean_&domain.;
			length value $500.;
            set domain_data_clean(where=(index(clean_input,'RAW.')));
			do i=1 by 1 while(scan(clean_input,i,',') ne '');
				value = scan(clean_input,i,',');
				dataset = scan(value,2,'.');
				variable = scan(value,3,'.');
				output;
			end;
		run;


    %end;
%mend process_domains;

%process_domains;


data all_mappings;
	set domain_data_clean_:;
run;

proc sort data=all_mappings out=rawmatch nodupkey;
by dataset domain;
run;

proc transpose data=rawmatch out= m;
by dataset;
var domain;
run;

proc sql noprint;
	create table mismatch as	
		select * 
			from raw_vars
	where raw_variable not in (select variable from all_mappings);

	create table mismatch1 as	
		select * 
			from raw_vars a
	where not exists (select 1 from all_mappings b
			where /*upcase(a.raw_variable) like cats('%',upcase(b.variable),'%')
				or*/ upcase(b.variable) like cats('%',upcase(a.raw_variable),'%'));

	create table mismatch2 as	
		select * 
			from mismatch
	where raw_variable not in (select raw_variable from mismatch1);

	create table mismatch_ as	
		select a.*,b.* 
			from raw_vars a
		left join
			all_mappings b
	on a.raw_variable=b.variable;

	create table mismatch_all as	
		select a.*,b.* 
			from raw_vars a
		left join
			all_mappings b
	on upcase(a.raw_variable) like cats('%',upcase(b.variable),'%')
				or upcase(b.variable) like cats('%',upcase(a.raw_variable),'%');
quit;

/*data all_issues;*/
/*	set check_:;*/
/*	if domain not in ('TA' 'TE' 'TI' 'TV' 'TS');*/
/*run;*/

/*proc sort data=all_mappings nodupkey out=a ;*/
/*by raw_dataset raw_variable domain sdtm_variable;*/
/*where match_type='EXACT';*/
/*run;*/
/**/
/*proc transpose data=a out=a1;*/
/*by raw_dataset raw_variable;*/
/*var sdtm_variable;*/
/*run;*/

/* Step 5: Create concatenanted mapping details */
proc sort data=all_mappings ;
	by raw_dataset raw_variable;
run;

data mapping_details;
	length mapping_details $2000;
	retain mapping_details;
	set all_mappings;

	by raw_dataset raw_variable;

	if first.raw_variable then do;
		match_count = 0;
		mapping_details = '';
	end;

	match_count + 1;

	/* Build concatenated string */

	if  mapping_details = '' then 
		mapping_details = cats(domain,'.',sdtm_variable,'(',match_type,')');
	else 
		mapping_details = catx('; ',mapping_details,
						  cats(domain,'.',sdtm_variable,'(',match_type,')'));

/*	mapping_details = compress(mapping_details);*/

	if last.raw_variable then output;

	keep raw_dataset raw_variable match_count mapping_details;
run;



/* Step 6: Create final report */
proc sql;
    create table final_report as
    select 
        r.raw_dataset,
        r.raw_variable,
        case when m.raw_dataset is not null then 'Yes' else 'No' end as is_mapped,
		coalesce(cats('Matches: ',put(m.match_count,3.),'')) as match_count length = 2000,
		coalesce((m.mapping_details),'') as mapping_details length = 2000

    from raw_vars r
    left join mapping_details m
        on r.raw_dataset = m.raw_dataset 
        and r.raw_variable = m.raw_variable
    order by r.raw_dataset, r.raw_variable;
quit;

/* Step 6: Export to Excel */
ods excel file="&output_path" options(
    sheet_interval='NOW'
    sheet_name='Variable Mapping'
    frozen_headers='yes'
    absolute_column_width='20,25,10,60'
);

proc report data=final_report nowd;
    columns raw_dataset raw_variable is_mapped mapping_details;
    define raw_dataset / display 'Raw Dataset';
    define raw_variable / display 'Raw Variable';
    define is_mapped / display 'Mapped?';
    define mapping_details / display 'Mapping Details' flow;
run;

ods excel options(sheet_interval='NOW' sheet_name='Summary');

proc sql;
    create table summary as
    select 
        raw_dataset,
        count(*) as total_vars,
        sum(case when is_mapped='Yes' then 1 else 0 end) as mapped_vars,
        calculated mapped_vars/calculated total_vars*100 as pct_mapped format=5.1,
        case 
            when calculated pct_mapped=100 then 'Complete'
            when calculated pct_mapped>=90 then 'Almost Complete'
            when calculated pct_mapped>=50 then 'Partially Complete'
            else 'Needs Work'
        end as status
    from final_report
    group by raw_dataset
    union all
    select 
        'ALL DATASETS' as raw_dataset,
        count(*) as total_vars,
        sum(case when is_mapped='Yes' then 1 else 0 end) as mapped_vars,
        calculated mapped_vars/calculated total_vars*100 as pct_mapped format=5.1,
        case 
            when calculated pct_mapped=100 then 'Complete'
            when calculated pct_mapped>=90 then 'Almost Complete'
            when calculated pct_mapped>=50 then 'Partially Complete'
            else 'Needs Work'
        end as status
    from final_report;
quit;

proc report data=summary nowd;
    columns raw_dataset total_vars mapped_vars pct_mapped status;
    define raw_dataset / display 'Dataset';
    define total_vars / display 'Total Variables' format=comma8.;
    define mapped_vars / display 'Mapped Variables' format=comma8.;
    define pct_mapped / display '% Mapped' format=5.1;
    define status / display 'Status';
run;

/*ods excel options(sheet_interval='NOW' sheet_name='ISSUE');*/
/**/
/*proc print data=all_issues noobs;*/
/*run;*/


ods excel close;

/* Step 7: Clean up */
proc datasets library=work nolist;
    delete toc_sheet raw_vars all_mappings final_report summary;
run;
quit;
