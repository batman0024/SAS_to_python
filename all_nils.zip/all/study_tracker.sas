/* Define the directory and file pattern */
%let tracker_path = /biometrics/users/nborade/private/test_tracker;
%put &tracker_path;

options mprint mlogic symbolgen;
/* Get list of Excel files in the directory */
filename filelist "&tracker_path";

data study_files;
    length fname $256 fullpath $500;
    did = dopen('filelist');
    if did > 0 then do;
        do i = 1 to dnum(did);
            fname = dread(did, i);
            /* Check for Excel files */
            if upcase(scan(fname, -1, '.')) in ('XLSX', 'XLS') then do;
                fullpath = catx("/", "&tracker_path", fname);
                output;
            end;
        end;
        did = dclose(did);
    end;
    keep fname fullpath;
run;

/* Check if any files were found */
%if %nobs(study_files) = 0 %then %do;
    %put ERROR: No Excel files found in the directory &tracker_path;
    %return;
%end;

%put Found %nobs(study_files) Excel files to process;

/* Debug: Print the list of files to be processed */
proc print data=study_files;
    title "List of Excel Files to Process";
run;

/* Create an empty master dataset with defined structure */
data work.all_combined;
    length Programmer $50 Study $20 Task_Type $15 Output $50 Status $30 Source_File $256;
    stop;
run;

/* Process each file */
%macro process_files_;

 /* Get the number of observations into a macro variable before the loop. */
    proc sql noprint;
        select count(*) into :file_count
        from study_files;
    quit;

    %do i = 1 %to &file_count;
        
        data _null_;
            set study_files (firstobs=&i obs=&i);
            call symputx('current_file', fname);
            call symputx('current_path', fullpath);
        run;
        
        %put Processing file &i: &current_file;
        %put Full path: &current_path;
        
        /* Use XLSX engine to get sheet names */
        libname xlsxLib xlsx "&current_path";
        
        /* Get list of sheets from dictionary tables */
        proc sql noprint;
            create table work.sheets as
            select memname 
            from dictionary.tables
            where libname = 'XLSXLIB' 
              and upcase(memname) in ('SDTM', 'ADAM');
        quit;
        
        libname xlsxLib clear;

 
        /* Get count of relevant sheets */
        %let sheet_count = 0;
        proc sql noprint;
            select count(*) into :sheet_count
            from work.sheets;
        quit;
        
        %if &sheet_count = 0 %then %do;
            %put WARNING: No relevant sheets found in &current_file;
            %put Trying to discover all sheet names...;
            
            /* Discover all sheet names */
            libname xlsxLib xlsx "&current_path";
            proc sql noprint;
                create table work.all_sheets as
                select memname 
                from dictionary.tables
                where libname = 'XLSXLIB';
            quit;
            libname xlsxLib clear;
            
            proc print data=work.all_sheets;
                title "Available sheets in &current_file";
            run;
            
            %continue;
        %end;
        
        %put Found &sheet_count relevant sheets in &current_file;
        
        /* Process each relevant sheet */
        %do j = 1 %to &sheet_count;
            
            data _null_;
                set work.sheets (firstobs=&j obs=&j);
                call symputx('current_sheet', memname);
            run;
            
            %put Importing sheet &j: &current_sheet;
            
            /* Import the specific sheet using XLSX engine */
            libname xlsxLib xlsx "&current_path";
            
            data work.temp_sheet;
                set xlsxLib."&current_sheet"n;
                
                /* Add identifying columns */
                length Task_Type $15 Source_File $256;
                Task_Type = "&current_sheet";
                Source_File = "&current_file";
                
                /* Standardize column names - handle different naming conventions */
                %if %sysfunc(exist(xlsxLib."&current_sheet"n)) %then %do;
                    /* Rename common variations */
/*                    if vname(production_programmer) ne ' ' then  programmer = Programmer;*/
/*                    if vname(validation_programmer) ne ' ' then  Programmer = Programmer;*/
/*                    if vname(domain) ne ' ' then  Outputs = Output;*/
/*                    if vname(title_key) ne ' ' then  STATUS = Status;*/
                %end;
                
                /* Keep only essential columns if they exist */
/*                keep production_programmer validation_programmer domain Study Task_Type Output Status Source_File;*/
            run;
            
            libname xlsxLib clear;
            
            /* Append to the master dataset */
            proc append base=work.all_combined data=work.temp_sheet force;
            run;
            
        %end; /* End sheet loop */
        
    %end; /* End file loop */
    
%mend process_files_;

%process_files_;

/* Alternative approach if above still doesn't work: Hardcode sheet names */
%macro process_files_simple;
    %let sheet_list = SDTM ADAM TFL TFLs;
    
    %do i = 1 %to %nobs(study_files);
        
        data _null_;
            set study_files (firstobs=&i obs=&i);
            call symputx('current_file', fname);
            call symputx('current_path', fullpath);
        run;
        
        %put Processing file &i: &current_file;
        
        %do j = 1 %to %sysfunc(countw(&sheet_list));
            %let current_sheet = %scan(&sheet_list, &j);
            
            %put Trying sheet: &current_sheet;
            
            /* Try to import the sheet */
            %if %sysfunc(fileexist(&current_path)) %then %do;
                proc import datafile="&current_path"
                    out=work.temp_sheet
                    dbms=xlsx
                    replace;
                    sheet="&current_sheet";
                    getnames=yes;
                    guessingrows=max;
                run;
                
                /* Check if import was successful */
                %if %nobs(work.temp_sheet) > 0 %then %do;
                    data work.temp_sheet_clean;
                        set work.temp_sheet;
                        length Task_Type $15 Source_File $256;
                        Task_Type = "&current_sheet";
                        Source_File = "&current_file";
                        keep Programmer Study Task_Type Output Status Source_File;
                    run;
                    
                    proc append base=work.all_combined data=work.temp_sheet_clean force;
                    run;
                    
                    %put Successfully imported from &current_sheet;
                %end;
                %else %do;
                    %put No data found in sheet &current_sheet;
                %end;
            %end;
        %end;
    %end;
%mend process_files_simple;

/* If the first method fails, try the simple method */
%if %nobs(all_combined) = 0 %then %do;
    %put Trying alternative import method...;
    %process_files_simple;
%end;

/* Check if we successfully imported any data */
%if %nobs(all_combined) = 0 %then %do;
    %put ERROR: No data was imported. Check the source files and sheet names.;
    %return;
%end;

%put Successfully imported %nobs(all_combined) records;

/* View the imported data */
proc print data=work.all_combined (obs=20);
    title "First 20 records of imported data";
run;

/* Create analysis datasets */
proc sql;
    create work.status_summary as
    select 
        Study,
        Programmer,
        Status,
        count(*) as Task_Count
    from work.all_combined
    group by Study, Programmer, Status
    order by Study, Programmer, Status;
quit;

/* Create a pivoted view */
proc transpose data=work.status_summary 
               out=work.occupancy_pivot
               prefix=Status_;
    by Study Programmer;
    id Status;
    var Task_Count;
run;

/* Final report */
proc print data=work.occupancy_pivot;
    title "Programmer Occupancy by Study and Status";
run;

