/* ================================================================
   LSTALVDT (Date Last Known Alive) - NO DATE IMPUTATION VERSION
   ================================================================ */

%let sdtmLib = sdtmdata;
%let death_clip_rule = LE;  /* LE or LT */

/* Helper macro: keep only variables existing in dataset */
%macro keep_existing_vars(ds, varlist);
  %local keep i v;
  %let keep=;
  %let i=1;
  %let v=%scan(&varlist, &i, %str( ));
  %do %while(%length(&v));
    %if %sysfunc(varnum(%sysfunc(open(&ds)), &v)) > 0 %then %let keep=&keep &v;
    %let i=%eval(&i+1);
    %let v=%scan(&varlist, &i, %str( ));
  %end;
  &keep
%mend;

/* Helper macro: convert only full ISO8601 dates (YYYY-MM-DD) */
%macro dtc_full(dtc, out=dt);
  if length(strip(&dtc)) = 10 then &out = input(&dtc, yymmdd10.);
  else &out = .;
%mend;

/* Macro to stack dates from domains with conditions */
%macro stack(dom=, ds=, vars=, out=, where=);

  %let use_vars = %keep_existing_vars(&ds, &vars);
  %if %length(&use_vars)=0 %then %do; %return; %end;

  data &out;
    set &ds %if %length(&where) %then (where=(&where)); ;
    length dt_source $40;
    array A {*} $ &use_vars;

    do i = 1 to dim(A);
      %dtc_full(A[i], out=dt);
      if not missing(dt) then do;
        dt_source = cats("&dom..", vname(A[i]));
        output;
      end;
    end;

    keep USUBJID dt dt_source;
    format dt date9.;
  run;

%mend;

/* ---------------------------------------------------------------
   STACK ALL DOMAINS WITH NEW FILTER RULES
   --------------------------------------------------------------- */

/* AE � exclude fatal events and grade 5 */
%stack(
  dom=AE,
  ds=&sdtmLib..AE,
  vars=AESTDTC AEENDTC,
  out=__AE,
  where=%str(aetoxgr ne "5" and upcase(coalescec(aeout,"")) ne "FATAL")
);

/* CM � no filters */
%stack(dom=CM, ds=&sdtmLib..CM, vars=CMSTDTC CMENDTC, out=__CM);

/* DS � only selected DSSCAT values */
%stack(
  dom=DS,
  ds=&sdtmLib..DS,
  vars=DSSTDTC,
  out=__DS,
  where=%str(upcase(DSSCAT) in ("CONSENTS","ENROLLMENT","WITHDRAWAL OF CONSENTS"," "))
);

/* EG � completed ECG only */
%stack(
  dom=EG,
  ds=&sdtmLib..EG,
  vars=EGDTC,
  out=__EG,
  where=%str(upcase(egstat) ne "NOT DONE")
);

/* EX � no filters */
%stack(dom=EX, ds=&sdtmLib..EX, vars=EXSTDTC EXENDTC, out=__EX);

/* LB � completed labs */
%stack(
  dom=LB,
  ds=&sdtmLib..LB,
  vars=LBDTC,
  out=__LB,
  where=%str(upcase(lbstat) ne "NOT DONE")
);

/* PR � no filters */
%stack(dom=PR, ds=&sdtmLib..PR, vars=PRSTDTC, out=__PR);

/* RS � completed assessments */
%stack(
  dom=RS,
  ds=&sdtmLib..RS,
  vars=RSDTC,
  out=__RS,
  where=%str(upcase(rsstat) ne "NOT DONE")
);

/* TR � no filters */
%stack(dom=TR, ds=&sdtmLib..TR, vars=TRDTC, out=__TR);

/* VS � completed vital signs */
%stack(
  dom=VS,
  ds=&sdtmLib..VS,
  vars=VSDTC,
  out=__VS,
  where=%str(upcase(vsstat) ne "NOT DONE")
);

/* RP � no filters */
%stack(dom=RP, ds=&sdtmLib..RP, vars=RPDTC, out=__RP);

/* EC � no filters */
%stack(dom=EC, ds=&sdtmLib..EC, vars=ECSTDTC, out=__EC);

/* SV � no filters */
%stack(dom=SV, ds=&sdtmLib..SV, vars=SVSTDTC SVENDTC, out=__SV);

/* SM � no filters */
%stack(dom=SM, ds=&sdtmLib..SM, vars=SMSTDTC, out=__SM);

/* ---------------------------------------------------------------
   GATHER ALL DATES
   --------------------------------------------------------------- */
data _all;
  set __:;
run;

proc sort data=_all;
	by dt;
run;
/* Final raw LSTALVDT */
proc sql;
  create table _max as
  select USUBJID,
         max(dt) as LSTALVDT format=date9. label="Last Known Alive Date"
  from _all
  group by USUBJID;
quit;

/* ---------------------------------------------------------------
   APPLY DEATH CLIP RULE
   --------------------------------------------------------------- */
data dm;
  set &sdtmLib..DM(keep=USUBJID DTHDTC);
  %dtc_full(DTHDTC, out=dth);
run;

/* Decide the clipping expression once, based on the macro parameter */


/* Then use that expression in a clean CASE block */
proc sql;
  create table LSTALVDT as
  select a.USUBJID,a.LSTALVDT as valdt,d.dthdtc,d.dth format=date9. ,e.LSTALVDT format=date9.,x.domain,x.visit,x.datevar,x.dt

  from _max as a
  left join dm  as d
    on a.USUBJID = d.USUBJID

left join
	adamdata.adsl e
	    on a.USUBJID = e.USUBJID	

left join
	(select x_subjid as usubjid,domain,visit, datevar ,dt
		from f
		where visit ne 'DEATH'
		group by x_subjid
		having dt = max(dt)
		) x
	    on a.USUBJID = x.USUBJID	
	
  ;
quit;




proc sql noprint;
	create table svlst as	
		select distinct a.usubjid, a.dt
			from __sv a
			group by usubjid
			having dt=max(dt);

	create table svlst2 as	
		select a.*,b.lstsvdt format = date9.
			from svlst a
			left join
			adamdata.adsl b
	on a.usubjid=b.usubjid;
quit;


proc sql noprint;
	create table lblst as	
		select distinct a.usubjid, a.dt
			from __lb a
			group by usubjid
			having dt=max(dt);

	create table lblst2 as	
		select a.*,b.lstlbdt format = date9.
			from lblst a
			left join
			adamdata.adsl b
	on a.usubjid=b.usubjid;
quit;

proc sort data=sdtmdata.lb nodupkey out=xlb(keep=usubjid lbdtc lbstat);
by usubjid descending lbdtc;
run;
