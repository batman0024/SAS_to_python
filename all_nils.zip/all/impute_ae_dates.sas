/* start of header *********************************************************************************

Program Name:      impute_ae_dates.sas
Program Author:    Nilesh Borade (nborade)
Program Purpose:   Impute partial/missing AE start and stop dates using the rules

*********************************************************************************** end of header *//*---------------------------------------------------------------
  Macro: %impute_ae_dates
  Purpose:
    Impute partial/missing AE start and stop dates using the rules
    first-dose date as reference.

  Inputs:
    IN=        input dataset
    OUT=       output dataset
    STARTC=    character start date variable (e.g., AESTDTC), ISO-like
    STOPC=     character stop date variable (e.g., AEENDTC), ISO-like
    TRTC=      character first-dose date (e.g., TRTSDTC), ISO-like
               (if you have a numeric TRTSDT already, pass TRTC= and
                add TRTDN= variable below.)
    TRTDN=     numeric first-dose date (optional; if provided it wins)
    PREFIX=    prefix for new variables (default=AE)

  Outputs (added to OUT):
    &PREFIX._STARTDT   (numeric SAS date, imputed)
    &PREFIX._STARTDTC  (char, ISO yyyy-mm-dd)
    &PREFIX._STOPDT    (numeric SAS date, imputed if needed)
    &PREFIX._STOPDTC   (char, ISO yyyy-mm-dd; blank if ongoing)
    &PREFIX._STOP_IMPFL  ('M','Y','')
    &PREFIX._STOP_ONGOING ('Y' or '')
    &PREFIX._START_RULE (1,2,3,4)
    &PREFIX._REL_STOP_TO_TRT ('LT','GE','AMB','MISS')

  Good practices used:
    - pure data step (no SQL), defensive parsing, no magic constants,
      explicit lengths, comments, and no overwrite of input variables.
	- CLEAN=DROP|KEEP (default DROP). When DROP, removes all intermediate
      scratch vars from &OUT.
----------------------------------------------------------------*/

%macro impute_ae_dates(
    in=
  , out=
  , startc=AESTDTC
  , stopc =AEENDTC
  , trtsdt=TRTSDT
  , prefix=AE
  , clean=DROP
);

/* ===== Compile-time validation ===== */
%local _lib _mem _clean_upcase _has_trtsdt _has_startc _has_stopc _drop_list;
%let _clean_upcase=%upcase(&clean);

/* Trim defensively */
%let in=%sysfunc(compbl(&in));
%let out=%sysfunc(compbl(&out));
%let startc=%sysfunc(compbl(&startc));
%let stopc=%sysfunc(compbl(&stopc));
%let trtsdt=%sysfunc(compbl(&trtsdt));

%if %sysevalf(%superq(in)=,boolean) %then %do; %put ERROR: [impute_ae_dates] IN= is required.; %abort cancel; %end;
%if not %sysfunc(exist(&in)) %then %do; %put ERROR: [impute_ae_dates] IN=&in does not exist.; %abort cancel; %end;
%if %sysevalf(%superq(trtsdt)=,boolean) %then %do; %put ERROR: [impute_ae_dates] TRTSDT is required and must be a numeric SAS date variable.; %abort cancel; %end;

%let _lib=%upcase(%scan(&in,1,.));
%let _mem=%upcase(%scan(&in,2,.));
%if %sysevalf(%superq(_mem)=,boolean) %then %do; %let _mem=&_lib; %let _lib=WORK; %end;

proc sql noprint;
  select sum(upcase(name)=upcase("&trtsdt")) into :_has_trtsdt
    from dictionary.columns where libname="&_lib" and memname="&_mem";
  select sum(upcase(name)=upcase("&startc")) into :_has_startc
    from dictionary.columns where libname="&_lib" and memname="&_mem";
  select sum(upcase(name)=upcase("&stopc")) into :_has_stopc
    from dictionary.columns where libname="&_lib" and memname="&_mem";
quit;

%if &_has_trtsdt=0 %then %do; %put ERROR: [impute_ae_dates] Variable &trtsdt not found in &in..; %abort cancel; %end;
%if &_has_startc=0 %then %do; %put ERROR: [impute_ae_dates] Variable &startc not found in &in..; %abort cancel; %end;
%if &_has_stopc=0 %then %do; %put ERROR: [impute_ae_dates] Variable &stopc not found in &in..; %abort cancel; %end;

/* Scratch vars optionally dropped at OUTPUT */
%let _drop_list=
  __ai_startc __ai_stopc
  __ai_start_digits __ai_stop_digits
  __ai_trt_num __ai_trt_lev
  __ai_s_lev __ai_e_lev
  __ai_s_y __ai_s_m __ai_s_d __ai_e_y __ai_e_m __ai_e_d
  __ai_s_min __ai_s_max __ai_e_min __ai_e_max
  __ai_same_y __ai_same_ym __ai_rel
  __ai_s_has_time __ai_e_has_time
  __ai_s_H __ai_s_MIN __ai_s_SEC __ai_e_H __ai_e_MIN __ai_e_SEC
  __ai_re_time __ai_pos __ai_len __ai_token
;

%put NOTE: impute_ae_dates v1.12: IN=&in OUT=&out STARTC=&startc STOPC=&stopc TRTSDT=&trtsdt CLEAN=&_clean_upcase;

/* =============================================================================
   DATA STEP
   - Drop-on-read any prior AST*AEN* outputs and any __ai_* scratch vars.
   - Use unique scratch names (__ai_*) to avoid collisions altogether.
   ========================================================================== */
data &out
  %if "&_clean_upcase"="DROP" %then %do; (drop=&_drop_list) %end;
;
  set &in

  ;

  /* Normalize and parse */
  length __ai_startc __ai_stopc $60; 
  __ai_startc = strip(&startc); 
  __ai_stopc  = strip(&stopc );

  /* Split date-part directly if ISO present, else use digits */
  length __ai_start_digits __ai_stop_digits $32;
  __ai_start_digits = compress(__ai_startc, , 'kd');
  __ai_stop_digits  = compress(__ai_stopc , , 'kd');

  /* First-dose (numeric date) */
  format __ai_trt_num yymmdd10.; length __ai_trt_lev $4; __ai_trt_lev='MISS';
  __ai_trt_num = &trtsdt; 
  if not missing(__ai_trt_num) then __ai_trt_lev='FULL';

  /* Scratch date mins/maxs: initialize explicitly */
  length __ai_s_lev __ai_e_lev $4;
  length __ai_s_y __ai_s_m __ai_s_d __ai_e_y __ai_e_m __ai_e_d 8;
  length __ai_s_min __ai_s_max __ai_e_min __ai_e_max 8;
  format __ai_s_min __ai_s_max __ai_e_min __ai_e_max yymmdd10.;
  call missing(__ai_s_lev,__ai_e_lev,__ai_s_y,__ai_s_m,__ai_s_d,__ai_e_y,__ai_e_m,__ai_e_d,
               __ai_s_min,__ai_s_max,__ai_e_min,__ai_e_max);

  /* Helper: extract an ISO date-part if present at the start (yyyy-mm-dd...) */
  /* If not present, fall back to digits parsing */
  length __ai_datepart $10;
  /* START */
  __ai_datepart = ifc(prxmatch('/^\d{4}-\d{2}-\d{2}/', __ai_startc),
                      substr(__ai_startc,1,10), '');
  if not missing(__ai_datepart) then do;
    __ai_s_y = input(substr(__ai_datepart,1,4),best.);
    __ai_s_m = input(substr(__ai_datepart,6,2),best.);
    __ai_s_d = input(substr(__ai_datepart,9,2),best.);
    __ai_s_lev='FULL';
    __ai_s_min=mdy(__ai_s_m,__ai_s_d,__ai_s_y); __ai_s_max=__ai_s_min;
  end;
  else do; /* fallback to digits */
    if missing(__ai_start_digits) then do; __ai_s_lev='MISS'; end;
    else if lengthn(__ai_start_digits) >= 8 then do;
      __ai_s_y = input(substr(__ai_start_digits,1,4),best.);
      __ai_s_m = input(substr(__ai_start_digits,5,2),best.);
      __ai_s_d = input(substr(__ai_start_digits,7,2),best.);
      __ai_s_lev='FULL';
      __ai_s_min=mdy(__ai_s_m,__ai_s_d,__ai_s_y); __ai_s_max=__ai_s_min;
    end;
    else if lengthn(__ai_start_digits)=6 then do;
      __ai_s_y = input(substr(__ai_start_digits,1,4),best.);
      __ai_s_m = input(substr(__ai_start_digits,5,2),best.);
      __ai_s_lev='YM';
      __ai_s_min=mdy(__ai_s_m,1,__ai_s_y);
      __ai_s_max=intnx('month',__ai_s_min,1,'B')-1;
    end;
    else if lengthn(__ai_start_digits)=4 then do;
      __ai_s_y = input(substr(__ai_start_digits,1,4),best.);
      __ai_s_lev='Y';
      __ai_s_min=mdy(1,1,__ai_s_y);
      __ai_s_max=mdy(12,31,__ai_s_y);
    end;
    else do; __ai_s_lev='MISS'; end;
  end;

  /* STOP */
  __ai_datepart = ifc(prxmatch('/^\d{4}-\d{2}-\d{2}/', __ai_stopc),
                      substr(__ai_stopc,1,10), '');
  if not missing(__ai_datepart) then do;
    __ai_e_y = input(substr(__ai_datepart,1,4),best.);
    __ai_e_m = input(substr(__ai_datepart,6,2),best.);
    __ai_e_d = input(substr(__ai_datepart,9,2),best.);
    __ai_e_lev='FULL';
    __ai_e_min=mdy(__ai_e_m,__ai_e_d,__ai_e_y); __ai_e_max=__ai_e_min;
  end;
  else do;
    if missing(__ai_stop_digits) then do; __ai_e_lev='MISS'; end;
    else if lengthn(__ai_stop_digits) >= 8 then do;
      __ai_e_y = input(substr(__ai_stop_digits,1,4),best.);
      __ai_e_m = input(substr(__ai_stop_digits,5,2),best.);
      __ai_e_d = input(substr(__ai_stop_digits,7,2),best.);
      __ai_e_lev='FULL';
      __ai_e_min=mdy(__ai_e_m,__ai_e_d,__ai_e_y); __ai_e_max=__ai_e_min;
    end;
    else if lengthn(__ai_stop_digits)=6 then do;
      __ai_e_y = input(substr(__ai_stop_digits,1,4),best.);
      __ai_e_m = input(substr(__ai_stop_digits,5,2),best.);
      __ai_e_lev='YM';
      __ai_e_min=mdy(__ai_e_m,1,__ai_e_y);
      __ai_e_max=intnx('month',__ai_e_min,1,'B')-1;
    end;
    else if lengthn(__ai_stop_digits)=4 then do;
      __ai_e_y = input(substr(__ai_stop_digits,1,4),best.);
      __ai_e_lev='Y';
      __ai_e_min=mdy(1,1,__ai_e_y);
      __ai_e_max=mdy(12,31,__ai_e_y);
    end;
    else do; __ai_e_lev='MISS'; end;
  end;

  /* One-time debug trap if FULL but computed min still 0 (should not happen) */
  if _N_=1 then do;
    if __ai_s_lev='FULL' and __ai_s_min=0 then
      put "WARN: __ai_s_min is 0 on first row despite FULL. start=" __ai_startc= __ai_start_digits= __ai_s_y= __ai_s_m= __ai_s_d=;
    if __ai_e_lev='FULL' and __ai_e_min=0 then
      put "WARN: __ai_e_min is 0 on first row despite FULL. stop=" __ai_stopc= __ai_stop_digits= __ai_e_y= __ai_e_m= __ai_e_d=;
  end;

  /* ---- STOP imputation (unchanged rules) ---- */
  length &prefix._STOP_IMPFL $1 &prefix._STOP_ONGOING $1 &prefix._STOPDTC $10;
  format &prefix._STOPDT yymmdd10.;
  &prefix._STOP_IMPFL=''; &prefix._STOP_ONGOING='';

  if __ai_e_lev='FULL' then do; &prefix._STOPDT = __ai_e_min; &prefix._STOPDTC = put(&prefix._STOPDT,yymmdd10.); end;
  else if __ai_e_lev='YM' then do; &prefix._STOPDT = __ai_e_max; &prefix._STOPDTC=put(&prefix._STOPDT,yymmdd10.); &prefix._STOP_IMPFL='M'; end;
  else if __ai_e_lev='Y' then do; &prefix._STOPDT = mdy(12,31,__ai_e_y); &prefix._STOPDTC=put(&prefix._STOPDT,yymmdd10.); &prefix._STOP_IMPFL='Y'; end;
  else do; &prefix._STOPDT=.; &prefix._STOPDTC=''; &prefix._STOP_ONGOING='Y'; end;

  /* Relation of STOP to TRT using ranges (AMB treated as GE) */
  length &prefix._REL_STOP_TO_TRT $4;  &prefix._REL_STOP_TO_TRT='MISS';
  if __ai_trt_lev='FULL' then do;
    if __ai_e_lev='MISS' then &prefix._REL_STOP_TO_TRT='MISS';
    else if __ai_e_max < __ai_trt_num then &prefix._REL_STOP_TO_TRT='LT';
    else if __ai_e_min >= __ai_trt_num then &prefix._REL_STOP_TO_TRT='GE';
    else &prefix._REL_STOP_TO_TRT='AMB';
  end;

  /* ---- START imputation (unchanged rules) ---- */
  length &prefix._START_RULE 8 &prefix._STARTDTC $10;
  format &prefix._STARTDT yymmdd10.;
  &prefix._START_RULE = .;  &prefix._STARTDT = .;  &prefix._STARTDTC = '';

  length __ai_same_y __ai_same_ym 3;
  __ai_same_y  = (__ai_s_lev in ('Y','YM','FULL')  and __ai_trt_lev='FULL' and __ai_s_y = year(__ai_trt_num));
  __ai_same_ym = (__ai_s_lev in ('YM','FULL')      and __ai_trt_lev='FULL' and __ai_s_y = year(__ai_trt_num) and __ai_s_m = month(__ai_trt_num));

  length __ai_rel $3; __ai_rel='MISS';
  if __ai_trt_lev='FULL' then do;
    if &prefix._REL_STOP_TO_TRT='LT' then __ai_rel='LT';
    else if &prefix._REL_STOP_TO_TRT in ('GE','AMB','MISS') then __ai_rel='GE';
  end;

  if __ai_s_lev='FULL' then do; 
    &prefix._STARTDT  = __ai_s_min;
    &prefix._STARTDTC = put(&prefix._STARTDT,yymmdd10.);
    &prefix._START_RULE = 0;
  end;
  else if __ai_s_lev='YM' then do;
    if __ai_trt_lev='FULL' and __ai_same_ym and __ai_rel ne 'LT' then do;
      &prefix._STARTDT = __ai_trt_num; &prefix._START_RULE = 1;
    end;
    else do;
      &prefix._STARTDT = mdy(__ai_s_m,1,__ai_s_y); &prefix._START_RULE = 2;
    end;
    &prefix._STARTDTC = put(&prefix._STARTDT,yymmdd10.);
  end;
  else if __ai_s_lev='Y' then do;
    if __ai_trt_lev='FULL' and __ai_same_y and __ai_rel ne 'LT' then do;
      &prefix._STARTDT = __ai_trt_num; &prefix._START_RULE = 1;
    end;
    else do;
      &prefix._STARTDT = mdy(1,1,__ai_s_y); &prefix._START_RULE = 3;
    end;
    &prefix._STARTDTC = put(&prefix._STARTDT,yymmdd10.);
  end;
  else do; /* START missing */
    if __ai_trt_lev='FULL' then do;
      if __ai_rel='LT' and not missing(__ai_e_y) then do;
        &prefix._STARTDT = mdy(1,1,__ai_e_y);  &prefix._START_RULE = 4;
      end;
      else do;
        &prefix._STARTDT = __ai_trt_num;       &prefix._START_RULE = 1;
      end;
      &prefix._STARTDTC = put(&prefix._STARTDT,yymmdd10.);
    end;
    else do;
      if not missing(__ai_e_y) then do;
        &prefix._STARTDT = mdy(1,1,__ai_e_y);  &prefix._START_RULE = 4;
        &prefix._STARTDTC = put(&prefix._STARTDT,yymmdd10.);
      end;
    end;
  end;

  if &prefix._STOP_ONGOING='Y' then &prefix._STOPDTC='';

  /* ---- Time extraction (no time imputation) ---- */
  length __ai_s_has_time __ai_e_has_time 3;
  length __ai_s_H __ai_s_MIN __ai_s_SEC __ai_e_H __ai_e_MIN __ai_e_SEC 8;
  length __ai_token $24;
  retain __ai_re_time;
  if _N_=1 then __ai_re_time = prxparse('/\b(\d{1,2}):(\d{2})(?::(\d{2}))?\b/');

  if __ai_re_time>0 then do;
    call prxsubstr(__ai_re_time, __ai_startc, __ai_pos, __ai_len);
    if __ai_pos>0 then do;
      __ai_token=substr(__ai_startc,__ai_pos,__ai_len);
      __ai_s_H  =input(scan(__ai_token,1,':'),best.);
      __ai_s_MIN=input(scan(__ai_token,2,':'),best.);
      if missing(scan(__ai_token,3,':')) then __ai_s_SEC=0; else __ai_s_SEC=input(scan(__ai_token,3,':'),best.);
      __ai_s_has_time=1;
    end; else do; __ai_s_H=.; __ai_s_MIN=.; __ai_s_SEC=.; __ai_s_has_time=0; end;
  end; else do; __ai_s_H=.; __ai_s_MIN=.; __ai_s_SEC=.; __ai_s_has_time=0; end;

  if __ai_re_time>0 then do;
    call prxsubstr(__ai_re_time, __ai_stopc, __ai_pos, __ai_len);
    if __ai_pos>0 then do;
      __ai_token=substr(__ai_stopc,__ai_pos,__ai_len);
      __ai_e_H  =input(scan(__ai_token,1,':'),best.);
      __ai_e_MIN=input(scan(__ai_token,2,':'),best.);
      if missing(scan(__ai_token,3,':')) then __ai_e_SEC=0; else __ai_e_SEC=input(scan(__ai_token,3,':'),best.);
      __ai_e_has_time=1;
    end; else do; __ai_e_H=.; __ai_e_MIN=.; __ai_e_SEC=.; __ai_e_has_time=0; end;
  end; else do; __ai_e_H=.; __ai_e_MIN=.; __ai_e_SEC=.; __ai_e_has_time=0; end;

  /* ---- Final outputs (ISO formats) ---- */
  length ASTDTF AENDTF $1;
  format ASTDT  e8601da10.  AENDT  e8601da10.;
  format ASTTM  e8601tm8.   AENTM  e8601tm8.;
  format ASTDTM e8601dt20.  AENDTM e8601dt20.;

  /* START */
  if &prefix._START_RULE=0 then do; 
    ASTDT = __ai_s_min;
    if __ai_s_has_time then do; ASTTM=hms(__ai_s_H,__ai_s_MIN,__ai_s_SEC); ASTDTM=dhms(ASTDT,__ai_s_H,__ai_s_MIN,__ai_s_SEC); end;
    else do; ASTTM=.; ASTDTM=.; end;
    ASTDTF='';
  end;
  else do; 
    ASTDT = &prefix._STARTDT;
    if __ai_s_has_time then do; ASTTM=hms(__ai_s_H,__ai_s_MIN,__ai_s_SEC); ASTDTM=dhms(ASTDT,__ai_s_H,__ai_s_MIN,__ai_s_SEC); end;
    else do; ASTTM=.; ASTDTM=.; end;
    if __ai_s_lev='YM' then ASTDTF='D';
    else if __ai_s_lev='Y' then ASTDTF='M';
    else if __ai_s_lev='MISS' then ASTDTF='Y';
    else ASTDTF='';
  end;

  /* STOP */
  if &prefix._STOP_ONGOING='Y' then do;
    AENDT=.; AENTM=.; AENDTM=.; AENDTF='';
  end;
  else if __ai_e_lev='FULL' then do; 
    AENDT = __ai_e_min;
    if __ai_e_has_time then do; AENTM=hms(__ai_e_H,__ai_e_MIN,__ai_e_SEC); AENDTM=dhms(AENDT,__ai_e_H,__ai_e_MIN,__ai_e_SEC); end;
    else do; AENTM=.; AENDTM=.; end;
    AENDTF='';
  end;
  else do; 
    AENDT = &prefix._STOPDT;
    if __ai_e_has_time then do; AENTM=hms(__ai_e_H,__ai_e_MIN,__ai_e_SEC); AENDTM=dhms(AENDT,__ai_e_H,__ai_e_MIN,__ai_e_SEC); end;
    else do; AENTM=.; AENDTM=.; end;
    if __ai_e_lev='YM' then AENDTF='D';
    else if __ai_e_lev='Y' then AENDTF='M';
    else AENDTF='';
  end;

  	if length(aestdtc)>10 then
		do;
			astdtm=input(aestdtc,e8601dt20.);
			astdt = input(aestdtc,e8601da10.);
			asttm = input(scan(aestdtc,2,"T"),e8601tm8.);
		end;
	else if length(aestdtc)=10 then
		do;
			astdt = input(aestdtc,e8601da10.);
		end;

	if length(aeendtc)>10 then
		do;
			aendtm = input(aeendtc,e8601dt20.);
			aendt = input(aeendtc,e8601da10.);
			aentm = input(scan(aeendtc,2,"T"),e8601tm8.);
		end;
	else if length(aeendtc) = 10 then
		do;
			aendt=input(aeendtc,e8601da10.);
		end;
run;
%mend impute_ae_dates;