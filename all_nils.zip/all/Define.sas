proc datasets lib=work kill nolist;run;
/**************************************************************************************************************/;
/*****PURPOSE: PURPOSE OF THIS MACRO IS TO CREAT VARIABLE, VALUE_LEVEL AND WHERE_CLAUSE TAB OF SPECIFICATION,
  WHICH WILL HELP US TO UPDATE OUR SPECIFICATION PRIOR TO P21 VALIDATION************************/
/**PREREQUISITE:AS THIS MACRO PULLS INFORMATION FROM SAS DATASETS, ALL THE REQUIRED DOMAINS MUST BE AVAILABLE 
IN THE ADAM OR SDTM LIBRARY, RESPECTIVELY*****************************************************/
/***REQUIREMENT:MACRO HAS ONLY 2 INPUTS, ONE IS LIBRARY, FOR WHICH RESULTS ARE EXPECTED [ADAM OR SDTM]
SECOND INPUT IS OUTPATH, THIS IS THE PATH WHERE MACRO WILL STORE ITS OUTPUT FILE IN EXCEL FORMAT
IN CASE OF CHILTERN STUDY USE [&projroot./...] AND IN CASE OF COVANCE STUDY USE [&base2./...]
/**************************************************************************************************************/;

%macro define(lib=,outpath=);

/*****TO GET LIST OF VARIABLES AND OTHER DETAILS FOR ALL DOMAINS IN LIBRARY********/
proc sql;
create table columns as
select name as variable
,memname as domain
,length
,label
/**As data contains only char & text data type, 
we have to create datetype which variable label contains 'Date'********/
,(case 
when strip(type)='num' then 'integer'
when strip(type)='char' and index(label,'Date')>0 then 'datetime'
else 'text'
end) as data_type
,format
from dictionary.columns
where libname = upcase("&lib.")
;
quit;
data columns;
set columns;
if index(domain,'_')>0 then delete;
run;

%if &lib.=ADAM %then %do;
/****To get AVAL/AVALC value in case of ADaM****/;
proc sort data=columns; by domain data_type;run;

proc transpose data=columns(where=(variable?'AVAL')) out=aval(drop=_name_ _label_);
by domain data_type;
var variable;
run;
proc sort data=aval nodupkey;
by domain;
run;
data values(keep=domain orres test variable data_type);
set aval;
orres=coalescec(col1,col2);
test = 'PARAM';
variable='PARAMCD';
run;
%end;

%else %do;
/****TO GET ALL DISTINCT TESTCD's AND SUPP VALUES**********/
proc sql;
create table values as
select domain, variable
,(case
when index(variable,'TESTCD')>0 then compress(upcase(domain)||'ORRES') 
when index(variable,'QNAM')>0 or index(variable,'PARMCD')>0  then 'QVAL'
when index(variable,'PARAMCD')>0 then 'AVAL'
else ""
end) as orres

,(case
when index(variable,'TESTCD')>0 then compress(upcase(domain)||'TEST') 
when index(variable,'QNAM')>0 or index(variable,'PARMCD')>0  then 'QLABEL'
when index(variable,'PARAMCD')>0 then 'PARAM'
else ""
end) as test

from columns
where index(variable,'TESTCD')>0 or index(variable,'QNAM')>0 or 
  index(variable,'PARMCD')>0 or index(variable,'PARAMCD')>0 
; 
quit;

%end;

/***Creating macro to make valuelevel tab from SDTM '--TESTCD' as well SUPP 'QNAM' variable****/

%macro uniq(variable=,test=,orres=,domain=,data_type=);
proc sql;
create table _&domain. as 
select distinct(&variable.) as value
/* ,length(strip("&domain."||'ORRES')) as length*/
,upcase("&domain.") as dataset
,(case
when index("&variable.",'TESTCD')>0 then upcase("&domain.")||'ORRES' 
when index("&variable.",'QNAM')>0 or index("&variable.",'PARMCD')>0 then 'QVAL'
when index("&variable.",'PARAMCD')>0  then "&orres."
else ""
end) as variable

,&test. as test
,&orres. as orres
/* ,(case*/
/* when index("&variable.",'TESTCD')>0 then length(strip("&domain."||'ORRES')) */
/* when index("&variable.",'QNAM')>0 then length(QVAL)*/
/* else .*/
/* end) as length*/

,(case
when index("&variable.",'TESTCD')>0 then upcase("&domain.")||'.'||upcase("&domain.")||'TESTCD'||'.'|| &variable. 
when index("&variable.",'QNAM')>0 or index("&variable.",'PARMCD')>0 then upcase("&domain.")||'.'||'QNAM'||'.'|| &variable.
when index("&variable.",'PARAMCD')>0 then upcase("&domain.")||'.'||'PARAMCD'||'.'|| &variable.
else ""
end) as where_clau
from &lib..&domain.
;
quit;

/*proc sort data=_&domain. nodupkey;by dataset variable where_clau value;run;*/
data wh_&domain.;
set _&domain.;
if not missing(where_clau);
keep dataset variable where_clau value;
run;
proc sort data=wh_&domain. nodupkey;by dataset variable where_clau value;run;

data a(where=(not missing(data_type)));
length data_type $12.;
set _&domain.;

num = input(orres,?? best.);
   if (not missing(num)) then do;
      IsNum    = 1;
      IsNum2   = 1;
      IsInt    = (int(num) = num);
      IsFloat  = (abs(num - int(num)) gt 0);
      IsNotNeg = (num ge 0);
      IsPos    = (num gt 0);
      t1=num-int(num);
   end;

   if IsFloat = 1 then do;
   sig=lengthn(scan(put(orres,20.12),2,'.'));
data_type = 'float';
   end;

   if IsNum = 1 and IsFloat = 1 then do;
   len=lengthn(scan(put(orres,20.12),1,'.'));
   end;

   else if IsNum = 1 and IsFloat ^= 1 and num ^= 0  then do;
   len=int(log10(abs(num)))+1;
data_type = 'integer';
   end;

   else if IsNum ^= 1  then do;
   len=lengthn(orres);
data_type = 'text';
   end;

   if index(test,'Date')>0 then do;
if length(orres)<11 then data_type = 'Date';
else data_type = 'Datetime';
len =.;
end;

   if not missing(sig) then 
   format = catx('.',put(len,8.),put(sig,8.));
drop IS:;

keep dataset variable where_clau data_type len sig format;
run;

proc sort data=a;
by dataset variable where_clau data_type  descending len  ;
run;

data  _&domain.(where=(not missing(where_clau)));
retain dataset variable where_clau data_type len sig format;
set a;
by dataset variable where_clau data_type descending len ;
if first.where_clau;
run;
/*proc sort data=_&domain. nodupkey;by dataset variable where_clau ;run;*/

%mend;

/****running all data through above macro using CALL EXECUTE TOcreate domain wise datasets***/;
data test;
%if %index(%upcase(&lib.),AD)>0 %then %do;
set values;
%end;
%else %if %index(%upcase(&lib.),AD)=0 %then %do;
set values(where=(domain not in ('TS' 'TI')));
%end;
/*   rc = dosubl(cats('SYSECHO "OBS N=',_n_,', DOMAIN=' ,domain,'";'));*/
CALL EXECUTE('%uniq(variable='||variable||',test='||test||'
,orres='||orres||',domain='||domain||',data_type='||data_type||');');
/* x=sleep(1,10);*/ /***suspends execution of a DATA step for a specified number of seconds***/
run;

/*****Appending all domain datasets to create on single dataset*****/; 

data fin1(keep=order dataset variable where_clau data_type len sig format);
retain order dataset variable where_clau data_type len sig format;
length dataset $15. variable data_type $40. where_clau  $100. ;
set _:;
by dataset;
if first.dataset then order=1;
else order + 1;
run;

data fin;
retain id dataset var comparator value;
length where_clau  $100. dataset $15. variable $40.  /*test $500. orres $500.*/;
set wh:;
%if &lib.=ADAM %then %do;
var='PARAMCD';
%end;
%else %if &lib.=SDTM %then %do;
var=variable;
%end;
comparator='EQ';
id=where_clau;
keep id dataset var comparator value;
run;


/***TO OUTPUT OBTAINED RESULTS IN EXCEL FILE*****/;
/*ods excel file="/sasdata/pds/sandbox/SAS Training/User/nborade/37444/sdtm/DEFINE/variables.xlsx" style=minimal;*/

ods excel file="&outpath./Define_&lib..xlsx" options(sheet_name="Variable" autofilter='all') style=minimal ;
proc print data=columns noobs;
run;
ods excel options(sheet_name="Value_Level" autofilter='all') style=minimal ;
proc print data=fin1 noobs;
run;
ods excel options(sheet_name="Where_Clause" autofilter='all') style=minimal ;
proc print data=fin noobs;
run;
ods excel close;

%mend;

goptions device=actximg;
options mprint mlogic symbolgen;

%define(lib=SDTMDATA,outpath=%str(/biometrics/users/nborade/private/s409-5696));
/*%define(lib=ADAM);*/

/* in case of Covance grid */
/*%define(lib=SDTM,outpath=%str(&base2./documentation/Other documents));*/
