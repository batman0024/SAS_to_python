*--------------------------------------*
| Imports excel table to SAS data.     |
*--------------------------------------*;

%macro convertxls(path=,datasheet=,col=,prefix=);

*--------------------------------------*
| Capture Table of Contents            |
*--------------------------------------*;
options validvarname=v7;

proc import out=&prefix.toc(where=(&col ne ''))
       datafile="&path"
       dbms=xlsx replace; sheet="&datasheet";
       getnames=yes;
run;

data &prefix.toc(where=(index(dataset,'DATA')=0));
  set &prefix.toc;
  num=_n_ ;
/*  if index(dataset,'DATA')=0;*/
run;

%local jnum ;

data _null_ ;
  set &prefix.toc end=eof ;
  if eof then do ;
    call symput('jnum',trim(left(put(num, 5.0 )) )  ) ;
  end;
run;

%put jnum=  &jnum ;

%do j= 1 %to &jnum ;
  data _null_ ;
    set &prefix.toc ;
    if num= &j ;
    call symput('sheet',trim(left(Dataset))  ) ;
  run;

  proc import out=&prefix._&sheet(where=(Dataset ne ''))
     datafile="&path"
     dbms=xlsx replace; sheet="&sheet";
     getnames=yes;
  run;
%end;
%mend convertxls ;

*----Path	= location of excel file to be read
  datasheet = sheet name from excel which contains list of all tabs 
        col = column which can be used as ID-----;

%convertxls(path=%str(/biomroot/biometrics/users/nborade/private/s6166291/ADaM/spec/V1.3_CORE_V1.0.xlsx)
		,datasheet=%str(TOC)
		,col=%str(Dataset)
		,prefix = %str(v1)) ;

%convertxls(path=%str(/biomroot/biometrics/users/nborade/private/s6166291/ADaM/spec/s6166291_final_adam_mapping.xlsx)
		,datasheet=%str(TOC)
		,col=%str(Dataset)
		,prefix = %str(v2)) ;

%convertxls(path=%str(/biomroot/biometrics/users/nborade/private/s6166291/ADaM/spec/V1.3_ONC_V1.0.xlsx)
		,datasheet=%str(TOC)
		,col=%str(Dataset)
		,prefix = %str(v3)) ;

data master_std;
	set v1_:;
run;

data master_study;
	set v2_:;
run;

proc sql noprint;
	create table list as	
		select scan(memname,2,'_') as name
			from dictionary.tables
where libname='WORK' and typemem='DATA' and index(memname,'V1_');
quit;

ods excel file="/biomroot/biometrics/users/nborade/private/5744/compare_core.xlsx"  style=SEASIDE;

%macro comp(dom);

ods excel options(sheet_interval="NOW" sheet_name="&dom." embedded_titles="YES" index="ON") style=SEASIDE;

proc compare b=v1_&dom. c=v2_&dom. outnoequal outdiff noprint outbase outcomp out=_&dom. ;
run;
proc print data=_&dom.;run;

%mend;

data _null_;
	set list;
	call execute(catx(''
		,'%comp('
		,name
		,');'
		));
run;

ods excel close;

data attrib;
	length attrib $400.;
	set v1_adsl;
	if sas_type = "Char" then
		attrib = (variable) || "			Label= '" || strip(label) || "'		" || "		length=$" || strip(put(sas_length,best.));
	else if sas_type = "Num" then
		attrib = (variable) || "			Label= '" || strip(label) || "'";
run;


/*proc compare b = master_std(where=(dataset="ADPC")) */
/*		 	 c = master_study(where=(dataset="ADPC")) */
/*	outnoequal outdiff noprint outbase outcomp */
/*		   out = _adsl ;*/
/*run;*/

%let labels = ;

proc sql noprint;
/*	select catx("=",trim(variable), trim(quote(label)))*/	
select cats(strip(variable),"	label=", strip(quote(label)),"	length=$",strip(put(sas_length,best.)))

		into :labels  separated by "	 "
		from work.v1_adsl
		;
quit;
 
%put &labels.;
	