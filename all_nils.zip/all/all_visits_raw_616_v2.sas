/*****TO GET LIST OF VARIABLES AND OTHER DETAILS FOR ALL DOMAINS IN LIBRARY********/
proc datasets library = work kill nolist;
quit;

libname rawdata "/biometrics/users/nborade/private/s6166291/rawdata/";


proc sql;
create table columns/*(where=(format='MMDDYY10.' and index(variable,'EVENT')=0))*/ as
select name as variable
,memname as domain
,length
,label
/**As data contains only char & text data type, 
we have to create datetype which variable label contains 'Date'********/
,(case 
when strip(type)='num' then 'integer'
when strip(type)='char' and index(label,'Date')>0 then 'datetime'
else 'text'
end) as data_type
,format
from dictionary.columns
where libname = "RAWDATA" ;
quit;

/***Porcessing RAWPLUS data variables***/
/*data columns;*/
/*set columns;*/
/*	if variable = 'VISNAM' then	*/
/*		variable = 'FOLDER';*/
/*	if variable = 'LBDTM' then	*/
/*		variable = 'FOLDER';*/
/*run;*/


proc sql;
create table vis as 
select distinct(domain) as dom ,variable as visit
from columns
having /*(index(variable,'FOLDER'))>0 */variable='FOLDER' or variable = 'VISNAM' 
/*or index(variable,'VISIT_')>0 or index(variable,'COLLD')>0) and 
index(variable,'_LABEL')=0*/ ;/***considersing domains having visit infomation only*****/

create table new as
select vis.dom,vis.visit,c.*
from vis
left join 
columns as c
on vis.dom=c.domain
where /*format='MMDDYY10.' and  index(variable,'COLLD')>0*/  (index(variable,'DAT_RAW') or variable = 'LBDTM') and domain not in ( 'MH') and variable ne 'BRTHDAT_RAW';/**Taking out only date variabls***/
quit;

/**Macro to store domains wise dates in sepeate datasets*****/;
%macro date(variable=,domain=,visit=);
proc sql;
create table d_&domain._&variable. as 
select x_subjid, &variable. as date,"&variable." as datevar,"&domain." as domain,catt( &visit.) as visit
from rawdata.&domain.
order by date;
quit;
%mend;

/***to run above macro for all available datasets in given directory***/;
data _null_;
set new;
call execute(catx(''
,'%date(variable='
,variable
,',domain='
,domain
,', visit='
,visit
,');'
)); 
run;

/***appending all dates from every datasets in a signle col***/;
data f;
length domain visit datevar $200. ; 
set d_:;
if date ne '' and strip(substr(date,1,2)) ne 'UN' /*and index(date,'UN')=0 and index(domain,'CONM')=0 and index(domain,'ADVERSE')=0 and index(domain,'ZZ')=0*/;
if index(domain,'RAWPLUS') = 0 then	
	dt=input(compress(date),date9.);
else 
	dt = input(date,e8601da.);
visit=upcase(scan(visit,1,'('));
visit=tranwrd(tranwrd(visit,' DAY ','D'),'CYCLE ','C');
format dt date9.;
run;

proc sort data=f nodupkey dupout=du;by _all_;run;
proc sort data=f ;by x_subjid dt;run;

/***Taking out max and min dates per subject**/;
proc sql noprint;
  create table sv as
   select x_subjid,min(dt) as stdt format=e8601da.,max(dt) as endt format=e8601da.,visit
   from f group by x_subjid,visit
   order by x_subjid,stdt,visit;
quit;


