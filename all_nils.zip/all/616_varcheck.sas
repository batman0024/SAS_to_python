
/* SAS Program with PRX Pattern Matching for Variable Mapping */
options validvarname=v7;
options mprint mlogic symbolgen;
/* Step 1: Define parameters */
libname sasdata "/biometrics/projects/p616/s6166291/final/draft1/sdtmdata";
%let spec_path = /biometrics/users/nborade/private/s6166291/SDTM/s6166291_final_sdtm_mapping.xlsx;  /* Excel specification */
%let output_path = /biometrics/users/nborade/private/s6166291/SDTM/SDTM_Spec_Mapping_Report_%sysfunc(today(),yymmddn8.).xlsx;



%macro metadata(data);

	%if %index(&data.,SUPP) %then %do;

		proc sort data=sasdata.&data nodupkey out=s;
		by qlabel qnam;
		run;

		proc transpose data=s out=&data(drop=_:);
		by qlabel;
		var qval;
		id qnam;
		run;

		proc contents data=&data out=_s_&data.(keep=memname name) noprint;
		run;
	%end;
	%else %do;
		
		proc contents data=sasdata.&data out=_s_&data.(keep=memname name) noprint;
		run;

	%end;

%mend;

		proc contents data=sasdata._all_ noprint out=list(keep=memname rename=(memname=data));
		run;
		proc sort data=list nodupkey;by _all_ ;where data not in ('TA' 'TE' 'TI' 'TV' 'TS');run;


	data _null_;
		set list;

	call execute(cats('',
		'%metadata(data=',
		data,
		');'
		));

	run;

	data all;
	length var label $200.;
		set _s: ;
		var = catx(".",memname,name);
	run;


%macro adam_varcheck(data=);
/* Step 2: Get active domains from TOC */
		proc import datafile="&spec_path"
		    out=toc_sheet(where=(upcase(active) = (&data.) and dataset not in ('TA' 'TE' 'TI' 'TV' 'TS' 'TD' 'TM')))
		    dbms=xlsx
		    replace;
		    sheet="toc";
		    getnames=yes;
		run;

		proc import datafile="&spec_path"
            out=codelist
            dbms=xlsx
            replace;
            sheet="Codelist";
            getnames=yes;
        run;

		proc import datafile="&spec_path"
            out=computation
            dbms=xlsx
            replace;
            sheet="Computation";
            getnames=yes;
        run;


proc sql noprint;
    select count(*) into :domain_count from toc_sheet;
    select dataset into :domain1-:domain%trim(&domain_count) from toc_sheet;
quit;

    %do i = 1 %to &domain_count;
        %let domain = &&domain&i;
        
        /* Import domain sheet */
        proc import datafile="&spec_path"
            out=domain_data
            dbms=xlsx
            replace;
            sheet="&domain";
            getnames=yes;
        run;


        /* Clean input_variables column */
        data _codelist_&domain(keep=dataset variable codelist) 
			 _comp_&domain(keep=dataset variable CompMethod_ID);

			length clean_input $500.;
            set domain_data;

			if not missing(codelist) and upcase(strip(mapping_action)) ^= 'DROP' then output _codelist_&domain;
			if not missing(CompMethod_ID) and upcase(strip(mapping_action)) ^= 'DROP'  then output _comp_&domain;
/*            rename variable = sdtm_variable;*/
        run;

		data check_&domain;
			length  check $2000 domain $4 variable $8;

			set domain_data;

				domain="&domain";
				
				if upcase(strip(gilead_core))='REQUIRED' and upcase(strip(mapping_action)) = 'DROP' then do;check='Check mapping action';output;end;
		if mapping_action not in ('' 'DROP') then do;
					if missing(input_variables) and index(implemented_sas_code,'"')=0 and upcase(implemented_sas_code) ne 'SEQ' then do;
						check = 'Missing input variable';output;
					end;

					if missing(implemented_sas_code) then do;
						check = 'Missing implemented sas code column';output;
					end;

					if upcase(strip(origin)) = 'ASSIGNED|SPONSOR' and missing (comment) then do;
							check='Missing comment column';output;
					end;

					if upcase(strip(origin)) = 'ASSIGNED|SPONSOR' and missing (comment) and not missing (compmethod_id)  then do;
							check='For Assigned origin comment missing but compmethod_id is present';output;
					end;

					if upcase(strip(origin)) = 'DERIVED|SPONSOR' and missing (compmethod_id) then do;
							check='Missing compmethod_id column';output;
					end;
	
					if upcase(strip(origin)) = 'DERIVED|SPONSOR' and missing (compmethod_id) and not missing (comment) then do;
							check='For Dervied origin compmethod_id is missing but comment is present';output;
					end;
				
					if missing(origin) then do;
						check='Missing origin column';output;
					end;

					if find(comment,"COMP:","i") then do;
						check='Comment contains COMP:';output;
					end;

					if comment ne '' and  findw(trim(comment),'  ')>0 then do;
						check='Check for double space"';output;
					end;

					if comment ne '' and substr(reverse(compress(comment)),1,1)^="." then do;
						check = "Comment col full stop missing";output;
					end;

					if gilead_core='R' and upcase(strip(mapping_action)) = 'DROP' then do;
						check='Dropped Required variable';output;
					end;

					if upcase(strip(origin)) = 'DERIVED|SPONSOR' and 
					compmethod_id = '<Programmer should specify computation method on study level>' then do;
						check='Check Compmethod_id';output;
					end;
	
		end;
			keep domain check variable ;

		run;

        /* All SDTM variables mapped to ADaM dataset check and not present variable in SDTM mapped in ADaM */

		proc sql noprint;
			create table _sdtm_&domain as	
				select a.dataset,a.variable,a.label,a.gilead_core,a.origin,a.mapping_action,b.var,ifc(b.var ne "","DONE","NOT DONE") as check
			from domain_data a
			full join
				all b
			on a.origin = b.var
				where  upcase(strip(a.mapping_action)) = "ASSIGN" and index(a.origin,".") and index(a.origin,"ADSL")=0;
		quit;

	%end;

%mend;

/*%adam_varcheck(data=%str('AE' 'DM' ));*/

%adam_varcheck(data=%str('Y'));

data all_issues;
	set check_:;
run;


data sdtm_map;
	length label $200.;
	set _sdtm_:;
run;

     /* Check if all unique codelist and compmethodId from all domains are set to YES in resp tabs */

data all_codelist;
	length dataset variable codelist $200;
	set _codelist_:;
run;

data all_comp;
	length dataset variable CompMethod_ID $2000;
	set _comp_:;
run;

proc sort data=codelist nodupkey;
by codelist_name active;
run;

proc sql noprint;
	create table _chk_code as
		select a.*,b.active
			from all_codelist a
	left join
		codelist b
	on a.codelist=b.codelist_name;

	create table _chk_comp as
		select a.*,b.active

			,compress(b.algorithm, '0D0A'x) as comp length=2000
/*			,prxchange('s/[\r\n]//',-1,a.compmethod_id) as comp*/
/*			,ifc(upcase(substr(calculated comp,1,5))="COMP:","DONE","Not starting with Comp:") as check1*/
			,ifc(not missing(compress(calculated comp)) and substr(reverse(compress(calculated comp)),1,1)="," ,"Check comma at the end","DONE") as check2
			,ifc(not missing(compress(calculated comp)) and substr(reverse(compress(calculated comp)),1,1)="." ,"DONE","Missing . at the end of the text") as check3
			,ifc(findw(trim(calculated comp),'  ')>0,"Check for double space","DONE") as check4
			,ifc(index(trim(calculated comp),'<I')>0,"Check for bracketed text and remove","DONE") as check5
			,ifc(index(trim(calculated comp),'"')>0,"Check for double quotes and replace by single quote","DONE") as check6


			from all_comp a
	left join
		computation b
	on a.compmethod_id=b.compmethod_id;
quit;

	/*  End  */	


/* Step 6: Export to Excel */
ods excel file="&output_path" options(
    sheet_interval='NOW'
    sheet_name='Issue'
    frozen_headers='yes'
	autofilter='all'
);

proc print data=all_issues noobs;
run;

ods excel options(sheet_interval='NOW' sheet_name='Codelist' autofilter='all');

proc print data=_chk_code noobs;
run;

ods excel options(sheet_interval='NOW' sheet_name='CompMethodID' autofilter='all');

proc print data=_chk_comp noobs;
run;


ods excel options(sheet_interval='NOW' sheet_name='SDTMtoADaM' autofilter='all');

proc print data=sdtm_map noobs;
run;


ods excel close;

