/*****TO GET LIST OF VARIABLES AND OTHER DETAILS FOR ALL DOMAINS IN LIBRARY********/
proc sql;
create table columns as
select name as variable
,memname as domain
,length
,label
/**As data contains only char & text data type, 
we have to create datetype which variable label contains 'Date'********/
,(case 
when strip(type)='num' then 'integer'
when strip(type)='char' and index(label,'Date')>0 then 'datetime'
else 'text'
end) as data_type
,format
from dictionary.columns
where libname = 'SDTMDATA'
;
quit;

/***TO OUTPUT OBTAINED RESULTS IN EXCEL FILE*****/;

/*ods excel file="/sasdata/pds/sandbox/SAS Training/User/nborade/37444/sdtm/DEFINE/variables.xlsx" style=minimal;*/
/*ods excel file="&projroot./documents/variables1.xlsx" style=minimal;*/
/*proc print data=columns;*/
/*run;*/
/*ods excel close;*/
/*****************************************************************/

/****TO GET ALL DISTINCT TESTCD's AND SUPP VALUES**********/
proc sql;
create table values as
select domain, variable
from columns
where index(variable,'TESTCD')>0 or index(variable,'QNAM')>0 or index(variable,'PARMCD')>0
;
quit;

/***Creating macro to make valuelevel tab from SDTM '--TESTCD' as well SUPP 'QNAM' variable****/

%macro uniq(variable=,domain=);
proc sql;
create table _&domain. as 
select distinct(&variable.) as value
/* ,length(strip("&domain."||'ORRES')) as length*/
,upcase("&domain.") as dataset
,(case
when index("&variable.",'TESTCD')>0 then upcase("&domain.")||'ORRES' 
when index("&variable.",'QNAM')>0 or index("&variable.",'PARMCD')>0 then 'QVAL'
else ""
end) as variable

/* ,(case*/
/* when index("&variable.",'TESTCD')>0 then length(strip("&domain."||'ORRES')) */
/* when index("&variable.",'QNAM')>0 then length(QVAL)*/
/* else .*/
/* end) as length*/

,(case
when index("&variable.",'TESTCD')>0 then upcase("&domain.")||'.'||upcase("&domain.")||'TESTCD'||'.'|| &variable. 
when index("&variable.",'QNAM')>0 or index("&variable.",'PARMCD')>0 then upcase("&domain.")||'.'||'QNAM'||'.'|| &variable.
else ""
end) as where_clau
from sdtmdata.&domain.
;
quit;
%mend;
/*%uniq(variable=EGTESTCD,domain=EG)*/
/**/
/*%uniq(variable=QNAM,domain=SUPPAE)*/

/****running all data through above macro using CALL EXECUTE TOcreate domain wise datasets***/;
data test;
set values;
  rc = dosubl(cats('SYSECHO "OBS N=',_n_,', DOMAIN=' ,domain,'";'));
CALL EXECUTE('%uniq(variable='||variable||',domain='||domain||');');
/*x=sleep(1,10); /***suspends execution of a DATA step for a specified number of seconds***/*/;

run;

/*****Appending all domain datasets to create on single dataset*****/; 
data fin(where=(not missing(where_clau)));
length dataset $15. variable $40. where_clau value $100. ;
set _:;
keep dataset variable where_clau value length;
run;

/***TO OUTPUT OBTAINED RESULTS IN EXCEL FILE*****/;
ods excel file="&projroot./documents/valuelevel1.xlsx" style=minimal;
/*ods excel file="/sasdata/pds/sandbox/SAS Training/User/nborade/37444/sdtm/DEFINE/variables.xlsx" style=minimal;*/
proc print data=fin;
run;
ods excel close;

/*********************************************************************************************************************************/

/* earlier versions, using SAS/ACCESS to PC Files */
/*PROC EXPORT data = columns*/
/*OUTFILE = 'variables1.xlsx' */
/*DBMS = EXCEL REPLACE;*/
/*SHEET='VARLIST'; */
/*RUN;*/

/******READING SDTM SPEC TO GET LIST OF VARIABLES HAVING CODELIST*******/
proc import datafile="&projroot./documents/sdtm/CStone- Study Data Tabulation (SDTM) Mapping Specification v0.3.xls"
out=spec(where=(codelist not in ('' 'MEDDRA'))) dbms=xls replace;
sheet="Variables";
getnames=yes;
run;

/******READING SDTM TERMINOLOGY*******/
/***CT CURRENTLY USING "SDTM Terminology_2018_12_21"***/
/**Latest CT "SDTM Terminology_2019_12_20"****/
proc import datafile="/sasdata/pds/sandbox/SAS Training/User/nborade/37444/sdtm/DEFINE/SDTM Terminology_2019_12_20.xls"
out=list/*(where=(codelist not in ('' 'MEDDRA')))*/ dbms=xls replace;
sheet="SDTM Terminology_2019_12_20";
getnames=yes;
run;

/***GET UNIQUE VALUES FOR EACH VARIABLE HAVING CODELIST*****/
proc sql;
create table values(where=(Dataset^='PF')) as
select distinct(Codelist) as code, Dataset, Variable
from spec
/**To keep only alphanumeric values****/
where /*compress(Codelist,'','ak') and*/not missing(Codelist) and  Use__y_ = '*' and code ne 'DRUGDICT'
order by dataset
;
quit;

options mprint mlogic symbolgen;
%macro uniq_val(variable=,domain=);

proc sql noprint;
	select count(*) into :cnt
		from sdtmdata.&domain.;
quit;

%put NOTE: dataset &domain. has &cnt record(s);
%if &cnt >1 %then %do;

proc sql;
create table _&variable._&domain. as 
%if %index(&variable,NUM) %then %do;
select distinct(put(&variable.,best.)) as value 
%end;
%else %do;
select distinct(&variable.) as value 
%end;
,upcase("&domain.") as dataset
,"&variable." as variable

from sdtmdata.&domain.

;
quit;

%end;
%else %do;
	%put Empty dataset;
%end;

%mend;

/*%uniq_val(variable=AEACN,domain=AE)*/

data _null_;
set all_codelist(where=(dataset ne "QNAM" and codelist not in ("WHODD" "MedDRA")));
CALL EXECUTE('%uniq_val(variable='||Variable||',domain='||Dataset||');');
run;

data fin1(where=(not missing(value)) );
length dataset variable $50. value val  $200. ;
set _:;
/***As per sponser's request values has been populated as Other:||[specify] instead of populating it in SUPP***/
if index(value,'OTHER')>0 then val = 'OTHER';
else val = value;
keep dataset value val variable ;
run;
 
proc sql;
create table code(drop=val variable where=(not missing(value))) as 
select a.*
,a.variable as ID
,b.Codelist_name as Name
,b.Codelist_Code as NCI_Codelist_Code
,b.CDISC_Submission_value as Term
,b.code as NCI_Term_Code
,b.NCI_Preferred_term as Decoded_Value
,b.VAR3 as Extensible
from fin1 as a
left join 
list as b
on a.value = b.CDISC_Submission_Value

order by dataset, ID, codelist_name,value, code
;
quit;

ods excel file="&projroot./programs/define/SDTM/DOCUMENTS/codelist_new.xlsx" style=minimal;
/*ods excel file="/sasdata/pds/sandbox/SAS Training/User/nborade/37444/sdtm/DEFINE/variables.xlsx" style=minimal;*/
proc print data=code;
run;
ods excel close;

