# pages/4_Date_Imputer.py
"""
AE Date Imputer page.
Imputes partial/missing AE dates per SAP rules.
Full datetime records (YYYY-MM-DDTHH:MM:SS) are passed through as-is.
Includes toggle to enable/disable imputation per run.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import io
from datetime import datetime

import pandas as pd
import streamlit as st

from core.date_imputer import impute_ae_dates, build_imputation_summary, RULE_LABELS

st.set_page_config(page_title="Date Imputer", layout="wide")
st.title("AE Date Imputer")
st.caption(
    "Imputes partial/missing AE start and stop dates per SAP rules. "
    "Records with a full datetime string (YYYY-MM-DDTHH:MM:SS) are "
    "parsed directly without imputation."
)

# --- Run toggle ---
run_imputation = st.toggle(
    "Enable imputation",
    value=True,
    help="When OFF, the file is parsed and output columns are added using "
         "direct ISO parsing only (no imputation rules applied). "
         "Useful to verify input data before applying SAP rules.",
)

st.divider()

# --- File upload ---
col1, col2 = st.columns([2, 1])
with col1:
    ae_file = st.file_uploader(
        "Upload AE dataset (.sas7bdat or .csv)",
        type=["sas7bdat", "csv"],
        help="The AE (or any) dataset containing the date variables to impute.",
    )
with col2:
    startc = st.text_input("Start date column", value="AESTDTC")
    stopc = st.text_input("Stop date column", value="AEENDTC")
    trtsdt = st.text_input("First dose date column (numeric)", value="TRTSDT")
    prefix = st.text_input("Output variable prefix", value="AE")

skip_datetime = st.checkbox(
    "Pass through records with full datetime strings (YYYY-MM-DDTHH:MM:SS) without imputation",
    value=True,
    help="Mirrors the SAS macro's intended behaviour: when a date is complete "
         "with time, extract date/time directly and skip the imputation rules.",
)

if ae_file is None:
    st.info("Upload an AE dataset (.sas7bdat or .csv) to begin.")
    st.stop()

# Load dataset
@st.cache_data
def load_ae(file_bytes: bytes, filename: str) -> pd.DataFrame:
    if filename.endswith(".sas7bdat"):
        try:
            import pyreadstat
            df, _ = pyreadstat.read_sas7bdat(io.BytesIO(file_bytes))
            df.columns = [c.upper() for c in df.columns]
            return df
        except Exception as exc:
            raise ValueError(f"Cannot read SAS dataset: {exc}") from exc
    elif filename.endswith(".csv"):
        return pd.read_csv(io.BytesIO(file_bytes))
    raise ValueError("Unsupported file type")

try:
    ae_bytes = ae_file.read()
    ae_df = load_ae(ae_bytes, ae_file.name)
except Exception as exc:
    st.error(str(exc))
    st.stop()

st.success(f"Loaded: {ae_file.name} ({len(ae_df):,} rows, {len(ae_df.columns)} columns)")

# Column checks
missing = [c for c in [startc, stopc, trtsdt] if c not in ae_df.columns]
if missing:
    st.error(
        f"Column(s) not found in dataset: {missing}. "
        f"Available: {sorted(ae_df.columns.tolist())}"
    )
    st.stop()

# Preview
with st.expander("Preview input data (first 10 rows)", expanded=False):
    preview_cols = [c for c in [startc, stopc, trtsdt] if c in ae_df.columns]
    other_cols = [c for c in ae_df.columns if c not in preview_cols][:5]
    st.dataframe(ae_df[preview_cols + other_cols].head(10), use_container_width=True)

st.divider()

if st.button("Run Imputation", type="primary", use_container_width=True,
             disabled=not run_imputation):
    with st.spinner("Imputing dates..."):
        try:
            result = impute_ae_dates(
                ae_df,
                startc=startc,
                stopc=stopc,
                trtsdt=trtsdt,
                prefix=prefix,
                skip_if_has_time=skip_datetime,
            )
            st.session_state["imputer_result"] = result
            st.session_state["imputer_prefix"] = prefix
        except Exception as exc:
            st.error(f"Imputation failed: {exc}")
            st.exception(exc)

elif not run_imputation:
    st.info("Imputation is toggled OFF. Enable to run.")

if "imputer_result" not in st.session_state:
    st.info("Click 'Run Imputation' to process the dataset.")
    st.stop()

result: pd.DataFrame = st.session_state["imputer_result"]
p = st.session_state.get("imputer_prefix", "AE")

# --- Summary ---
rule_summary = build_imputation_summary(result, prefix=p)
st.subheader("Imputation Summary")

cols = st.columns(len(rule_summary))
for col, (label, count) in zip(cols, rule_summary.items()):
    col.metric(label[:40] + "..." if len(label) > 40 else label, count)

st.divider()

# --- Output columns ---
output_cols = [startc, stopc, trtsdt, "ASTDT", "ASTDTC", "ASTDTF",
               "AENDT", "AENDTC", "AENDTF",
               f"{p}_START_RULE", f"{p}_STOP_IMPFL", f"{p}_STOP_ONGOING",
               f"{p}_REL_STOP_TO_TRT"]
output_cols_present = [c for c in output_cols if c in result.columns]

# Add rule label
rule_col = f"{p}_START_RULE"
if rule_col in result.columns:
    result["_rule_label"] = result[rule_col].map(
        {k: v for k, v in RULE_LABELS.items()}
    ).fillna("Unknown")
    output_cols_present.append("_rule_label")

tab1, tab2 = st.tabs(["All Records", "Imputed Only"])

def _colour_imputed(row):
    rule = row.get(f"{p}_START_RULE", 0)
    try:
        rule = float(rule)
    except (TypeError, ValueError):
        rule = 0
    if rule == -1:
        return ["background-color: #E0F2FE"] * len(row)   # datetime passthrough
    if rule == 0:
        return [""] * len(row)                              # full date, no imputation
    if rule in (1, 2):
        return ["background-color: #FEF3C7"] * len(row)   # partial
    return ["background-color: #FECACA"] * len(row)        # missing/year-only

with tab1:
    st.dataframe(
        result[output_cols_present].style.apply(_colour_imputed, axis=1),
        use_container_width=True,
        height=400,
    )

with tab2:
    rule_col = f"{p}_START_RULE"
    if rule_col in result.columns:
        imputed = result[result[rule_col].notna() & (result[rule_col] != 0) & (result[rule_col] != -1)]
    else:
        imputed = result.head(0)
    st.caption(f"{len(imputed)} records had imputation applied (rule != 0 and != passthrough)")
    st.dataframe(
        imputed[output_cols_present].style.apply(_colour_imputed, axis=1),
        use_container_width=True,
        height=400,
    )

# Download
csv_bytes = result[output_cols_present].to_csv(index=False).encode("utf-8")
st.download_button(
    label="Download Imputed Dataset (.csv)",
    data=csv_bytes,
    file_name=f"AE_imputed_{datetime.now():%Y%m%d_%H%M}.csv",
    mime="text/csv",
)
