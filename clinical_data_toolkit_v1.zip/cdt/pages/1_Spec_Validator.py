# pages/1_Spec_Validator.py
"""
Spec Validator page.
Runs per-variable checks on every active domain sheet.
Outputs: Issues (flat + by domain), Codelist check, CompMethod check, SDTM source.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from datetime import datetime

import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.check_rules import CHECK_RULES
from core.spec_validator import run_spec_validation, build_domain_summary
from core.excel_export import export_validation_results

st.set_page_config(page_title="Spec Validator", layout="wide")
st.title("Spec Validator")
st.caption(
    "Checks every active domain in the mapping spec for completeness "
    "and consistency issues before sponsor review."
)

if "spec" not in st.session_state:
    st.warning("Upload a mapping specification in the sidebar first.")
    st.stop()

spec = st.session_state["spec"]
spec_name = st.session_state.get("spec_name", "spec")
domains = st.session_state.get("spec_domains", [])

# --- Configuration ---
with st.expander("Run configuration", expanded=False):
    col1, col2, col3 = st.columns(3)
    with col1:
        active_filter = st.text_input(
            "Active flag value (TOC column)",
            value="Y",
            help="Value in the 'active' column of the TOC sheet that marks a domain as active.",
        )
        explicit_input = st.text_area(
            "Override: explicit dataset list (comma-separated)",
            value="",
            help="Leave blank to use the active flag. Enter e.g. ADAE,ADSL,ADLB to check specific datasets.",
        )
    with col2:
        st.write("Enable/disable checks:")
        enabled_checks = []
        for key, rule in CHECK_RULES.items():
            default = rule["active"]
            label = f"{rule['severity']}: {key}"
            if st.checkbox(label, value=default, key=f"chk_{key}"):
                enabled_checks.append(key)
    with col3:
        sdtm_path = st.session_state.get("sdtm_path", "")
        run_sdtm_check = st.checkbox(
            "Run SDTM source check (requires SDTM library path)",
            value=bool(sdtm_path),
        )

# Parse explicit dataset list
explicit_datasets = None
if explicit_input.strip():
    explicit_datasets = [d.strip().upper() for d in explicit_input.split(",") if d.strip()]

# --- Run button ---
if st.button("Run Validation", type="primary", use_container_width=True):
    sdtm_var_index = None
    if run_sdtm_check and sdtm_path:
        try:
            import pyreadstat
            var_index = set()
            for fp in Path(sdtm_path).glob("*.sas7bdat"):
                _, meta = pyreadstat.read_sas7bdat(str(fp), metadataonly=True)
                dom = fp.stem.upper()
                for col in meta.column_names:
                    var_index.add(f"{dom}.{col.upper()}")
            sdtm_var_index = var_index
            st.info(f"Loaded SDTM variable index: {len(var_index)} variables.")
        except Exception as exc:
            st.warning(f"Cannot load SDTM library: {exc}")

    with st.spinner("Running checks..."):
        progress = st.progress(0)
        try:
            results = run_spec_validation(
                spec,
                active_filter=active_filter,
                explicit_datasets=explicit_datasets,
                enabled_checks=enabled_checks if enabled_checks else None,
                sdtm_var_index=sdtm_var_index,
            )
            progress.progress(100)
            st.session_state["validation_results"] = results

            # Update run history
            history = st.session_state.get("run_history", [])
            history.append({
                "time": datetime.now().strftime("%H:%M:%S"),
                "spec_name": spec_name,
                "errors": results["summary"]["errors"],
                "warnings": results["summary"]["warnings"],
            })
            st.session_state["run_history"] = history

        except Exception as exc:
            st.error(f"Validation failed: {exc}")
            st.exception(exc)

# --- Display results ---
if "validation_results" not in st.session_state:
    st.info("Configure options above and click 'Run Validation'.")
    st.stop()

results = st.session_state["validation_results"]
summary = results["summary"]
issues: pd.DataFrame = results["issues"]
codelist_check: pd.DataFrame = results["codelist_check"]
compmethod_check: pd.DataFrame = results["compmethod_check"]
sdtm_source: pd.DataFrame = results["sdtm_source"]

# --- Score banner ---
score = summary["health_score"]
grade = summary["grade"]
score_colour = "normal" if score >= 75 else "inverse"

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Health Score", f"{score}/100 ({grade})")
c2.metric("Errors", summary["errors"], delta=None)
c3.metric("Warnings", summary["warnings"], delta=None)
c4.metric("Codelist Issues", summary["codelist_issues"])
c5.metric("CompMethod Issues", summary["comp_issues"])

st.divider()

# --- Download ---
if not issues.empty or not codelist_check.empty:
    excel_bytes = export_validation_results(results, spec_name)
    st.download_button(
        label="Download Full Report (.xlsx)",
        data=excel_bytes,
        file_name=f"SpecValidation_{spec_name.replace('.xlsx','')}_{datetime.now():%Y%m%d_%H%M}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        type="secondary",
    )

# --- Domain summary chart ---
if not issues.empty and HAS_PLOTLY:
    dom_summary = build_domain_summary(issues)
    if not dom_summary.empty:
        with st.expander("Issue distribution by domain", expanded=True):
            fig = px.bar(
                dom_summary,
                x="domain", y=["errors", "warnings"],
                barmode="stack",
                color_discrete_map={"errors": "#EF4444", "warnings": "#F59E0B"},
                labels={"value": "Count", "domain": "Domain"},
                title="Issues per Domain",
                height=300,
            )
            fig.update_layout(legend_title="Severity", margin=dict(l=0, r=0, t=40, b=0))
            st.plotly_chart(fig, use_container_width=True)

# --- Tabs ---
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "Issues (Flat)",
    "Issues by Domain",
    "Codelist",
    "CompMethod",
    "SDTM Source",
])

with tab1:
    if issues.empty:
        st.success("No issues found!")
    else:
        # Filters
        col_f1, col_f2, col_f3 = st.columns(3)
        sev_options = ["All"] + sorted(issues["severity"].unique().tolist())
        dom_options = ["All"] + sorted(issues["domain"].unique().tolist())
        chk_options = ["All"] + sorted(issues["check"].unique().tolist())

        with col_f1:
            sev_filter = st.selectbox("Severity", sev_options, key="sev_flat")
        with col_f2:
            dom_filter = st.selectbox("Domain", dom_options, key="dom_flat")
        with col_f3:
            chk_filter = st.selectbox("Check", chk_options, key="chk_flat")

        filtered = issues.copy()
        if sev_filter != "All":
            filtered = filtered[filtered["severity"] == sev_filter]
        if dom_filter != "All":
            filtered = filtered[filtered["domain"] == dom_filter]
        if chk_filter != "All":
            filtered = filtered[filtered["check"] == chk_filter]

        st.caption(f"Showing {len(filtered)} of {len(issues)} issues")

        def _colour_row(row):
            if row["severity"] == "ERROR":
                return ["background-color: #FFCCCC"] * len(row)
            if row["severity"] == "WARNING":
                return ["background-color: #FFF3CC"] * len(row)
            return [""] * len(row)

        display_cols = [c for c in [
            "domain", "variable", "severity", "check",
            "description", "suggestion", "mapping_action", "origin",
        ] if c in filtered.columns]

        st.dataframe(
            filtered[display_cols].style.apply(_colour_row, axis=1),
            use_container_width=True,
            height=450,
        )

with tab2:
    if issues.empty:
        st.success("No issues found!")
    else:
        all_domains = sorted(issues["domain"].unique())
        selected_domain = st.selectbox(
            "Select domain to view",
            all_domains,
            key="dom_bydom",
        )
        dom_issues = issues[issues["domain"] == selected_domain]
        n_e = int((dom_issues["severity"] == "ERROR").sum())
        n_w = int((dom_issues["severity"] == "WARNING").sum())
        st.caption(f"**{selected_domain}**: {n_e} errors, {n_w} warnings")

        def _colour_row2(row):
            if row["severity"] == "ERROR":
                return ["background-color: #FFCCCC"] * len(row)
            if row["severity"] == "WARNING":
                return ["background-color: #FFF3CC"] * len(row)
            return [""] * len(row)

        display_cols2 = [c for c in [
            "variable", "severity", "check", "description", "suggestion",
        ] if c in dom_issues.columns]

        st.dataframe(
            dom_issues[display_cols2].style.apply(_colour_row2, axis=1),
            use_container_width=True,
            height=400,
        )

with tab3:
    if codelist_check.empty:
        st.info("No codelist references found in spec, or Codelist tab is missing.")
    else:
        missing_mask = codelist_check.get("in_codelist_tab", pd.Series(dtype=str)).str.startswith("NO")
        inactive_mask = codelist_check.get("active", pd.Series(dtype=str)).str.upper().isin(
            ["N", "NO", "FALSE", "0"]
        )
        n_missing = int(missing_mask.sum())
        n_inactive = int(inactive_mask.sum())
        cc1, cc2 = st.columns(2)
        cc1.metric("Not in Codelist tab", n_missing)
        cc2.metric("Marked inactive", n_inactive)

        show_issues_only = st.checkbox("Show issues only", value=False, key="cl_issues_only")
        display = codelist_check[missing_mask | inactive_mask] if show_issues_only else codelist_check

        def _colour_cl(row):
            if str(row.get("in_codelist_tab", "")).startswith("NO"):
                return ["background-color: #FFCCCC"] * len(row)
            if str(row.get("active", "")).upper() in ("N", "NO"):
                return ["background-color: #FFF3CC"] * len(row)
            return [""] * len(row)

        st.dataframe(
            display.style.apply(_colour_cl, axis=1),
            use_container_width=True,
            height=400,
        )

with tab4:
    if compmethod_check.empty:
        st.info("No CompMethod references found in spec, or Computation tab is missing.")
    else:
        fail_cols = [c for c in compmethod_check.columns if c.startswith("comp_")]
        n_fails = int((compmethod_check[fail_cols].isin(
            [c for c in compmethod_check.stack().unique() if str(c).startswith("FAIL")]
        )).any(axis=1).sum()) if fail_cols else 0

        n_missing_tab = int(
            compmethod_check["in_computation_tab"].str.startswith("NO").sum()
        ) if "in_computation_tab" in compmethod_check.columns else 0

        cm1, cm2 = st.columns(2)
        cm1.metric("Not in Computation tab", n_missing_tab)
        cm2.metric("Text check failures", n_fails)

        show_fails = st.checkbox("Show failures only", value=False, key="comp_fails")

        if show_fails and fail_cols:
            fail_mask = compmethod_check[fail_cols].apply(
                lambda col: col.astype(str).str.startswith("FAIL")
            ).any(axis=1)
            miss_mask = compmethod_check["in_computation_tab"].str.startswith("NO") \
                if "in_computation_tab" in compmethod_check.columns else pd.Series(False)
            display_comp = compmethod_check[fail_mask | miss_mask]
        else:
            display_comp = compmethod_check

        # Expandable detail view for algorithm text
        selected_comp = st.selectbox(
            "View algorithm text for CompMethod ID:",
            ["(none)"] + compmethod_check["compmethod_id"].unique().tolist(),
            key="comp_detail",
        )
        if selected_comp != "(none)":
            row = compmethod_check[
                compmethod_check["compmethod_id"] == selected_comp
            ].iloc[0]
            st.text_area(
                "Algorithm text (preview)",
                value=row.get("algorithm_preview", ""),
                height=120,
                disabled=True,
            )
            st.caption(f"Used by domains: {row.get('used_by_domains', '')}")

        st.dataframe(
            display_comp.drop(
                columns=["algorithm_preview"], errors="ignore"
            ),
            use_container_width=True,
            height=350,
        )

with tab5:
    if sdtm_source.empty:
        st.info(
            "SDTM source check not run. "
            "Provide a SDTM library path in the sidebar and enable the check."
        )
    else:
        n_not_found = int(
            sdtm_source["in_sdtm_lib"].str.startswith("NO").sum()
        ) if "in_sdtm_lib" in sdtm_source.columns else 0
        st.metric("Variables not found in SDTM library", n_not_found)

        def _colour_sdtm(row):
            if str(row.get("in_sdtm_lib", "")).startswith("NO"):
                return ["background-color: #FFCCCC"] * len(row)
            return [""] * len(row)

        st.dataframe(
            sdtm_source.style.apply(_colour_sdtm, axis=1),
            use_container_width=True,
            height=400,
        )
