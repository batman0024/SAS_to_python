# core/spec_validator.py
"""
Spec validator: runs all per-variable checks on every active domain sheet.
Returns structured DataFrames for Issues, Codelist gaps, CompMethod gaps,
and SDTM-source traceability.

Mirrors the logic from 616_varcheck.sas and adam_varcheck_409_v2.sas
combined into one unified, parameterised implementation.
"""

import logging
from typing import Dict, List, Optional

import pandas as pd

from config.check_rules import (
    CHECK_RULES,
    COMP_TEXT_CHECKS,
    SEVERITY_ORDER,
    PLACEHOLDER_COMP,
)
from core.spec_loader import get_active_domains, get_toc

log = logging.getLogger(__name__)

# Columns expected in a domain sheet (lowercase)
REQUIRED_DOMAIN_COLS = {
    "variable", "mapping_action", "origin",
    "input_variables", "implemented_sas_code",
}


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_spec_validation(
    spec: Dict[str, pd.DataFrame],
    active_filter: str = "Y",
    explicit_datasets: Optional[List[str]] = None,
    enabled_checks: Optional[List[str]] = None,
    sdtm_var_index: Optional[set] = None,
) -> dict:
    """
    Run all spec validation checks.

    Parameters
    ----------
    spec             : loaded spec dict from spec_loader
    active_filter    : value in TOC 'active' column to treat as active
    explicit_datasets: if provided, override active_filter
    enabled_checks   : list of check keys to run; None = all active checks
    sdtm_var_index   : set of "DOMAIN.VARIABLE" strings from SDTM library
                       (used for SDTM-source check; pass None to skip)

    Returns
    -------
    dict with keys:
        issues          : DataFrame - per-variable check failures
        codelist_check  : DataFrame - codelist usage vs Codelist tab
        compmethod_check: DataFrame - compmethod usage vs Computation tab
        sdtm_source     : DataFrame - SDTM-origin vars vs actual SDTM library
        summary         : dict with counts
    """
    domains = get_active_domains(spec, active_filter, explicit_datasets)
    log.info("Running spec validation on %d domains.", len(domains))

    # Determine which checks to run
    if enabled_checks is None:
        run_checks = {k for k, v in CHECK_RULES.items() if v["active"]}
    else:
        run_checks = set(enabled_checks)

    all_issues: List[pd.DataFrame] = []
    all_codelist_refs: List[pd.DataFrame] = []
    all_comp_refs: List[pd.DataFrame] = []
    all_sdtm_map: List[pd.DataFrame] = []

    for domain in domains:
        if domain not in spec:
            log.warning("Domain '%s' listed in TOC but sheet not found.", domain)
            continue

        df = spec[domain].copy()
        # Ensure required columns exist with empty defaults
        for col in REQUIRED_DOMAIN_COLS | {"comment", "codelist", "compmethod_id",
                                            "gilead_core", "label"}:
            if col not in df.columns:
                df[col] = ""

        issues_df = _check_domain(df, domain, run_checks)
        all_issues.append(issues_df)
        all_codelist_refs.append(_collect_codelist_refs(df, domain))
        all_comp_refs.append(_collect_comp_refs(df, domain))

        if sdtm_var_index is not None:
            all_sdtm_map.append(_check_sdtm_sources(df, domain, sdtm_var_index))

    issues = _safe_concat(all_issues)
    codelist_usage = _safe_concat(all_codelist_refs)
    comp_usage = _safe_concat(all_comp_refs)
    sdtm_source = _safe_concat(all_sdtm_map)

    codelist_check = _validate_codelist_tab(codelist_usage, spec)
    compmethod_check = _validate_compmethod_tab(comp_usage, spec)

    summary = _build_summary(issues, codelist_check, compmethod_check, sdtm_source)

    return {
        "issues": issues,
        "codelist_check": codelist_check,
        "compmethod_check": compmethod_check,
        "sdtm_source": sdtm_source,
        "summary": summary,
    }


# ---------------------------------------------------------------------------
# Per-domain checks
# ---------------------------------------------------------------------------

def _check_domain(df: pd.DataFrame, domain: str, run_checks: set) -> pd.DataFrame:
    """Run all enabled per-variable checks on one domain sheet."""
    rows = []

    for _, row in df.iterrows():
        variable = str(row.get("variable", "")).strip()
        if not variable:
            continue

        ma = str(row.get("mapping_action", "")).strip().upper()
        core = str(row.get("gilead_core", "")).strip().upper()
        origin = str(row.get("origin", "")).strip().upper()
        inp = str(row.get("input_variables", "")).strip()
        code = str(row.get("implemented_sas_code", "")).strip()
        comment = str(row.get("comment", "")).strip()
        comp = str(row.get("compmethod_id", "")).strip()

        def add(check_key: str):
            if check_key not in run_checks:
                return
            rule = CHECK_RULES[check_key]
            rows.append({
                "domain": domain,
                "variable": variable,
                "check": check_key,
                "description": rule["description"],
                "suggestion": rule["suggestion"],
                "severity": rule["severity"],
                "mapping_action": row.get("mapping_action", ""),
                "origin": row.get("origin", ""),
                "gilead_core": row.get("gilead_core", ""),
            })

        # Check 1: required variable dropped
        if core == "REQUIRED" and ma == "DROP":
            add("required_dropped")

        if core == "R" and ma == "DROP":
            add("gilead_r_dropped")

        # Only run remaining checks on mapped variables
        if ma in ("", "DROP"):
            continue

        # Check 2: missing input variables
        # Skip if implemented_sas_code contains a literal (has quote)
        # Skip if SEQ (auto-generated sequence)
        if (not inp
                and '"' not in code
                and code.upper() != "SEQ"):
            add("missing_input_var")

        # Check 3: missing SAS code
        if not code:
            add("missing_sas_code")

        # Check 4: missing origin
        if not origin:
            add("missing_origin")

        # Check 5: ASSIGNED|SPONSOR without comment
        if origin == "ASSIGNED|SPONSOR" and not comment:
            add("assigned_no_comment")

        # Check 6: ASSIGNED|SPONSOR with compmethod_id (should use comment)
        if origin == "ASSIGNED|SPONSOR" and not comment and comp:
            add("assigned_has_compmethod")

        # Check 7: DERIVED|SPONSOR without compmethod_id
        if origin == "DERIVED|SPONSOR" and not comp:
            add("derived_no_compmethod")

        # Check 8: DERIVED|SPONSOR with comment but no compmethod_id
        if origin == "DERIVED|SPONSOR" and not comp and comment:
            add("derived_has_comment")

        # Check 9: comment contains COMP: text
        if comment and "comp:" in comment.lower():
            add("comment_has_comp")

        # Check 10: double space in comment (fixed: was findw bug in SAS)
        if comment and "  " in comment:
            add("double_space_comment")

        # Check 11: comment does not end with full stop
        if comment and not comment.rstrip().endswith("."):
            add("comment_no_fullstop")

        # Check 12: placeholder compmethod text
        if PLACEHOLDER_COMP.lower() in comp.lower():
            add("placeholder_compmethod")

    if not rows:
        return pd.DataFrame(columns=[
            "domain", "variable", "check", "description",
            "suggestion", "severity", "mapping_action", "origin", "gilead_core",
        ])

    result = pd.DataFrame(rows)
    result["severity_order"] = result["severity"].map(SEVERITY_ORDER)
    result = result.sort_values(
        ["domain", "severity_order", "variable"]
    ).drop(columns=["severity_order"])
    return result.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Codelist reference collection + validation
# ---------------------------------------------------------------------------

def _collect_codelist_refs(df: pd.DataFrame, domain: str) -> pd.DataFrame:
    """Collect all codelist references from a domain sheet."""
    if "codelist" not in df.columns:
        return pd.DataFrame()
    mask = (
        df["codelist"].str.strip().ne("") &
        df["mapping_action"].str.strip().str.upper().ne("DROP")
    )
    sub = df[mask][["variable", "codelist"]].copy()
    sub["dataset"] = domain
    return sub[["dataset", "variable", "codelist"]]


def _validate_codelist_tab(
    usage: pd.DataFrame, spec: Dict[str, pd.DataFrame]
) -> pd.DataFrame:
    """
    For each referenced codelist, check it exists in the Codelist tab
    and whether it is marked active.
    """
    if usage.empty:
        return pd.DataFrame(
            columns=["dataset", "variable", "codelist", "in_codelist_tab", "active"]
        )

    codelist_ref = spec.get("Codelist", spec.get("codelist", pd.DataFrame()))
    if codelist_ref.empty:
        usage = usage.copy()
        usage["in_codelist_tab"] = "NO - Codelist sheet missing"
        usage["active"] = ""
        return usage

    # Normalise reference sheet
    ref = codelist_ref.copy()
    name_col = next(
        (c for c in ref.columns if "codelist_name" in c or "codelist" == c), None
    )
    active_col = next(
        (c for c in ref.columns if "active" in c), None
    )

    if name_col is None:
        usage["in_codelist_tab"] = "Cannot check - no codelist_name column"
        usage["active"] = ""
        return usage

    ref["_key"] = ref[name_col].str.strip().str.upper()
    lookup = {
        row["_key"]: str(row[active_col]).strip() if active_col else ""
        for _, row in ref.iterrows()
    }

    result = usage.copy()
    result["_key"] = result["codelist"].str.strip().str.upper()
    result["in_codelist_tab"] = result["_key"].apply(
        lambda k: "YES" if k in lookup else "NO - not in Codelist tab"
    )
    result["active"] = result["_key"].apply(
        lambda k: lookup.get(k, "")
    )
    return result.drop(columns=["_key"]).reset_index(drop=True)


# ---------------------------------------------------------------------------
# CompMethod reference collection + validation
# ---------------------------------------------------------------------------

def _collect_comp_refs(df: pd.DataFrame, domain: str) -> pd.DataFrame:
    """Collect all compmethod_id references from a domain sheet."""
    if "compmethod_id" not in df.columns:
        return pd.DataFrame()
    mask = (
        df["compmethod_id"].str.strip().ne("") &
        df["mapping_action"].str.strip().str.upper().ne("DROP")
    )
    sub = df[mask][["variable", "compmethod_id"]].copy()
    sub["dataset"] = domain
    return sub[["dataset", "variable", "compmethod_id"]]


def _validate_compmethod_tab(
    usage: pd.DataFrame, spec: Dict[str, pd.DataFrame]
) -> pd.DataFrame:
    """
    For each referenced compmethod_id, pull the algorithm text from the
    Computation tab and run text quality checks.
    Source: b.algorithm from Computation tab (consistent fix vs SAS divergence).
    """
    if usage.empty:
        return pd.DataFrame()

    computation = spec.get("Computation", spec.get("computation", pd.DataFrame()))

    # Build lookup
    if not computation.empty:
        comp_id_col = next(
            (c for c in computation.columns if "compmethod_id" in c), None
        )
        algo_col = next(
            (c for c in computation.columns if "algorithm" in c), None
        )
        active_col = next(
            (c for c in computation.columns if "active" in c), None
        )
        if comp_id_col and algo_col:
            lookup = {}
            for _, row in computation.iterrows():
                cid = str(row[comp_id_col]).strip()
                alg = str(row[algo_col]).strip() if row[algo_col] else ""
                act = str(row[active_col]).strip() if active_col else ""
                # Clean CRLF (equivalent to SAS compress('0D0A'x))
                alg = alg.replace("\r", " ").replace("\n", " ").strip()
                lookup[cid] = {"algorithm": alg, "active": act}
        else:
            lookup = {}
    else:
        lookup = {}

    rows = []
    for _, row in usage.iterrows():
        comp_id = str(row["compmethod_id"]).strip()
        found = lookup.get(comp_id)
        algo = found["algorithm"] if found else ""
        active = found["active"] if found else ""
        in_tab = "YES" if found else "NO - ID not in Computation tab"

        checks = {}
        if algo:
            checks["comp_no_fullstop"] = (
                "PASS" if algo.rstrip().endswith(".")
                else "FAIL - " + COMP_TEXT_CHECKS["comp_no_fullstop"]["description"]
            )
            checks["comp_comma_end"] = (
                "FAIL - " + COMP_TEXT_CHECKS["comp_comma_end"]["description"]
                if algo.rstrip().endswith(",") else "PASS"
            )
            # Fixed: use str.count instead of findw equivalent
            checks["comp_double_space"] = (
                "FAIL - " + COMP_TEXT_CHECKS["comp_double_space"]["description"]
                if "  " in algo else "PASS"
            )
            checks["comp_bracket_text"] = (
                "FAIL - " + COMP_TEXT_CHECKS["comp_bracket_text"]["description"]
                if "<I" in algo else "PASS"
            )
            checks["comp_double_quote"] = (
                "FAIL - " + COMP_TEXT_CHECKS["comp_double_quote"]["description"]
                if '"' in algo else "PASS"
            )
        else:
            for k in COMP_TEXT_CHECKS:
                checks[k] = "N/A - no algorithm text"

        used_by_all = usage[
            usage["compmethod_id"] == comp_id
        ]["dataset"].unique().tolist()
        used_by = ", ".join(sorted(used_by_all))

        rows.append({
            "dataset": row["dataset"],
            "variable": row["variable"],
            "compmethod_id": comp_id,
            "in_computation_tab": in_tab,
            "active": active,
            "algorithm_preview": algo[:120] + ("..." if len(algo) > 120 else ""),
            "used_by_domains": used_by,
            **checks,
        })

    return pd.DataFrame(rows).reset_index(drop=True)


# ---------------------------------------------------------------------------
# SDTM source check
# ---------------------------------------------------------------------------

def _check_sdtm_sources(
    df: pd.DataFrame, domain: str, sdtm_var_index: set
) -> pd.DataFrame:
    """
    For variables with mapping_action=ASSIGN and origin containing a dot
    (i.e. SDTM.DOMAIN.VARIABLE reference), check whether that variable
    actually exists in the SDTM library.
    Skips ADSL-sourced variables (they come from the same study).
    """
    if "origin" not in df.columns:
        return pd.DataFrame()

    mask = (
        df["mapping_action"].str.strip().str.upper() == "ASSIGN"
    ) & (
        df["origin"].str.contains(".", regex=False, na=False)
    ) & (
        ~df["origin"].str.upper().str.contains("ADSL", na=False)
    )

    sub = df[mask][["variable", "label", "gilead_core", "origin",
                     "mapping_action"]].copy()
    sub["dataset"] = domain

    if sub.empty:
        return pd.DataFrame()

    # Normalise origin to "DOMAIN.VARIABLE" format
    def _parse_origin(orig: str) -> str:
        parts = str(orig).strip().split(".")
        if len(parts) >= 2:
            return (parts[-2] + "." + parts[-1]).upper()
        return orig.upper()

    sub["origin_key"] = sub["origin"].apply(_parse_origin)
    sub["in_sdtm_lib"] = sub["origin_key"].apply(
        lambda k: "YES" if k in sdtm_var_index else "NO - not found in SDTM library"
    )

    return sub[["dataset", "variable", "label", "gilead_core",
                "origin", "mapping_action", "in_sdtm_lib"]].reset_index(drop=True)


# ---------------------------------------------------------------------------
# Summary builder
# ---------------------------------------------------------------------------

def _build_summary(
    issues: pd.DataFrame,
    codelist_check: pd.DataFrame,
    compmethod_check: pd.DataFrame,
    sdtm_source: pd.DataFrame,
) -> dict:
    errors = int((issues["severity"] == "ERROR").sum()) if not issues.empty else 0
    warnings = int((issues["severity"] == "WARNING").sum()) if not issues.empty else 0
    codelist_issues = int(
        codelist_check["in_codelist_tab"].str.startswith("NO").sum()
    ) if not codelist_check.empty and "in_codelist_tab" in codelist_check.columns else 0
    comp_issues = int(
        compmethod_check["in_computation_tab"].str.startswith("NO").sum()
    ) if not compmethod_check.empty and "in_computation_tab" in compmethod_check.columns else 0
    sdtm_issues = int(
        sdtm_source["in_sdtm_lib"].str.startswith("NO").sum()
    ) if not sdtm_source.empty and "in_sdtm_lib" in sdtm_source.columns else 0

    total = errors + warnings + codelist_issues + comp_issues
    score = max(0, 100 - errors * 5 - warnings * 1 - codelist_issues * 2 - comp_issues * 2)

    return {
        "errors": errors,
        "warnings": warnings,
        "codelist_issues": codelist_issues,
        "comp_issues": comp_issues,
        "sdtm_issues": sdtm_issues,
        "total_issues": total,
        "health_score": score,
        "grade": _grade(score),
    }


def _grade(score: int) -> str:
    if score >= 90:
        return "A"
    if score >= 75:
        return "B"
    if score >= 50:
        return "C"
    return "F"


def _safe_concat(frames: list) -> pd.DataFrame:
    non_empty = [f for f in frames if f is not None and not f.empty]
    if not non_empty:
        return pd.DataFrame()
    return pd.concat(non_empty, ignore_index=True)


# ---------------------------------------------------------------------------
# Domain-level summary (for per-domain view)
# ---------------------------------------------------------------------------

def build_domain_summary(issues: pd.DataFrame) -> pd.DataFrame:
    """Build a summary of issue counts per domain."""
    if issues.empty:
        return pd.DataFrame(columns=["domain", "errors", "warnings", "total"])

    grp = issues.groupby(["domain", "severity"]).size().unstack(fill_value=0)
    grp.columns = [c.lower() + "s" for c in grp.columns]
    grp = grp.reset_index()
    for col in ["errors", "warnings"]:
        if col not in grp.columns:
            grp[col] = 0
    grp["total"] = grp["errors"] + grp["warnings"]
    return grp.sort_values("total", ascending=False).reset_index(drop=True)
