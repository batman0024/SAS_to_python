# core/define_helper.py
"""
Define helper: extracts Variable metadata and Value-Level entries
from SAS datasets (or CSV fallback).
Ports Define.sas - handles both SDTM and ADaM modes.
"""

import logging
import re
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

log = logging.getLogger(__name__)

EXCLUDE_DOMAIN_PREFIXES = ("_",)


def get_column_metadata(lib_path: str) -> pd.DataFrame:
    """
    Read variable metadata from all datasets in a SAS library.
    Equivalent to PROC CONTENTS data=lib._all_.
    Uses metadataonly=True so no data rows are loaded.
    """
    rows = []
    lib = Path(lib_path)
    files = sorted(lib.glob("*.sas7bdat"))
    if not files:
        # Fallback: try CSV
        files = sorted(lib.glob("*.csv"))

    for fp in files:
        dom = fp.stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES):
            continue
        if fp.suffix.lower() == ".sas7bdat":
            rows.extend(_meta_from_sas(str(fp), dom))
        else:
            rows.extend(_meta_from_csv(str(fp), dom))

    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=[
            "domain", "variable", "label", "data_type", "length", "format"
        ])
    return df.drop_duplicates(subset=["domain", "variable"]).reset_index(drop=True)


def _meta_from_sas(path: str, domain: str) -> list:
    try:
        import pyreadstat
        _, meta = pyreadstat.read_sas7bdat(path, metadataonly=True)
        rows = []
        for col in meta.column_names:
            idx = meta.column_names.index(col)
            label = ""
            if meta.column_labels and idx < len(meta.column_labels):
                label = meta.column_labels[idx] or ""
            fmt = ""
            if meta.variable_formats:
                fmt = meta.variable_formats.get(col, "")
            typ_raw = ""
            if meta.original_variable_types and idx < len(meta.original_variable_types):
                typ_raw = meta.original_variable_types[idx] or ""

            # Type inference matching Define.sas CASE logic
            if "char" in str(typ_raw).lower() and "date" in str(label).lower():
                dtype = "datetime"
            elif "char" in str(typ_raw).lower():
                dtype = "text"
            else:
                dtype = "integer"

            lgth = ""
            if meta.variable_storage_width:
                lgth = meta.variable_storage_width.get(col, "")

            rows.append({
                "domain": domain,
                "variable": col.upper(),
                "label": str(label),
                "data_type": dtype,
                "length": lgth,
                "format": fmt,
            })
        return rows
    except Exception as exc:
        log.warning("Cannot read SAS metadata for %s: %s", path, exc)
        return []


def _meta_from_csv(path: str, domain: str) -> list:
    try:
        df = pd.read_csv(path, nrows=0)
        rows = []
        for col in df.columns:
            rows.append({
                "domain": domain,
                "variable": col.upper(),
                "label": "",
                "data_type": "text",
                "length": "",
                "format": "",
            })
        return rows
    except Exception as exc:
        log.warning("Cannot read CSV metadata for %s: %s", path, exc)
        return []


def get_value_level(
    lib_path: str,
    columns_df: pd.DataFrame,
    mode: str = "SDTM",
) -> pd.DataFrame:
    """
    Extract distinct TESTCD/QNAM/PARAMCD values from SAS datasets
    to build the value-level (where-clause) table for Define-XML prep.
    Only loads data rows for domains that have the relevant columns.
    """
    mode = mode.upper()
    lib = Path(lib_path)

    # Identify which domains have value-level candidates
    if mode == "ADAM":
        cands = columns_df[
            columns_df["variable"].str.upper().isin(["PARAMCD"])
        ][["domain", "variable"]].copy()
        cands["orres"] = "AVAL"
        cands["where_prefix"] = cands["domain"] + ".PARAMCD."
    else:
        pattern = re.compile(r"TESTCD|QNAM|PARMCD", re.IGNORECASE)
        cands = columns_df[
            columns_df["variable"].str.match(pattern, na=False)
        ][["domain", "variable"]].copy()

        def _orres(v: str) -> str:
            v = v.upper()
            if "TESTCD" in v:
                return ""   # filled per domain below
            return "QVAL"

        cands["orres"] = cands["variable"].apply(_orres)
        cands["where_prefix"] = cands.apply(
            lambda r: r["domain"] + "." + r["variable"] + ".", axis=1
        )

    rows = []
    for _, cand in cands.iterrows():
        dom = cand["domain"]
        var = cand["variable"]
        fp = next(lib.glob(f"{dom.lower()}.sas7bdat"), None)
        if fp is None:
            fp = next(lib.glob(f"{dom.upper()}.sas7bdat"), None)
        if fp is None:
            fp = next(lib.glob(f"{dom.lower()}.csv"), None)
        if fp is None:
            continue

        try:
            if str(fp).endswith(".sas7bdat"):
                import pyreadstat
                df, _ = pyreadstat.read_sas7bdat(str(fp), usecols=[var])
            else:
                df = pd.read_csv(str(fp), usecols=[var])
            df.columns = [c.upper() for c in df.columns]
            if var not in df.columns:
                continue

            orres = cand["orres"]
            if not orres and "TESTCD" in var:
                orres = dom.upper() + "ORRES"

            for val in df[var].dropna().unique():
                val_str = str(val).strip()
                if not val_str:
                    continue
                where_c = cand["where_prefix"] + val_str
                rows.append({
                    "dataset": dom,
                    "variable": var,
                    "result_variable": orres,
                    "value": val_str,
                    "where_clause": where_c,
                    "data_type": _infer_dtype(val_str),
                })
        except Exception as exc:
            log.warning("Cannot read %s for value-level: %s", fp.name, exc)

    if not rows:
        return pd.DataFrame(columns=[
            "dataset", "variable", "result_variable", "value",
            "where_clause", "data_type"
        ])

    result = pd.DataFrame(rows).drop_duplicates(
        subset=["dataset", "variable", "value"]
    ).reset_index(drop=True)
    return result


def _infer_dtype(val: str) -> str:
    try:
        n = float(val)
        if n == int(n):
            return "integer"
        return "float"
    except (ValueError, TypeError):
        pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T", val):
        return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$", val):
        return "Date"
    return "text"


def build_where_clause_table(value_level: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    """Build the Where-Clause tab for Define-XML prep."""
    if value_level.empty:
        return pd.DataFrame(columns=["id", "dataset", "var", "comparator", "value"])
    wh = value_level[["dataset", "variable", "value", "where_clause"]].copy()
    wh["var"] = "PARAMCD" if mode.upper() == "ADAM" else wh["variable"]
    wh["comparator"] = "EQ"
    wh["id"] = wh["where_clause"]
    return wh[["id", "dataset", "var", "comparator", "value"]].reset_index(drop=True)
