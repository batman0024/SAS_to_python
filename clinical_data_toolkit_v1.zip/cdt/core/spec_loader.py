# core/spec_loader.py
"""
Spec loader: reads an Excel mapping specification into a dict of DataFrames.
All sheet column names are normalised to lowercase, stripped strings.
Handles both SDTM and ADaM specs transparently.
"""

import io
import logging
from typing import Dict, Optional

import pandas as pd

log = logging.getLogger(__name__)

KNOWN_REF_SHEETS = {"toc", "codelist", "computation", "standard", "ig"}
EXCLUDE_DOMAINS = {"TA", "TE", "TI", "TV", "TS", "TD", "TM"}


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Lowercase, strip whitespace from all column names."""
    df = df.copy()
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    return df


def load_spec(path: str) -> Dict[str, pd.DataFrame]:
    """Load spec from a file path."""
    with open(path, "rb") as fh:
        return load_spec_from_bytes(fh.read())


def load_spec_from_bytes(data: bytes) -> Dict[str, pd.DataFrame]:
    """
    Load all sheets from a spec Excel file (as bytes).
    Returns dict of {sheet_name: DataFrame} with normalised column names.
    """
    buf = io.BytesIO(data)
    try:
        raw = pd.read_excel(buf, sheet_name=None, engine="openpyxl",
                            dtype=str)
    except Exception as exc:
        raise ValueError(f"Cannot read spec Excel: {exc}") from exc

    result = {}
    for sheet, df in raw.items():
        df = _normalise_columns(df)
        # Replace pandas NA with empty string for string columns
        df = df.fillna("")
        result[sheet] = df
        log.debug("Loaded sheet '%s': %d rows, %d cols", sheet, len(df), len(df.columns))

    return result


def get_toc(spec: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Return the TOC sheet, trying both 'toc' and 'TOC' keys."""
    for key in ("toc", "TOC"):
        if key in spec:
            return spec[key]
    # Try case-insensitive match
    for key, df in spec.items():
        if key.strip().lower() == "toc":
            return df
    raise KeyError("No 'toc' sheet found in spec.")


def get_active_domains(
    spec: Dict[str, pd.DataFrame],
    active_filter: str = "Y",
    explicit_datasets: Optional[list] = None,
) -> list:
    """
    Return list of active domain names from the TOC sheet.
    If explicit_datasets provided, use those instead of the active filter.
    Always excludes TA/TE/TI/TV/TS/TD/TM.
    """
    toc = get_toc(spec)

    if explicit_datasets:
        domains = [d.strip().upper() for d in explicit_datasets if d.strip()]
        return [d for d in domains if d not in EXCLUDE_DOMAINS]

    if "dataset" not in toc.columns:
        raise ValueError("TOC sheet has no 'dataset' column.")

    if "active" in toc.columns:
        mask = toc["active"].str.strip().str.upper() == active_filter.strip().upper()
        active_toc = toc[mask]
    else:
        log.warning("TOC has no 'active' column; treating all rows as active.")
        active_toc = toc

    domains = active_toc["dataset"].dropna().str.strip().str.upper().tolist()
    return [d for d in domains if d not in EXCLUDE_DOMAINS and d != ""]


def get_spec_metadata(spec: Dict[str, pd.DataFrame]) -> dict:
    """
    Try to extract IG version and CT version from TOC or Standard sheet.
    Returns dict with keys: ig_version, ct_version, spec_type (SDTM/ADAM).
    All values default to empty string if not found.
    """
    meta = {"ig_version": "", "ct_version": "", "spec_type": ""}

    # Check TOC columns for version info
    try:
        toc = get_toc(spec)
        for col in toc.columns:
            low = col.lower()
            if "ig" in low and "ver" in low:
                vals = toc[col].dropna().unique()
                if len(vals):
                    meta["ig_version"] = str(vals[0]).strip()
            if "ct" in low and "ver" in low:
                vals = toc[col].dropna().unique()
                if len(vals):
                    meta["ct_version"] = str(vals[0]).strip()
    except Exception:
        pass

    # Infer spec type from domain names in TOC
    try:
        domains = get_active_domains(spec)
        adam_domains = {d for d in domains if d.startswith("AD")}
        meta["spec_type"] = "ADaM" if len(adam_domains) > len(domains) / 2 else "SDTM"
    except Exception:
        pass

    return meta
