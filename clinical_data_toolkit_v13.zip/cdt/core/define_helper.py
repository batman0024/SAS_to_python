# core/define_helper.py  v12 — definitive rewrite
"""
ROOT CAUSES CONFIRMED AND FIXED:

1. CT ACTIVE=N BUG (Images 2, 7):
   _get_codelist_from_spec stores active flag in each entry. Then
   compare_data_vs_codelist builds:
     allowed = {e["value"].upper(): e for e in entries if e["active"]=="Y"}
   Since ALL Codelist tab rows have Active=N in this spec, allowed={} → everything MISMATCH.
   FIX: The Active column in the Codelist tab is at codelist level (is this codelist
   used in the study). It is NOT a per-value validity flag. Include ALL values always.

2. CT decode/vcode/standard EMPTY (Image 2):
   Direct consequence of bug #1 — because allowed={}, in_ct is always False,
   so decode/vcode/standard are never looked up. Fixed by fixing bug #1.

3. VALUE LEVEL ALWAYS EMPTY (Images 1, 3):
   get_value_level_from_store scans columns_df for TESTCD/QNAM patterns.
   When pyreadstat fails → columns_df is empty → no TESTCD cols found → 0 rows.
   FIX: Scan actual file column headers directly, independent of columns_df.

4. WHERE CLAUSE EMPTY (Image 4):
   Direct consequence of bug #3 — no value level = no where clause.
   Fixed by fixing bug #3.

5. XPT FORMAT (Image 3):
   User says they only have .sas7bdat and .xpt. Add XPT support throughout.

6. MEDDRA EXCLUSION (user requirement):
   Codelists whose source is "MEDDRA" or whose name contains MedDRA patterns
   (LLT, HLT, PT, SOC, HLGT) are excluded from CT comparison (too many values,
   not relevant for SDTM CT checks).

7. VARIABLE METADATA (Image 1, 3):
   pyreadstat metadataonly fails on Windows. Since data rows ARE readable (VLM works),
   use the data read as metadata source. Column names from data, labels=blank if unavailable.
"""
import io
import logging
import re
import warnings
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import pandas as pd
import numpy as np

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)

EXCLUDE_DOMAIN_PREFIXES = ("_",)
MAX_CT_UNIQUE_PER_VAR    = 50   # cap unique values checked per variable in CT comparison
MAX_SAMPLE_DISPLAY       = 20   # max values listed in sample_values cell

# MedDRA codelist detection — these produce thousands of numeric codes, not useful for CT
MEDDRA_SOURCE_PATTERNS    = ["MEDDRA", "MEDDR"]
MEDDRA_CODELIST_PATTERNS  = [
    "MEDDRA", "LLT", "HLT", "SOC", "HLGT",
    "LLTCD", "HLTCD", "SOCCD", "HLGTCD", "PTCD",
]


def _is_meddra_codelist(cl_name: str, source: str = "") -> bool:
    """Return True if this codelist is a MedDRA dictionary codelist."""
    n = cl_name.upper()
    s = source.upper()
    if any(p in s for p in MEDDRA_SOURCE_PATTERNS):
        return True
    # Only flag if the ENTIRE name matches MedDRA patterns, not partial substrings
    # e.g. "LLTCD" yes, "LLTRESP" no
    for p in MEDDRA_CODELIST_PATTERNS:
        if n == p or n.startswith(p + "_") or n.endswith("_" + p):
            return True
    return False


# ─────────────────────────────────────────────────────────────────────────────
# File loading — SAS7BDAT, XPT, CSV
# ─────────────────────────────────────────────────────────────────────────────

def _load_file(
    fdata: bytes,
    fname: str,
    usecols: Optional[List[str]] = None,
) -> Tuple[pd.DataFrame, Optional[Any], str]:
    """
    Load SAS7BDAT, XPT, or CSV from bytes.
    Returns (df, meta_or_None, error_string).
    Never raises — always returns a 3-tuple.
    """
    if not fdata:
        dom = Path(fname).stem.upper()
        return pd.DataFrame(), None, f"[{dom}] file bytes are empty"

    fl  = fname.lower()
    dom = Path(fname).stem.upper()
    errors = []

    # ── SAS7BDAT ─────────────────────────────────────────────────────────────
    if fl.endswith(".sas7bdat"):
        try:
            import pyreadstat
        except ImportError:
            errors.append("pyreadstat not installed")
            # fall through to pandas
        else:
            for strategy, kwargs in [
                ("metadataonly+full", {"metadataonly": True}),
                ("row_limit_1",       {"row_limit": 1}),
                ("direct_full",       {}),
            ]:
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kwargs)
                    col_names = _extract_col_names(meta)
                    if col_names:
                        kw = {"usecols": usecols} if usecols else {}
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore")
                            df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
                        df.columns = [c.upper() for c in df.columns]
                        return df, meta, ""
                    # strategy worked but 0 cols — try reading full
                    if strategy == "metadataonly+full":
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore")
                            df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
                        if len(df.columns) > 0:
                            df.columns = [c.upper() for c in df.columns]
                            if usecols:
                                uc = [c.upper() for c in usecols]
                                df = df[[c for c in uc if c in df.columns]]
                            return df, meta, ""
                        errors.append(f"pyreadstat {strategy}: 0 columns")
                    else:
                        errors.append(f"pyreadstat {strategy}: 0 columns")
                except Exception as exc:
                    errors.append(f"pyreadstat {strategy}: {type(exc).__name__}: {exc}")

        # pandas.read_sas fallback for SAS7BDAT
        try:
            df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
            df.columns = [c.upper() for c in df.columns]
            if usecols:
                uc = [c.upper() for c in usecols]
                df = df[[c for c in uc if c in df.columns]]
            if len(df.columns) > 0:
                return df, None, ""
            errors.append("pandas.read_sas sas7bdat: 0 columns")
        except Exception as exc:
            errors.append(f"pandas.read_sas sas7bdat: {type(exc).__name__}: {exc}")

    # ── XPT (SAS Transport) ──────────────────────────────────────────────────
    elif fl.endswith(".xpt") or fl.endswith(".v5"):
        try:
            df = pd.read_sas(io.BytesIO(fdata), format="xport", encoding="latin-1")
            df.columns = [c.upper() for c in df.columns]
            if usecols:
                uc = [c.upper() for c in usecols]
                df = df[[c for c in uc if c in df.columns]]
            if len(df.columns) > 0:
                return df, None, ""
            errors.append("pandas XPT: 0 columns")
        except Exception as exc:
            errors.append(f"pandas XPT: {type(exc).__name__}: {exc}")

    # ── CSV ──────────────────────────────────────────────────────────────────
    elif fl.endswith(".csv"):
        try:
            kw = {"usecols": usecols} if usecols else {}
            df = pd.read_csv(io.BytesIO(fdata), **kw)
            df.columns = [c.upper() for c in df.columns]
            return df, None, ""
        except Exception as exc:
            errors.append(f"CSV: {type(exc).__name__}: {exc}")

    else:
        errors.append(f"Unsupported format: {fl}")

    return pd.DataFrame(), None, f"[{dom}] all strategies failed: {'; '.join(errors)}"


def _extract_col_names(meta) -> List[str]:
    for attr in ("column_names", "column_names_to_labels",
                 "readstat_variable_names", "variable_names"):
        val = getattr(meta, attr, None)
        if isinstance(val, list) and val:
            return val
        if isinstance(val, dict) and val:
            return list(val.keys())
    return []


def _supported_ext(fname: str) -> bool:
    return fname.lower().endswith((".sas7bdat", ".xpt", ".v5", ".csv"))


# ─────────────────────────────────────────────────────────────────────────────
# Variable metadata from dataset files
# ─────────────────────────────────────────────────────────────────────────────

def get_column_metadata_from_store(
    files_store: Dict[str, bytes],
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Read variable metadata from files_store {filename: bytes}.
    Always returns (DataFrame, errors) — never raises.
    """
    rows = []; errors = []
    for fname, fdata in sorted(files_store.items()):
        if not _supported_ext(fname):
            continue
        dom = Path(fname).stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES):
            continue

        df, meta, err = _load_file(fdata, fname)
        if err:
            errors.append(err)
        if df.empty:
            continue

        col_labels = getattr(meta, "column_labels", []) or [] if meta else []
        var_fmts   = getattr(meta, "variable_formats", {}) or {} if meta else {}
        var_types  = (getattr(meta, "original_variable_types", []) or
                      getattr(meta, "readstat_variable_types", []) or []) if meta else []
        var_widths = getattr(meta, "variable_storage_width", {}) or {} if meta else {}

        for idx, col in enumerate(df.columns):
            col_up = col.upper()
            label  = str(col_labels[idx]) if idx < len(col_labels) and col_labels[idx] else ""
            fmt    = (var_fmts.get(col, "") or var_fmts.get(col_up, "")) if isinstance(var_fmts, dict) else ""
            t_raw  = str(var_types[idx]) if idx < len(var_types) and var_types[idx] else ""
            lgth   = (str(var_widths.get(col, "") or var_widths.get(col_up, ""))
                      if isinstance(var_widths, dict) else "")
            pd_dt  = str(df[col].dtype)

            if "char" in t_raw.lower() and "date" in label.lower():   dtype = "datetime"
            elif "char" in t_raw.lower():                              dtype = "text"
            elif any(h in str(fmt).upper() for h in ("DATE","TIME","MMDD","YYMMDD")): dtype = "datetime"
            elif "float" in pd_dt or "int" in pd_dt:                   dtype = "integer"
            else:                                                       dtype = "text"

            rows.append({"domain": dom, "variable": col_up, "label": label,
                         "data_type": dtype, "length": lgth, "format": fmt})

    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["domain","variable","label","data_type","length","format"]), errors
    return df.drop_duplicates(subset=["domain","variable"]).reset_index(drop=True), errors


def get_column_metadata(lib_path: str) -> pd.DataFrame:
    store = {}
    lib = Path(lib_path)
    for ext in ("*.sas7bdat", "*.xpt", "*.csv"):
        for fp in sorted(lib.glob(ext)):
            store[fp.name] = fp.read_bytes()
    df, _ = get_column_metadata_from_store(store)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Spec parsing
# ─────────────────────────────────────────────────────────────────────────────

def _find_codelist_tab(spec: Dict[str, pd.DataFrame]) -> Optional[pd.DataFrame]:
    """Find Codelist sheet case-insensitively."""
    if not spec:
        return None
    for key in spec:
        kl = str(key).strip().lower().replace(" ", "").replace("_", "")
        if kl in ("codelist", "codelists", "codlst", "codes"):
            return spec[key]
    return None


def _get_active_domains_from_toc(spec: Dict[str, pd.DataFrame]) -> List[str]:
    """Return domain names where TOC Active == Y."""
    toc = None
    for key in spec:
        if str(key).strip().lower() == "toc":
            toc = spec[key]
            break
    if toc is None or toc.empty:
        return []
    toc = toc.copy()
    toc.columns = [str(c).strip().lower().replace(" ", "_") for c in toc.columns]
    ds_col  = next((c for c in toc.columns if c in ("dataset", "domain")), None)
    act_col = next((c for c in toc.columns if c == "active"), None)
    if not ds_col:
        return []
    if act_col:
        mask = toc[act_col].astype(str).str.strip().str.upper() == "Y"
        return toc[mask][ds_col].dropna().str.strip().str.upper().tolist()
    return toc[ds_col].dropna().str.strip().str.upper().tolist()


def _get_codelist_from_spec(spec: Dict[str, pd.DataFrame]) -> Dict[str, List[dict]]:
    """
    Parse Codelist tab → {CODELIST_NAME_UPPER: [list_of_value_entries]}.

    CRITICAL: Do NOT filter by Active column.
    The Active column is at codelist level (is codelist used in study).
    ALL values in any codelist row are always valid CT terms.
    """
    cl_df = _find_codelist_tab(spec)
    if cl_df is None or cl_df.empty:
        return {}

    cl_df = cl_df.copy()
    cl_df.columns = [str(c).strip().lower().replace(" ", "_") for c in cl_df.columns]

    # Column detection — Image 7 layout:
    # active, codelist_name, codelist_label, codelist_code, codelist_value_code,
    # codelist_value, codelist_value_decode, synonym, codelist_extensible, codelist_source, standard
    name_col   = next((c for c in cl_df.columns if c == "codelist_name"), None)
    # value col: must be "codelist_value" exactly, NOT "codelist_value_code" or "codelist_value_decode"
    value_col  = next((c for c in cl_df.columns if c == "codelist_value"), None)
    if not value_col:
        # fallback: contains codelist_value but not decode/code suffix
        value_col = next((c for c in cl_df.columns
                          if "codelist_value" in c and "decode" not in c
                          and c != "codelist_value_code"), None)
    decode_col = next((c for c in cl_df.columns if c == "codelist_value_decode"), None)
    vcode_col  = next((c for c in cl_df.columns if c == "codelist_value_code"), None)
    cl_code_col= next((c for c in cl_df.columns if c == "codelist_code"), None)
    ext_col    = next((c for c in cl_df.columns if "extensible" in c), None)
    source_col = next((c for c in cl_df.columns if c in ("codelist_source", "source")), None)
    std_col    = next((c for c in cl_df.columns if c == "standard"), None)
    # active col kept for info only — NOT used to filter
    active_col = next((c for c in cl_df.columns if c == "active"), None)

    if not name_col or not value_col:
        return {}

    result: Dict[str, List[dict]] = {}
    for _, row in cl_df.iterrows():
        cl_name = str(row.get(name_col, "")).strip().upper()
        val     = str(row.get(value_col, "")).strip()
        if not cl_name or not val or val.lower() == "nan":
            continue

        source = str(row.get(source_col, "")).strip() if source_col else ""

        entry = {
            "value":    val,
            "decode":   str(row.get(decode_col,  "")).strip() if decode_col  else "",
            "vcode":    str(row.get(vcode_col,   "")).strip() if vcode_col   else "",
            "cl_code":  str(row.get(cl_code_col, "")).strip() if cl_code_col else "",
            "active":   str(row.get(active_col,  "")).strip() if active_col  else "",
            "extensible": str(row.get(ext_col,   "")).strip() if ext_col     else "",
            "source":   source,
            "standard": str(row.get(std_col,     "")).strip() if std_col     else "",
        }
        result.setdefault(cl_name, []).append(entry)
    return result


def _get_codelist_map_from_spec(spec: Dict[str, pd.DataFrame]) -> Dict[tuple, str]:
    """
    Build {(DOMAIN_UPPER, VARIABLE_UPPER) -> CODELIST_NAME_UPPER}.

    Rules:
    1. Only domains where TOC Active == Y
    2. Only variables where mapping_action not in (DROP, "")
    3. Codelist from named 'codelist' col OR positional index 20 (column U)
    """
    if not spec:
        return {}

    active_domains = set(_get_active_domains_from_toc(spec))
    SKIP_SHEETS = {
        "toc","codelist","codelists","computation","valuelist",
        "maintenance","study","standard","ig",
    }
    try:
        from core.spec_loader import EXCLUDE_DOMAINS
        EXCLUDE = set(EXCLUDE_DOMAINS)
    except ImportError:
        EXCLUDE = {"TA","TE","TI","TV","TS","TD","TM"}

    result = {}
    for sheet, df in spec.items():
        if sheet.strip().lower() in SKIP_SHEETS:
            continue
        if not isinstance(df, pd.DataFrame) or df.empty:
            continue
        dom = sheet.upper()
        if active_domains and dom not in active_domains:
            continue
        if dom in EXCLUDE:
            continue

        var_col = next((c for c in df.columns if c.lower() == "variable"), None)
        if not var_col:
            continue
        ma_col  = next((c for c in df.columns
                        if c.lower() in ("mapping_action","mappingaction","action")), None)
        cl_col  = next((c for c in df.columns
                        if c.lower() in ("codelist","codelist_name","codelist_ref",
                                          "hasnodet","hasnodeterministic")), None)
        if cl_col is None and len(df.columns) > 20:
            cl_col = df.columns[20]
        if not cl_col:
            continue

        for _, row in df.iterrows():
            var = str(row.get(var_col, "")).strip().upper()
            cl  = str(row.get(cl_col,  "")).strip()
            if not var or not cl or cl.lower() in ("nan","","none"):
                continue
            if ma_col:
                ma = str(row.get(ma_col, "")).strip().upper()
                if ma in ("DROP", ""):
                    continue
            result[(dom, var)] = cl.upper()

    return result


def _get_spec_variable_meta(spec: Dict[str, pd.DataFrame]) -> Dict[tuple, dict]:
    """Extract label/type/length for each (domain,variable) from spec sheets."""
    SKIP = {"toc","codelist","codelists","computation","valuelist","maintenance","study","standard","ig"}
    out = {}
    for sheet, df in spec.items():
        if sheet.strip().lower() in SKIP:
            continue
        if not isinstance(df, pd.DataFrame) or df.empty:
            continue
        dom = sheet.upper()
        var_col   = next((c for c in df.columns if c.lower() == "variable"), None)
        label_col = next((c for c in df.columns if c.lower() in ("label","variable_label")), None)
        type_col  = next((c for c in df.columns if c.lower() in ("sas_type","type","sastype")), None)
        len_col   = next((c for c in df.columns if c.lower() in ("sas_length","length","saslength")), None)
        if not var_col:
            continue
        for _, row in df.iterrows():
            var = str(row.get(var_col, "")).strip().upper()
            if not var:
                continue
            out[(dom, var)] = {
                "label":      str(row.get(label_col,"")).strip() if label_col else "",
                "sas_type":   str(row.get(type_col, "")).strip() if type_col  else "",
                "sas_length": str(row.get(len_col,  "")).strip() if len_col   else "",
            }
    return out


# ─────────────────────────────────────────────────────────────────────────────
# CT Comparison
# ─────────────────────────────────────────────────────────────────────────────

def compare_data_vs_codelist(
    files_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
    max_unique_per_var: int = MAX_CT_UNIQUE_PER_VAR,
) -> pd.DataFrame:
    """
    Compare actual SDTM variable values against Codelist tab column F (Codelist_Value).

    KEY FIXES:
    - ALL codelist values included regardless of Active column (Active=N ≠ invalid value)
    - MedDRA codelists excluded (too many numeric codes, not SDTM CT)
    - Capped at 50 unique values per variable
    - Populates ct_decode, ct_vcode, ct_standard, ct_source columns from codelist tab
    """
    if not spec or not files_store:
        return pd.DataFrame()

    cl_map    = _get_codelist_map_from_spec(spec)
    cl_lookup = _get_codelist_from_spec(spec)

    if not cl_map:
        return pd.DataFrame()

    dom_store = {}
    for fname, fdata in files_store.items():
        if _supported_ext(fname):
            dom_store[Path(fname).stem.upper()] = (fname, fdata)

    domain_vars: Dict[str, List[str]] = defaultdict(list)
    for (dom, var) in cl_map:
        domain_vars[dom].append(var)

    rows = []
    for dom, vars_list in sorted(domain_vars.items()):
        if dom not in dom_store:
            continue
        fname, fdata = dom_store[dom]
        df_dom, _, load_err = _load_file(fdata, fname)
        if df_dom.empty:
            if load_err:
                log.debug("CT compare load: %s", load_err)
            continue

        for var in vars_list:
            if var not in df_dom.columns:
                continue

            cl_name    = cl_map.get((dom, var), "")
            ct_entries = cl_lookup.get(cl_name, [])

            if not ct_entries:
                continue

            # Skip MedDRA codelists
            source_sample = ct_entries[0].get("source", "") if ct_entries else ""
            if _is_meddra_codelist(cl_name, source_sample):
                continue

            # Build lookup from ALL entries (do NOT filter by active)
            allowed: Dict[str, dict] = {e["value"].upper(): e for e in ct_entries}

            col_data = (df_dom[var]
                        .dropna()
                        .astype(str)
                        .str.strip())
            col_data = col_data[col_data.str.lower() != "nan"]
            if col_data.empty:
                continue

            unique_vals = sorted(col_data.unique())
            truncated   = len(unique_vals) > max_unique_per_var
            if truncated:
                unique_vals = unique_vals[:max_unique_per_var]

            for val in unique_vals:
                val_upper = val.upper()
                in_ct     = val_upper in allowed
                entry     = allowed.get(val_upper, {})
                n_obs     = int((col_data == val).sum())

                rows.append({
                    "domain":      dom,
                    "variable":    var,
                    "codelist":    cl_name,
                    "value":       val,
                    "n_obs":       n_obs,
                    "in_ct":       "YES" if in_ct else "NO",
                    "ct_decode":   entry.get("decode",   ""),
                    "ct_vcode":    entry.get("vcode",    ""),
                    "ct_standard": entry.get("standard", ""),
                    "ct_source":   entry.get("source",   ""),
                    "status":      "PASS" if in_ct else "MISMATCH",
                    "note":        f"First {max_unique_per_var} of {col_data.nunique()} values shown" if truncated else "",
                })

    if not rows:
        return pd.DataFrame()
    return (pd.DataFrame(rows)
            .sort_values(["domain","variable","status","value"])
            .reset_index(drop=True))


# ─────────────────────────────────────────────────────────────────────────────
# VLM — Variable Level Metadata
# ─────────────────────────────────────────────────────────────────────────────

def build_vlm_from_spec_and_data(
    files_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """
    One row per (domain, variable) with codelist in spec.
    Includes spec metadata, actual data stats, CT values from codelist tab.
    """
    if not spec:
        return pd.DataFrame()

    cl_map    = _get_codelist_map_from_spec(spec)
    cl_lookup = _get_codelist_from_spec(spec)
    spec_meta = _get_spec_variable_meta(spec)
    if not cl_map:
        return pd.DataFrame()

    dom_store = {}
    for fname, fdata in files_store.items():
        if _supported_ext(fname):
            dom_store[Path(fname).stem.upper()] = (fname, fdata)

    domain_vars: Dict[str, List[str]] = defaultdict(list)
    for (dom, var) in cl_map:
        domain_vars[dom].append(var)

    domain_data: Dict[str, pd.DataFrame] = {}
    for dom, _ in domain_vars.items():
        if dom not in dom_store:
            continue
        fname, fdata = dom_store[dom]
        df_d, _, _ = _load_file(fdata, fname)
        if not df_d.empty:
            domain_data[dom] = df_d

    rows = []
    for (dom, var), cl_name in sorted(cl_map.items()):
        sm         = spec_meta.get((dom, var), {})
        label      = sm.get("label", "")
        sas_type   = sm.get("sas_type", "")
        sas_length = sm.get("sas_length", "")

        ct_entries    = cl_lookup.get(cl_name, [])
        source_sample = ct_entries[0].get("source", "") if ct_entries else ""
        is_meddra     = _is_meddra_codelist(cl_name, source_sample)
        ct_vals_all   = sorted({e["value"] for e in ct_entries})
        ct_ext = ct_entries[0]["extensible"] if ct_entries else ""
        ct_src = ct_entries[0]["source"]     if ct_entries else ""
        ct_std = ct_entries[0]["standard"]   if ct_entries else ""

        n = len(ct_vals_all)
        ct_vals_display = ("; ".join(ct_vals_all) if n <= MAX_SAMPLE_DISPLAY
                           else "; ".join(ct_vals_all[:MAX_SAMPLE_DISPLAY]) + f" ... (+{n-MAX_SAMPLE_DISPLAY} more)")

        actual_max_len = ""; n_distinct = ""; has_decimals = ""
        sample_vals = ""; mismatch_vals = ""; mismatch_count = ""
        ct_status = "NO DATA"; actual_data_type = "text"

        df_dom = domain_data.get(dom)
        if df_dom is not None and var in df_dom.columns:
            col_data = df_dom[var].dropna()
            col_str  = col_data.astype(str).str.strip()
            col_str  = col_str[col_str.str.lower() != "nan"]
            n_uniq   = col_str.nunique()
            n_distinct = str(n_uniq)

            uniq_vals = sorted(col_str.unique())
            if n_uniq <= MAX_SAMPLE_DISPLAY:
                sample_vals = "; ".join(uniq_vals)
            else:
                sample_vals = "; ".join(uniq_vals[:5]) + f" ... (+{n_uniq-5} more)"

            if sas_type.upper() in ("CHAR","C","CHARACTER","TEXT"):
                actual_max_len   = str(col_str.str.len().max()) if not col_str.empty else "0"
                has_decimals     = "N/A"
                actual_data_type = "text"
            else:
                try:
                    numeric = pd.to_numeric(col_data, errors="coerce").dropna()
                    if not numeric.empty:
                        actual_max_len = str(int(numeric.abs().max()))
                        dec = numeric[numeric != numeric.round()]
                        has_decimals   = f"Y (max {int(numeric.apply(lambda x: len(str(x).split('.')[-1]) if '.' in str(x) else 0).max())} dp)" if len(dec) > 0 else "N"
                        actual_data_type = "float" if len(dec) > 0 else "integer"
                except Exception:
                    pass

            if is_meddra:
                ct_status = "SKIPPED (MedDRA — too many values)"
            elif ct_entries:
                allowed_upper = {e["value"].upper() for e in ct_entries}
                check_vals    = uniq_vals[:MAX_CT_UNIQUE_PER_VAR]
                mismatches    = [v for v in check_vals if v.upper() not in allowed_upper]
                mismatch_count = str(len(mismatches))
                mismatch_vals  = "; ".join(mismatches[:10])
                suffix = f" (first {MAX_CT_UNIQUE_PER_VAR} checked)" if n_uniq > MAX_CT_UNIQUE_PER_VAR else ""
                ct_status = "PASS" if not mismatches else f"MISMATCH ({len(mismatches)} values){suffix}"
            else:
                ct_status = "NO CT VALUES IN SPEC"

        rows.append({
            "domain":             dom,
            "variable":           var,
            "label":              label,
            "sas_type":           sas_type,
            "sas_length":         sas_length,
            "spec_codelist":      cl_name,
            "is_meddra":          "YES" if is_meddra else "",
            "actual_data_type":   actual_data_type,
            "actual_max_length":  actual_max_len,
            "n_distinct_values":  n_distinct,
            "has_decimals":       has_decimals,
            "sample_values":      sample_vals,
            "ct_values_allowed":  ct_vals_display,
            "n_ct_values":        str(n),
            "ct_extensible":      ct_ext,
            "ct_source":          ct_src,
            "ct_standard":        ct_std,
            "ct_mismatch_values": mismatch_vals,
            "ct_mismatch_count":  mismatch_count,
            "ct_status":          ct_status,
        })

    return pd.DataFrame(rows)


# ─────────────────────────────────────────────────────────────────────────────
# Value Level — scans file headers directly, does NOT need columns_df
# ─────────────────────────────────────────────────────────────────────────────

def get_value_level_from_store(
    files_store: Dict[str, bytes],
    columns_df: Optional[pd.DataFrame] = None,
    mode: str = "SDTM",
) -> pd.DataFrame:
    """
    Extract value-level (TESTCD/QNAM for SDTM, PARAMCD for ADaM).

    FIX: Scans file column headers directly — does NOT require columns_df to be
    populated. This means value level works even when pyreadstat metadata fails.
    columns_df is accepted for backward compatibility but ignored for column detection.
    """
    mode = mode.upper()
    EMPTY = pd.DataFrame(columns=["dataset","variable","result_variable",
                                   "value","where_clause","data_type"])

    if not files_store:
        return EMPTY

    dom_store = {}
    for fname, fdata in files_store.items():
        if _supported_ext(fname):
            dom_store[Path(fname).stem.upper()] = (fname, fdata)

    pat_sdtm = re.compile(r"TESTCD|QNAM|PARMCD", re.IGNORECASE)
    pat_adam  = re.compile(r"^PARAMCD$", re.IGNORECASE)

    rows = []
    for dom, (fname, fdata) in sorted(dom_store.items()):
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES):
            continue

        # Get file column headers cheaply
        try:
            if fname.lower().endswith(".csv"):
                df_hdr = pd.read_csv(io.BytesIO(fdata), nrows=0)
                col_names = [c.upper() for c in df_hdr.columns]
            else:
                # For SAS/XPT: load the full file (needed for data anyway)
                df_full, _, err = _load_file(fdata, fname)
                if df_full.empty:
                    continue
                col_names = list(df_full.columns)
        except Exception:
            continue

        if mode == "ADAM":
            testcd_cols = [(c, "AVAL", f"{dom}.{c}.") for c in col_names if pat_adam.match(c)]
        else:
            testcd_cols = [(c,
                            ("" if "TESTCD" in c else "QVAL"),
                            f"{dom}.{c}.")
                           for c in col_names if pat_sdtm.search(c)]

        if not testcd_cols:
            continue

        # Load the full data (may already be loaded above)
        try:
            if fname.lower().endswith(".csv"):
                df_full = pd.read_csv(io.BytesIO(fdata))
                df_full.columns = [c.upper() for c in df_full.columns]
            # For SAS/XPT df_full is already loaded above
        except Exception:
            continue

        for (col, orres_suffix, where_prefix) in testcd_cols:
            if col not in df_full.columns:
                continue
            if not orres_suffix:
                # For TESTCD: result variable is domain + ORRES, e.g. LBORRES
                orres = dom + "ORRES"
            else:
                orres = orres_suffix

            for val in df_full[col].dropna().unique():
                vs = str(val).strip()
                if not vs or vs.lower() == "nan":
                    continue
                rows.append({
                    "dataset":         dom,
                    "variable":        col,
                    "result_variable": orres,
                    "value":           vs,
                    "where_clause":    where_prefix + vs,
                    "data_type":       _infer_dtype(vs),
                })

    if not rows:
        return EMPTY
    return (pd.DataFrame(rows)
            .drop_duplicates(subset=["dataset","variable","value"])
            .reset_index(drop=True))


def get_value_level(lib_path: str, columns_df=None, mode: str = "SDTM") -> pd.DataFrame:
    store = {}
    lib = Path(lib_path)
    for ext in ("*.sas7bdat", "*.xpt", "*.csv"):
        for fp in sorted(lib.glob(ext)):
            store[fp.name] = fp.read_bytes()
    return get_value_level_from_store(store, columns_df, mode)


def build_where_clause_table(value_level: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    """Build Define-XML where-clause table from value level."""
    if value_level is None or value_level.empty:
        return pd.DataFrame(columns=["id","dataset","variable","comparator","value","where_clause"])
    wh = value_level[["dataset","variable","value","where_clause"]].copy()
    wh["comparator"] = "EQ"
    wh["id"]         = wh["where_clause"]
    if "result_variable" in value_level.columns:
        wh["result_variable"] = value_level["result_variable"].values
    return wh[["id","dataset","variable","comparator","value","where_clause"]].reset_index(drop=True)


def _infer_dtype(val: str) -> str:
    try:
        n = float(val)
        return "integer" if n == int(n) else "float"
    except (ValueError, TypeError):
        pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T", val): return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$",  val): return "Date"
    return "text"


def validate_ct_values(value_level: pd.DataFrame, spec: Dict) -> pd.DataFrame:
    """Legacy wrapper for backward compatibility."""
    if value_level is None or value_level.empty:
        return pd.DataFrame()
    cl_lookup = _get_codelist_from_spec(spec)
    cl_map    = _get_codelist_map_from_spec(spec)
    rows = []
    for _, vrow in value_level.iterrows():
        ds  = str(vrow["dataset"]).upper()
        var = str(vrow["variable"]).upper()
        val = str(vrow["value"]).strip()
        cl_name = cl_map.get((ds, var))
        if not cl_name:
            continue
        allowed = {e["value"].upper() for e in cl_lookup.get(cl_name, [])}
        if not allowed:
            continue
        in_ct = val.upper() in allowed
        rows.append({"dataset":ds,"variable":var,"value":val,"codelist":cl_name,
                     "in_ct":"YES" if in_ct else "NO",
                     "status":"PASS" if in_ct else "MISMATCH"})
    return pd.DataFrame(rows).reset_index(drop=True)


# backward compat aliases
_find_codelist_tab_alias     = _find_codelist_tab
_get_codelist_map_from_spec_alias = _get_codelist_map_from_spec
