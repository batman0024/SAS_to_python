# pages/3_Define_Helper.py  v12 — definitive
import sys, warnings, io, traceback
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import get_palette, build_css, render_table
from core.define_helper import (
    get_column_metadata_from_store,
    get_value_level_from_store,
    build_where_clause_table,
    build_vlm_from_spec_and_data,
    compare_data_vs_codelist,
    _find_codelist_tab,
    _get_codelist_map_from_spec,
    _get_active_domains_from_toc,
    _is_meddra_codelist,
)
from core.excel_export import export_define_results

st.set_page_config(page_title="Define Helper", layout="wide")
theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True, key="def_theme")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)

st.title("Define Helper")
st.caption(
    "Extracts variable metadata, VLM with codelist values, CT comparison "
    "and value-level / where-clause from SDTM or ADaM datasets."
)

# ── Check uploads ─────────────────────────────────────────────────────────
if "sdtm_files_store" not in st.session_state or not st.session_state["sdtm_files_store"]:
    st.warning("Upload SDTM/ADaM datasets in the sidebar first (.sas7bdat, .xpt, or .csv).")
    st.stop()

sdtm_store = st.session_state["sdtm_files_store"]
spec       = st.session_state.get("spec")
spec_name  = st.session_state.get("spec_name","")

# ── Dataset info ───────────────────────────────────────────────────────────
ds_names = ", ".join(sorted(Path(k).stem.upper() for k in sdtm_store.keys()))
st.info(f"**{len(sdtm_store)} dataset(s) loaded:** {ds_names[:200]}{'...' if len(ds_names)>200 else ''}")

# ── Spec status ────────────────────────────────────────────────────────────
cl_tab = None; cl_map = {}; active_domains = []
if spec:
    cl_tab         = _find_codelist_tab(spec)
    cl_map         = _get_codelist_map_from_spec(spec)
    active_domains = _get_active_domains_from_toc(spec)
    cl_ok          = cl_tab is not None

    c1, c2 = st.columns(2)
    cl_msg = f"✅ Codelist tab found ({len(cl_tab):,} rows)" if cl_ok else "⚠️ Codelist tab NOT found"
    c1.info(f"**Spec:** {spec_name}  |  {cl_msg}")
    c2.info(f"**TOC active domains:** {len(active_domains)}  |  **Variables with codelist:** {len(cl_map)}")

    if not cl_ok:
        with st.expander("Codelist tab not found — details", expanded=True):
            st.markdown(
                f"**Sheets in spec:** `{', '.join(spec.keys())}`\n\n"
                "The tool searches for a sheet named `Codelist` (case-insensitive). "
                "Ensure your Excel spec has a sheet matching that name."
            )
else:
    st.warning("No mapping spec loaded. VLM and CT tabs require a spec. Upload in the sidebar.")

# ── Options ────────────────────────────────────────────────────────────────
with st.expander("Options", expanded=False):
    col1, col2 = st.columns(2)
    with col1:
        mode     = st.radio("Mode", ["SDTM","ADaM"], horizontal=True)
        run_meta = st.checkbox("Extract variable metadata from datasets", value=True,
            help="Reads domain/variable/label/type/length/format from each file.")
        run_vlm  = st.checkbox("Build VLM from spec codelist column", value=bool(spec and cl_tab is not None))
        run_ct   = st.checkbox("Run CT comparison (actual data vs codelist)", value=bool(spec and cl_tab is not None))
    with col2:
        run_vl   = st.checkbox("Extract value-level TESTCD/PARAMCD", value=True,
            help="Works directly from file column headers — does NOT need metadata step.")
        st.caption("ℹ️ Value level scans file column headers directly, independent of metadata.")
        st.caption("ℹ️ MedDRA codelists (LLTCD, HLGTCD, etc.) are automatically excluded from CT comparison.")

if st.button("Generate", type="primary", use_container_width=True):
    columns_df = pd.DataFrame()
    vlm_df     = pd.DataFrame()
    ct_df      = pd.DataFrame()
    vl_df      = pd.DataFrame()
    wh_df      = pd.DataFrame()
    read_errors = []

    # Step 1: Variable metadata
    if run_meta:
        with st.spinner("Extracting variable metadata from datasets..."):
            try:
                result = get_column_metadata_from_store(sdtm_store)
                if isinstance(result, tuple):
                    columns_df, read_errors = result
                else:
                    columns_df, read_errors = pd.DataFrame(), ["Unexpected return from metadata function"]
            except Exception as exc:
                read_errors = [f"Exception: {type(exc).__name__}: {exc}\n{traceback.format_exc()}"]
                columns_df = pd.DataFrame()

        if read_errors:
            with st.expander(f"⚠ {len(read_errors)} file(s) had metadata read issues", expanded=False):
                for err in read_errors[:20]:
                    st.code(str(err))

    # Step 2: VLM
    if run_vlm and spec and cl_tab is not None:
        with st.spinner("Building VLM from spec codelist column + actual data..."):
            try:
                vlm_df = build_vlm_from_spec_and_data(sdtm_store, spec)
            except Exception as exc:
                st.warning(f"VLM error: {type(exc).__name__}: {exc}")
                st.code(traceback.format_exc())

    # Step 3: CT comparison
    if run_ct and spec and cl_tab is not None:
        with st.spinner("Running CT comparison (actual data vs codelist)..."):
            try:
                ct_df = compare_data_vs_codelist(sdtm_store, spec)
            except Exception as exc:
                st.warning(f"CT comparison error: {type(exc).__name__}: {exc}")
                st.code(traceback.format_exc())

    # Step 4: Value level — works WITHOUT columns_df
    if run_vl:
        with st.spinner("Extracting value-level (TESTCD/PARAMCD/QNAM)..."):
            try:
                vl_df = get_value_level_from_store(sdtm_store, columns_df or None, mode)
                if not vl_df.empty:
                    wh_df = build_where_clause_table(vl_df, mode)
            except Exception as exc:
                st.warning(f"Value-level error: {type(exc).__name__}: {exc}")
                st.code(traceback.format_exc())

    st.session_state.update({
        "define_columns":      columns_df,
        "define_mode":         mode,
        "define_vlm":          vlm_df,
        "define_ct_compare":   ct_df,
        "define_value_level":  vl_df,
        "define_where_clause": wh_df,
        "define_meta_skipped": not run_meta,
        "define_meta_failed":  run_meta and columns_df.empty,
    })
    st.rerun()

# ── Nothing generated yet ──────────────────────────────────────────────────
if not any(k in st.session_state for k in ("define_columns","define_vlm",
                                             "define_ct_compare","define_value_level")):
    st.info("Configure options above and click Generate.")
    st.stop()

columns_df   = st.session_state.get("define_columns",     pd.DataFrame())
vlm_df       = st.session_state.get("define_vlm",         pd.DataFrame())
ct_df        = st.session_state.get("define_ct_compare",  pd.DataFrame())
vl_df        = st.session_state.get("define_value_level", pd.DataFrame())
wh_df        = st.session_state.get("define_where_clause",pd.DataFrame())
mode         = st.session_state.get("define_mode",        "SDTM")
meta_skipped = st.session_state.get("define_meta_skipped",False)
meta_failed  = st.session_state.get("define_meta_failed", False)

n_vars    = len(columns_df)
n_cl_vars = vlm_df["variable"].nunique() if not vlm_df.empty else 0
n_miss    = int((ct_df["status"]=="MISMATCH").sum()) if not ct_df.empty else 0
n_miss_v  = int(ct_df[ct_df["status"]=="MISMATCH"]["variable"].nunique()) if not ct_df.empty else 0
n_vl      = len(vl_df) if not vl_df.empty else 0
n_wh      = len(wh_df) if not wh_df.empty else 0

# ── Metrics ────────────────────────────────────────────────────────────────
st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">Variables (metadata)</div>'
    f'<div class="value" style="color:{C["text_main"]};">{n_vars:,}</div></div>'
    f'<div class="metric-item"><div class="label">VLM Variables (codelist)</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{n_cl_vars:,}</div></div>'
    f'<div class="metric-item"><div class="label">CT Mismatch Values</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_miss:,}</div></div>'
    f'<div class="metric-item"><div class="label">CT Mismatch Variables</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_miss_v:,}</div></div>'
    f'<div class="metric-item"><div class="label">Value-Level Rows</div>'
    f'<div class="value" style="color:{C["pass_fg"]};">{n_vl:,}</div></div>'
    f'<div class="metric-item"><div class="label">Where-Clause Rows</div>'
    f'<div class="value" style="color:{C["pass_fg"]};">{n_wh:,}</div></div>'
    f'</div>',
    unsafe_allow_html=True
)

# ── Download ───────────────────────────────────────────────────────────────
excel_bytes = export_define_results(
    columns_df if not columns_df.empty else pd.DataFrame(),
    vl_df      if not vl_df.empty      else pd.DataFrame(),
    wh_df      if not wh_df.empty      else pd.DataFrame(),
    vlm_df     if not vlm_df.empty     else None,
    ct_df      if not ct_df.empty      else None,
)
st.download_button(
    "⬇ Download Define Report (.xlsx)", data=excel_bytes,
    file_name=f"Define_{mode}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)
st.divider()

# ── Tabs ───────────────────────────────────────────────────────────────────
tabs = st.tabs([
    f"Variable Metadata ({n_vars:,})",
    f"VLM / Codelist ({n_cl_vars:,} vars)",
    f"CT Comparison ({n_miss:,} mismatches)",
    f"Value Level ({n_vl:,} rows)",
    f"Where Clause ({n_wh:,} rows)",
])

# Tab 1: Variable Metadata
with tabs[0]:
    if columns_df.empty:
        if meta_skipped:
            st.info(
                "**Variable metadata was not extracted** — 'Extract variable metadata' was unchecked.  \n\n"
                "VLM, CT Comparison, Value Level, and Where Clause all work independently of this step.  \n\n"
                "To populate this tab: check the option and click Generate again."
            )
        else:
            st.warning(
                "**Variable metadata could not be read from the .sas7bdat files.**  \n\n"
                "This is a known pyreadstat limitation on some Windows builds — the metadata header "
                "cannot be parsed but the data rows are still readable.  \n\n"
                "**This does NOT affect VLM, CT Comparison, Value Level, or Where Clause tabs** — "
                "those read data rows directly.  \n\n"
                "To get metadata: upgrade pyreadstat (`pip install --upgrade pyreadstat`) "
                "or export datasets as CSV."
            )
    else:
        dom_opts = ["All"] + sorted(columns_df["domain"].unique().tolist())
        dom_sel  = st.selectbox("Domain", dom_opts, key="def_dom")
        disp     = columns_df if dom_sel=="All" else columns_df[columns_df["domain"]==dom_sel]
        st.caption(f"{len(disp):,} variables")
        st.dataframe(disp, use_container_width=True, height=450)

# Tab 2: VLM
with tabs[1]:
    if vlm_df.empty:
        if not spec:
            st.info("Load a mapping spec in the sidebar to enable VLM.")
        elif cl_tab is None:
            st.error(f"Codelist tab not found. Available sheets: `{', '.join(spec.keys())}`")
        else:
            st.warning("VLM is empty — ensure domain sheets have a codelist value in column U (the 21st column).")
    else:
        cf1,cf2,cf3 = st.columns(3)
        dom_opts = ["All"] + sorted(vlm_df["domain"].unique().tolist())
        dom_sel  = cf1.selectbox("Domain", dom_opts, key="vlm_dom")
        cl_opts  = ["All"] + sorted(vlm_df["spec_codelist"].unique().tolist())
        cl_sel   = cf2.selectbox("Codelist", cl_opts, key="vlm_cl")
        st_opts  = ["All","PASS","MISMATCH","NO DATA","NO CT VALUES IN SPEC","SKIPPED (MedDRA)"]
        st_sel   = cf3.selectbox("CT Status", st_opts, key="vlm_st")

        disp = vlm_df.copy()
        if dom_sel != "All": disp = disp[disp["domain"]==dom_sel]
        if cl_sel  != "All": disp = disp[disp["spec_codelist"]==cl_sel]
        if st_sel  != "All": disp = disp[disp["ct_status"].str.contains(st_sel, na=False, regex=False)]

        def _vlm_rc(r):
            s = str(r.get("ct_status",""))
            return "row-miss" if "MISMATCH" in s else ("row-pass" if s=="PASS" else "")

        st.caption(f"Showing {len(disp):,} of {len(vlm_df):,} rows")
        st.markdown(render_table(disp, row_class_fn=_vlm_rc, C=C), unsafe_allow_html=True)

        if HAS_PLOTLY:
            sc = vlm_df["ct_status"].apply(
                lambda s: "PASS" if s=="PASS" else "MISMATCH" if "MISMATCH" in str(s)
                         else "MedDRA (skipped)" if "MedDRA" in str(s) else "NO DATA"
            ).value_counts().reset_index()
            sc.columns = ["status","count"]
            tpl = "plotly" if theme_mode=="light" else "plotly_dark"
            fig = px.pie(sc, names="status", values="count", hole=0.4, height=240,
                         color="status", title="CT Status Distribution",
                         color_discrete_map={"PASS":"#4ade80","MISMATCH":"#f87171",
                                             "MedDRA (skipped)":"#94a3b8","NO DATA":"#64748b"})
            fig.update_layout(template=tpl, margin=dict(l=0,r=0,t=36,b=0),
                               paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
            st.plotly_chart(fig, use_container_width=True)

# Tab 3: CT Comparison
with tabs[2]:
    if ct_df.empty:
        if not spec:
            st.info("Load a mapping spec to enable CT comparison.")
        elif cl_tab is None:
            st.error("Codelist tab not found in spec.")
        else:
            st.info(
                "CT comparison returned no results.  \n"
                "Possible reasons:\n"
                "- Domain sheets do not have a codelist value in column U\n"
                "- TOC Active=Y domains not matching uploaded datasets\n"
                "- All matching codelists are MedDRA (automatically excluded)"
            )
    else:
        n_p = int((ct_df["status"]=="PASS").sum())
        c1,c2,c3 = st.columns(3)
        c1.metric("Total values checked", len(ct_df))
        c2.metric("PASS", n_p)
        c3.metric("MISMATCH", n_miss)

        cf1,cf2,cf3 = st.columns(3)
        show_miss = cf1.checkbox("Mismatches only", value=True, key="ct_miss")
        dom_ct    = cf2.selectbox("Domain", ["All"]+sorted(ct_df["domain"].unique().tolist()), key="ct_dom")
        var_ct    = cf3.selectbox("Variable", ["All"]+sorted(ct_df["variable"].unique().tolist()), key="ct_var")

        disp_ct = ct_df[ct_df["status"]=="MISMATCH"] if show_miss else ct_df
        if dom_ct != "All": disp_ct = disp_ct[disp_ct["domain"]==dom_ct]
        if var_ct != "All": disp_ct = disp_ct[disp_ct["variable"]==var_ct]

        st.download_button("⬇ CT Comparison (.csv)", data=disp_ct.to_csv(index=False).encode(),
            file_name=f"CT_Comparison_{datetime.now():%Y%m%d_%H%M}.csv", mime="text/csv")

        def _ct_rc(r): return "row-miss" if r.get("status","")=="MISMATCH" else "row-pass"
        st.caption(f"Showing {len(disp_ct):,} rows")
        st.markdown(render_table(disp_ct, row_class_fn=_ct_rc, C=C), unsafe_allow_html=True)

        if HAS_PLOTLY and n_miss > 0:
            miss_by = (ct_df[ct_df["status"]=="MISMATCH"]
                       .groupby(["domain","variable"])
                       .agg(n=("status","count")).reset_index()
                       .sort_values("n", ascending=False).head(20))
            miss_by["dv"] = miss_by["domain"] + "." + miss_by["variable"]
            tpl = "plotly" if theme_mode=="light" else "plotly_dark"
            fig2 = px.bar(miss_by, x="dv", y="n",
                          title="CT Mismatches by Variable (top 20)",
                          color="n", color_continuous_scale=["#fbbf24","#ef4444"], height=260)
            fig2.update_layout(template=tpl, margin=dict(l=0,r=0,t=36,b=0),
                                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                                showlegend=False, coloraxis_showscale=False)
            fig2.update_xaxes(tickangle=-40)
            st.plotly_chart(fig2, use_container_width=True)

# Tab 4: Value Level
with tabs[3]:
    if vl_df is None or vl_df.empty:
        st.info(
            "Value-level is empty.  \n\n"
            "This tab extracts distinct values from TESTCD, QNAM, PARAMCD columns "
            "found in the uploaded datasets.  \n\n"
            "If your datasets contain these columns but nothing appears:  \n"
            "- Ensure the datasets are uploaded in the sidebar  \n"
            "- Check the Mode (SDTM vs ADaM) matches your datasets  \n"
            "- The datasets must contain columns matching TESTCD, QNAM, or PARMCD patterns"
        )
    else:
        dom2  = ["All"] + sorted(vl_df["dataset"].unique().tolist())
        d2    = st.selectbox("Domain", dom2, key="def_vl")
        disp2 = vl_df if d2=="All" else vl_df[vl_df["dataset"]==d2]
        st.caption(f"{len(disp2):,} value-level rows")
        st.dataframe(disp2, use_container_width=True, height=450)

# Tab 5: Where Clause
with tabs[4]:
    if wh_df is None or wh_df.empty:
        st.info("Where clause not generated — requires value-level data (Tab 4) to be populated first.")
    else:
        st.caption(f"{len(wh_df):,} where-clause rows")
        st.dataframe(wh_df, use_container_width=True, height=450)
