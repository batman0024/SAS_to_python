# core/define_helper.py
"""
Define helper v8 — full redesign based on actual spec structure:

IMAGE 1 (domain tab columns):
  C=Dataset, D=Variable, E=Label, F=SAS_Type, G=SAS_Length,
  K=Input_Variables, L=Mapping_Action, U=Codelist (column 21 = index 20)

IMAGE 2 (Codelist tab columns):
  Active, Codelist_Name, Codelist_Label, Codelist_Code,
  Codelist_Value_Code, Codelist_Value, Codelist_Value_Decode,
  Synonym, Codelist_Extensible, Codelist_Source, Standard

KEY CHANGES:
  1. VLM built from spec column U (codelist), not from TESTCD pattern-matching
  2. Actual data statistics: max_length, n_distinct, has_decimals, sample_values
  3. Codelist tab lookup fixed: searches ALL sheet names case-insensitively
  4. CT comparison: actual data values vs codelist permitted values
  5. 4-pass SAS reader with pandas.read_sas fallback
  6. Empty bytes guard
"""
import io
import logging
import re
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd
import numpy as np

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)

EXCLUDE_DOMAIN_PREFIXES = ("_",)

SAS_EPOCH = pd.Timestamp("1960-01-01")


# ─────────────────────────────────────────────────────────────────────────────
# pyreadstat helpers
# ─────────────────────────────────────────────────────────────────────────────

def _safe_meta_attr(meta, attr, default=None):
    return getattr(meta, attr, default)


def _extract_col_names(meta) -> List[str]:
    for attr in ("column_names","column_names_to_labels",
                 "readstat_variable_names","variable_names"):
        val = getattr(meta, attr, None)
        if isinstance(val, list) and val: return val
        if isinstance(val, dict) and val: return list(val.keys())
    return []


def _load_sas_df(fdata: bytes, domain: str,
                 usecols: Optional[List[str]] = None) -> Tuple[pd.DataFrame, Optional[object], str]:
    """
    Load a SAS dataset from bytes.
    Returns (df, meta, error_message).
    Tries pyreadstat (3 passes) then pandas.read_sas.
    """
    if not fdata:
        return pd.DataFrame(), None, f"[{domain}] empty bytes"

    try:
        import pyreadstat
        # Pass 1: metadataonly
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                kwargs = {"metadataonly": True}
                _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kwargs)
            if _extract_col_names(meta):
                # Re-read with data
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    kw = {"usecols": usecols} if usecols else {}
                    df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
                df.columns = [c.upper() for c in df.columns]
                return df, meta, ""
        except Exception:
            pass

        # Pass 2: row_limit=1 to get schema
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df1, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), row_limit=1)
            if len(df1.columns) > 0:
                # Full read
                kw = {"usecols": usecols} if usecols else {}
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
                df.columns = [c.upper() for c in df.columns]
                return df, meta, ""
        except Exception:
            pass

        # Pass 3: full read direct
        try:
            kw = {"usecols": usecols} if usecols else {}
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
            if len(df.columns) > 0:
                df.columns = [c.upper() for c in df.columns]
                return df, meta, ""
        except Exception as e3:
            pass

    except ImportError:
        pass

    # Pass 4: pandas.read_sas
    try:
        df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
        df.columns = [c.upper() for c in df.columns]
        if usecols:
            uc = [c.upper() for c in usecols]
            df = df[[c for c in uc if c in df.columns]]
        return df, None, ""
    except Exception as e4:
        return pd.DataFrame(), None, f"[{domain}] all reads failed: {e4}"


def _meta_from_sas_bytes(fdata: bytes, domain: str) -> Tuple[list, str]:
    """Read variable metadata rows. Returns (rows, error)."""
    if not fdata:
        return [], f"[{domain}] File bytes are empty — use .getvalue() in app.py upload handler."

    df, meta, err = _load_sas_df(fdata, domain)
    if df.empty and err:
        return [], err
    if df.empty:
        # Try metadata-only path for column names without reading data
        try:
            import pyreadstat
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), metadataonly=True)
            col_names = _extract_col_names(meta)
            if col_names:
                return _build_meta_rows_from_names(col_names, meta, domain), ""
        except Exception:
            pass
        return [], f"[{domain}] 0 columns returned"

    col_labels = _safe_meta_attr(meta, "column_labels", []) or [] if meta else []
    var_fmts   = _safe_meta_attr(meta, "variable_formats", {}) or {} if meta else {}
    var_types  = (_safe_meta_attr(meta, "original_variable_types", []) or
                  _safe_meta_attr(meta, "readstat_variable_types",  []) or []) if meta else []
    var_widths = _safe_meta_attr(meta, "variable_storage_width", {}) or {} if meta else {}

    rows = []
    for idx, col in enumerate(df.columns):
        col_up = col.upper()
        label  = (str(col_labels[idx]) if idx < len(col_labels) and col_labels[idx] else "")
        fmt    = (var_fmts.get(col,"") or var_fmts.get(col_up,"")) if isinstance(var_fmts,dict) else ""
        typ_raw= (str(var_types[idx]) if idx < len(var_types) and var_types[idx] else "")
        lgth   = (var_widths.get(col,"") or var_widths.get(col_up,"")) if isinstance(var_widths,dict) else ""

        pd_dtype = str(df[col].dtype)
        if "char" in typ_raw.lower() and "date" in label.lower(): dtype = "datetime"
        elif "char" in typ_raw.lower(): dtype = "text"
        elif any(h in str(fmt).upper() for h in ("DATE","TIME","MMDD","YYMMDD")): dtype = "datetime"
        elif "float" in pd_dtype or "int" in pd_dtype: dtype = "integer"
        else: dtype = "text"

        rows.append({"domain":domain,"variable":col_up,"label":label,
                     "data_type":dtype,"length":lgth,"format":fmt})
    return rows, ""


def _build_meta_rows_from_names(col_names, meta, domain) -> list:
    col_labels = _safe_meta_attr(meta,"column_labels",[]) or []
    var_fmts   = _safe_meta_attr(meta,"variable_formats",{}) or {}
    var_types  = (_safe_meta_attr(meta,"original_variable_types",[]) or
                  _safe_meta_attr(meta,"readstat_variable_types",[]) or [])
    var_widths = _safe_meta_attr(meta,"variable_storage_width",{}) or {}
    rows = []
    for idx,col in enumerate(col_names):
        col_up = col.upper()
        label  = str(col_labels[idx]) if idx<len(col_labels) and col_labels[idx] else ""
        fmt    = (var_fmts.get(col,"") or var_fmts.get(col_up,"")) if isinstance(var_fmts,dict) else ""
        typ_raw= str(var_types[idx]) if idx<len(var_types) and var_types[idx] else ""
        lgth   = (var_widths.get(col,"") or var_widths.get(col_up,"")) if isinstance(var_widths,dict) else ""
        if "char" in typ_raw.lower() and "date" in label.lower(): dtype="datetime"
        elif "char" in typ_raw.lower(): dtype="text"
        elif any(h in str(fmt).upper() for h in ("DATE","TIME","MMDD","YYMMDD")): dtype="datetime"
        else: dtype="integer"
        rows.append({"domain":domain,"variable":col_up,"label":label,
                     "data_type":dtype,"length":lgth,"format":fmt})
    return rows


def _meta_from_csv_bytes(fdata:bytes, domain:str) -> Tuple[list,str]:
    if not fdata:
        return [], f"[{domain}] CSV empty bytes"
    try:
        df = pd.read_csv(io.BytesIO(fdata), nrows=0)
        return [{"domain":domain,"variable":c.upper(),"label":"","data_type":"text","length":"","format":""}
                for c in df.columns], ""
    except Exception as exc:
        return [], f"[{domain}] CSV: {exc}"


def get_column_metadata_from_store(
    files_store: Dict[str, bytes],
) -> Tuple[pd.DataFrame, List[str]]:
    rows=[]; errors=[]
    for fname,fdata in sorted(files_store.items()):
        dom = Path(fname).stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES): continue
        if fname.lower().endswith(".sas7bdat"):
            r,e = _meta_from_sas_bytes(fdata, dom)
            if e: errors.append(e)
            rows.extend(r)
        elif fname.lower().endswith(".csv"):
            r,e = _meta_from_csv_bytes(fdata, dom)
            if e: errors.append(e)
            rows.extend(r)
    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["domain","variable","label","data_type","length","format"]), errors
    return df.drop_duplicates(subset=["domain","variable"]).reset_index(drop=True), errors


def get_column_metadata(lib_path: str) -> pd.DataFrame:
    store = {}
    lib = Path(lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")): store[fp.name]=fp.read_bytes()
    for fp in sorted(lib.glob("*.csv")):      store[fp.name]=fp.read_bytes()
    df,_ = get_column_metadata_from_store(store)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# VLM (Variable-Level Metadata) — FROM SPEC CODELIST COLUMN (Image 1, col U)
# ─────────────────────────────────────────────────────────────────────────────

def _find_codelist_tab(spec: Dict[str, pd.DataFrame]) -> Optional[pd.DataFrame]:
    """
    Find the Codelist sheet in the spec dict.
    Searches case-insensitively for 'codelist', 'code list', 'codelists'.
    The spec_loader normalises sheet names to lowercase with underscores,
    BUT the original sheet name is preserved as the dict key.
    """
    if spec is None:
        return None
    for key in spec:
        kl = str(key).strip().lower().replace(" ","").replace("_","")
        if kl in ("codelist","codelists","codlst","codes"):
            return spec[key]
    return None


def _get_codelist_from_spec(spec: Dict[str, pd.DataFrame]) -> Dict[str, List[dict]]:
    """
    Parse the Codelist tab from the spec.
    Returns dict: {CODELIST_NAME_UPPER -> list of {value, decode, code, extensible, source, standard}}

    Image 2 shows Codelist tab columns:
      Active, Codelist_Name, Codelist_Label, Codelist_Code,
      Codelist_Value_Code, Codelist_Value, Codelist_Value_Decode,
      Synonym, Codelist_Extensible, Codelist_Source, Standard
    """
    cl = _find_codelist_tab(spec)
    if cl is None or cl.empty:
        return {}

    # Normalise column names for lookup
    cl = cl.copy()
    cl.columns = [str(c).strip().lower().replace(" ","_") for c in cl.columns]

    # Find key columns
    name_col    = next((c for c in cl.columns if "codelist_name" in c or c=="codelist_name"), None)
    value_col   = next((c for c in cl.columns
                        if "codelist_value" in c
                        and "decode" not in c and "code" not in c.replace("codelist_value","")), None)
    if not value_col:
        value_col = next((c for c in cl.columns if c=="codelist_value"), None)
    decode_col  = next((c for c in cl.columns if "decode" in c), None)
    vcode_col   = next((c for c in cl.columns if "codelist_value_code" in c), None)
    active_col  = next((c for c in cl.columns if c=="active"), None)
    ext_col     = next((c for c in cl.columns if "extensible" in c), None)
    source_col  = next((c for c in cl.columns if "source" in c and "codelist" not in c.replace("codelist_source","")), None)
    std_col     = next((c for c in cl.columns if "standard" in c and "codelist" not in c.replace("codelist_standard","")), None)

    if not name_col or not value_col:
        return {}

    result: Dict[str, List[dict]] = {}
    for _, row in cl.iterrows():
        act = str(row.get(active_col,"Y")).strip().upper() if active_col else "Y"
        # Include both active and inactive entries in lookup (for full VLM)
        cl_name = str(row.get(name_col,"")).strip().upper()
        val     = str(row.get(value_col,"")).strip()
        if not cl_name or not val or val.lower()=="nan":
            continue
        entry = {
            "value":      val,
            "decode":     str(row.get(decode_col,"")).strip() if decode_col else "",
            "vcode":      str(row.get(vcode_col,"")).strip() if vcode_col else "",
            "active":     act,
            "extensible": str(row.get(ext_col,"")).strip() if ext_col else "",
            "source":     str(row.get(source_col,"")).strip() if source_col else "",
            "standard":   str(row.get(std_col,"")).strip() if std_col else "",
        }
        result.setdefault(cl_name, []).append(entry)
    return result


def _get_codelist_map_from_spec(spec: Dict[str, pd.DataFrame]) -> Dict[str, str]:
    """
    Build {(DOMAIN_UPPER, VARIABLE_UPPER) -> CODELIST_NAME} from all domain sheets.
    Uses column index 20 (column U, 0-based) or column named 'codelist'/'hasnodet'.

    Image 1: column U (index 20 from left including IDVAR as col A = index 0)
    The spec_loader normalises columns to lowercase, so we look for 'codelist'
    or the 21st column (index 20).
    """
    if spec is None:
        return {}
    from core.spec_loader import EXCLUDE_DOMAINS
    result = {}
    for sheet, df in spec.items():
        if sheet.lower() in ("toc","codelist","computation","valuelist","maintenance",
                              "study","standard","ig","codelists"):
            continue
        if not isinstance(df, pd.DataFrame) or df.empty:
            continue
        dom = sheet.upper()
        if dom in EXCLUDE_DOMAINS:
            continue

        # Find variable column
        var_col = next((c for c in df.columns if c.lower()=="variable"), None)
        if var_col is None:
            continue

        # Find codelist column: prefer named 'codelist', else column at index ~20
        cl_col = next((c for c in df.columns
                       if c.lower() in ("codelist","codelist_name","hasnodeterministic",
                                        "hasnodet","codelist_ref")), None)
        if cl_col is None and len(df.columns) > 20:
            # Column U = index 20 (0-based: A=0,B=1,...,U=20)
            cl_col = df.columns[20]

        if cl_col is None:
            continue

        for _, row in df.iterrows():
            var = str(row.get(var_col,"")).strip().upper()
            cl  = str(row.get(cl_col,"")).strip()
            if var and cl and cl.lower() not in ("nan","","none"):
                result[(dom, var)] = cl.upper()

    return result


def build_vlm_from_spec_and_data(
    files_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """
    Build a VLM (Variable-Level Metadata) table combining:
      - Variables with a codelist entry in spec (column U)
      - Actual data statistics: max_length, n_distinct, has_decimals, sample_values
      - All allowed CT values from the Codelist tab
      - Per-value data comparison (actual vs allowed)

    Output columns:
      domain, variable, label, sas_type, sas_length, spec_codelist,
      data_type, actual_max_length, n_distinct_values, has_decimals,
      sample_values, ct_values_allowed, ct_extensible, ct_source, ct_standard,
      ct_mismatch_values, ct_mismatch_count, ct_status
    """
    if not spec:
        return pd.DataFrame()

    cl_map      = _get_codelist_map_from_spec(spec)
    cl_lookup   = _get_codelist_from_spec(spec)
    spec_meta   = _build_spec_variable_meta(spec)

    if not cl_map:
        return pd.DataFrame()

    # Load actual data for variables that have a codelist
    dom_to_bytes = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".sas7bdat")}
    dom_to_csv   = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".csv")}

    # Group by domain for efficient loading
    from collections import defaultdict
    domain_vars: Dict[str, List[str]] = defaultdict(list)
    for (dom, var) in cl_map:
        domain_vars[dom].append(var)

    # Load each domain once and compute stats
    domain_data: Dict[str, pd.DataFrame] = {}
    for dom, vars_list in domain_vars.items():
        fdata = dom_to_bytes.get(dom) or dom_to_csv.get(dom)
        if not fdata:
            continue
        try:
            if dom in dom_to_bytes:
                df_dom, _, _ = _load_sas_df(fdata, dom)
            else:
                df_dom = pd.read_csv(io.BytesIO(fdata))
                df_dom.columns = [c.upper() for c in df_dom.columns]
            domain_data[dom] = df_dom
        except Exception:
            pass

    rows = []
    for (dom, var), cl_name in sorted(cl_map.items()):
        # Spec metadata
        sm = spec_meta.get((dom, var), {})
        label      = sm.get("label","")
        sas_type   = sm.get("sas_type","")
        sas_length = sm.get("sas_length","")

        # CT lookup
        ct_entries = cl_lookup.get(cl_name, [])
        ct_vals_allowed = sorted({e["value"] for e in ct_entries if e["active"]=="Y"})
        ct_vals_all     = sorted({e["value"] for e in ct_entries})
        ct_extensible   = ct_entries[0]["extensible"] if ct_entries else ""
        ct_source       = ct_entries[0]["source"]     if ct_entries else ""
        ct_standard     = ct_entries[0]["standard"]   if ct_entries else ""
        ct_decode_map   = {e["value"]: e["decode"] for e in ct_entries}

        # Actual data stats
        actual_max_len = ""
        n_distinct     = ""
        has_decimals   = ""
        sample_vals    = ""
        mismatch_vals  = ""
        mismatch_count = ""
        ct_status      = "NO DATA"
        actual_data_type = _infer_spec_type(sas_type)

        df_dom = domain_data.get(dom)
        if df_dom is not None and var in df_dom.columns:
            col_data = df_dom[var].dropna()
            col_str  = col_data.astype(str).str.strip()
            col_str  = col_str[col_str.str.lower() != "nan"]

            n_distinct     = str(col_str.nunique())
            uniq_vals = sorted(col_str.unique())
            n_uniq    = len(uniq_vals)
            if n_uniq <= 20:
                sample_vals = "; ".join(uniq_vals)
            else:
                sample_vals = "; ".join(uniq_vals[:5]) + f" ... (+{n_uniq-5} more)"

            if sas_type.upper() in ("CHAR","C","CHARACTER","TEXT"):
                actual_max_len   = str(col_str.str.len().max()) if not col_str.empty else "0"
                has_decimals     = "N/A"
                actual_data_type = "text"
            else:
                # Numeric
                try:
                    numeric = pd.to_numeric(col_data, errors="coerce").dropna()
                    if not numeric.empty:
                        actual_max_len = str(int(numeric.abs().max()))
                        dec_check      = numeric[numeric != numeric.round()]
                        has_decimals   = "Y" if len(dec_check) > 0 else "N"
                        if has_decimals == "Y":
                            max_dec = int(numeric.apply(
                                lambda x: len(str(x).split(".")[-1]) if "." in str(x) else 0
                            ).max())
                            has_decimals = f"Y (max {max_dec} dp)"
                        actual_data_type = "float" if has_decimals.startswith("Y") else "integer"
                except Exception:
                    pass

            # CT comparison
            if ct_vals_allowed and not col_str.empty:
                allowed_upper = {v.upper() for v in ct_vals_allowed}
                actual_upper  = col_str.str.upper()
                mismatch_mask = ~actual_upper.isin(allowed_upper)
                mismatch_uniq = sorted(col_str[mismatch_mask].unique())
                mismatch_count= str(col_str[mismatch_mask].nunique())
                mismatch_vals = "; ".join(mismatch_uniq[:10])
                ct_status     = "PASS" if not mismatch_uniq else f"MISMATCH ({len(mismatch_uniq)} values)"
            elif ct_vals_allowed:
                ct_status = "NO DATA FOR COMPARISON"
            else:
                ct_status = "NO CT VALUES IN SPEC"

        rows.append({
            "domain":             dom,
            "variable":           var,
            "label":              label,
            "sas_type":           sas_type,
            "sas_length":         sas_length,
            "spec_codelist":      cl_name,
            "actual_data_type":   actual_data_type,
            "actual_max_length":  actual_max_len,
            "n_distinct_values":  n_distinct,
            "has_decimals":       has_decimals,
            "sample_values":      sample_vals,
            "ct_values_allowed":  ("; ".join(ct_vals_allowed)
                                       if len(ct_vals_allowed)<=20
                                       else "; ".join(ct_vals_allowed[:20])+f" ... (+{len(ct_vals_allowed)-20} more)"),
            "n_ct_values":        str(len(ct_vals_all)),
            "ct_extensible":      ct_extensible,
            "ct_source":          ct_source,
            "ct_standard":        ct_standard,
            "ct_mismatch_values": mismatch_vals,
            "ct_mismatch_count":  mismatch_count,
            "ct_status":          ct_status,
        })

    return pd.DataFrame(rows)


def _build_spec_variable_meta(spec: Dict[str, pd.DataFrame]) -> Dict[tuple, dict]:
    """Extract variable metadata from spec domain sheets."""
    from core.spec_loader import EXCLUDE_DOMAINS
    result = {}
    for sheet, df in spec.items():
        if not isinstance(df, pd.DataFrame) or df.empty: continue
        dom = sheet.upper()
        if dom in EXCLUDE_DOMAINS: continue
        if sheet.lower() in ("toc","codelist","computation","valuelist",
                              "maintenance","study","standard","ig"): continue

        var_col   = next((c for c in df.columns if c.lower()=="variable"), None)
        label_col = next((c for c in df.columns if c.lower() in ("label","variable_label")), None)
        type_col  = next((c for c in df.columns if c.lower() in ("sas_type","type","sastype",
                                                                    "sas_typ","f")), None)
        len_col   = next((c for c in df.columns if c.lower() in ("sas_length","length","saslength",
                                                                   "sas_len","g")), None)
        if var_col is None: continue

        for _, row in df.iterrows():
            var = str(row.get(var_col,"")).strip().upper()
            if not var: continue
            result[(dom, var)] = {
                "label":      str(row.get(label_col,"")).strip() if label_col else "",
                "sas_type":   str(row.get(type_col,"")).strip() if type_col else "",
                "sas_length": str(row.get(len_col,"")).strip() if len_col else "",
            }
    return result


def _infer_spec_type(sas_type: str) -> str:
    s = sas_type.upper()
    if s in ("CHAR","C","CHARACTER","TEXT","VARCHAR"): return "text"
    if s in ("NUM","N","NUMERIC","NUMBER","INTEGER","FLOAT"): return "numeric"
    return "text"


# ─────────────────────────────────────────────────────────────────────────────
# Codelist comparison (actual data vs CT)
# ─────────────────────────────────────────────────────────────────────────────

def compare_data_vs_codelist(
    files_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """
    For every variable that has a codelist in the spec (column U),
    compare actual data values against the CT values from the Codelist tab.
    Returns a flat DataFrame with one row per unique actual value.
    """
    if not spec or not files_store:
        return pd.DataFrame()

    cl_map    = _get_codelist_map_from_spec(spec)
    cl_lookup = _get_codelist_from_spec(spec)

    if not cl_map:
        return pd.DataFrame()

    dom_to_bytes = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".sas7bdat")}
    dom_to_csv   = {Path(k).stem.upper(): v for k,v in files_store.items()
                    if k.lower().endswith(".csv")}

    from collections import defaultdict
    domain_vars: Dict[str,List[str]] = defaultdict(list)
    for (dom,var) in cl_map: domain_vars[dom].append(var)

    rows = []
    for dom, vars_list in domain_vars.items():
        fdata = dom_to_bytes.get(dom) or dom_to_csv.get(dom)
        if not fdata: continue
        try:
            if dom in dom_to_bytes:
                df_dom,_,_ = _load_sas_df(fdata, dom)
            else:
                df_dom = pd.read_csv(io.BytesIO(fdata))
                df_dom.columns = [c.upper() for c in df_dom.columns]
        except Exception:
            continue

        for var in vars_list:
            if var not in df_dom.columns: continue
            cl_name   = cl_map.get((dom,var),"")
            ct_entries= cl_lookup.get(cl_name,[])
            allowed   = {e["value"].upper(): e for e in ct_entries if e["active"]=="Y"}

            col_data = df_dom[var].dropna().astype(str).str.strip()
            col_data = col_data[col_data.str.lower()!="nan"]

            for val in sorted(col_data.unique()):
                in_ct = val.upper() in allowed
                decode = allowed.get(val.upper(),{}).get("decode","") if in_ct else ""
                n_obs  = int((col_data==val).sum())
                rows.append({
                    "domain":   dom, "variable": var,
                    "codelist": cl_name,
                    "value":    val,
                    "n_obs":    n_obs,
                    "in_ct":    "YES" if in_ct else "NO",
                    "ct_decode":decode,
                    "status":  "PASS" if in_ct else "MISMATCH",
                })

    return pd.DataFrame(rows).reset_index(drop=True) if rows else pd.DataFrame()


# ─────────────────────────────────────────────────────────────────────────────
# Legacy value-level (TESTCD/PARAMCD pattern) — kept for backward compat
# ─────────────────────────────────────────────────────────────────────────────

def get_value_level_from_store(
    files_store: Dict[str, bytes],
    columns_df: pd.DataFrame,
    mode: str = "SDTM",
) -> pd.DataFrame:
    mode = mode.upper()
    if mode == "ADAM":
        cands = columns_df[columns_df["variable"].str.upper().isin(["PARAMCD"])][
            ["domain","variable"]].copy().reset_index(drop=True)
        cands["orres"]        = "AVAL"
        cands["where_prefix"] = (cands["domain"]+".PARAMCD.").values
    else:
        pat   = re.compile(r"TESTCD|QNAM|PARMCD", re.IGNORECASE)
        cands = columns_df[columns_df["variable"].str.contains(pat,na=False)][
            ["domain","variable"]].copy().reset_index(drop=True)
        cands["orres"]        = cands["variable"].apply(lambda v: "" if "TESTCD" in v.upper() else "QVAL")
        cands["where_prefix"] = (cands["domain"]+"."+cands["variable"]+".").values

    if cands.empty:
        return pd.DataFrame(columns=["dataset","variable","result_variable","value","where_clause","data_type"])

    dom_to_bytes = {Path(k).stem.upper(): v for k,v in files_store.items() if k.lower().endswith(".sas7bdat")}
    dom_to_csv   = {Path(k).stem.upper(): v for k,v in files_store.items() if k.lower().endswith(".csv")}

    rows = []
    for _, cand in cands.iterrows():
        dom  = str(cand["domain"]).upper()
        var  = str(cand["variable"]).upper()
        fdata= dom_to_bytes.get(dom) or dom_to_csv.get(dom)
        if not fdata: continue
        try:
            if dom in dom_to_bytes:
                df,_,_ = _load_sas_df(fdata, dom, usecols=[var])
            else:
                df = pd.read_csv(io.BytesIO(fdata), usecols=[var])
            df.columns = [c.upper() for c in df.columns]
            if var not in df.columns: continue
            orres = str(cand["orres"]) or dom+"ORRES"
            for val in df[var].dropna().unique():
                vs = str(val).strip()
                if not vs or vs.lower()=="nan": continue
                rows.append({"dataset":dom,"variable":var,"result_variable":orres,
                             "value":vs,"where_clause":str(cand["where_prefix"])+vs,"data_type":_infer_dtype(vs)})
        except Exception as exc:
            log.debug("VL error %s.%s: %s", dom, var, exc)

    if not rows:
        return pd.DataFrame(columns=["dataset","variable","result_variable","value","where_clause","data_type"])
    return pd.DataFrame(rows).drop_duplicates(subset=["dataset","variable","value"]).reset_index(drop=True)


def get_value_level(lib_path: str, columns_df: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    store = {}
    lib = Path(lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")): store[fp.name]=fp.read_bytes()
    for fp in sorted(lib.glob("*.csv")):      store[fp.name]=fp.read_bytes()
    return get_value_level_from_store(store, columns_df, mode)


def _infer_dtype(val: str) -> str:
    try:
        n=float(val); return "integer" if n==int(n) else "float"
    except: pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T",val): return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$",val): return "Date"
    return "text"


def build_where_clause_table(value_level: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    if value_level.empty:
        return pd.DataFrame(columns=["id","dataset","var","comparator","value"])
    wh = value_level[["dataset","variable","value","where_clause"]].copy()
    wh["var"]="PARAMCD" if mode.upper()=="ADAM" else wh["variable"]
    wh["comparator"]="EQ"; wh["id"]=wh["where_clause"]
    return wh[["id","dataset","var","comparator","value"]].reset_index(drop=True)


def validate_ct_values(value_level: pd.DataFrame, spec: Dict) -> pd.DataFrame:
    """Legacy CT validation via TESTCD value-level."""
    if value_level.empty: return pd.DataFrame()
    cl_lookup = _get_codelist_from_spec(spec)
    cl_map    = _get_codelist_map_from_spec(spec)
    rows=[]
    for _,vrow in value_level.iterrows():
        ds=str(vrow["dataset"]).upper(); var=str(vrow["variable"]).upper(); val=str(vrow["value"]).strip()
        cl_name=cl_map.get((ds,var))
        if not cl_name: continue
        allowed={e["value"].upper() for e in cl_lookup.get(cl_name,[]) if e["active"]=="Y"}
        if not allowed: continue
        in_ct=val.upper() in allowed
        rows.append({"dataset":ds,"variable":var,"value":val,"codelist":cl_name,
                     "in_ct":"YES" if in_ct else "NO","status":"PASS" if in_ct else "MISMATCH"})
    return pd.DataFrame(rows).reset_index(drop=True)
