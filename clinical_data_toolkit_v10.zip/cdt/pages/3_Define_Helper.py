# pages/3_Define_Helper.py  — v9
import sys, warnings, io, traceback
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import get_palette, build_css, render_table
from core.define_helper import (
    get_column_metadata_from_store, get_value_level_from_store,
    build_where_clause_table, build_vlm_from_spec_and_data,
    compare_data_vs_codelist, _find_codelist_tab, _get_codelist_map_from_spec,
)
from core.excel_export import export_define_results

st.set_page_config(page_title="Define Helper", layout="wide")

# ── Theme selector ─────────────────────────────────────────────────────────
theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True,
    key="define_theme", help="Switch between dark and light display mode.")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)

st.title("Define Helper")
st.caption("Extracts variable metadata, VLM with codelist values from spec, CT comparison, and value-level analysis.")

if "sdtm_files_store" not in st.session_state:
    st.warning("Upload SDTM or ADaM .sas7bdat files in the sidebar first.")
    st.stop()

sdtm_store = st.session_state["sdtm_files_store"]
spec       = st.session_state.get("spec")
spec_name  = st.session_state.get("spec_name","")

# ── Dataset list ─────────────────────────────────────────────────────────
ds_names = ", ".join(Path(k).stem.upper() for k in sorted(sdtm_store.keys()))
st.info(f"**{len(sdtm_store)} dataset(s) loaded:** {ds_names[:200]}{'...' if len(ds_names)>200 else ''}")

# ── Spec status ───────────────────────────────────────────────────────────
if spec:
    cl_tab   = _find_codelist_tab(spec)
    cl_map   = _get_codelist_map_from_spec(spec)
    n_cl_map = len(cl_map)
    cl_ok    = cl_tab is not None
    cl_msg   = f"✅ Codelist tab found ({len(cl_tab):,} rows)" if cl_ok else "⚠️ Codelist tab NOT found"
    col_a, col_b = st.columns(2)
    col_a.info(f"**Spec:** {spec_name}  |  {cl_msg}")
    col_b.info(f"**Variables with codelist in spec:** {n_cl_map}")
    if not cl_ok:
        with st.expander("Codelist tab not found — details", expanded=True):
            st.markdown(
                f"**Sheets found in spec:** `{', '.join(spec.keys())}`\n\n"
                "The tool searches for a sheet whose name (case-insensitive) matches "
                "`codelist`, `codelists`, `codlst` or similar. "
                "Please check the exact sheet name in your Excel file and "
                "ensure it matches one of these patterns."
            )
else:
    st.warning("No mapping spec loaded. Upload spec in the sidebar for VLM and CT features.")

# ── Options ───────────────────────────────────────────────────────────────
with st.expander("Options", expanded=False):
    col1, col2 = st.columns(2)
    with col1:
        mode    = st.radio("Mode", ["SDTM","ADaM"], horizontal=True)
        run_meta= st.checkbox("Read variable metadata from datasets", value=True)
        run_vlm = st.checkbox("Build VLM from spec codelist column (col U)",
                               value=bool(spec and cl_tab is not None if spec else False))
        run_ct  = st.checkbox("Run CT comparison (actual data vs codelist)",
                               value=bool(spec and cl_tab is not None if spec else False))
    with col2:
        run_vl  = st.checkbox("Extract value-level TESTCD/PARAMCD", value=True)

if st.button("Generate", type="primary", use_container_width=True):
    columns_df  = pd.DataFrame()
    vl_df       = pd.DataFrame()
    wh_df       = pd.DataFrame()
    vlm_df      = pd.DataFrame()
    ct_df       = pd.DataFrame()
    read_errors = []

    # ── Step 1: Variable metadata ──────────────────────────────────────
    if run_meta:
        with st.spinner("Reading variable metadata from datasets..."):
            try:
                result = get_column_metadata_from_store(sdtm_store)
                # Always returns a 2-tuple (df, errors)
                if isinstance(result, tuple) and len(result) == 2:
                    columns_df, read_errors = result
                else:
                    columns_df = pd.DataFrame()
                    read_errors = [f"Unexpected return type: {type(result)}"]
            except Exception as exc:
                tb = traceback.format_exc()
                read_errors = [f"Exception reading metadata: {type(exc).__name__}: {exc}\n{tb}"]
                columns_df = pd.DataFrame()

        if read_errors:
            with st.expander(f"⚠ {len(read_errors)} file(s) had read issues (click for details)", expanded=not columns_df.empty):
                for err in read_errors[:30]:
                    st.code(str(err), language="text")
                if columns_df.empty:
                    st.info(
                        "**Variable metadata could not be read from .sas7bdat files.**\n\n"
                        "**This does NOT prevent VLM and CT comparison from running** — "
                        "those features read the actual data separately.\n\n"
                        "To fix metadata: try upgrading pyreadstat (`pip install --upgrade pyreadstat`) "
                        "or export datasets as .csv and upload those instead."
                    )
        if columns_df.empty and not read_errors:
            st.info("No variable metadata found. This may be expected if all files are empty.")

    # ── Step 2: VLM from spec ─────────────────────────────────────────
    if run_vlm and spec:
        with st.spinner("Building VLM from spec codelist column + actual data..."):
            try:
                vlm_df = build_vlm_from_spec_and_data(sdtm_store, spec)
            except Exception as exc:
                st.warning(f"VLM error: {type(exc).__name__}: {exc}")
                st.code(traceback.format_exc())

    # ── Step 3: CT comparison ─────────────────────────────────────────
    if run_ct and spec:
        with st.spinner("Comparing actual data values against CT codelists..."):
            try:
                ct_df = compare_data_vs_codelist(sdtm_store, spec)
            except Exception as exc:
                st.warning(f"CT comparison error: {type(exc).__name__}: {exc}")
                st.code(traceback.format_exc())

    # ── Step 4: Legacy value-level ────────────────────────────────────
    if run_vl and not columns_df.empty:
        with st.spinner("Extracting TESTCD/PARAMCD value-level..."):
            try:
                vl_df = get_value_level_from_store(sdtm_store, columns_df, mode)
                wh_df = build_where_clause_table(vl_df, mode)
            except Exception as exc:
                st.warning(f"Value-level error: {type(exc).__name__}: {exc}")

    st.session_state.update({
        "define_columns":     columns_df,
        "define_mode":        mode,
        "define_vlm":         vlm_df,
        "define_ct_compare":  ct_df,
        "define_value_level": vl_df,
        "define_where_clause":wh_df,
        "define_meta_skipped":not run_meta,       # user intentionally skipped
        "define_meta_failed": run_meta and columns_df.empty,  # pyreadstat failure
    })
    st.rerun()

# ── Nothing generated yet ────────────────────────────────────────────────
if ("define_columns" not in st.session_state and
        "define_vlm" not in st.session_state and
        "define_ct_compare" not in st.session_state):
    st.info("Configure options above and click 'Generate'.")
    st.stop()

columns_df   = st.session_state.get("define_columns", pd.DataFrame())
meta_skipped = st.session_state.get("define_meta_skipped", False)
meta_failed  = st.session_state.get("define_meta_failed",  False)
vlm_df     = st.session_state.get("define_vlm",     pd.DataFrame())
ct_df      = st.session_state.get("define_ct_compare", pd.DataFrame())
vl_df      = st.session_state.get("define_value_level", pd.DataFrame())
wh_df      = st.session_state.get("define_where_clause", pd.DataFrame())
mode       = st.session_state.get("define_mode","SDTM")

n_vars     = len(columns_df)
n_cl_vars  = vlm_df["variable"].nunique() if not vlm_df.empty else 0
n_miss     = int((ct_df["status"]=="MISMATCH").sum()) if not ct_df.empty else 0
n_miss_vars= int(ct_df[ct_df["status"]=="MISMATCH"]["variable"].nunique()) if not ct_df.empty else 0

# ── Metrics ───────────────────────────────────────────────────────────────
st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">Variables (metadata)</div>'
    f'<div class="value" style="color:{C["text_main"]};">{n_vars:,}</div></div>'
    f'<div class="metric-item"><div class="label">VLM Variables (codelist)</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{n_cl_vars:,}</div></div>'
    f'<div class="metric-item"><div class="label">CT Mismatch Values</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_miss:,}</div></div>'
    f'<div class="metric-item"><div class="label">CT Mismatch Variables</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_miss_vars:,}</div></div>'
    f'</div>',
    unsafe_allow_html=True
)

# ── Download ──────────────────────────────────────────────────────────────
excel_bytes = export_define_results(
    columns_df if not columns_df.empty else pd.DataFrame(),
    vl_df      if not vl_df.empty      else pd.DataFrame(),
    wh_df      if not wh_df.empty      else pd.DataFrame(),
    vlm_df     if not vlm_df.empty     else None,
    ct_df      if not ct_df.empty      else None,
)
st.download_button(
    "⬇ Download Define Report (.xlsx)", data=excel_bytes,
    file_name=f"Define_{mode}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)

st.divider()

# ── Tabs ──────────────────────────────────────────────────────────────────
tabs = st.tabs([
    f"Variable Metadata ({n_vars:,})",
    f"VLM / Codelist ({n_cl_vars:,} vars)",
    f"CT Comparison ({n_miss:,} mismatches)",
    f"Value Level TESTCD ({len(vl_df) if not vl_df.empty else 0:,})",
    "Where Clause",
])

with tabs[0]:
    if columns_df.empty:
        meta_skipped = st.session_state.get("define_meta_skipped", False)
        meta_failed  = st.session_state.get("define_meta_failed",  False)
        if meta_skipped:
            st.info(
                "**Variable metadata was not read** because 'Read variable metadata from datasets' "
                "was unchecked in Options. \n\n"
                "VLM, CT Comparison and all other tabs work normally — they read the actual "
                "data rows directly and do not need this step. \n\n"
                "To populate this tab, check 'Read variable metadata from datasets' and click Generate again."
            )
        elif meta_failed:
            st.warning(
                "**Variable metadata could not be read from the .sas7bdat files.** \n\n"
                "This is a known pyreadstat limitation on some Windows builds — the metadata header "
                "cannot be parsed but the data rows are still readable. \n\n"
                "**This does not affect VLM, CT Comparison, or Value Level tabs** — those read "
                "data rows directly. \n\n"
                "To get column metadata: either upgrade pyreadstat "
                "(`pip install --upgrade pyreadstat`) or export your datasets as .csv and "
                "upload those instead."
            )
        else:
            st.info("No variable metadata found in the uploaded datasets.")
    else:
        dom_opts = ["All"] + sorted(columns_df["domain"].unique().tolist())
        dom_sel  = st.selectbox("Domain", dom_opts, key="def_dom")
        disp     = columns_df if dom_sel=="All" else columns_df[columns_df["domain"]==dom_sel]
        st.caption(f"{len(disp):,} variables")
        st.dataframe(disp, use_container_width=True, height=450)

with tabs[1]:
    if vlm_df.empty:
        if not spec:
            st.info("Load a mapping spec in the sidebar to enable VLM generation.")
        elif _find_codelist_tab(spec) is None:
            st.error(
                "**Codelist tab not found in the spec.**  "
                f"Available sheets: `{', '.join(spec.keys())}`  \n"
                "The tool looks for a sheet named 'Codelist' (case-insensitive). "
                "Rename the sheet in your Excel file if needed."
            )
        else:
            st.warning(
                "VLM is empty. Ensure domain sheets have a 'codelist' column "
                "or a non-empty value in column U (the 21st column)."
            )
    else:
        cf1,cf2,cf3 = st.columns(3)
        dom_opts    = ["All"] + sorted(vlm_df["domain"].unique().tolist())
        dom_sel     = cf1.selectbox("Domain", dom_opts, key="vlm_dom")
        cl_opts     = ["All"] + sorted(vlm_df["spec_codelist"].unique().tolist())
        cl_sel      = cf2.selectbox("Codelist", cl_opts, key="vlm_cl")
        st_opts     = ["All","PASS","MISMATCH","NO DATA","NO CT VALUES IN SPEC","NO DATA FOR COMPARISON"]
        st_sel      = cf3.selectbox("CT Status", st_opts, key="vlm_st")

        disp = vlm_df.copy()
        if dom_sel != "All": disp = disp[disp["domain"]==dom_sel]
        if cl_sel  != "All": disp = disp[disp["spec_codelist"]==cl_sel]
        if st_sel  != "All": disp = disp[disp["ct_status"].str.contains(st_sel,na=False,regex=False)]

        def _vlm_rc(row):
            s = str(row.get("ct_status",""))
            if "MISMATCH" in s: return "row-miss"
            if s == "PASS":     return "row-pass"
            return ""
        st.markdown(f'<div style="color:{C["text_muted"]};font-size:12px;margin:4px 0;">Showing {len(disp):,} of {len(vlm_df):,} rows</div>', unsafe_allow_html=True)
        st.markdown(render_table(disp, row_class_fn=_vlm_rc, C=C), unsafe_allow_html=True)

        if HAS_PLOTLY:
            st_counts = vlm_df["ct_status"].apply(
                lambda s: "PASS" if s=="PASS" else ("MISMATCH" if "MISMATCH" in str(s) else "NO DATA")
            ).value_counts().reset_index()
            st_counts.columns = ["status","count"]
            fig = px.pie(st_counts, names="status", values="count",
                         color="status",
                         color_discrete_map={"PASS":"#4ade80","MISMATCH":"#f87171","NO DATA":"#94a3b8"},
                         title="CT Status Distribution", hole=0.4, height=240)
            tpl = "plotly" if theme_mode=="light" else "plotly_dark"
            fig.update_layout(template=tpl, margin=dict(l=0,r=0,t=36,b=0),
                               paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
            st.plotly_chart(fig, use_container_width=True)

with tabs[2]:
    if ct_df.empty:
        if not spec:
            st.info("Load a mapping spec to enable CT comparison.")
        else:
            st.info(
                "CT comparison produced no results.  \n"
                "Ensure: (1) domain sheets have codelist names in column U, "
                "(2) Codelist tab exists with values, "
                "(3) SDTM datasets are uploaded."
            )
    else:
        n_m = int((ct_df["status"]=="MISMATCH").sum())
        n_p = int((ct_df["status"]=="PASS").sum())
        c1,c2,c3 = st.columns(3)
        c1.metric("Total values", len(ct_df))
        c2.metric("PASS", n_p)
        c3.metric("MISMATCH", n_m)

        cf1,cf2,cf3 = st.columns(3)
        show_miss = cf1.checkbox("Mismatches only", value=True, key="ct_miss")
        dom_ct    = cf2.selectbox("Domain", ["All"]+sorted(ct_df["domain"].unique().tolist()), key="ct_dom")
        var_ct    = cf3.selectbox("Variable", ["All"]+sorted(ct_df["variable"].unique().tolist()), key="ct_var")

        disp_ct = ct_df[ct_df["status"]=="MISMATCH"] if show_miss else ct_df
        if dom_ct != "All": disp_ct = disp_ct[disp_ct["domain"]==dom_ct]
        if var_ct != "All": disp_ct = disp_ct[disp_ct["variable"]==var_ct]

        st.download_button("⬇ CT Comparison (.csv)", data=disp_ct.to_csv(index=False).encode(),
            file_name=f"CT_Comparison_{datetime.now():%Y%m%d_%H%M}.csv", mime="text/csv")

        def _ct_rc(row): return "row-miss" if row.get("status","")=="MISMATCH" else "row-pass"
        st.markdown(render_table(disp_ct, row_class_fn=_ct_rc, C=C), unsafe_allow_html=True)

        if HAS_PLOTLY and n_m > 0:
            miss_by = (ct_df[ct_df["status"]=="MISMATCH"]
                       .groupby(["domain","variable"])
                       .agg(n=("status","count")).reset_index()
                       .sort_values("n",ascending=False).head(20))
            miss_by["dv"] = miss_by["domain"]+"."+miss_by["variable"]
            tpl = "plotly" if theme_mode=="light" else "plotly_dark"
            fig2 = px.bar(miss_by, x="dv", y="n",
                          title="CT Mismatches by Variable (top 20)",
                          color="n", color_continuous_scale=["#fbbf24","#ef4444"],
                          height=240)
            fig2.update_layout(template=tpl, margin=dict(l=0,r=0,t=36,b=0),
                                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                                showlegend=False)
            fig2.update_xaxes(tickangle=-40)
            st.plotly_chart(fig2, use_container_width=True)

with tabs[3]:
    if vl_df is None or vl_df.empty:
        st.info("Value-level (TESTCD/PARAMCD) not extracted or no matching variables found.")
    else:
        d2 = st.selectbox("Domain", ["All"]+sorted(vl_df["dataset"].unique().tolist()), key="def_vl")
        disp2 = vl_df if d2=="All" else vl_df[vl_df["dataset"]==d2]
        st.dataframe(disp2, use_container_width=True, height=450)

with tabs[4]:
    if wh_df is None or wh_df.empty:
        st.info("Where-clause not generated.")
    else:
        st.dataframe(wh_df, use_container_width=True, height=450)
