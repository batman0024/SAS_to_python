# pages/6_Dataset_Compare.py  v9
"""
Dataset Comparison — upload multiple files per side, compare all in one run.
Metadata diff includes variable labels, SAS types, lengths, formats.
Value diff shows before/after for every changed cell.
"""
import sys, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import get_palette, build_css, render_table, DARK as C_default
from core.dataset_compare import (
    compare_all_datasets, export_comparison_report,
    export_multi_comparison_report, compare_metadata, compare_values,
)

st.set_page_config(page_title="Dataset Compare", layout="wide")
theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True,
    key="cmp_theme", help="Switch display theme.")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)

st.title("Dataset Comparison")
st.caption(
    "Compare two sets of datasets at metadata level (variable names, labels, types, "
    "lengths, formats) and value level (added/removed rows, changed values). "
    "Upload multiple files per side — each file is matched by filename stem."
)

# ─────────────────────────────────────────────────────────────────────────────
# File upload
# ─────────────────────────────────────────────────────────────────────────────
col1, col2 = st.columns(2)
with col1:
    st.markdown("**Set A — baseline / before**")
    files_a = st.file_uploader(
        "Upload Dataset(s) A (.sas7bdat or .csv)",
        type=["sas7bdat","csv"], accept_multiple_files=True, key="cmp_files_a",
        help="Upload one or more files. Matched to Set B by filename stem.",
    )
    if files_a:
        names_list = ", ".join(Path(f.name).stem.upper() for f in files_a)
        st.caption(f"{len(files_a)} file(s): {names_list[:120]}")

with col2:
    st.markdown("**Set B — comparison / after**")
    files_b = st.file_uploader(
        "Upload Dataset(s) B (.sas7bdat or .csv)",
        type=["sas7bdat","csv"], accept_multiple_files=True, key="cmp_files_b",
        help="Files are matched to Set A by filename stem.",
    )
    if files_b:
        names_list = ", ".join(Path(f.name).stem.upper() for f in files_b)
        st.caption(f"{len(files_b)} file(s): {names_list[:120]}")

if not files_a or not files_b:
    st.info("Upload files in both Set A and Set B to begin comparison.")
    st.stop()

# Build stores {stem -> (fname, bytes)}
store_a = {Path(f.name).stem.upper(): (f.name, f.getvalue()) for f in files_a}
store_b = {Path(f.name).stem.upper(): (f.name, f.getvalue()) for f in files_b}
names_a   = set(store_a.keys())
names_b   = set(store_b.keys())
matched   = sorted(names_a & names_b)
only_in_a = sorted(names_a - names_b)
only_in_b = sorted(names_b - names_a)

# ─────────────────────────────────────────────────────────────────────────────
# Matching status
# ─────────────────────────────────────────────────────────────────────────────
st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">Matched pairs</div>'
    f'<div class="value" style="color:{C["pass_fg"]};">{len(matched)}</div></div>'
    f'<div class="metric-item"><div class="label">Only in A</div>'
    f'<div class="value" style="color:{C["warn_fg"]};">{len(only_in_a)}</div></div>'
    f'<div class="metric-item"><div class="label">Only in B</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{len(only_in_b)}</div></div>'
    f'</div>', unsafe_allow_html=True
)

if only_in_a:
    st.warning(f"In A but not B (not compared): **{', '.join(only_in_a)}**")
if only_in_b:
    st.info(f"In B but not A (not compared): **{', '.join(only_in_b)}**")
if not matched:
    st.error("No matching datasets. Files are matched by filename stem (e.g. ae.sas7bdat → AE).")
    st.stop()

# ─────────────────────────────────────────────────────────────────────────────
# Options
# ─────────────────────────────────────────────────────────────────────────────
with st.expander("Options", expanded=False):
    c1, c2 = st.columns(2)
    with c1:
        key_input  = st.text_input(
            "Key variables for row matching (comma-separated)",
            value="", placeholder="USUBJID, AESEQ — leave blank for auto-detect",
        )
        run_values = st.checkbox("Run value-level comparison", value=True,
            help="Compares row additions/removals and value changes. May be slow for large datasets.")
    with c2:
        label_a = st.text_input("Label for Set A", value="A")
        label_b = st.text_input("Label for Set B", value="B")

key_cols = [k.strip().upper() for k in key_input.split(",") if k.strip()] or None

# ─────────────────────────────────────────────────────────────────────────────
# Run comparison
# ─────────────────────────────────────────────────────────────────────────────
if st.button("Run Comparison on All Datasets", type="primary", use_container_width=True):
    progress = st.progress(0, text="Starting...")

    def _progress(done, total):
        pct = int(done / total * 100)
        progress.progress(pct, text=f"Processing {done}/{total} datasets...")

    with st.spinner(f"Comparing {len(matched)} dataset pair(s)..."):
        all_results, cross_summary, _oia, _oib = compare_all_datasets(
            store_a, store_b,
            key_cols=key_cols,
            run_values=run_values,
            progress_cb=_progress,
        )

    progress.progress(100, text="Done.")
    st.session_state.update({
        "cmp_all_results":  all_results,
        "cmp_cross_summary":cross_summary,
        "cmp_only_in_a":    only_in_a,
        "cmp_only_in_b":    only_in_b,
        "cmp_label_a":      label_a,
        "cmp_label_b":      label_b,
    })
    st.rerun()

# ─────────────────────────────────────────────────────────────────────────────
# Results
# ─────────────────────────────────────────────────────────────────────────────
if "cmp_all_results" not in st.session_state:
    st.stop()

all_results   = st.session_state["cmp_all_results"]
cross_summary = st.session_state["cmp_cross_summary"]
label_a       = st.session_state.get("cmp_label_a","A")
label_b       = st.session_state.get("cmp_label_b","B")
ds_names_done = sorted(k for k, v in all_results.items() if "error" not in v)
ds_errors     = {k: v["error"] for k, v in all_results.items() if "error" in v}

if ds_errors:
    for ds, err in ds_errors.items():
        st.error(f"**{ds}**: {err}")

if not ds_names_done:
    st.error("All datasets failed to load."); st.stop()

# ─────────────────────────────────────────────────────────────────────────────
# Cross-dataset summary metrics
# ─────────────────────────────────────────────────────────────────────────────
n_compared = len(ds_names_done)
if not cross_summary.empty and n_compared > 0:
    ok = cross_summary[cross_summary["status"]=="COMPARED"]
    total_meta_changes = int(ok["meta_changes"].sum()) if "meta_changes" in ok.columns else 0
    total_val_diffs    = int(ok["vars_with_diffs"].sum()) if "vars_with_diffs" in ok.columns else 0
    total_label_chg    = int(ok["label_changes"].sum()) if "label_changes" in ok.columns else 0
    total_dtype_chg    = int(ok["dtype_changes"].sum()) if "dtype_changes" in ok.columns else 0

    st.markdown(
        f'<div class="metric-bar">'
        f'<div class="metric-item"><div class="label">Datasets compared</div>'
        f'<div class="value" style="color:{C["pass_fg"]};">{n_compared}</div></div>'
        f'<div class="metric-item"><div class="label">Total meta changes</div>'
        f'<div class="value" style="color:{C["warn_fg"]};">{total_meta_changes:,}</div></div>'
        f'<div class="metric-item"><div class="label">Label changes</div>'
        f'<div class="value" style="color:{C["warn_fg"]};">{total_label_chg:,}</div></div>'
        f'<div class="metric-item"><div class="label">Dtype changes</div>'
        f'<div class="value" style="color:{C["warn_fg"]};">{total_dtype_chg:,}</div></div>'
        f'<div class="metric-item"><div class="label">Vars with value diffs</div>'
        f'<div class="value" style="color:{C["unmap_fg"]};">{total_val_diffs:,}</div></div>'
        f'</div>', unsafe_allow_html=True
    )

# ─────────────────────────────────────────────────────────────────────────────
# Downloads
# ─────────────────────────────────────────────────────────────────────────────
dl1, dl2 = st.columns(2)
with dl1:
    multi_bytes = export_multi_comparison_report(
        all_results, cross_summary, only_in_a, only_in_b, label_a, label_b
    )
    st.download_button(
        f"⬇ Download Full Report — All {n_compared} Dataset(s) (.xlsx)",
        data=multi_bytes,
        file_name=f"Compare_ALL_{datetime.now():%Y%m%d_%H%M}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True, type="primary",
    )
with dl2:
    st.download_button(
        "⬇ Cross-Dataset Summary (.csv)",
        data=cross_summary.to_csv(index=False).encode(),
        file_name=f"Compare_Summary_{datetime.now():%Y%m%d_%H%M}.csv",
        mime="text/csv", use_container_width=True,
    )

st.divider()

# ─────────────────────────────────────────────────────────────────────────────
# Cross-dataset charts
# ─────────────────────────────────────────────────────────────────────────────
if HAS_PLOTLY and len(ds_names_done) > 1:
    with st.expander("Cross-dataset overview charts", expanded=True):
        ok = cross_summary[cross_summary["status"]=="COMPARED"].copy()
        if not ok.empty:
            c1, c2 = st.columns(2)
            with c1:
                melt_cols = [c for c in ["only_in_A","only_in_B","label_changes",
                                          "dtype_changes","length_changes"] if c in ok.columns]
                if melt_cols:
                    melt_df = ok.melt(id_vars="dataset", value_vars=melt_cols,
                                      var_name="change_type", value_name="count")
                    fig = px.bar(melt_df, x="dataset", y="count", color="change_type",
                                 barmode="group", title="Metadata Changes by Dataset",
                                 height=300,
                                 color_discrete_sequence=["#f59e0b","#60a5fa","#a78bfa","#f87171","#34d399"])
                    tpl = "plotly" if theme_mode=="light" else "plotly_dark"
                    fig.update_layout(template=tpl, margin=dict(l=0,r=0,t=36,b=0),
                                       paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
                    fig.update_xaxes(tickangle=-30)
                    st.plotly_chart(fig, use_container_width=True)
            with c2:
                if "vars_with_diffs" in ok.columns:
                    fig2 = px.bar(ok, x="dataset", y="vars_with_diffs",
                                  title="Variables with Value Differences by Dataset",
                                  color="vars_with_diffs",
                                  color_continuous_scale=["#4ade80","#f59e0b","#ef4444"],
                                  height=300)
                    tpl = "plotly" if theme_mode=="light" else "plotly_dark"
                    fig2.update_layout(template=tpl, margin=dict(l=0,r=0,t=36,b=0),
                                        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                                        showlegend=False, coloraxis_showscale=False)
                    fig2.update_xaxes(tickangle=-30)
                    st.plotly_chart(fig2, use_container_width=True)

# ─────────────────────────────────────────────────────────────────────────────
# Cross-dataset summary table
# ─────────────────────────────────────────────────────────────────────────────
with st.expander("Cross-dataset summary table", expanded=(len(ds_names_done)>1)):
    def _cross_rc(row):
        if str(row.get("status","")) != "COMPARED": return "row-miss"
        mc = int(row.get("meta_changes",0))
        vd = int(row.get("vars_with_diffs",0))
        if mc > 0 or vd > 0: return "row-warning"
        return "row-pass"
    st.markdown(render_table(cross_summary, row_class_fn=_cross_rc, C=C), unsafe_allow_html=True)

st.divider()

# ─────────────────────────────────────────────────────────────────────────────
# Per-dataset detail view
# ─────────────────────────────────────────────────────────────────────────────
if len(ds_names_done) == 1:
    selected_ds = ds_names_done[0]
else:
    selected_ds = st.selectbox(
        "Select dataset to inspect in detail:",
        ds_names_done,
        help="Shows metadata diff and value-level diff for the selected dataset.",
    )

curr          = all_results[selected_ds]
meta_diff     = curr.get("meta_diff", pd.DataFrame())
value_results = curr.get("value_results", {})
shape_a       = curr.get("shape_a", (0,0))
shape_b       = curr.get("shape_b", (0,0))

# Per-dataset metrics
n_same      = int((meta_diff["status"]=="SAME").sum())           if not meta_diff.empty else 0
n_only_a    = int((meta_diff["status"]=="ONLY_IN_A").sum())      if not meta_diff.empty else 0
n_only_b    = int((meta_diff["status"]=="ONLY_IN_B").sum())      if not meta_diff.empty else 0
n_changed   = int(meta_diff["status"].str.startswith("CHANGED").sum()) if not meta_diff.empty else 0
n_label_chg = int(meta_diff["label_changed"].eq("YES").sum())   if not meta_diff.empty else 0
n_dtype_chg = int(meta_diff["dtype_changed"].eq("YES").sum())   if not meta_diff.empty else 0
n_len_chg   = int(meta_diff["length_changed"].eq("YES").sum())  if not meta_diff.empty else 0
n_fmt_chg   = int(meta_diff["format_changed"].eq("YES").sum())  if not meta_diff.empty else 0
n_added     = value_results.get("n_added", 0)
n_removed   = value_results.get("n_removed", 0)
n_vchg      = value_results.get("n_vars_changed", 0)
key_used    = ", ".join(value_results.get("key_cols_used",[])) or "auto"

st.subheader(f"Detail — {selected_ds}")
st.caption(f"A: {shape_a[0]:,} rows × {shape_a[1]} cols  |  B: {shape_b[0]:,} rows × {shape_b[1]} cols  |  Keys: {key_used}")

st.markdown(
    f'<div class="metric-bar" style="flex-wrap:wrap;gap:18px;">'
    f'<div class="metric-item"><div class="label">Same</div><div class="value" style="color:{C["pass_fg"]};font-size:20px;">{n_same}</div></div>'
    f'<div class="metric-item"><div class="label">Meta changed</div><div class="value" style="color:{C["warn_fg"]};font-size:20px;">{n_changed}</div></div>'
    f'<div class="metric-item"><div class="label">Only in A</div><div class="value" style="color:{C["warn_fg"]};font-size:20px;">{n_only_a}</div></div>'
    f'<div class="metric-item"><div class="label">Only in B</div><div class="value" style="color:{C["dt_fg"]};font-size:20px;">{n_only_b}</div></div>'
    f'<div class="metric-item"><div class="label">Label Δ</div><div class="value" style="color:{C["warn_fg"]};font-size:20px;">{n_label_chg}</div></div>'
    f'<div class="metric-item"><div class="label">Dtype Δ</div><div class="value" style="color:{C["warn_fg"]};font-size:20px;">{n_dtype_chg}</div></div>'
    f'<div class="metric-item"><div class="label">Length Δ</div><div class="value" style="color:{C["warn_fg"]};font-size:20px;">{n_len_chg}</div></div>'
    f'<div class="metric-item"><div class="label">Format Δ</div><div class="value" style="color:{C["warn_fg"]};font-size:20px;">{n_fmt_chg}</div></div>'
    f'<div class="metric-item"><div class="label">Rows added</div><div class="value" style="color:{C["dt_fg"]};font-size:20px;">{n_added:,}</div></div>'
    f'<div class="metric-item"><div class="label">Rows removed</div><div class="value" style="color:{C["unmap_fg"]};font-size:20px;">{n_removed:,}</div></div>'
    f'<div class="metric-item"><div class="label">Vars changed</div><div class="value" style="color:{C["unmap_fg"]};font-size:20px;">{n_vchg}</div></div>'
    f'</div>', unsafe_allow_html=True
)

# Per-dataset download
ds_report = export_comparison_report(meta_diff, value_results, label_a, label_b, selected_ds)
st.download_button(
    f"⬇ Download {selected_ds} Report (.xlsx)", data=ds_report,
    file_name=f"Compare_{selected_ds}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)

# ─────────────────────────────────────────────────────────────────────────────
# Detail tabs
# ─────────────────────────────────────────────────────────────────────────────
tab_meta, tab_val, tab_chg, tab_add, tab_rem = st.tabs([
    f"Metadata Diff ({len(meta_diff)})",
    f"Value Summary ({n_vchg} vars with diffs)",
    f"Changed Values",
    f"Added Rows ({n_added:,})",
    f"Removed Rows ({n_removed:,})",
])

# Row-class functions
def _meta_rc(row):
    s = str(row.get("status",""))
    if s == "SAME":              return "row-pass"
    if s == "ONLY_IN_A":         return "row-warning"
    if s == "ONLY_IN_B":         return "row-dt"
    if s.startswith("CHANGED"):  return "row-warning"
    return ""

def _val_rc(row):
    n = int(row.get("different",0))
    if n == 0: return "row-pass"
    pct = float(row.get("pct_different",0))
    return "row-miss" if pct > 50 else "row-warning"

with tab_meta:
    if meta_diff.empty:
        st.info("No metadata comparison available.")
    else:
        # Filter controls
        fc1, fc2 = st.columns(2)
        status_opts = ["All","SAME","ONLY_IN_A","ONLY_IN_B"] + \
                      sorted(s for s in meta_diff["status"].unique() if s.startswith("CHANGED"))
        sf  = fc1.selectbox("Status filter", status_opts, key="meta_sf_ds")
        chg = fc2.checkbox("Show only changed variables", value=False, key="meta_chg_only")

        dm = meta_diff.copy()
        if sf != "All":
            dm = dm[dm["status"]==sf]
        if chg:
            dm = dm[dm["status"] != "SAME"]

        st.caption(f"Showing {len(dm):,} of {len(meta_diff):,} variables")

        # Highlight columns with changes
        def _meta_cell(col, val, row):
            if col in ("label_changed","dtype_changed","length_changed","format_changed"):
                if val == "YES":
                    return f'<span style="background:{C["warn_bg"]};color:{C["warn_fg"]};padding:2px 6px;border-radius:4px;font-weight:700;">YES</span>'
            if col == "status":
                if val == "SAME":
                    return f'<span style="color:{C["pass_fg"]};">{val}</span>'
                if val in ("ONLY_IN_A","ONLY_IN_B"):
                    return f'<span style="color:{C["dt_fg"]};">{val}</span>'
                if val.startswith("CHANGED"):
                    return f'<span style="color:{C["warn_fg"]};font-weight:600;">{val}</span>'
            return val

        st.markdown(render_table(dm, row_class_fn=_meta_rc, cell_fn=_meta_cell, C=C),
                    unsafe_allow_html=True)

with tab_val:
    summ = value_results.get("summary", pd.DataFrame())
    if summ is None or summ.empty:
        st.info("Value comparison not run or no common variables found.")
    else:
        show_d = st.checkbox("Show only variables with differences", value=True, key="val_d_ds")
        ds6    = summ[summ["different"]>0] if show_d else summ
        st.caption(f"Showing {len(ds6):,} of {len(summ):,} variables")
        st.markdown(render_table(ds6, row_class_fn=_val_rc, C=C), unsafe_allow_html=True)

        if HAS_PLOTLY and not ds6.empty and n_vchg > 0:
            top_n = ds6.head(20)
            tpl   = "plotly" if theme_mode=="light" else "plotly_dark"
            fig   = px.bar(top_n, x="variable", y="different",
                           color="pct_different",
                           color_continuous_scale=["#4ade80","#fbbf24","#ef4444"],
                           title="Top Variables by # Different Values",
                           height=260)
            fig.update_layout(template=tpl, margin=dict(l=0,r=0,t=36,b=0),
                               paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
                               coloraxis_showscale=False)
            fig.update_xaxes(tickangle=-35)
            st.plotly_chart(fig, use_container_width=True)

with tab_chg:
    chg_df = value_results.get("changed_values", pd.DataFrame())
    if chg_df is None or chg_df.empty:
        st.success("No value differences found." if n_vchg == 0 else
                   "Value comparison not run.")
    else:
        var_opts = ["All"] + sorted(chg_df["variable"].unique().tolist()) \
                   if "variable" in chg_df.columns else ["All"]
        vs = st.selectbox("Filter by variable", var_opts, key="chg_var_ds")
        dc = chg_df if vs=="All" else chg_df[chg_df["variable"]==vs]
        st.caption(f"{len(dc):,} differing records")

        def _chg_cell(col, val, row):
            na = f"value_{label_a}"
            nb = f"value_{label_b}"
            if col == na:
                return f'<span style="color:{C["warn_fg"]};">{val}</span>'
            if col == nb:
                return f'<span style="color:{C["pass_fg"]};">{val}</span>'
            return val

        st.markdown(render_table(dc, row_class_fn=lambda r:"row-miss",
                                  cell_fn=_chg_cell, max_rows=500, C=C),
                    unsafe_allow_html=True)

with tab_add:
    added = value_results.get("added_rows", pd.DataFrame())
    if added is None or added.empty:
        st.success("No added rows.")
    else:
        st.caption(f"{len(added):,} rows in B ({label_b}) not in A ({label_a})")
        st.markdown(render_table(added, row_class_fn=lambda r:"row-dt",
                                  max_rows=500, C=C), unsafe_allow_html=True)

with tab_rem:
    removed = value_results.get("removed_rows", pd.DataFrame())
    if removed is None or removed.empty:
        st.success("No removed rows.")
    else:
        st.caption(f"{len(removed):,} rows in A ({label_a}) not in B ({label_b})")
        st.markdown(render_table(removed, row_class_fn=lambda r:"row-warning",
                                  max_rows=500, C=C), unsafe_allow_html=True)
