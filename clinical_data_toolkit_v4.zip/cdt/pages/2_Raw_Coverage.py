# pages/2_Raw_Coverage.py
"""
Raw Coverage — validates at raw.DATASET.VARIABLE level.
Files come from session_state (uploaded in sidebar on app.py).
"""
import sys, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from core.raw_coverage import run_raw_coverage_from_store
from core.excel_export import export_coverage_results

st.set_page_config(page_title="Raw Coverage", layout="wide")

st.markdown("""
<style>
.cov-table{width:100%;border-collapse:collapse;font-size:13px;font-family:'Segoe UI',system-ui,sans-serif}
.cov-table th{background:#1e293b;color:#f1f5f9;padding:9px 12px;text-align:left;font-size:12px;letter-spacing:.04em;position:sticky;top:0;z-index:1}
.cov-table td{padding:7px 12px;border-bottom:1px solid rgba(148,163,184,.12);vertical-align:middle}
.cov-table tr.exact  td{background:#f0fdf4;color:#14532d}
.cov-table tr.partial td{background:#fffbeb;color:#713f12}
.cov-table tr.unmapped td{background:#fff1f2;color:#881337}
.cov-table tr.even td{background:#f8fafc}
.cov-table tr:hover td{filter:brightness(.96)}
.cov-table .mono{font-family:monospace;font-size:12px}
.sbadge{display:inline-block;padding:2px 9px;border-radius:10px;font-size:11px;font-weight:700}
.b-exact{background:#dcfce7;color:#166534}
.b-partial{background:#fef9c3;color:#854d0e}
.b-unmapped{background:#ffe4e6;color:#9f1239}
.cov-scroll{max-height:480px;overflow-y:auto;border:1px solid rgba(148,163,184,.25);border-radius:8px}
</style>
""", unsafe_allow_html=True)

st.title("Raw Variable Coverage")
st.caption("Validates at raw.DATASET.VARIABLE level against spec INPUT_VARIABLES. "
           "SUPP domain logic applied automatically.")

# ── Check prerequisites ────────────────────────────────────────────────────
if "spec" not in st.session_state:
    st.warning("Upload a mapping specification in the sidebar (app page) first.")
    st.stop()
if "raw_files_store" not in st.session_state:
    st.warning("Upload raw CRF datasets (.sas7bdat) in the sidebar first.")
    st.stop()

spec       = st.session_state["spec"]
spec_name  = st.session_state.get("spec_name","spec")
raw_store  = st.session_state["raw_files_store"]


def _render_cov_table(df: pd.DataFrame, max_rows: int = 1000) -> str:
    cols = list(df.columns)
    header = "".join(f"<th>{c.replace('_',' ').title()}</th>" for c in cols)
    rows_html = []
    for i,(_, row) in enumerate(df.head(max_rows).iterrows()):
        status = str(row.get("status","")).upper()
        rc = {"EXACT":"exact","PARTIAL":"partial","UNMAPPED":"unmapped"}.get(
            status, "even" if i%2==0 else "")
        cells = []
        for col in cols:
            val = str(row.get(col,""))
            if col == "status":
                bc = {"EXACT":"b-exact","PARTIAL":"b-partial","UNMAPPED":"b-unmapped"}.get(status,"")
                cell = f'<td><span class="sbadge {bc}">{val}</span></td>'
            elif col in ("raw_variable","mapped_to","raw_triplet","sdtm_domain"):
                cell = f'<td class="mono">{val}</td>'
            else:
                cell = f"<td>{val}</td>"
            cells.append(cell)
        rows_html.append(f'<tr class="{rc}">{"".join(cells)}</tr>')
    if len(df) > max_rows:
        rows_html.append(f'<tr><td colspan="{len(cols)}" style="text-align:center;color:#64748b;'
                         f'padding:10px;font-style:italic;">Showing {max_rows} of {len(df)} rows'
                         f' — download Excel for full list</td></tr>')
    return (f'<div class="cov-scroll"><table class="cov-table">'
            f'<thead><tr>{header}</tr></thead>'
            f'<tbody>{"".join(rows_html)}</tbody></table></div>')


# ── Config row ────────────────────────────────────────────────────────────
col1, col2 = st.columns([3,1])
with col1:
    st.info(f"Using {len(raw_store)} raw file(s) uploaded in sidebar: "
            f"{', '.join(Path(k).stem.upper() for k in sorted(raw_store.keys()))}")
with col2:
    active_filter = st.text_input("Active flag value", value="Y", key="cov_active")
    extra_excl    = st.text_input("Extra exclude vars", value="", placeholder="VAR1,VAR2")

extra_set = {v.strip().upper() for v in extra_excl.split(",") if v.strip()} if extra_excl.strip() else set()

if st.button("Run Coverage Check", type="primary", use_container_width=True):
    with st.spinner(f"Analysing {len(raw_store)} file(s)..."):
        try:
            results = run_raw_coverage_from_store(
                raw_store, spec,
                active_filter=active_filter,
                exclude_vars=extra_set,
            )
            st.session_state["cov_results"] = results
        except Exception as exc:
            st.error(f"Coverage check failed: {exc}")
            st.exception(exc)

if "cov_results" not in st.session_state:
    st.info("Click 'Run Coverage Check' to begin.")
    st.stop()

cov_r    = st.session_state["cov_results"]
coverage : pd.DataFrame = cov_r.get("coverage", pd.DataFrame())
summary  : pd.DataFrame = cov_r.get("summary", pd.DataFrame())
dom_map  : pd.DataFrame = cov_r.get("domain_mapping", pd.DataFrame())
spec_refs: pd.DataFrame = cov_r.get("spec_refs", pd.DataFrame())

if coverage.empty:
    st.warning("No raw variables found. Check the uploaded files.")
    st.stop()

# ── Metrics ────────────────────────────────────────────────────────────────
total     = len(coverage)
n_exact   = int((coverage["status"]=="EXACT").sum())
n_partial = int((coverage["status"]=="PARTIAL").sum())
n_unmap   = int((coverage["status"]=="UNMAPPED").sum())
pct       = round((n_exact+n_partial)/total*100,1) if total else 0

st.markdown(
    f'<div style="background:#1e293b;border-radius:10px;padding:16px 24px;'
    f'display:flex;gap:32px;flex-wrap:wrap;align-items:center;">'
    f'<div><div style="font-size:11px;color:#94a3b8;text-transform:uppercase;">Total Raw Vars</div>'
    f'<div style="font-size:26px;font-weight:800;color:#f1f5f9;">{total:,}</div></div>'
    f'<div><div style="font-size:11px;color:#94a3b8;">EXACT</div>'
    f'<div style="font-size:26px;font-weight:700;color:#4ade80;">{n_exact:,}</div></div>'
    f'<div><div style="font-size:11px;color:#94a3b8;">PARTIAL</div>'
    f'<div style="font-size:26px;font-weight:700;color:#fbbf24;">{n_partial:,}</div></div>'
    f'<div><div style="font-size:11px;color:#94a3b8;">UNMAPPED</div>'
    f'<div style="font-size:26px;font-weight:700;color:#f87171;">{n_unmap:,}</div></div>'
    f'<div><div style="font-size:11px;color:#94a3b8;">% Covered</div>'
    f'<div style="font-size:26px;font-weight:800;color:#38bdf8;">{pct}%</div></div>'
    f'</div>',
    unsafe_allow_html=True,
)

# ── Chart ─────────────────────────────────────────────────────────────────
if HAS_PLOTLY and not summary.empty:
    with st.expander("Coverage by raw dataset", expanded=True):
        chart_data = summary.melt(
            id_vars=["raw_dataset"],
            value_vars=[c for c in ["EXACT","PARTIAL","UNMAPPED"] if c in summary.columns],
            var_name="status", value_name="count",
        )
        fig = px.bar(chart_data, x="raw_dataset", y="count", color="status",
                     color_discrete_map={"EXACT":"#22c55e","PARTIAL":"#f59e0b","UNMAPPED":"#ef4444"},
                     barmode="stack", height=280)
        fig.update_layout(margin=dict(l=0,r=0,t=20,b=0),
                          plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)")
        fig.update_xaxes(tickangle=-30)
        st.plotly_chart(fig, use_container_width=True)

# ── Download ──────────────────────────────────────────────────────────────
excel_bytes = export_coverage_results(coverage, summary)
st.download_button("Download Coverage Report (.xlsx)", data=excel_bytes,
    file_name=f"RawCoverage_{spec_name.replace('.xlsx','')}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

st.divider()

# ── Tabs ──────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs([
    f"Variable Detail ({len(coverage):,})",
    "Dataset Summary",
    "Raw-to-SDTM Domain Map",
    f"Unmapped ({n_unmap:,})",
])

with tab1:
    cf1, cf2 = st.columns(2)
    with cf1:
        sf = st.selectbox("Status", ["All","EXACT","PARTIAL","UNMAPPED"], key="cov_sf")
    with cf2:
        ds_opts = ["All"] + sorted(coverage["raw_dataset"].dropna().unique().tolist())
        df_sel  = st.selectbox("Raw Dataset", ds_opts, key="cov_df")

    disp = coverage.copy()
    if sf != "All":   disp = disp[disp["status"] == sf]
    if df_sel != "All": disp = disp[disp["raw_dataset"] == df_sel]

    st.markdown(
        f'<div style="display:flex;gap:14px;font-size:12px;margin:6px 0;align-items:center;">'
        f'<span style="background:#f0fdf4;padding:2px 10px;border-radius:4px;border:1px solid #86efac;color:#14532d;">EXACT — raw.dataset.variable matched</span>'
        f'<span style="background:#fffbeb;padding:2px 10px;border-radius:4px;border:1px solid #fde68a;color:#713f12;">PARTIAL — variable name match only</span>'
        f'<span style="background:#fff1f2;padding:2px 10px;border-radius:4px;border:1px solid #fecdd3;color:#881337;">UNMAPPED — no match</span>'
        f'<span style="margin-left:auto;color:#64748b;">Showing {len(disp):,} of {len(coverage):,}</span>'
        f'</div>',
        unsafe_allow_html=True,
    )
    # Show relevant columns
    show_cols = [c for c in ["raw_dataset","raw_variable","status","sdtm_domain","mapped_to"]
                 if c in disp.columns]
    st.markdown(_render_cov_table(disp[show_cols]), unsafe_allow_html=True)

with tab2:
    if summary.empty:
        st.info("No summary available.")
    else:
        st.dataframe(summary, use_container_width=True, height=400)

with tab3:
    st.markdown("**Raw Dataset → SDTM Domain Mapping Overview**")
    st.caption("Shows which SDTM domains each raw dataset feeds into, based on spec INPUT_VARIABLES references.")
    if dom_map.empty:
        st.info("No domain mapping data available.")
    else:
        # Render as clean table
        disp_dm = dom_map[["raw_dataset","sdtm_domains","n_sdtm_domains","n_variables"]].copy()
        disp_dm.columns = ["Raw Dataset","SDTM Domains","# SDTM Domains","# Spec Refs"]
        st.dataframe(disp_dm, use_container_width=True, height=400)

        # Plotly chord / bar showing breadth of mapping
        if HAS_PLOTLY:
            fig2 = px.bar(dom_map, x="raw_dataset", y="n_sdtm_domains",
                          title="Number of SDTM domains per raw dataset",
                          labels={"raw_dataset":"Raw Dataset","n_sdtm_domains":"# SDTM Domains"},
                          color="n_sdtm_domains",
                          color_continuous_scale="Blues",
                          height=260)
            fig2.update_layout(margin=dict(l=0,r=0,t=36,b=0),
                               plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
                               showlegend=False)
            fig2.update_xaxes(tickangle=-30)
            st.plotly_chart(fig2, use_container_width=True)

with tab4:
    if coverage[coverage["status"]=="UNMAPPED"].empty:
        st.success("No unmapped variables!")
    else:
        unm = coverage[coverage["status"]=="UNMAPPED"].copy()
        ds_u_opts = ["All"] + sorted(unm["raw_dataset"].dropna().unique().tolist())
        ds_u = st.selectbox("Raw Dataset filter", ds_u_opts, key="cov_unm_ds")
        if ds_u != "All":
            unm = unm[unm["raw_dataset"]==ds_u]
        show_u = [c for c in ["raw_dataset","raw_variable"] if c in unm.columns]
        st.markdown(_render_cov_table(unm[show_u]), unsafe_allow_html=True)
