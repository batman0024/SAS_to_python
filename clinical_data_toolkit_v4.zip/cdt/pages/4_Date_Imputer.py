# pages/4_Date_Imputer.py
"""
AE Date Imputer — files from session_state (sidebar).
New features:
- ADSL auto-merged for TRTSDT when AE doesn't contain it
- ADAE comparison mode: re-impute and compare with existing vars
- Run toggle
"""
import sys, warnings, io
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime, date
import pandas as pd
import numpy as np
import streamlit as st

from core.date_imputer import impute_ae_dates, build_imputation_summary, RULE_LABELS

st.set_page_config(page_title="Date Imputer", layout="wide")

st.markdown("""
<style>
.imp-table{width:100%;border-collapse:collapse;font-size:12px;font-family:'Courier New',monospace}
.imp-table th{background:#1e293b;color:#f1f5f9;padding:8px 10px;text-align:left;font-size:11px;position:sticky;top:0}
.imp-table td{padding:6px 10px;border-bottom:1px solid rgba(148,163,184,.12)}
.imp-table tr.pass td{background:#f0fdf4}
.imp-table tr.part td{background:#fffbeb}
.imp-table tr.miss td{background:#fff1f2}
.imp-table tr.dt  td{background:#eff6ff}
.imp-table tr.even td{background:#f8fafc}
.imp-scroll{max-height:440px;overflow-y:auto;border:1px solid rgba(148,163,184,.25);border-radius:8px}
.diff-match{background:#dcfce7}
.diff-no  {background:#fee2e2}
</style>
""", unsafe_allow_html=True)

st.title("AE Date Imputer")
st.caption("Imputes partial/missing AE dates. ADSL merged automatically for TRTSDT. "
           "ADAE comparison mode available for re-imputation checking.")

SAS_EPOCH = pd.Timestamp("1960-01-01")

def _conv_sas_date(v):
    if pd.isna(v): return pd.NaT
    if isinstance(v,(pd.Timestamp,datetime,date)): return pd.Timestamp(v)
    s = str(v).strip()
    if "-" in s or "/" in s:
        try: return pd.Timestamp(s)
        except: pass
    try:
        n = float(s)
        if -5000 <= n <= 50000:
            return SAS_EPOCH + pd.Timedelta(days=int(n))
    except: pass
    return pd.NaT

@st.cache_data
def _load_df(fdata: bytes, fname: str) -> pd.DataFrame:
    if fname.lower().endswith(".sas7bdat"):
        try:
            import pyreadstat
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df,_ = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
            df.columns = [c.upper() for c in df.columns]
            return df
        except Exception as e:
            raise ValueError(f"Cannot read {fname}: {e}")
    df = pd.read_csv(io.BytesIO(fdata))
    df.columns = [c.upper() for c in df.columns]
    return df

# ── Run toggle ─────────────────────────────────────────────────────────────
run_imp = st.toggle("Enable imputation", value=True,
    help="OFF = parse dates only, no imputation rules applied.")

st.divider()

# ── Load files from session state ─────────────────────────────────────────
ae_bytes   = st.session_state.get("ae_file_bytes")
ae_name    = st.session_state.get("ae_file_name","")
adsl_bytes = st.session_state.get("adsl_file_bytes")
adsl_name  = st.session_state.get("adsl_file_name","")

if not ae_bytes:
    st.warning("Upload an AE or ADAE dataset in the sidebar first.")
    st.stop()

# ── Column config ─────────────────────────────────────────────────────────
col1, col2 = st.columns([2,1])
with col1:
    st.info(f"AE: **{ae_name}**" + (f"  |  ADSL: **{adsl_name}**" if adsl_bytes else ""))
    if adsl_bytes:
        st.caption("ADSL will be merged on USUBJID to supply TRTSDT.")
with col2:
    startc = st.text_input("Start DTC", value="AESTDTC")
    stopc  = st.text_input("Stop DTC",  value="AEENDTC")
    trtsdt = st.text_input("First dose date", value="TRTSDT",
        help="If not in AE/ADAE, will be merged from ADSL.")
    prefix = st.text_input("Output prefix", value="AE")
    skip_dt= st.checkbox("Pass datetime strings through", value=True)
    is_adae= st.checkbox("Input is ADAE (comparison mode)",
        value="ADAE" in ae_name.upper(),
        help="If checked, re-imputes dates and compares new output with existing ASTDT/AENDT.")

# ── Load AE ───────────────────────────────────────────────────────────────
try:
    ae_df = _load_df(ae_bytes, ae_name)
except Exception as exc:
    st.error(str(exc)); st.stop()

st.success(f"Loaded {ae_name}: {len(ae_df):,} rows, {len(ae_df.columns)} columns")

# ── Merge ADSL for TRTSDT if not in AE ───────────────────────────────────
if trtsdt not in ae_df.columns and adsl_bytes:
    try:
        adsl_df = _load_df(adsl_bytes, adsl_name)
        merge_cols = ["USUBJID", trtsdt]
        # Also bring TRTSDTM if present
        if "TRTSDTM" in adsl_df.columns:
            merge_cols.append("TRTSDTM")
        avail = [c for c in merge_cols if c in adsl_df.columns]
        if "USUBJID" in adsl_df.columns and trtsdt in adsl_df.columns:
            ae_df = ae_df.merge(adsl_df[avail].drop_duplicates("USUBJID"),
                                on="USUBJID", how="left")
            st.info(f"Merged {trtsdt} from ADSL.")
        else:
            st.warning(f"ADSL does not contain USUBJID + {trtsdt}.")
    except Exception as exc:
        st.warning(f"Cannot load ADSL: {exc}")
elif trtsdt not in ae_df.columns:
    st.warning(f"Column '{trtsdt}' not found. Upload ADSL in the sidebar for auto-merge.")

# ── Column check ─────────────────────────────────────────────────────────
missing = [c for c in [startc, stopc] if c not in ae_df.columns]
if missing:
    st.error(f"Columns not found: {missing}. Available: {sorted(ae_df.columns[:20].tolist())}")
    st.stop()
if trtsdt not in ae_df.columns:
    st.error(f"'{trtsdt}' not available. Cannot impute without first dose date.")
    st.stop()

ae_df[trtsdt] = _conv_sas_date(ae_df[trtsdt]) if ae_df[trtsdt].dtype == object else ae_df[trtsdt].apply(_conv_sas_date)

# Preview
with st.expander("Input preview (10 rows)", expanded=False):
    id_c  = [c for c in ["USUBJID","SUBJID","AESEQ"] if c in ae_df.columns]
    prev  = [c for c in [startc,stopc,trtsdt] if c in ae_df.columns]
    st.dataframe(ae_df[id_c+prev].head(10), use_container_width=True)

st.divider()

btn_label = "Run Imputation" if run_imp else "Parse Dates Only"
if st.button(btn_label, type="primary", use_container_width=True):
    with st.spinner("Processing..."):
        try:
            result = impute_ae_dates(ae_df, startc=startc, stopc=stopc,
                                     trtsdt=trtsdt, prefix=prefix, skip_if_has_time=skip_dt)
            if not run_imp:
                rc = f"{prefix}_START_RULE"
                if rc in result.columns:
                    result[rc] = result[rc].apply(lambda r: r if r in (-1,0) else np.nan)
            st.session_state.update({
                "imputer_result": result, "imputer_prefix": prefix,
                "imputer_startc": startc, "imputer_stopc": stopc,
                "imputer_trtsdt": trtsdt, "imputer_is_adae": is_adae,
            })
        except Exception as exc:
            st.error(f"Failed: {exc}"); st.exception(exc)

if "imputer_result" not in st.session_state:
    st.info("Click the button to process."); st.stop()

result   = st.session_state["imputer_result"]
p        = st.session_state.get("imputer_prefix","AE")
is_adae  = st.session_state.get("imputer_is_adae", False)
startc   = st.session_state.get("imputer_startc","AESTDTC")
stopc    = st.session_state.get("imputer_stopc","AEENDTC")
trtsdt   = st.session_state.get("imputer_trtsdt","TRTSDT")

# Summary
rsumm = build_imputation_summary(result, prefix=p)
st.subheader("Imputation Summary")
items = [(l,c) for l,c in rsumm.items() if c>0]
if items:
    scols = st.columns(min(len(items),4))
    for sc,(lbl,cnt) in zip(scols,items):
        sc.metric(lbl[:38]+"..." if len(lbl)>38 else lbl, cnt)

st.markdown("""
<div style="display:flex;gap:16px;font-size:12px;margin:6px 0;align-items:center;">
<span style="background:#eff6ff;padding:2px 10px;border-radius:4px;border:1px solid #bfdbfe;">Blue=datetime passthrough</span>
<span style="background:#f0fdf4;padding:2px 10px;border-radius:4px;border:1px solid #bbf7d0;">White/Green=full date</span>
<span style="background:#fffbeb;padding:2px 10px;border-radius:4px;border:1px solid #fde68a;">Amber=partial imputed</span>
<span style="background:#fff1f2;padding:2px 10px;border-radius:4px;border:1px solid #fecaca;">Red=missing imputed</span>
</div>""", unsafe_allow_html=True)

st.divider()

# ── Output columns ────────────────────────────────────────────────────────
id_disp   = [c for c in ["USUBJID","SUBJID","AESEQ"] if c in result.columns]
inp_cols  = [c for c in [startc,stopc,trtsdt] if c in result.columns]
start_out = [c for c in ["ASTDT","ASTDTC","ASTDTF","ASTTM","ASTDTM"] if c in result.columns]
stop_out  = [c for c in ["AENDT","AENDTC","AENDTF","AENTM","AENDTM"] if c in result.columns]
flag_cols = [c for c in [f"{p}_START_RULE",f"{p}_STOP_IMPFL",f"{p}_STOP_ONGOING",
                          f"{p}_REL_STOP_TO_TRT"] if c in result.columns]

all_out = id_disp + inp_cols + start_out + stop_out + flag_cols
rc2 = f"{p}_START_RULE"
if rc2 in result.columns:
    result["_rule_label"] = result[rc2].map(RULE_LABELS).fillna("")
    all_out.append("_rule_label")
all_out = [c for c in all_out if c in result.columns]

def _row_class(rv):
    try: r = float(rv) if pd.notna(rv) else 0
    except: r = 0
    if r==-1: return "dt"
    if r==0:  return "pass"
    if r in(1.,2.): return "part"
    return "miss"

def _render_imp(df, max_rows=500):
    cols = [c for c in all_out if c in df.columns]
    hdr  = "".join(f"<th>{c}</th>" for c in cols)
    rows = []
    for i,(_,row) in enumerate(df.head(max_rows).iterrows()):
        rc_v = row.get(f"{p}_START_RULE", np.nan)
        cls  = _row_class(rc_v)
        if cls=="pass" and i%2==0: cls="even"
        cells = []
        for col in cols:
            v = row.get(col,"")
            if pd.isna(v) or v!=v: v=""
            elif isinstance(v,pd.Timestamp):
                v = v.strftime("%Y-%m-%d %H:%M") if (v.hour or v.minute) else v.strftime("%Y-%m-%d")
            else: v=str(v)
            cells.append(f"<td>{v}</td>")
        rows.append(f'<tr class="{cls}">{"".join(cells)}</tr>')
    if len(df)>max_rows:
        rows.append(f'<tr><td colspan="{len(cols)}" style="text-align:center;color:#64748b;padding:8px;">'
                    f'... {len(df)-max_rows} more rows in download</td></tr>')
    return (f'<div class="imp-scroll"><table class="imp-table">'
            f'<thead><tr>{hdr}</tr></thead><tbody>{"".join(rows)}</tbody></table></div>')

# ── Tabs ──────────────────────────────────────────────────────────────────
tab_labels = [f"All ({len(result):,})", "Imputed Only"]
if is_adae:
    tab_labels.append("ADAE Comparison")
tabs = st.tabs(tab_labels)

with tabs[0]:
    st.markdown(_render_imp(result), unsafe_allow_html=True)

with tabs[1]:
    imponly = result[result[rc2].notna() & (~result[rc2].isin([0,-1]))] if rc2 in result.columns else result.head(0)
    st.caption(f"{len(imponly):,} records had imputation applied")
    if imponly.empty:
        st.success("No records required imputation.")
    else:
        st.markdown(_render_imp(imponly), unsafe_allow_html=True)

if is_adae and len(tabs) > 2:
    with tabs[2]:
        st.markdown("**ADAE Comparison — new imputed values vs existing variables**")
        existing_start = [c for c in ["ASTDT","ASTDTC","ASTDTF"] if c in ae_df.columns]
        existing_stop  = [c for c in ["AENDT","AENDTC","AENDTF"] if c in ae_df.columns]
        if not existing_start and not existing_stop:
            st.info("No existing ASTDT/AENDT columns found in ADAE to compare against.")
        else:
            comp_rows = []
            for col in existing_start + existing_stop:
                new_col = col  # same name in result
                if new_col not in result.columns or col not in ae_df.columns:
                    continue
                orig = ae_df[col].astype(str).str.strip()
                new  = result[new_col].astype(str).str.strip()
                match_mask = orig == new
                n_match = int(match_mask.sum())
                n_diff  = int((~match_mask).sum())
                comp_rows.append({"Variable": col,
                                   "Matches": n_match,
                                   "Differences": n_diff,
                                   "Total": len(orig)})
            if comp_rows:
                comp_df = pd.DataFrame(comp_rows)
                st.dataframe(comp_df, use_container_width=True)

                # Show records where values differ
                sel_var = st.selectbox("Show differing records for:", 
                    [r["Variable"] for r in comp_rows if r["Differences"]>0] or ["(none)"])
                if sel_var and sel_var != "(none)" and sel_var in result.columns and sel_var in ae_df.columns:
                    orig_s  = ae_df[sel_var].astype(str).str.strip()
                    new_s   = result[sel_var].astype(str).str.strip()
                    diff_idx= orig_s.index[orig_s != new_s]
                    diff_df = pd.DataFrame({
                        "USUBJID": ae_df.get("USUBJID", pd.Series(dtype=str)).reindex(diff_idx),
                        f"Original_{sel_var}": orig_s[diff_idx],
                        f"New_{sel_var}":      new_s[diff_idx],
                    })
                    st.dataframe(diff_df, use_container_width=True, height=350)

# ── Downloads ─────────────────────────────────────────────────────────────
st.divider()
dl1, dl2 = st.columns(2)
csv_out = result[all_out].copy()
for col in csv_out.columns:
    if pd.api.types.is_datetime64_any_dtype(csv_out[col]):
        csv_out[col] = csv_out[col].dt.strftime("%Y-%m-%dT%H:%M:%S").fillna("")
with dl1:
    st.download_button("Download All Records (.csv)",
        data=csv_out.to_csv(index=False).encode("utf-8"),
        file_name=f"AE_imputed_{datetime.now():%Y%m%d_%H%M}.csv", mime="text/csv",
        use_container_width=True)
with dl2:
    if not imponly.empty:
        csv_imp = imponly[all_out].copy()
        for col in csv_imp.columns:
            if pd.api.types.is_datetime64_any_dtype(csv_imp[col]):
                csv_imp[col] = csv_imp[col].dt.strftime("%Y-%m-%dT%H:%M:%S").fillna("")
        st.download_button("Download Imputed Only (.csv)",
            data=csv_imp.to_csv(index=False).encode("utf-8"),
            file_name=f"AE_imputed_only_{datetime.now():%Y%m%d_%H%M}.csv", mime="text/csv",
            use_container_width=True)
