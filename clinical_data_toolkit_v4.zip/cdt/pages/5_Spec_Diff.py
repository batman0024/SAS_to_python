# pages/5_Spec_Diff.py
"""
Spec Diff page.
Compares two mapping spec Excel files variable by variable.
Useful for comparing a core standard spec against a study-level spec.
Ports read_spec_616_adam.sas - replaces PROC COMPARE with structured pandas diff.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import warnings
warnings.filterwarnings("ignore")

import io
from datetime import datetime

import pandas as pd
import streamlit as st

from core.spec_loader import load_spec_from_bytes
from core.spec_diff import compare_specs, diff_summary, COMPARE_FIELDS
from core.excel_export import export_diff_results

st.set_page_config(page_title="Spec Diff", layout="wide")
st.title("Spec Diff")
st.caption(
    "Compare two mapping spec Excel files field by field. "
    "Identifies variables that are CHANGED, ONLY_IN_A, ONLY_IN_B, or SAME."
)

# Spec A comes from the sidebar (already loaded)
spec_a      = st.session_state.get("spec")
spec_a_name = st.session_state.get("spec_name", "Spec A")

if spec_a is None:
    st.warning("Upload Spec A (the base spec) in the sidebar (app page) first.")
    st.stop()

st.info(f"Spec A (base): **{spec_a_name}** — loaded from sidebar")

# Spec B upload
spec_b_file = st.file_uploader(
    "Upload Spec B (.xlsx) - the spec to compare against",
    type=["xlsx"],
    help="E.g. upload your core standard spec here to compare against the study spec.",
)

if spec_b_file is None:
    st.info("Upload Spec B to begin comparison.")
    st.stop()

spec_b_bytes = spec_b_file.read()
spec_b_key = f"specb__{spec_b_file.name}__{len(spec_b_bytes)}"

if st.session_state.get("_specb_key") != spec_b_key:
    with st.spinner("Loading Spec B..."):
        try:
            spec_b = load_spec_from_bytes(spec_b_bytes)
            st.session_state["spec_b"] = spec_b
            st.session_state["spec_b_name"] = spec_b_file.name
            st.session_state["_specb_key"] = spec_b_key
            st.session_state.pop("diff_result", None)
        except Exception as exc:
            st.error(f"Cannot load Spec B: {exc}")
            st.stop()

spec_b = st.session_state.get("spec_b")
spec_b_name = st.session_state.get("spec_b_name", "Spec B")
st.success(f"Spec B loaded: {spec_b_name}")

# Field selection
with st.expander("Configure comparison fields", expanded=False):
    selected_fields = []
    cols = st.columns(4)
    for i, field in enumerate(COMPARE_FIELDS):
        with cols[i % 4]:
            if st.checkbox(field, value=True, key=f"diff_field_{field}"):
                selected_fields.append(field)

if not selected_fields:
    st.warning("Select at least one field to compare.")
    st.stop()

# Run
if st.button("Run Comparison", type="primary", use_container_width=True):
    with st.spinner("Comparing specs..."):
        try:
            diff_df = compare_specs(
                spec_a, spec_b,
                label_a=spec_a_name,
                label_b=spec_b_name,
                compare_fields=selected_fields,
            )
            st.session_state["diff_result"] = diff_df
        except Exception as exc:
            st.error(f"Comparison failed: {exc}")
            st.exception(exc)

if "diff_result" not in st.session_state:
    st.info("Click 'Run Comparison' to begin.")
    st.stop()

diff_df: pd.DataFrame = st.session_state["diff_result"]

if diff_df.empty:
    st.info("No differences found or no comparable domains.")
    st.stop()

# Summary metrics
dsumm = diff_summary(diff_df)
m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("SAME", dsumm["same"])
m2.metric("CHANGED", dsumm["changed"])
m3.metric(f"Only in {spec_a_name[:15]}", dsumm["only_a"])
m4.metric(f"Only in {spec_b_name[:15]}", dsumm["only_b"])
m5.metric("Total rows", dsumm["total"])

st.divider()

# Download
excel_bytes = export_diff_results(diff_df)
st.download_button(
    label="Download Diff Report (.xlsx)",
    data=excel_bytes,
    file_name=f"SpecDiff_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)

st.divider()

# Filters
col1, col2, col3 = st.columns(3)
with col1:
    status_opts = ["All", "CHANGED", "ONLY_IN_A", "ONLY_IN_B", "SAME"]
    status_filter = st.selectbox("Filter by status", status_opts, key="diff_status")
with col2:
    dom_opts = ["All"] + sorted(diff_df["dataset"].unique().tolist())
    dom_filter = st.selectbox("Filter by domain", dom_opts, key="diff_dom")
with col3:
    field_opts = ["All"] + sorted(diff_df["field"].unique().tolist())
    field_filter = st.selectbox("Filter by field", field_opts, key="diff_field_flt")

disp = diff_df.copy()
if status_filter != "All":
    disp = disp[disp["status"] == status_filter]
if dom_filter != "All":
    disp = disp[disp["dataset"] == dom_filter]
if field_filter != "All":
    disp = disp[disp["field"] == field_filter]

st.caption(
    f"Showing {len(disp)} rows | "
    f"A={spec_a_name}  B={spec_b_name}"
)


def _colour_diff(row):
    s = str(row.get("status", ""))
    if s == "CHANGED":
        return ["background-color: #FEF3C7"] * len(row)
    if s == "ONLY_IN_A":
        return ["background-color: #FECACA"] * len(row)
    if s == "ONLY_IN_B":
        return ["background-color: #DBEAFE"] * len(row)
    return [""] * len(row)


# Rename columns for display clarity
disp_display = disp.rename(columns={
    "value_in_a": f"Value in {spec_a_name[:20]}",
    "value_in_b": f"Value in {spec_b_name[:20]}",
})

st.dataframe(
    disp_display.style.apply(_colour_diff, axis=1),
    use_container_width=True,
    height=500,
)
