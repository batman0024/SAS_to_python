# core/define_helper.py
"""
Define helper — extracts variable metadata and value-level from SAS datasets.
Accepts in-memory bytes dict from session_state (no tempdir race condition).
"""
import io
import logging
import re
import warnings
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)
log.setLevel(logging.ERROR)

EXCLUDE_DOMAIN_PREFIXES = ("_",)


def _safe_meta_attr(meta, attr: str, default=None):
    return getattr(meta, attr, default)


# ── Metadata from in-memory bytes (PRIMARY path) ─────────────────────────────
def get_column_metadata_from_store(
    files_store: Dict[str, bytes],
) -> pd.DataFrame:
    """
    Read variable metadata from in-memory dict {filename: bytes}.
    This is the reliable path — avoids tempfile deletion race condition.
    """
    rows = []
    for fname, fdata in sorted(files_store.items()):
        dom = Path(fname).stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES):
            continue
        if fname.lower().endswith(".sas7bdat"):
            rows.extend(_meta_from_sas_bytes(fdata, dom))
        elif fname.lower().endswith(".csv"):
            rows.extend(_meta_from_csv_bytes(fdata, dom))
    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["domain","variable","label","data_type","length","format"])
    return df.drop_duplicates(subset=["domain","variable"]).reset_index(drop=True)


def _meta_from_sas_bytes(fdata: bytes, domain: str) -> list:
    try:
        import pyreadstat
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), metadataonly=True)

        col_names  = _safe_meta_attr(meta, "column_names", []) or []
        col_labels = _safe_meta_attr(meta, "column_labels", []) or []
        var_fmts   = _safe_meta_attr(meta, "variable_formats", {}) or {}
        var_types  = (_safe_meta_attr(meta, "original_variable_types", []) or
                      _safe_meta_attr(meta, "readstat_variable_types", []) or [])
        var_widths = _safe_meta_attr(meta, "variable_storage_width", {}) or {}
        col_types_map = _safe_meta_attr(meta, "column_names_to_types", {}) or {}

        rows = []
        for idx, col in enumerate(col_names):
            label = ""
            if idx < len(col_labels) and col_labels[idx]:
                label = str(col_labels[idx])
            fmt = var_fmts.get(col, "") if isinstance(var_fmts, dict) else ""
            typ_raw = ""
            if idx < len(var_types) and var_types[idx]:
                typ_raw = str(var_types[idx])
            elif col in col_types_map:
                typ_raw = str(col_types_map[col])

            if "char" in typ_raw.lower() and "date" in label.lower():
                dtype = "datetime"
            elif "char" in typ_raw.lower():
                dtype = "text"
            elif any(h in str(fmt).upper() for h in ("DATE","TIME","MMDD","YYMMDD")):
                dtype = "datetime"
            else:
                dtype = "integer"

            lgth = var_widths.get(col, "") if isinstance(var_widths, dict) else ""
            rows.append({
                "domain": domain, "variable": col.upper(),
                "label": label, "data_type": dtype,
                "length": lgth, "format": fmt,
            })
        return rows
    except Exception as exc:
        log.debug("Cannot read SAS metadata for %s: %s", domain, exc)
        return []


def _meta_from_csv_bytes(fdata: bytes, domain: str) -> list:
    try:
        df = pd.read_csv(io.BytesIO(fdata), nrows=0)
        return [{"domain": domain, "variable": c.upper(), "label": "",
                 "data_type": "text", "length": "", "format": ""} for c in df.columns]
    except Exception as exc:
        log.debug("Cannot read CSV metadata for %s: %s", domain, exc)
        return []


# ── Legacy path-based entry point ────────────────────────────────────────────
def get_column_metadata(lib_path: str) -> pd.DataFrame:
    store = {}
    lib = Path(lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")):
        dom = fp.stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES):
            continue
        store[fp.name] = fp.read_bytes()
    for fp in sorted(lib.glob("*.csv")):
        store[fp.name] = fp.read_bytes()
    return get_column_metadata_from_store(store)


# ── Value-level extraction ────────────────────────────────────────────────────
def get_value_level_from_store(
    files_store: Dict[str, bytes],
    columns_df: pd.DataFrame,
    mode: str = "SDTM",
) -> pd.DataFrame:
    """Extract TESTCD/QNAM/PARAMCD distinct values from in-memory bytes."""
    mode = mode.upper()
    if mode == "ADAM":
        cands = columns_df[columns_df["variable"].str.upper().isin(["PARAMCD"])][
            ["domain","variable"]].copy().reset_index(drop=True)
        cands["orres"]        = "AVAL"
        cands["where_prefix"] = (cands["domain"] + ".PARAMCD.").values
    else:
        pat = re.compile(r"TESTCD|QNAM|PARMCD", re.IGNORECASE)
        cands = columns_df[columns_df["variable"].str.contains(pat, na=False)][
            ["domain","variable"]].copy().reset_index(drop=True)
        cands["orres"] = cands["variable"].apply(
            lambda v: "" if "TESTCD" in v.upper() else "QVAL")
        cands["where_prefix"] = (cands["domain"] + "." + cands["variable"] + ".").values

    rows = []
    # Build a lookup: domain_name (upper) -> bytes
    dom_to_bytes = {Path(k).stem.upper(): v for k, v in files_store.items()
                    if k.lower().endswith(".sas7bdat")}
    dom_to_csv   = {Path(k).stem.upper(): v for k, v in files_store.items()
                    if k.lower().endswith(".csv")}

    for _, cand in cands.iterrows():
        dom = cand["domain"].upper()
        var = cand["variable"].upper()
        fdata = dom_to_bytes.get(dom) or dom_to_csv.get(dom)
        if fdata is None:
            continue
        try:
            if dom in dom_to_bytes:
                import pyreadstat
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df, _ = pyreadstat.read_sas7bdat(io.BytesIO(fdata), usecols=[var])
            else:
                df = pd.read_csv(io.BytesIO(fdata), usecols=[var])
            df.columns = [c.upper() for c in df.columns]
            if var not in df.columns:
                continue
            orres = cand["orres"]
            if not orres and "TESTCD" in var:
                orres = dom + "ORRES"
            for val in df[var].dropna().unique():
                vs = str(val).strip()
                if not vs:
                    continue
                rows.append({
                    "dataset": dom, "variable": var, "result_variable": orres,
                    "value": vs, "where_clause": cand["where_prefix"] + vs,
                    "data_type": _infer_dtype(vs),
                })
        except Exception as exc:
            log.debug("Value-level error for %s.%s: %s", dom, var, exc)

    if not rows:
        return pd.DataFrame(columns=[
            "dataset","variable","result_variable","value","where_clause","data_type"])
    return pd.DataFrame(rows).drop_duplicates(
        subset=["dataset","variable","value"]).reset_index(drop=True)


def get_value_level(lib_path: str, columns_df: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    """Legacy path-based entry point."""
    store = {}
    lib = Path(lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")):
        store[fp.name] = fp.read_bytes()
    for fp in sorted(lib.glob("*.csv")):
        store[fp.name] = fp.read_bytes()
    return get_value_level_from_store(store, columns_df, mode)


def _infer_dtype(val: str) -> str:
    try:
        n = float(val)
        return "integer" if n == int(n) else "float"
    except (ValueError, TypeError):
        pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T", val): return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$", val): return "Date"
    return "text"


def build_where_clause_table(value_level: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    if value_level.empty:
        return pd.DataFrame(columns=["id","dataset","var","comparator","value"])
    wh = value_level[["dataset","variable","value","where_clause"]].copy()
    wh["var"]        = "PARAMCD" if mode.upper() == "ADAM" else wh["variable"]
    wh["comparator"] = "EQ"
    wh["id"]         = wh["where_clause"]
    return wh[["id","dataset","var","comparator","value"]].reset_index(drop=True)


# ── CT Validation against Codelist tab ───────────────────────────────────────
def validate_ct_values(
    value_level: pd.DataFrame,
    spec: Dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """
    Compare actual SDTM values (from value_level) against CT terms in
    the spec Codelist tab. Returns domain-wise mismatch report.

    Codelist tab columns expected: Active, codelist_name, Codelist_Value
    (or similar — resolved case-insensitively).
    """
    if value_level.empty:
        return pd.DataFrame()

    cl_sheet = None
    for k in spec:
        if k.strip().lower() == "codelist":
            cl_sheet = spec[k].copy()
            break
    if cl_sheet is None or cl_sheet.empty:
        return pd.DataFrame()

    cl_sheet.columns = [c.strip().lower().replace(" ", "_") for c in cl_sheet.columns]

    name_col  = next((c for c in cl_sheet.columns if "codelist_name" in c or c=="codelist"), None)
    value_col = next((c for c in cl_sheet.columns
                      if "codelist_value" in c and "decode" not in c
                      and "code" not in c.replace("codelist_value","")), None)
    if not value_col:
        value_col = next((c for c in cl_sheet.columns if "value" in c
                          and "decode" not in c), None)
    active_col = next((c for c in cl_sheet.columns if c=="active"), None)

    if not name_col or not value_col:
        return pd.DataFrame()

    # Build allowed-values lookup: codelist_name -> set of allowed values
    allowed: Dict[str, set] = {}
    for _, row in cl_sheet.iterrows():
        act = str(row.get(active_col,"Y")).strip().upper() if active_col else "Y"
        if act not in ("Y","YES","TRUE","1",""):
            continue
        cl_name = str(row[name_col]).strip().upper()
        val     = str(row[value_col]).strip()
        if cl_name and val and val.lower() != "nan":
            allowed.setdefault(cl_name, set()).add(val)

    if not allowed:
        return pd.DataFrame()

    # We need to join value_level with codelist references from the spec domain sheets
    # Build: dataset+variable -> codelist_name mapping from spec
    cl_refs: Dict = {}
    for sheet, df in spec.items():
        if "variable" in df.columns and "codelist" in df.columns:
            for _, row in df.iterrows():
                cl = str(row.get("codelist","")).strip()
                v  = str(row.get("variable","")).strip().upper()
                if cl and v:
                    cl_refs[(sheet.upper(), v)] = cl.upper()

    rows = []
    for _, vrow in value_level.iterrows():
        ds  = str(vrow["dataset"]).upper()
        var = str(vrow["variable"]).upper()
        val = str(vrow["value"]).strip()
        cl_name = cl_refs.get((ds, var))
        if not cl_name:
            continue
        allowed_vals = allowed.get(cl_name)
        if not allowed_vals:
            continue
        in_ct = val.upper() in {v.upper() for v in allowed_vals}
        rows.append({
            "dataset":        ds,
            "variable":       var,
            "value":          val,
            "codelist":       cl_name,
            "in_ct":          "YES" if in_ct else "NO",
            "status":         "PASS" if in_ct else "MISMATCH",
        })

    return pd.DataFrame(rows).reset_index(drop=True)
