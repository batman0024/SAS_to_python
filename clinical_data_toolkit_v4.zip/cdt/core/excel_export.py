import warnings
warnings.filterwarnings("ignore")
# core/excel_export.py
"""
Excel export: writes structured QC results to an Excel workbook.
Uses XlsxWriter for colour formatting.
"""

import io
import logging
from typing import Dict, Optional

import pandas as pd

log = logging.getLogger(__name__)

SEVERITY_BG = {
    "ERROR":   "#FFCCCC",
    "WARNING": "#FFF3CC",
    "INFO":    "#E8F4FD",
}

HEADER_BG = "#2C3E50"
HEADER_FG = "#FFFFFF"
ALT_ROW_BG = "#F5F5F5"


def export_validation_results(
    results: dict,
    spec_name: str = "spec",
) -> bytes:
    """
    Export spec validation results to a formatted Excel workbook.
    Returns bytes suitable for st.download_button.

    Sheets produced:
        Summary         - high level counts and health score
        Issues          - all per-variable check failures
        Issues_ByDomain - pivot: one section per domain
        Codelist        - codelist usage vs Codelist tab
        CompMethod      - compmethod usage + text checks
        SDTMSource      - SDTM-sourced variable traceability (if data available)
    """
    buf = io.BytesIO()
    writer = pd.ExcelWriter(buf, engine="xlsxwriter")
    wb = writer.book

    # --- Formats ---
    fmt_header = wb.add_format({
        "bold": True, "font_color": HEADER_FG, "bg_color": HEADER_BG,
        "border": 1, "text_wrap": True, "valign": "vcenter",
    })
    fmt_error = wb.add_format({"bg_color": SEVERITY_BG["ERROR"], "border": 1})
    fmt_warning = wb.add_format({"bg_color": SEVERITY_BG["WARNING"], "border": 1})
    fmt_normal = wb.add_format({"border": 1})
    fmt_alt = wb.add_format({"bg_color": ALT_ROW_BG, "border": 1})
    fmt_title = wb.add_format({
        "bold": True, "font_size": 14, "font_color": HEADER_BG,
    })
    fmt_section = wb.add_format({
        "bold": True, "font_size": 11, "bg_color": "#D5E8D4",
        "border": 1,
    })

    # 1. Summary sheet
    summary = results.get("summary", {})
    ws_sum = wb.add_worksheet("Summary")
    ws_sum.write("A1", f"Spec Validation Report: {spec_name}", fmt_title)
    ws_sum.write("A3", "Metric", fmt_header)
    ws_sum.write("B3", "Value", fmt_header)
    summary_rows = [
        ("Health Score", f"{summary.get('health_score', 0)}/100  (Grade: {summary.get('grade', '-')})"),
        ("Errors (must fix)", summary.get("errors", 0)),
        ("Warnings (review)", summary.get("warnings", 0)),
        ("Codelist Issues", summary.get("codelist_issues", 0)),
        ("CompMethod Issues", summary.get("comp_issues", 0)),
        ("SDTM Source Issues", summary.get("sdtm_issues", 0)),
        ("Total Issues", summary.get("total_issues", 0)),
    ]
    for i, (metric, val) in enumerate(summary_rows, start=3):
        ws_sum.write(i, 0, metric, fmt_normal)
        ws_sum.write(i, 1, str(val), fmt_normal)
    ws_sum.set_column("A:A", 30)
    ws_sum.set_column("B:B", 40)

    # 2. Issues sheet
    issues: pd.DataFrame = results.get("issues", pd.DataFrame())
    if not issues.empty:
        _write_issues_sheet(writer, wb, issues, fmt_header, fmt_error,
                            fmt_warning, fmt_normal, fmt_alt)
        _write_issues_by_domain(writer, wb, issues, fmt_header, fmt_error,
                                fmt_warning, fmt_section, fmt_normal)

    # 3. Codelist sheet
    codelist: pd.DataFrame = results.get("codelist_check", pd.DataFrame())
    if not codelist.empty:
        _write_df_sheet(writer, wb, codelist, "Codelist", fmt_header, fmt_normal,
                        fmt_alt, highlight_col="in_codelist_tab",
                        highlight_neg="NO")

    # 4. CompMethod sheet
    comp: pd.DataFrame = results.get("compmethod_check", pd.DataFrame())
    if not comp.empty:
        _write_df_sheet(writer, wb, comp, "CompMethod", fmt_header, fmt_normal,
                        fmt_alt, highlight_col=None)

    # 5. SDTM Source sheet
    sdtm: pd.DataFrame = results.get("sdtm_source", pd.DataFrame())
    if not sdtm.empty:
        _write_df_sheet(writer, wb, sdtm, "SDTMSource", fmt_header, fmt_normal,
                        fmt_alt, highlight_col="in_sdtm_lib",
                        highlight_neg="NO")

    writer.close()
    return buf.getvalue()


def export_define_results(
    columns_df: pd.DataFrame,
    value_level_df: pd.DataFrame,
    where_clause_df: pd.DataFrame,
) -> bytes:
    """Export Define helper tabs to Excel."""
    buf = io.BytesIO()
    writer = pd.ExcelWriter(buf, engine="xlsxwriter")
    wb = writer.book
    fmt_header = wb.add_format({
        "bold": True, "font_color": HEADER_FG, "bg_color": HEADER_BG, "border": 1,
    })
    fmt_normal = wb.add_format({"border": 1})
    fmt_alt = wb.add_format({"bg_color": ALT_ROW_BG, "border": 1})

    for df, sheet in [
        (columns_df, "Variable"),
        (value_level_df, "Value_Level"),
        (where_clause_df, "Where_Clause"),
    ]:
        if df is not None and not df.empty:
            _write_df_sheet(writer, wb, df, sheet, fmt_header,
                            fmt_normal, fmt_alt)

    writer.close()
    return buf.getvalue()


def export_coverage_results(
    coverage: pd.DataFrame,
    summary: pd.DataFrame,
) -> bytes:
    """Export raw coverage results to Excel."""
    buf = io.BytesIO()
    writer = pd.ExcelWriter(buf, engine="xlsxwriter")
    wb = writer.book
    fmt_header = wb.add_format({
        "bold": True, "font_color": HEADER_FG, "bg_color": HEADER_BG, "border": 1,
    })
    fmt_normal = wb.add_format({"border": 1})
    fmt_alt = wb.add_format({"bg_color": ALT_ROW_BG, "border": 1})

    if not summary.empty:
        _write_df_sheet(writer, wb, summary, "Summary", fmt_header,
                        fmt_normal, fmt_alt)
    if not coverage.empty:
        _write_df_sheet(writer, wb, coverage, "Variable Mapping", fmt_header,
                        fmt_normal, fmt_alt, highlight_col="status",
                        highlight_neg="UNMAPPED")
    writer.close()
    return buf.getvalue()


def export_diff_results(diff_df: pd.DataFrame) -> bytes:
    """Export spec diff results to Excel."""
    buf = io.BytesIO()
    writer = pd.ExcelWriter(buf, engine="xlsxwriter")
    wb = writer.book
    fmt_header = wb.add_format({
        "bold": True, "font_color": HEADER_FG, "bg_color": HEADER_BG, "border": 1,
    })
    fmt_normal = wb.add_format({"border": 1})
    fmt_alt = wb.add_format({"bg_color": ALT_ROW_BG, "border": 1})
    if not diff_df.empty:
        _write_df_sheet(writer, wb, diff_df, "Diff", fmt_header,
                        fmt_normal, fmt_alt, highlight_col="status",
                        highlight_neg="CHANGED")
    writer.close()
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _write_issues_sheet(writer, wb, issues, fmt_hdr, fmt_err, fmt_warn,
                         fmt_norm, fmt_alt):
    """Write all issues flat with severity colouring."""
    ws = wb.add_worksheet("Issues")
    display_cols = ["domain", "variable", "severity", "check",
                    "description", "suggestion", "mapping_action", "origin"]
    cols = [c for c in display_cols if c in issues.columns]

    # Header
    for ci, col in enumerate(cols):
        ws.write(0, ci, col.replace("_", " ").title(), fmt_hdr)

    # Rows
    for ri, (_, row) in enumerate(issues[cols].iterrows(), start=1):
        sev = str(row.get("severity", "")).upper()
        fmt = fmt_err if sev == "ERROR" else (
            fmt_warn if sev == "WARNING" else (
                fmt_alt if ri % 2 == 0 else fmt_norm
            )
        )
        for ci, col in enumerate(cols):
            ws.write(ri, ci, str(row[col]), fmt)

    ws.autofilter(0, 0, len(issues), len(cols) - 1)
    ws.freeze_panes(1, 0)
    ws.set_column("A:A", 10)
    ws.set_column("B:B", 15)
    ws.set_column("C:C", 10)
    ws.set_column("D:D", 25)
    ws.set_column("E:E", 50)
    ws.set_column("F:F", 50)


def _write_issues_by_domain(writer, wb, issues, fmt_hdr, fmt_err, fmt_warn,
                              fmt_sec, fmt_norm):
    """Write issues grouped by domain - one section per domain."""
    ws = wb.add_worksheet("Issues_ByDomain")
    display_cols = ["variable", "severity", "check", "description", "suggestion"]
    cols = [c for c in display_cols if c in issues.columns]
    current_row = 0

    for domain, group in issues.groupby("domain"):
        # Domain section header
        ws.merge_range(current_row, 0, current_row, len(cols) - 1,
                       f"Domain: {domain}  ({len(group)} issues)", fmt_sec)
        current_row += 1

        # Column headers
        for ci, col in enumerate(cols):
            ws.write(current_row, ci, col.replace("_", " ").title(), fmt_hdr)
        current_row += 1

        # Rows
        for _, row in group[cols].iterrows():
            sev = str(row.get("severity", "")).upper()
            fmt = fmt_err if sev == "ERROR" else fmt_warn
            for ci, col in enumerate(cols):
                ws.write(current_row, ci, str(row[col]), fmt)
            current_row += 1

        current_row += 1  # blank row between domains

    ws.freeze_panes(1, 0)
    ws.set_column("A:A", 15)
    ws.set_column("B:B", 10)
    ws.set_column("C:C", 25)
    ws.set_column("D:D", 50)
    ws.set_column("E:E", 50)


def _write_df_sheet(writer, wb, df, sheet_name, fmt_hdr, fmt_norm, fmt_alt,
                    highlight_col: Optional[str] = None,
                    highlight_neg: Optional[str] = None):
    """Write a generic DataFrame to a sheet with alternating row colours."""
    ws = wb.add_worksheet(sheet_name)
    cols = list(df.columns)

    fmt_highlight = wb.add_format({"bg_color": SEVERITY_BG["ERROR"], "border": 1})

    for ci, col in enumerate(cols):
        ws.write(0, ci, col.replace("_", " ").title(), fmt_hdr)

    for ri, (_, row) in enumerate(df.iterrows(), start=1):
        needs_highlight = (
            highlight_col is not None
            and highlight_col in row.index
            and str(row[highlight_col]).startswith(highlight_neg or "")
        )
        for ci, col in enumerate(cols):
            fmt = fmt_highlight if needs_highlight else (
                fmt_alt if ri % 2 == 0 else fmt_norm
            )
            val = row[col]
            if pd.isna(val):
                val = ""
            ws.write(ri, ci, str(val), fmt)

    ws.autofilter(0, 0, len(df), len(cols) - 1)
    ws.freeze_panes(1, 0)
    # Auto-width approximation
    for ci, col in enumerate(cols):
        max_len = max(
            len(str(col)),
            df[col].astype(str).str.len().max() if not df.empty else 0,
        )
        ws.set_column(ci, ci, min(max_len + 2, 60))
