# config/theme.py  v17
"""
Enhanced theme: glassmorphism cards, animated metrics, rich Plotly charts.
Supports light and dark modes.
"""
import streamlit as st

# ── Dark mode palette ─────────────────────────────────────────────────────
DARK = {
    "bg_card":    "#0f172a",
    "bg_glass":   "rgba(15,23,42,0.75)",
    "border":     "rgba(148,163,184,.18)",
    "hdr_bg":     "#0f172a",  "hdr_fg":    "#f1f5f9",
    "text_main":  "#f1f5f9",  "text_muted":"#94a3b8",
    "exact_bg":   "#052e16",  "exact_fg":   "#4ade80",
    "partial_bg": "#422006",  "partial_fg": "#fbbf24",
    "unmap_bg":   "#450a0a",  "unmap_fg":   "#f87171",
    "error_bg":   "#450a0a",  "error_fg":   "#fca5a5",
    "warn_bg":    "#451a03",  "warn_fg":    "#fcd34d",
    "pass_bg":    "#052e16",  "pass_fg":    "#4ade80",
    "miss_bg":    "#450a0a",  "miss_fg":    "#fca5a5",
    "dt_bg":      "#0c1a3a",  "dt_fg":      "#93c5fd",
    "inline_bg":  "#0c2340",  "inline_fg":  "#7dd3fc",
    "row_alt":    "#1e293b",
    "badge_error_bg":"#dc2626","badge_error_fg":"#fff",
    "badge_warn_bg": "#d97706","badge_warn_fg": "#fff",
    "badge_inline_bg":"#0369a1","badge_inline_fg":"#fff",
    # chart accents
    "accent1":    "#38bdf8",
    "accent2":    "#818cf8",
    "accent3":    "#34d399",
    "accent4":    "#fb7185",
    "accent5":    "#fbbf24",
    "chart_bg":   "#0f172a",
    "chart_paper":"rgba(15,23,42,0)",
    "grid_color": "rgba(148,163,184,0.08)",
}

# ── Light mode palette ────────────────────────────────────────────────────
LIGHT = {
    "bg_card":    "#f8fafc",
    "bg_glass":   "rgba(248,250,252,0.82)",
    "border":     "rgba(100,116,139,.22)",
    "hdr_bg":     "#1e3a5f",  "hdr_fg":    "#ffffff",
    "text_main":  "#0f172a",  "text_muted":"#475569",
    "exact_bg":   "#dcfce7",  "exact_fg":   "#14532d",
    "partial_bg": "#fef9c3",  "partial_fg": "#713f12",
    "unmap_bg":   "#fee2e2",  "unmap_fg":   "#7f1d1d",
    "error_bg":   "#fee2e2",  "error_fg":   "#7f1d1d",
    "warn_bg":    "#fef3c7",  "warn_fg":    "#78350f",
    "pass_bg":    "#dcfce7",  "pass_fg":    "#14532d",
    "miss_bg":    "#fee2e2",  "miss_fg":    "#7f1d1d",
    "dt_bg":      "#dbeafe",  "dt_fg":      "#1e3a5f",
    "inline_bg":  "#e0f2fe",  "inline_fg":  "#075985",
    "row_alt":    "#f1f5f9",
    "badge_error_bg":"#dc2626","badge_error_fg":"#fff",
    "badge_warn_bg": "#d97706","badge_warn_fg": "#fff",
    "badge_inline_bg":"#0369a1","badge_inline_fg":"#fff",
    # chart accents
    "accent1":    "#0284c7",
    "accent2":    "#6366f1",
    "accent3":    "#10b981",
    "accent4":    "#e11d48",
    "accent5":    "#d97706",
    "chart_bg":   "#ffffff",
    "chart_paper":"rgba(255,255,255,0)",
    "grid_color": "rgba(100,116,139,0.12)",
}


def get_palette(mode: str = "dark") -> dict:
    return LIGHT if mode == "light" else DARK


def build_css(C: dict) -> str:
    return f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Space+Grotesk:wght@300;400;500;600;700&display=swap');

/* ── Global tokens ───────────────────────────────────────────────── */
:root {{
  --c-text:    {C['text_main']};
  --c-muted:   {C['text_muted']};
  --c-border:  {C['border']};
  --c-card:    {C['bg_card']};
  --c-glass:   {C['bg_glass']};
  --c-accent1: {C['accent1']};
  --c-accent2: {C['accent2']};
  --c-accent3: {C['accent3']};
  --c-accent4: {C['accent4']};
  --c-accent5: {C['accent5']};
}}

/* ── Glass cards ─────────────────────────────────────────────────── */
.glass-card {{
    background: var(--c-glass);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--c-border);
    border-radius: 16px;
    padding: 20px 24px;
    margin-bottom: 14px;
    transition: transform .2s ease, box-shadow .2s ease;
}}
.glass-card:hover {{
    transform: translateY(-2px);
    box-shadow: 0 8px 32px rgba(0,0,0,.18);
}}

/* ── KPI / stat cards ────────────────────────────────────────────── */
.kpi-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 14px;
    margin-bottom: 18px;
}}
.kpi-card {{
    background: var(--c-glass);
    backdrop-filter: blur(10px);
    border: 1px solid var(--c-border);
    border-radius: 14px;
    padding: 16px 20px;
    position: relative;
    overflow: hidden;
    transition: transform .2s, box-shadow .2s;
}}
.kpi-card:hover {{ transform:translateY(-3px); box-shadow:0 10px 28px rgba(0,0,0,.15); }}
.kpi-card::before {{
    content: '';
    position: absolute; top: 0; left: 0;
    width: 100%; height: 3px;
    border-radius: 14px 14px 0 0;
}}
.kpi-card.accent1::before {{ background: linear-gradient(90deg,{C['accent1']},{C['accent2']}); }}
.kpi-card.accent2::before {{ background: linear-gradient(90deg,{C['accent2']},{C['accent3']}); }}
.kpi-card.accent3::before {{ background: linear-gradient(90deg,{C['accent3']},{C['accent1']}); }}
.kpi-card.accent4::before {{ background: linear-gradient(90deg,{C['accent4']},{C['accent5']}); }}
.kpi-card.accent5::before {{ background: linear-gradient(90deg,{C['accent5']},{C['accent4']}); }}
.kpi-label {{
    font-size: 10px; font-weight: 700; letter-spacing: .1em;
    text-transform: uppercase; color: var(--c-muted); margin-bottom: 6px;
    font-family: 'Space Grotesk', sans-serif;
}}
.kpi-value {{
    font-size: 30px; font-weight: 700; letter-spacing: -.02em;
    line-height: 1; color: var(--c-text);
    font-family: 'Space Grotesk', sans-serif;
}}
.kpi-sub {{
    font-size: 11px; color: var(--c-muted); margin-top: 4px;
    font-family: 'Space Grotesk', sans-serif;
}}

/* ── Progress bar ────────────────────────────────────────────────── */
.prog-wrap {{
    background: var(--c-border);
    border-radius: 99px; height: 8px; width: 100%; overflow: hidden; margin-top: 8px;
}}
.prog-fill {{
    height: 100%; border-radius: 99px;
    background: linear-gradient(90deg,{C['accent1']},{C['accent3']});
    transition: width 1.2s cubic-bezier(.4,0,.2,1);
}}

/* ── Status donut legend ─────────────────────────────────────────── */
.donut-legend {{
    display:flex; gap:10px; flex-wrap:wrap; margin-top:10px;
}}
.donut-legend-item {{
    display:inline-flex; align-items:center; gap:6px;
    font-size:12px; color:var(--c-muted);
    font-family:'Space Grotesk',sans-serif;
}}
.donut-legend-dot {{
    width:10px; height:10px; border-radius:50%; flex-shrink:0;
}}

/* ── Data table ──────────────────────────────────────────────────── */
.cdt-table {{
    width:100%; border-collapse:collapse; font-size:13px;
    font-family:'Space Grotesk',system-ui,sans-serif; color:{C['text_main']};
}}
.cdt-table th {{
    background:{C['hdr_bg']}; color:{C['hdr_fg']}; padding:9px 12px;
    text-align:left; font-size:11px; font-weight:700; letter-spacing:.05em;
    text-transform:uppercase; position:sticky; top:0; z-index:2;
    border-bottom:2px solid {C['border']};
}}
.cdt-table td {{
    padding:7px 12px; border-bottom:1px solid {C['border']};
    vertical-align:top; line-height:1.45;
}}
.cdt-table tr.row-exact    td {{ background:{C['exact_bg']};   color:{C['exact_fg']}; }}
.cdt-table tr.row-partial  td {{ background:{C['partial_bg']}; color:{C['partial_fg']}; }}
.cdt-table tr.row-unmapped td {{ background:{C['unmap_bg']};   color:{C['unmap_fg']}; }}
.cdt-table tr.row-error    td {{ background:{C['error_bg']};   color:{C['error_fg']}; }}
.cdt-table tr.row-warning  td {{ background:{C['warn_bg']};    color:{C['warn_fg']}; }}
.cdt-table tr.row-pass     td {{ background:{C['pass_bg']};    color:{C['pass_fg']}; }}
.cdt-table tr.row-miss     td {{ background:{C['miss_bg']};    color:{C['miss_fg']}; }}
.cdt-table tr.row-dt       td {{ background:{C['dt_bg']};      color:{C['dt_fg']}; }}
.cdt-table tr.row-inline   td {{ background:{C['inline_bg']};  color:{C['inline_fg']}; }}
.cdt-table tr.row-alt      td {{ background:{C['row_alt']}; }}
.cdt-table tr:hover        td {{ filter:brightness(1.07); }}
.cdt-table .mono {{ font-family:'JetBrains Mono',monospace; font-size:12px; }}
.cdt-scroll {{
    max-height:500px; overflow-y:auto;
    border:1px solid {C['border']}; border-radius:12px;
}}

/* ── Badge pills ─────────────────────────────────────────────────── */
.badge {{
    display:inline-block; padding:2px 9px; border-radius:10px;
    font-size:11px; font-weight:700; letter-spacing:.04em;
    font-family:'Space Grotesk',sans-serif;
}}
.badge-error   {{ background:{C['badge_error_bg']};  color:{C['badge_error_fg']}; }}
.badge-warning {{ background:{C['badge_warn_bg']};   color:{C['badge_warn_fg']}; }}
.badge-exact   {{ background:{C['exact_bg']};  color:{C['exact_fg']}; border:1px solid {C['exact_fg']}33; }}
.badge-partial {{ background:{C['partial_bg']}; color:{C['partial_fg']}; border:1px solid {C['partial_fg']}33; }}
.badge-unmapped{{ background:{C['unmap_bg']};  color:{C['unmap_fg']}; border:1px solid {C['unmap_fg']}33; }}
.badge-pass    {{ background:{C['pass_bg']};   color:{C['pass_fg']}; border:1px solid {C['pass_fg']}33; }}
.badge-miss    {{ background:{C['miss_bg']};   color:{C['miss_fg']}; border:1px solid {C['miss_fg']}33; }}
.badge-inline  {{ background:{C['inline_bg']}; color:{C['inline_fg']}; border:1px solid {C['inline_fg']}33; }}

/* ── Metric bar (legacy compat) ──────────────────────────────────── */
.metric-bar {{
    background:{C['bg_card']}; border-radius:14px; padding:14px 24px;
    display:flex; gap:32px; flex-wrap:wrap; align-items:center; margin-bottom:8px;
    border:1px solid {C['border']};
}}
.metric-item .label {{
    font-size:11px; color:{C['text_muted']};
    text-transform:uppercase; letter-spacing:.06em;
    font-family:'Space Grotesk',sans-serif;
}}
.metric-item .value {{ font-size:24px; font-weight:800; font-family:'Space Grotesk',sans-serif; }}

/* ── Legend row ──────────────────────────────────────────────────── */
.legend-row {{
    display:flex; gap:12px; font-size:12px; margin:6px 0;
    align-items:center; flex-wrap:wrap; color:{C['text_muted']};
    font-family:'Space Grotesk',sans-serif;
}}
.legend-chip {{ padding:2px 10px; border-radius:4px; font-size:12px; }}

/* ── Score banner ────────────────────────────────────────────────── */
.score-banner {{
    border-radius:14px; padding:14px 20px; margin-bottom:4px;
    display:flex; align-items:center; gap:32px; flex-wrap:wrap;
    border:1px solid {C['border']};
}}

/* ── Section header ──────────────────────────────────────────────── */
.section-header {{
    font-family:'Space Grotesk',sans-serif;
    font-size:13px; font-weight:600; letter-spacing:.06em;
    text-transform:uppercase; color:var(--c-muted);
    border-bottom:1px solid var(--c-border);
    padding-bottom:6px; margin:18px 0 12px 0;
}}

/* ── Animations ──────────────────────────────────────────────────── */
@keyframes fadeSlideUp {{
    from {{ opacity:0; transform:translateY(14px); }}
    to   {{ opacity:1; transform:translateY(0); }}
}}
.kpi-card, .glass-card {{
    animation: fadeSlideUp .45s ease both;
}}
.kpi-card:nth-child(1) {{ animation-delay:.05s; }}
.kpi-card:nth-child(2) {{ animation-delay:.10s; }}
.kpi-card:nth-child(3) {{ animation-delay:.15s; }}
.kpi-card:nth-child(4) {{ animation-delay:.20s; }}
.kpi-card:nth-child(5) {{ animation-delay:.25s; }}
</style>
"""


# Defaults
C        = DARK
BASE_CSS = build_css(C)


def get_theme_css(mode: str = "dark") -> str:
    return build_css(get_palette(mode))


def render_table(
    df,
    row_class_fn=None,
    cell_fn=None,
    max_rows: int = 1000,
    id_str: str = "",
    C: dict = None,
) -> str:
    if C is None:
        from config.theme import DARK
        C = DARK
    if df is None or df.empty:
        return f"<p style='color:{C['text_muted']};font-style:italic;padding:8px;'>No data.</p>"

    cols   = list(df.columns)
    header = "".join(f"<th>{c.replace('_',' ').title()}</th>" for c in cols)

    rows_html = []
    for i, (_, row) in enumerate(df.head(max_rows).iterrows()):
        row_d = row.to_dict()
        rc = row_class_fn(row_d) if row_class_fn else ("row-alt" if i % 2 == 0 else "")
        cells = []
        for col in cols:
            val = row_d.get(col, "")
            if val is None or (isinstance(val, float) and val != val):
                val = ""
            if cell_fn:
                cells.append(f"<td>{cell_fn(col, str(val), row_d)}</td>")
            else:
                mono = "mono" if col.lower() in (
                    "variable","raw_variable","mapped_to","compmethod_id",
                    "where_clause","raw_dataset","value","ct_values_allowed",
                    "sample_values","ct_mismatch_values") else ""
                cells.append(f'<td class="{mono}">{val}</td>')
        rows_html.append(f'<tr class="{rc}">{"".join(cells)}</tr>')

    if len(df) > max_rows:
        rows_html.append(
            f'<tr><td colspan="{len(cols)}" style="text-align:center;'
            f'color:{C["text_muted"]};padding:10px;font-style:italic;">'
            f'Showing {max_rows:,} of {len(df):,} rows — download Excel for full list'
            f'</td></tr>'
        )

    return (
        f'<div class="cdt-scroll" id="{id_str}">'
        f'<table class="cdt-table"><thead><tr>{header}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table></div>'
    )


# ── Plotly chart helpers ──────────────────────────────────────────────────────

def plotly_layout(C: dict, title: str = "", height: int = 320) -> dict:
    """Return a dict of layout kwargs for Plotly figures matching the theme."""
    return dict(
        height=height,
        title=dict(text=title, font=dict(family="Space Grotesk", size=14, color=C["text_muted"]),
                   x=0, pad=dict(l=4, t=4)) if title else None,
        paper_bgcolor=C["chart_paper"],
        plot_bgcolor=C["chart_bg"],
        font=dict(family="Space Grotesk, system-ui", size=12, color=C["text_muted"]),
        margin=dict(l=8, r=8, t=36 if title else 12, b=8),
        xaxis=dict(gridcolor=C["grid_color"], zeroline=False, showline=False,
                   tickfont=dict(size=11)),
        yaxis=dict(gridcolor=C["grid_color"], zeroline=False, showline=False,
                   tickfont=dict(size=11)),
        legend=dict(bgcolor="rgba(0,0,0,0)", borderwidth=0,
                    font=dict(size=11)),
        showlegend=True,
    )


def status_colors(C: dict) -> dict:
    """Map status labels to theme accent colours."""
    return {
        "EXACT":    C["exact_fg"],
        "PARTIAL":  C["partial_fg"],
        "UNMAPPED": C["unmap_fg"],
        "ERROR":    C["error_fg"],
        "WARNING":  C["warn_fg"],
        "PASS":     C["pass_fg"],
        "MISS":     C["miss_fg"],
    }


def render_kpi_cards(metrics: list, C: dict) -> str:
    """
    metrics: list of dicts with keys: label, value, sub (opt), accent (1-5), pct (opt 0-100)
    Returns HTML string for a KPI grid.
    """
    cards = []
    for m in metrics:
        pct_html = ""
        if m.get("pct") is not None:
            pct_html = (
                f'<div class="prog-wrap">'
                f'<div class="prog-fill" style="width:{m["pct"]}%;"></div>'
                f'</div>'
            )
        sub_html = f'<div class="kpi-sub">{m["sub"]}</div>' if m.get("sub") else ""
        color = C.get(f'accent{m.get("accent", 1)}', C["accent1"])
        cards.append(
            f'<div class="kpi-card accent{m.get("accent",1)}">'
            f'  <div class="kpi-label">{m["label"]}</div>'
            f'  <div class="kpi-value" style="color:{color};">{m["value"]}</div>'
            f'  {sub_html}{pct_html}'
            f'</div>'
        )
    return f'<div class="kpi-grid">{"".join(cards)}</div>'
