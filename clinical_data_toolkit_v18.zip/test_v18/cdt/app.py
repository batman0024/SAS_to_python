# app.py  v18
"""
Clinical Data Toolkit — main entry point.
FIX v18:
  - fillcolor uses hex_to_rgba() not 8-char hex strings
  - light/dark Plotly template switched via C['plotly_tpl']
  - demo scatter traces fixed
"""
import sys
import warnings
from pathlib import Path
warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).parent))

import streamlit as st

st.set_page_config(
    page_title="Clinical Data Toolkit",
    page_icon=":microscope:",
    layout="wide",
    initial_sidebar_state="expanded",
)

try:
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import (
    get_palette, build_css, render_kpi_cards,
    plotly_layout, status_colors, hex_to_rgba, DARK,
)

# ── helpers ───────────────────────────────────────────────────────────────────
def _load_sas_bytes(file_bytes: bytes, filename: str):
    import io
    try:
        import pyreadstat
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            df, meta = pyreadstat.read_sas7bdat(io.BytesIO(file_bytes))
        df.columns = [c.upper() for c in df.columns]
        return df, meta
    except Exception as exc:
        return None, str(exc)


# ── THEME ─────────────────────────────────────────────────────────────────────
theme_mode = st.sidebar.radio("Theme", ["dark", "light"], horizontal=True,
    key="app_theme", help="Switch display theme.")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)

# ── SIDEBAR ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(
        f'<div style="font-family:Space Grotesk,sans-serif;font-size:18px;font-weight:700;'
        f'color:{C["text_main"]};letter-spacing:-.01em;padding:4px 0 2px 0;">⚕ Clinical Data Toolkit</div>'
        f'<div style="font-size:11px;color:{C["text_muted"]};letter-spacing:.04em;margin-bottom:10px;">'
        f'PRE-SPONSOR REVIEW QC · v1.8</div>',
        unsafe_allow_html=True,
    )

    if st.button("↺ Reset Session", type="secondary", use_container_width=True,
                 help="Clear all uploaded files and results."):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

    st.divider()

    # 1. Mapping Spec
    st.markdown("**Mapping Specification**")
    spec_file = st.file_uploader(
        "Upload Spec (.xlsx)", type=["xlsx"], key="sidebar_spec_upload",
        help="SDTM or ADaM mapping specification. Must contain a 'toc' sheet.",
    )
    if spec_file:
        spec_bytes = spec_file.getvalue()
        spec_key   = f"spec__{spec_file.name}__{len(spec_bytes)}"
        if st.session_state.get("_spec_key") != spec_key:
            with st.spinner("Loading spec..."):
                try:
                    from core.spec_loader import load_spec_from_bytes, get_active_domains, get_spec_metadata
                    spec  = load_spec_from_bytes(spec_bytes)
                    meta  = get_spec_metadata(spec)
                    doms  = get_active_domains(spec)
                    st.session_state.update({
                        "spec": spec, "spec_bytes": spec_bytes,
                        "spec_name": spec_file.name, "spec_meta": meta,
                        "spec_domains": doms, "_spec_key": spec_key,
                    })
                    for k in ["validation_results","run_history","cov_results",
                              "define_columns","imputer_result"]:
                        st.session_state.pop(k, None)
                except Exception as exc:
                    st.error(f"Cannot load spec: {exc}")

    if "spec" in st.session_state:
        meta = st.session_state.get("spec_meta", {})
        doms = st.session_state.get("spec_domains", [])
        st.success(f"Spec: {st.session_state.get('spec_name','')}")
        c1, c2 = st.columns(2)
        c1.metric("Domains", len(doms))
        c2.metric("Type", meta.get("spec_type", "?"))
        if meta.get("ig_version"):  st.caption(f"IG: {meta['ig_version']}")
        ct = meta.get("ct_version") or (meta.get("ct_from_codelist") or [""])[0]
        if ct: st.caption(f"CT: {ct}")
        if meta.get("study_name"): st.caption(f"Study: {meta['study_name']}")

    st.divider()

    # 2. Raw CRF
    st.markdown("**Raw CRF Datasets (.sas7bdat)**")
    raw_files = st.file_uploader(
        "Upload raw datasets", type=["sas7bdat","xpt","csv"],
        accept_multiple_files=True, key="sidebar_raw_upload",
    )
    if raw_files:
        raw_key = "_".join(f"{f.name}{f.size}" for f in raw_files)
        if st.session_state.get("_raw_key") != raw_key:
            st.session_state["raw_files_store"] = {f.name: f.getvalue() for f in raw_files}
            st.session_state["_raw_key"] = raw_key
            st.session_state.pop("cov_results", None)
        n = len(raw_files)
        st.success(f"{n} raw file{'s' if n>1 else ''} loaded")

    st.divider()

    # 3. SDTM/ADaM
    st.markdown("**SDTM / ADaM Datasets**")
    sdtm_files = st.file_uploader(
        "Upload SDTM or ADaM datasets", type=["sas7bdat","xpt","csv"],
        accept_multiple_files=True, key="sidebar_sdtm_upload",
    )
    if sdtm_files:
        sdtm_key = "_".join(f"{f.name}{f.size}" for f in sdtm_files)
        if st.session_state.get("_sdtm_key") != sdtm_key:
            st.session_state["sdtm_files_store"] = {f.name: f.getvalue() for f in sdtm_files}
            st.session_state["_sdtm_key"] = sdtm_key
            st.session_state.pop("define_columns", None)
        n = len(sdtm_files)
        st.success(f"{n} SDTM/ADaM file{'s' if n>1 else ''} loaded")

    st.divider()

    # 4. AE / ADSL
    st.markdown("**AE / ADAE Datasets (Date Imputer)**")
    ae_files_sb = st.file_uploader(
        "Upload AE or ADAE dataset(s)", type=["sas7bdat","xpt","csv"],
        accept_multiple_files=True, key="sidebar_ae_upload",
    )
    adsl_file_sb = st.file_uploader(
        "Upload ADSL (contains TRTSDT)", type=["sas7bdat","xpt","csv"],
        key="sidebar_adsl_upload",
    )
    if ae_files_sb:
        ae_key = "_".join(f"{f.name}{f.size}" for f in ae_files_sb)
        if st.session_state.get("_ae_key") != ae_key:
            st.session_state["ae_files_store"] = {f.name: f.getvalue() for f in ae_files_sb}
            st.session_state["_ae_key"] = ae_key
            st.session_state.pop("imputer_result", None)
        n_ae = len(ae_files_sb)
        st.success(f"{n_ae} AE file{'s' if n_ae>1 else ''} loaded")
    if adsl_file_sb:
        adsl_key = f"{adsl_file_sb.name}{adsl_file_sb.size}"
        if st.session_state.get("_adsl_key") != adsl_key:
            st.session_state["adsl_file_bytes"] = adsl_file_sb.getvalue()
            st.session_state["adsl_file_name"]  = adsl_file_sb.name
            st.session_state["_adsl_key"] = adsl_key
        st.success(f"ADSL: {adsl_file_sb.name}")

    if st.session_state.get("run_history"):
        st.divider()
        st.caption("Recent validation runs")
        for run in reversed(st.session_state["run_history"][-5:]):
            icon = "red_circle" if run["errors"]>0 else (
                "large_yellow_circle" if run["warnings"]>0 else "large_green_circle")
            st.caption(f":{icon}: {run['time']}  {run['errors']}E / {run['warnings']}W")


# ── HOME DASHBOARD ────────────────────────────────────────────────────────────
st.markdown(
    f'<div style="font-family:Space Grotesk,sans-serif;font-size:26px;font-weight:700;'
    f'letter-spacing:-.02em;color:{C["text_main"]};margin-bottom:2px;">⚕ Clinical Data Toolkit</div>'
    f'<div style="font-size:13px;color:{C["text_muted"]};margin-bottom:18px;">'
    f'Pre-Sponsor Review QC — upload files in the sidebar, shared across all pages</div>',
    unsafe_allow_html=True,
)

# ── Session KPI cards ─────────────────────────────────────────────────────────
has_spec  = "spec"             in st.session_state
has_raw   = "raw_files_store"  in st.session_state
has_sdtm  = "sdtm_files_store" in st.session_state
has_ae    = "ae_files_store"   in st.session_state
has_adsl  = "adsl_file_bytes"  in st.session_state

n_raw   = len(st.session_state["raw_files_store"])  if has_raw  else 0
n_sdtm  = len(st.session_state["sdtm_files_store"]) if has_sdtm else 0
n_ae    = len(st.session_state["ae_files_store"])    if has_ae   else 0
n_doms  = len(st.session_state.get("spec_domains", [])) if has_spec else 0

metrics = [
    {"label": "Spec Loaded",    "value": "Yes" if has_spec else "—",
     "sub": (st.session_state.get("spec_name","") or "")[:28] if has_spec else "No spec uploaded",
     "accent": 3 if has_spec else 1},
    {"label": "Active Domains", "value": str(n_doms) if has_spec else "—",
     "sub": st.session_state.get("spec_meta",{}).get("spec_type","") or "–",
     "accent": 1},
    {"label": "Raw Files",      "value": str(n_raw)  if n_raw  else "—",
     "sub": "CRF datasets loaded" if n_raw  else "None loaded", "accent": 2},
    {"label": "SDTM / ADaM",    "value": str(n_sdtm) if n_sdtm else "—",
     "sub": "Datasets loaded"     if n_sdtm else "None loaded", "accent": 5},
    {"label": "AE Datasets",    "value": str(n_ae)   if n_ae   else "—",
     "sub": "For Date Imputer"    if n_ae   else "None loaded", "accent": 4},
]
st.markdown(render_kpi_cards(metrics, C), unsafe_allow_html=True)

# ── Live result charts ────────────────────────────────────────────────────────
cov_r = st.session_state.get("cov_results")
val_r = st.session_state.get("validation_results")

if HAS_PLOTLY and (cov_r or val_r):
    import pandas as pd
    col_a, col_b = st.columns(2, gap="medium")

    if cov_r:
        coverage = cov_r.get("coverage", pd.DataFrame())
        if not coverage.empty and "status" in coverage.columns:
            with col_a:
                sc    = status_colors(C)
                vc    = coverage["status"].value_counts()
                lbls  = list(vc.index)
                vals  = list(vc.values)
                clrs  = [sc.get(l, C["accent1"]) for l in lbls]
                total = len(coverage)
                pct   = round(sum(v for l,v in zip(lbls,vals) if l!="UNMAPPED")/total*100,1) if total else 0
                fig = go.Figure(go.Pie(
                    labels=lbls, values=vals, hole=.62,
                    marker=dict(colors=clrs, line=dict(color="rgba(0,0,0,0.3)", width=2)),
                    textinfo="label+percent",
                    textfont=dict(size=12, family="Space Grotesk"),
                    hovertemplate="<b>%{label}</b><br>%{value:,} vars (%{percent})<extra></extra>",
                ))
                lyt = plotly_layout(C, "Raw Variable Coverage", height=300)
                lyt.pop("xaxis", None); lyt.pop("yaxis", None)
                lyt["annotations"] = [dict(
                    text=f"<b>{pct}%</b><br>covered",
                    x=.5, y=.5, showarrow=False,
                    font=dict(size=15, family="Space Grotesk", color=C["text_main"]),
                )]
                fig.update_layout(**lyt)
                st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    if val_r and isinstance(val_r, dict):
        dom_sum = val_r.get("domain_summary", pd.DataFrame())
        if not dom_sum.empty:
            with col_b:
                err_col  = next((c for c in dom_sum.columns if "error"   in c.lower()), None)
                warn_col = next((c for c in dom_sum.columns if "warning" in c.lower()), None)
                dom_col  = next((c for c in dom_sum.columns if "domain"  in c.lower()), None)
                if dom_col and (err_col or warn_col):
                    fig2 = go.Figure()
                    if err_col:
                        fig2.add_trace(go.Bar(name="Errors",
                            x=dom_sum[dom_col], y=dom_sum[err_col],
                            marker_color=C["accent4"],
                            hovertemplate="<b>%{x}</b><br>Errors: %{y}<extra></extra>"))
                    if warn_col:
                        fig2.add_trace(go.Bar(name="Warnings",
                            x=dom_sum[dom_col], y=dom_sum[warn_col],
                            marker_color=C["accent5"],
                            hovertemplate="<b>%{x}</b><br>Warnings: %{y}<extra></extra>"))
                    lyt2 = plotly_layout(C, "Validation Issues by Domain", height=300)
                    lyt2["barmode"] = "group"
                    lyt2["xaxis"]["tickangle"] = -35
                    fig2.update_layout(**lyt2)
                    st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

    # Run history sparkline
    run_hist = st.session_state.get("run_history", [])
    if len(run_hist) >= 2:
        col_c, _ = st.columns([1, 1], gap="medium")
        with col_c:
            times  = [r["time"]           for r in run_hist]
            errors = [r.get("errors", 0)  for r in run_hist]
            warns  = [r.get("warnings", 0) for r in run_hist]
            xs     = list(range(len(times)))
            fig3   = go.Figure()
            fig3.add_trace(go.Scatter(
                x=xs, y=errors, mode="lines+markers", name="Errors",
                line=dict(color=C["accent4"], width=2.5),
                marker=dict(size=6),
                fill="tozeroy",
                # FIX: use rgba() not 8-char hex
                fillcolor=hex_to_rgba(C["accent4"], 0.12),
                hovertext=times,
                hovertemplate="<b>%{hovertext}</b><br>Errors: %{y}<extra></extra>",
            ))
            fig3.add_trace(go.Scatter(
                x=xs, y=warns, mode="lines+markers", name="Warnings",
                line=dict(color=C["accent5"], width=2.5),
                marker=dict(size=6),
                fill="tozeroy",
                fillcolor=hex_to_rgba(C["accent5"], 0.12),
                hovertext=times,
                hovertemplate="<b>%{hovertext}</b><br>Warnings: %{y}<extra></extra>",
            ))
            lyt3 = plotly_layout(C, "Validation Run History", height=260)
            lyt3["xaxis"]["showticklabels"] = False
            fig3.update_layout(**lyt3)
            st.plotly_chart(fig3, use_container_width=True, config={"displayModeBar": False})

elif HAS_PLOTLY:
    # ── Demo / placeholder charts ─────────────────────────────────────────────
    st.markdown(
        f'<div class="section-header">Dashboard Preview — run a tool to populate live charts</div>',
        unsafe_allow_html=True,
    )
    import random, numpy as np
    random.seed(42); np.random.seed(7)

    col_p1, col_p2, col_p3 = st.columns(3, gap="medium")

    with col_p1:
        sc = status_colors(C)
        demo_labels = ["EXACT","PARTIAL","UNMAPPED"]
        demo_vals   = [72, 18, 10]
        colors      = [sc[l] for l in demo_labels]
        fig_d = go.Figure(go.Pie(
            labels=demo_labels, values=demo_vals, hole=.60,
            marker=dict(colors=colors, line=dict(color="rgba(0,0,0,0.2)", width=2)),
            textinfo="label+percent",
            textfont=dict(size=12, family="Space Grotesk"),
            hoverinfo="skip",
        ))
        lyt = plotly_layout(C, "Coverage Distribution (demo)", height=280)
        lyt.pop("xaxis", None); lyt.pop("yaxis", None)
        lyt["annotations"] = [dict(
            text="<b>Demo</b>", x=.5, y=.5, showarrow=False,
            font=dict(size=14, family="Space Grotesk", color=C["text_muted"]),
        )]
        fig_d.update_layout(**lyt)
        st.plotly_chart(fig_d, use_container_width=True, config={"displayModeBar": False})

    with col_p2:
        domains = ["AE","CM","DM","EX","LB","MH","VS","PE","TU","RS"]
        errs  = [random.randint(0,8)  for _ in domains]
        warns = [random.randint(2,14) for _ in domains]
        fig_b = go.Figure()
        fig_b.add_trace(go.Bar(name="Errors",   x=domains, y=errs,  marker_color=C["accent4"]))
        fig_b.add_trace(go.Bar(name="Warnings", x=domains, y=warns, marker_color=C["accent5"]))
        lyt_b = plotly_layout(C, "Issues by Domain (demo)", height=280)
        lyt_b["barmode"] = "group"
        fig_b.update_layout(**lyt_b)
        st.plotly_chart(fig_b, use_container_width=True, config={"displayModeBar": False})

    with col_p3:
        xs      = list(range(1, 9))
        e_trend = [12, 9, 11, 7, 6, 4, 3, 2]
        w_trend = [18, 16, 14, 13, 11, 10, 8, 7]
        fig_t = go.Figure()
        # FIX: rgba() for fillcolor instead of 8-char hex
        fig_t.add_trace(go.Scatter(
            x=xs, y=e_trend, mode="lines+markers", name="Errors",
            line=dict(color=C["accent4"], width=2.5),
            fill="tozeroy", fillcolor=hex_to_rgba(C["accent4"], 0.12),
        ))
        fig_t.add_trace(go.Scatter(
            x=xs, y=w_trend, mode="lines+markers", name="Warnings",
            line=dict(color=C["accent5"], width=2.5),
            fill="tozeroy", fillcolor=hex_to_rgba(C["accent5"], 0.12),
        ))
        lyt_t = plotly_layout(C, "Issue Trend Over Runs (demo)", height=280)
        fig_t.update_layout(**lyt_t)
        st.plotly_chart(fig_t, use_container_width=True, config={"displayModeBar": False})

# ── Tool cards ────────────────────────────────────────────────────────────────
st.markdown(f'<div class="section-header">Available Tools</div>', unsafe_allow_html=True)

TOOLS = [
    ("🔍", "Spec Validator",  "Checks every active domain for completeness, missing origins, compmethod IDs, codelist gaps and comment formatting.", C["accent1"]),
    ("📊", "Raw Coverage",    "Validates at raw.DATASET.VARIABLE level. EXACT / PARTIAL / UNMAPPED with SUPP domain logic and domain mapping overview.", C["accent3"]),
    ("📋", "Define Helper",   "Extracts variable metadata and value-level from SDTM/ADaM datasets. CT validation against spec Codelist tab.", C["accent2"]),
    ("📅", "Date Imputer",    "Imputes partial/missing AE dates. ADSL merged automatically for TRTSDT. ADAE comparison mode for re-imputation.", C["accent5"]),
    ("⚖️",  "Spec Diff",       "Compares two spec files field-by-field and highlights every change, addition and removal.", C["accent4"]),
    ("✅", "CT Validation",   "Compares actual SDTM variable values against Codelist tab CT terms. Domain-wise mismatch report.", C["accent1"]),
]

cols = st.columns(3, gap="medium")
for i, (icon, name, desc, accent) in enumerate(TOOLS):
    with cols[i % 3]:
        st.markdown(
            f'<div class="glass-card" style="border-top:3px solid {accent};">'
            f'  <div style="font-size:20px;margin-bottom:6px;">{icon}</div>'
            f'  <div style="font-family:Space Grotesk,sans-serif;font-size:14px;font-weight:600;'
            f'       color:{C["text_main"]};margin-bottom:6px;">{name}</div>'
            f'  <div style="font-size:12px;color:{C["text_muted"]};line-height:1.55;">{desc}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

# ── Footer status ─────────────────────────────────────────────────────────────
loaded = []
if has_spec:  loaded.append(f"Spec: {st.session_state.get('spec_name','')}")
if has_raw:   loaded.append(f"Raw: {n_raw} file{'s' if n_raw!=1 else ''}")
if has_sdtm:  loaded.append(f"SDTM/ADaM: {n_sdtm} file{'s' if n_sdtm!=1 else ''}")
if has_ae:    loaded.append(f"AE: {n_ae} file{'s' if n_ae!=1 else ''}")
if has_adsl:  loaded.append(f"ADSL: {st.session_state.get('adsl_file_name','')}")

if loaded:
    st.success("Loaded: " + " · ".join(loaded))
else:
    st.info("Upload files in the sidebar to begin. All tools share the same uploaded files.")
