# core/dataset_compare.py  v9
"""
Dataset comparison engine.

Compares two SAS/CSV datasets at:
  1. METADATA level — variable names, labels, SAS types, lengths, formats
  2. VALUE level    — row additions, removals, value changes per variable

Supports multiple file pairs (Set A vs Set B matched by filename stem).
"""
import io
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import pandas as pd
import numpy as np

warnings.filterwarnings("ignore")


# ─────────────────────────────────────────────────────────────────────────────
# File loading
# ─────────────────────────────────────────────────────────────────────────────

def _load_sas_with_meta(fdata: bytes, fname: str) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Load a SAS/CSV dataset and return (df, meta_dict).
    meta_dict keys: labels, formats, types, lengths
      each is {VARNAME_UPPER -> value}
    """
    if not fdata:
        raise ValueError(f"Empty bytes for {fname}")

    fl = fname.lower()

    if fl.endswith(".sas7bdat"):
        # ── Try pyreadstat first ──────────────────────────────────────────
        try:
            import pyreadstat
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
            df.columns = [c.upper() for c in df.columns]

            col_names  = [c.upper() for c in (getattr(meta,"column_names",[]) or df.columns)]
            col_labels = getattr(meta,"column_labels",[]) or []
            var_fmts   = getattr(meta,"variable_formats",{}) or {}
            var_types  = (getattr(meta,"original_variable_types",[]) or
                          getattr(meta,"readstat_variable_types",[]) or [])
            var_widths = getattr(meta,"variable_storage_width",{}) or {}

            labels  = {col: (str(col_labels[i]) if i < len(col_labels) and col_labels[i] else "")
                       for i, col in enumerate(col_names)}
            formats = {col: (var_fmts.get(col,"") or var_fmts.get(col.lower(),""))
                       for col in col_names} if isinstance(var_fmts, dict) else {}
            types   = {col: (str(var_types[i]) if i < len(var_types) and var_types[i] else "")
                       for i, col in enumerate(col_names)}
            lengths = {col: (str(var_widths.get(col,"") or var_widths.get(col.lower(),""))
                       if isinstance(var_widths, dict) else "")
                       for col in col_names}
            return df, {"labels": labels, "formats": formats, "types": types, "lengths": lengths}
        except Exception:
            pass

        # ── pandas.read_sas fallback ──────────────────────────────────────
        try:
            df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
            df.columns = [c.upper() for c in df.columns]
            return df, {"labels": {}, "formats": {}, "types": {}, "lengths": {}}
        except Exception as exc:
            raise ValueError(f"Cannot read {fname}: {exc}")

    elif fl.endswith(".csv"):
        df = pd.read_csv(io.BytesIO(fdata))
        df.columns = [c.upper() for c in df.columns]
        return df, {"labels": {}, "formats": {}, "types": {}, "lengths": {}}

    raise ValueError(f"Unsupported format: {fname}")


def _load_from_bytes(fdata: bytes, fname: str) -> pd.DataFrame:
    """Simplified loader (no metadata) — used by page for quick loads."""
    df, _ = _load_sas_with_meta(fdata, fname)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Metadata comparison
# ─────────────────────────────────────────────────────────────────────────────

def compare_metadata(
    df_a: pd.DataFrame, name_a: str,
    df_b: pd.DataFrame, name_b: str,
    meta_a: Optional[Dict] = None,
    meta_b: Optional[Dict] = None,
) -> pd.DataFrame:
    """
    Compare variable metadata between two datasets.

    Columns in output:
      variable, label_A, label_B, label_changed,
      dtype_A, dtype_B, dtype_changed,
      sas_type_A, sas_type_B,
      length_A, length_B, length_changed,
      format_A, format_B, format_changed,
      in_A, in_B, status
    """
    meta_a = meta_a or {}
    meta_b = meta_b or {}

    labels_a  = meta_a.get("labels",  {})
    labels_b  = meta_b.get("labels",  {})
    formats_a = meta_a.get("formats", {})
    formats_b = meta_b.get("formats", {})
    types_a   = meta_a.get("types",   {})
    types_b   = meta_b.get("types",   {})
    lengths_a = meta_a.get("lengths", {})
    lengths_b = meta_b.get("lengths", {})

    cols_a = set(df_a.columns)
    cols_b = set(df_b.columns)
    all_cols = sorted(cols_a | cols_b)

    rows = []
    for col in all_cols:
        in_a = col in cols_a
        in_b = col in cols_b

        dtype_a  = str(df_a[col].dtype) if in_a else ""
        dtype_b  = str(df_b[col].dtype) if in_b else ""
        label_a  = labels_a.get(col, "")
        label_b  = labels_b.get(col, "")
        fmt_a    = formats_a.get(col, "")
        fmt_b    = formats_b.get(col, "")
        stype_a  = types_a.get(col, "")
        stype_b  = types_b.get(col, "")
        len_a    = lengths_a.get(col, "")
        len_b    = lengths_b.get(col, "")

        # Determine status
        if not in_a:
            status = f"ONLY_IN_B"
        elif not in_b:
            status = f"ONLY_IN_A"
        else:
            changes = []
            if label_a  != label_b  and (label_a or label_b):   changes.append("LABEL")
            if dtype_a  != dtype_b:                              changes.append("DTYPE")
            if fmt_a    != fmt_b    and (fmt_a or fmt_b):        changes.append("FORMAT")
            if len_a    != len_b    and (len_a or len_b):        changes.append("LENGTH")
            status = "CHANGED: " + "+".join(changes) if changes else "SAME"

        rows.append({
            "variable":       col,
            f"label_{name_a}":    label_a,
            f"label_{name_b}":    label_b,
            "label_changed":  "YES" if (in_a and in_b and label_a != label_b) else "",
            f"dtype_{name_a}":    dtype_a,
            f"dtype_{name_b}":    dtype_b,
            "dtype_changed":  "YES" if (in_a and in_b and dtype_a != dtype_b) else "",
            f"sas_type_{name_a}": stype_a,
            f"sas_type_{name_b}": stype_b,
            f"length_{name_a}":   str(len_a),
            f"length_{name_b}":   str(len_b),
            "length_changed": "YES" if (in_a and in_b and str(len_a) != str(len_b) and (len_a or len_b)) else "",
            f"format_{name_a}":   fmt_a,
            f"format_{name_b}":   fmt_b,
            "format_changed": "YES" if (in_a and in_b and fmt_a != fmt_b and (fmt_a or fmt_b)) else "",
            "in_A":           "YES" if in_a else "NO",
            "in_B":           "YES" if in_b else "NO",
            "status":         status,
        })

    return pd.DataFrame(rows)


# ─────────────────────────────────────────────────────────────────────────────
# Value comparison
# ─────────────────────────────────────────────────────────────────────────────

def _auto_keys(common_cols: List[str]) -> List[str]:
    """Detect likely key columns from common column names."""
    priority = [
        "USUBJID", "SUBJID", "STUDYID",
        "AESEQ","LBSEQ","CMSEQ","VSSEQ","EXSEQ","MHSEQ",
        "DSSEQ","EGSEQ","PESEQ","PRSEQ","RPSEQ","SCSEQ",
        "VISITNUM","VISIT","TIMEPOINT",
    ]
    keys = [c for c in priority if c in common_cols]
    if not keys and common_cols:
        keys = [common_cols[0]]
    return keys


def compare_values(
    df_a: pd.DataFrame, name_a: str,
    df_b: pd.DataFrame, name_b: str,
    key_cols: Optional[List[str]] = None,
    max_diff_rows: int = 10000,
) -> Dict[str, Any]:
    """
    Value-level comparison between two datasets.

    Returns dict:
      summary        — per-variable: rows_compared, matching, different, pct_different
      added_rows     — rows in B not in A (by key)
      removed_rows   — rows in A not in B (by key)
      changed_values — all differing cells with before/after columns
      n_added, n_removed, n_common_rows, n_vars_changed, key_cols_used
    """
    common_cols = sorted(set(df_a.columns) & set(df_b.columns))
    if not common_cols:
        return _empty_value_result()

    # Determine keys
    if not key_cols:
        key_cols = _auto_keys(common_cols)
    else:
        key_cols = [c for c in key_cols if c in common_cols]
        if not key_cols:
            key_cols = _auto_keys(common_cols)

    value_cols = [c for c in common_cols if c not in key_cols]

    # Stringify everything for comparison
    df_a2 = df_a[common_cols].copy().fillna("").astype(str).apply(lambda s: s.str.strip())
    df_b2 = df_b[common_cols].copy().fillna("").astype(str).apply(lambda s: s.str.strip())

    # ── Row-level (by key) ────────────────────────────────────────────────
    # Check if keys are unique in both datasets (required for simple sort-align)
    keys_unique_in_a = df_a2[key_cols].duplicated().sum() == 0 if key_cols else False
    keys_unique_in_b = df_b2[key_cols].duplicated().sum() == 0 if key_cols else False
    keys_are_unique  = keys_unique_in_a and keys_unique_in_b

    if key_cols:
        a_key_series = df_a2[key_cols].apply(tuple, axis=1)
        b_key_series = df_b2[key_cols].apply(tuple, axis=1)
        a_keys = set(a_key_series)
        b_keys = set(b_key_series)
        added_keys   = b_keys - a_keys
        removed_keys = a_keys - b_keys
        common_keys  = a_keys & b_keys

        added_rows   = df_b[b_key_series.isin(added_keys)].head(max_diff_rows)
        removed_rows = df_a[a_key_series.isin(removed_keys)].head(max_diff_rows)

        if keys_are_unique:
            # Simple sort-and-align (safe — keys are 1:1)
            a_match = df_a2[a_key_series.isin(common_keys)].sort_values(key_cols).reset_index(drop=True)
            b_match = df_b2[b_key_series.isin(common_keys)].sort_values(key_cols).reset_index(drop=True)
            use_merge = False
        else:
            # Keys have duplicates — use merge to avoid false sort-order differences
            # Add a within-key occurrence counter so rows with same key can be matched
            a_common = df_a2[a_key_series.isin(common_keys)].copy()
            b_common = df_b2[b_key_series.isin(common_keys)].copy()
            a_common["_rank"] = a_common.groupby(key_cols).cumcount()
            b_common["_rank"] = b_common.groupby(key_cols).cumcount()
            merge_keys = key_cols + ["_rank"]
            merged = pd.merge(
                a_common.reset_index(drop=True),
                b_common.reset_index(drop=True),
                on=merge_keys,
                suffixes=("__A", "__B"),
                how="inner",
            )
            a_match = merged[[c + "__A" if c not in merge_keys else c for c in common_cols]].copy()
            b_match = merged[[c + "__B" if c not in merge_keys else c for c in common_cols]].copy()
            a_match.columns = common_cols
            b_match.columns = common_cols
            a_match = a_match.reset_index(drop=True)
            b_match = b_match.reset_index(drop=True)
            use_merge = True
    else:
        added_rows   = pd.DataFrame()
        removed_rows = pd.DataFrame()
        added_keys   = set()
        removed_keys = set()
        common_keys  = set()
        min_len      = min(len(df_a2), len(df_b2))
        a_match      = df_a2.head(min_len).reset_index(drop=True)
        b_match      = df_b2.head(min_len).reset_index(drop=True)
        use_merge    = False

    # Align lengths
    min_len = min(len(a_match), len(b_match))
    a_match = a_match.head(min_len)
    b_match = b_match.head(min_len)

    # ── Per-column value diff ─────────────────────────────────────────────
    summary_rows = []
    changed_all  = []

    for col in value_cols:
        if col not in a_match.columns or col not in b_match.columns:
            continue
        diff_mask = a_match[col] != b_match[col]
        n_diff    = int(diff_mask.sum())
        n_match   = int((~diff_mask).sum())
        pct       = round(n_diff / max(min_len, 1) * 100, 2)
        summary_rows.append({
            "variable":      col,
            "rows_compared": min_len,
            "matching":      n_match,
            "different":     n_diff,
            "pct_different": pct,
        })
        if n_diff > 0:
            cap = max(1, max_diff_rows // max(len(value_cols), 1))
            key_part = a_match[diff_mask][[c for c in key_cols if c in a_match.columns]].copy()
            diff_df  = key_part.head(cap).copy()
            diff_df["variable"]           = col
            diff_df[f"value_{name_a}"]    = a_match[col][diff_mask].values[:cap]
            diff_df[f"value_{name_b}"]    = b_match[col][diff_mask].values[:cap]
            changed_all.append(diff_df)

    summary_df = (pd.DataFrame(summary_rows)
                  .sort_values("different", ascending=False)
                  .reset_index(drop=True))
    changed_df = (pd.concat(changed_all, ignore_index=True)
                  if changed_all else pd.DataFrame())

    dup_key_note = ""
    if key_cols and not keys_are_unique:
        dup_key_note = (
            "ℹ️ **Non-unique keys detected** — rows were matched using a within-key occurrence "
            "counter to avoid false sort-order mismatches (e.g. FOLDERSEQ / FOLDERNAME). "
            "Only rows present in both datasets at the same key+occurrence position are compared."
        )

    return {
        "summary":        summary_df,
        "added_rows":     added_rows.reset_index(drop=True),
        "removed_rows":   removed_rows.reset_index(drop=True),
        "changed_values": changed_df,
        "n_common_rows":  min_len,
        "n_added":        len(added_rows),
        "n_removed":      len(removed_rows),
        "n_vars_changed": int(summary_df["different"].gt(0).sum()) if not summary_df.empty else 0,
        "key_cols_used":  key_cols,
        "dup_key_note":   dup_key_note,
    }


def _empty_value_result() -> Dict:
    return {
        "summary": pd.DataFrame(),
        "added_rows": pd.DataFrame(),
        "removed_rows": pd.DataFrame(),
        "changed_values": pd.DataFrame(),
        "n_common_rows": 0, "n_added": 0,
        "n_removed": 0, "n_vars_changed": 0,
        "key_cols_used": [],
        "dup_key_note": "",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Multi-dataset comparison
# ─────────────────────────────────────────────────────────────────────────────

def compare_all_datasets(
    store_a: Dict[str, Tuple[str, bytes]],  # {stem: (fname, bytes)}
    store_b: Dict[str, Tuple[str, bytes]],
    key_cols: Optional[List[str]] = None,
    run_values: bool = True,
    progress_cb=None,
) -> Tuple[Dict[str, Dict], pd.DataFrame, List[str], List[str]]:
    """
    Compare all matched dataset pairs between store_a and store_b.

    Returns:
      all_results   — {ds_name: {meta_diff, value_results, shape_a, shape_b, ...}}
      cross_summary — DataFrame summarising all datasets
      only_in_a     — dataset names only in store_a
      only_in_b     — dataset names only in store_b
    """
    names_a   = set(store_a.keys())
    names_b   = set(store_b.keys())
    matched   = sorted(names_a & names_b)
    only_in_a = sorted(names_a - names_b)
    only_in_b = sorted(names_b - names_a)

    all_results   = {}
    summary_rows  = []
    total = len(matched)

    for i, ds_name in enumerate(matched):
        fname_a, bytes_a = store_a[ds_name]
        fname_b, bytes_b = store_b[ds_name]

        try:
            df_a, meta_a = _load_sas_with_meta(bytes_a, fname_a)
            df_b, meta_b = _load_sas_with_meta(bytes_b, fname_b)
        except Exception as exc:
            all_results[ds_name] = {"error": str(exc)}
            summary_rows.append({"dataset": ds_name, "status": f"LOAD ERROR: {exc}",
                                   "rows_A": 0, "cols_A": 0, "rows_B": 0, "cols_B": 0})
            if progress_cb: progress_cb(i+1, total)
            continue

        meta_diff    = compare_metadata(df_a, "A", df_b, "B", meta_a, meta_b)
        value_result = compare_values(df_a, "A", df_b, "B", key_cols=key_cols) \
                       if run_values else _empty_value_result()

        all_results[ds_name] = {
            "meta_diff":     meta_diff,
            "value_results": value_result,
            "shape_a":       df_a.shape,
            "shape_b":       df_b.shape,
            "meta_a":        meta_a,
            "meta_b":        meta_b,
        }

        n_changed_meta = int((~meta_diff["status"].isin(["SAME"])).sum()) if not meta_diff.empty else 0
        summary_rows.append({
            "dataset":         ds_name,
            "status":          "COMPARED",
            "rows_A":          df_a.shape[0],
            "cols_A":          df_a.shape[1],
            "rows_B":          df_b.shape[0],
            "cols_B":          df_b.shape[1],
            "row_diff":        df_b.shape[0] - df_a.shape[0],
            "col_diff":        df_b.shape[1] - df_a.shape[1],
            "meta_changes":    n_changed_meta,
            "only_in_A":       int((meta_diff["status"]=="ONLY_IN_A").sum()) if not meta_diff.empty else 0,
            "only_in_B":       int((meta_diff["status"]=="ONLY_IN_B").sum()) if not meta_diff.empty else 0,
            "label_changes":   int(meta_diff["label_changed"].eq("YES").sum()) if not meta_diff.empty else 0,
            "dtype_changes":   int(meta_diff["dtype_changed"].eq("YES").sum()) if not meta_diff.empty else 0,
            "length_changes":  int(meta_diff["length_changed"].eq("YES").sum()) if not meta_diff.empty else 0,
            "format_changes":  int(meta_diff["format_changed"].eq("YES").sum()) if not meta_diff.empty else 0,
            "rows_added":      value_result.get("n_added", 0),
            "rows_removed":    value_result.get("n_removed", 0),
            "vars_with_diffs": value_result.get("n_vars_changed", 0),
            "key_cols":        ", ".join(value_result.get("key_cols_used", [])),
        })

        if progress_cb:
            progress_cb(i + 1, total)

    cross_summary = pd.DataFrame(summary_rows)
    return all_results, cross_summary, only_in_a, only_in_b


# ─────────────────────────────────────────────────────────────────────────────
# Excel export
# ─────────────────────────────────────────────────────────────────────────────

def export_comparison_report(
    meta_diff: pd.DataFrame,
    value_results: Dict,
    name_a: str,
    name_b: str,
    ds_name: str = "",
) -> bytes:
    """Export single-dataset comparison report to xlsx."""
    import xlsxwriter

    buf = io.BytesIO()
    with xlsxwriter.Workbook(buf, {"in_memory": True, "strings_to_urls": False}) as wb:
        fmts = _xl_formats(wb)

        # Summary
        ws0 = wb.add_worksheet("Summary")
        _xl_summary(ws0, fmts, meta_diff, value_results, name_a, name_b, ds_name)

        # Metadata diff (with labels)
        ws1 = wb.add_worksheet("Metadata_Diff")
        _xl_write(ws1, fmts, meta_diff,
                  row_fmt=lambda r: _meta_fmt(r, name_a, name_b, fmts))

        # Value summary
        ws2 = wb.add_worksheet("Value_Summary")
        _xl_write(ws2, fmts, value_results.get("summary", pd.DataFrame()),
                  row_fmt=lambda r: fmts["diff"] if int(r.get("different",0))>0 else fmts["pass"])

        # Changed values detail
        ws3 = wb.add_worksheet("Changed_Values")
        _xl_write(ws3, fmts, value_results.get("changed_values", pd.DataFrame()),
                  row_fmt=lambda r: fmts["diff"])

        # Added / removed rows
        ws4 = wb.add_worksheet("Added_Rows")
        _xl_write(ws4, fmts, value_results.get("added_rows", pd.DataFrame()),
                  row_fmt=lambda r: fmts["only_b"])

        ws5 = wb.add_worksheet("Removed_Rows")
        _xl_write(ws5, fmts, value_results.get("removed_rows", pd.DataFrame()),
                  row_fmt=lambda r: fmts["only_a"])

    buf.seek(0)
    return buf.read()


def export_multi_comparison_report(
    all_results: Dict[str, Dict],
    cross_summary: pd.DataFrame,
    only_in_a: List[str],
    only_in_b: List[str],
    name_a: str = "A",
    name_b: str = "B",
) -> bytes:
    """Export multi-dataset comparison report to a single xlsx with one sheet per dataset."""
    import xlsxwriter

    buf = io.BytesIO()
    with xlsxwriter.Workbook(buf, {"in_memory": True, "strings_to_urls": False}) as wb:
        fmts = _xl_formats(wb)

        # Cross-dataset summary
        ws_cross = wb.add_worksheet("SUMMARY_ALL")
        _xl_write(ws_cross, fmts, cross_summary,
                  row_fmt=lambda r: fmts["diff"] if str(r.get("status",""))!="COMPARED" else fmts["norm"])

        # Unmatched datasets
        ws_unmatched = wb.add_worksheet("Unmatched")
        rows_unm = ([{"dataset":d,"side":"Only in A"} for d in only_in_a] +
                    [{"dataset":d,"side":"Only in B"} for d in only_in_b])
        _xl_write(ws_unmatched, fmts, pd.DataFrame(rows_unm) if rows_unm else pd.DataFrame())

        # Per-dataset sheets
        for ds_name, result in all_results.items():
            if "error" in result:
                ws = wb.add_worksheet(f"{ds_name[:25]}_ERR")
                ws.write(0, 0, f"Error loading {ds_name}: {result['error']}", fmts["diff"])
                continue

            meta_diff    = result.get("meta_diff", pd.DataFrame())
            value_result = result.get("value_results", {})
            safe_name    = ds_name[:25]  # Excel sheet name limit

            # Meta diff sheet per dataset
            ws_m = wb.add_worksheet(f"{safe_name}_META")
            _xl_write(ws_m, fmts, meta_diff,
                      row_fmt=lambda r, na=name_a, nb=name_b: _meta_fmt(r, na, nb, fmts))

            # Value summary per dataset
            ws_v = wb.add_worksheet(f"{safe_name}_VAL")
            _xl_write(ws_v, fmts, value_result.get("summary", pd.DataFrame()),
                      row_fmt=lambda r: fmts["diff"] if int(r.get("different",0))>0 else fmts["pass"])

            # Changed values detail
            chg = value_result.get("changed_values", pd.DataFrame())
            if chg is not None and not chg.empty:
                ws_c = wb.add_worksheet(f"{safe_name}_CHG")
                _xl_write(ws_c, fmts, chg, row_fmt=lambda r: fmts["diff"])

    buf.seek(0)
    return buf.read()


# ─────────────────────────────────────────────────────────────────────────────
# Excel helpers
# ─────────────────────────────────────────────────────────────────────────────

def _xl_formats(wb) -> Dict:
    common = {"border": 1, "text_wrap": True, "valign": "top", "font_size": 10}
    return {
        "hdr":    wb.add_format({**common, "bold": True, "bg_color": "#1E3A5F",
                                  "font_color": "#FFFFFF", "valign": "vcenter"}),
        "norm":   wb.add_format({**common}),
        "alt":    wb.add_format({**common, "bg_color": "#F5F8FA"}),
        "pass":   wb.add_format({**common, "bg_color": "#D4F5DC"}),
        "diff":   wb.add_format({**common, "bg_color": "#FFD0D0"}),
        "warn":   wb.add_format({**common, "bg_color": "#FFF3CC"}),
        "only_a": wb.add_format({**common, "bg_color": "#FFF3CC"}),
        "only_b": wb.add_format({**common, "bg_color": "#D0E8FF"}),
        "title":  wb.add_format({"bold": True, "font_size": 13, "font_color": "#1E3A5F"}),
    }


def _xl_write(ws, fmts, df: pd.DataFrame, row_fmt=None):
    if df is None or df.empty:
        ws.write(0, 0, "(no data)", fmts["norm"])
        return
    cols = list(df.columns)
    ws.set_row(0, 20)
    ws.freeze_panes(1, 0)
    ws.autofilter(0, 0, len(df), len(cols) - 1)
    for ci, col in enumerate(cols):
        w = min(max(len(col) + 2, 10), 45)
        ws.set_column(ci, ci, w)
        ws.write(0, ci, col.replace("_", " ").title(), fmts["hdr"])
    for ri, (_, row) in enumerate(df.iterrows(), 1):
        fmt = row_fmt(row.to_dict()) if row_fmt else (fmts["alt"] if ri % 2 == 0 else fmts["norm"])
        for ci, col in enumerate(cols):
            v = row.get(col, "")
            if v is None or (isinstance(v, float) and v != v):
                v = ""
            try:
                ws.write(ri, ci, str(v)[:32767], fmt)
            except Exception:
                ws.write(ri, ci, "", fmt)


def _meta_fmt(row, name_a, name_b, fmts):
    s = str(row.get("status", ""))
    if s == "ONLY_IN_A":    return fmts["only_a"]
    if s == "ONLY_IN_B":    return fmts["only_b"]
    if s.startswith("CHANGED"): return fmts["diff"]
    return fmts["pass"]


def _xl_summary(ws, fmts, meta_diff, value_results, name_a, name_b, ds_name):
    ws.set_column(0, 0, 40)
    ws.set_column(1, 1, 20)
    ws.write(0, 0, f"Dataset Comparison: {ds_name}  ({name_a} vs {name_b})", fmts["title"])
    info = [
        ("Dataset A", name_a),
        ("Dataset B", name_b),
        ("Variables same", int((meta_diff["status"] == "SAME").sum()) if not meta_diff.empty else 0),
        ("Variables only in A", int((meta_diff["status"] == "ONLY_IN_A").sum()) if not meta_diff.empty else 0),
        ("Variables only in B", int((meta_diff["status"] == "ONLY_IN_B").sum()) if not meta_diff.empty else 0),
        ("Label changes", int(meta_diff["label_changed"].eq("YES").sum()) if not meta_diff.empty else 0),
        ("Dtype changes", int(meta_diff["dtype_changed"].eq("YES").sum()) if not meta_diff.empty else 0),
        ("Length changes", int(meta_diff["length_changed"].eq("YES").sum()) if not meta_diff.empty else 0),
        ("Format changes", int(meta_diff["format_changed"].eq("YES").sum()) if not meta_diff.empty else 0),
        ("Rows added (in B not A)", value_results.get("n_added", 0)),
        ("Rows removed (in A not B)", value_results.get("n_removed", 0)),
        ("Common rows compared", value_results.get("n_common_rows", 0)),
        ("Variables with value diffs", value_results.get("n_vars_changed", 0)),
        ("Key columns used", ", ".join(value_results.get("key_cols_used", []))),
    ]
    for ri, (k, v) in enumerate(info, 2):
        ws.write(ri, 0, k, fmts["norm"])
        ws.write(ri, 1, str(v), fmts["norm"])
