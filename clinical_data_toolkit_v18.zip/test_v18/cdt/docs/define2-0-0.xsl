<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:odm="http://www.cdisc.org/ns/odm/v1.3"
  xmlns:def="http://www.cdisc.org/ns/def/v2.1">
<xsl:output method="html" encoding="UTF-8" indent="yes"/>

<xsl:template match="/">
<html>
<head>
  <meta charset="UTF-8"/>
  <title>Define-XML v2.1</title>
  <style>
    body{font-family:Segoe UI,Arial,sans-serif;background:#0f172a;color:#e2e8f0;margin:0;padding:16px}
    h1{color:#60a5fa;font-size:1.4rem;margin:0 0 8px}
    h2{color:#94a3b8;font-size:1rem;margin:16px 0 6px;padding-bottom:4px;border-bottom:1px solid #334155}
    h3{color:#cbd5e1;font-size:.9rem;margin:12px 0 4px}
    table{width:100%;border-collapse:collapse;font-size:12px;margin-bottom:12px}
    th{background:#1e3a5f;color:#93c5fd;padding:6px 8px;text-align:left;font-size:11px;
       letter-spacing:.04em;text-transform:uppercase}
    td{padding:5px 8px;border-bottom:1px solid #1e293b;vertical-align:top}
    tr:nth-child(even) td{background:#111827}
    .tag{color:#86efac;font-weight:600}
    .oid{color:#fbbf24;font-size:11px}
    .lbl{color:#93c5fd}
    .pass{color:#4ade80}
    .miss{color:#f87171}
    .card{background:#1e293b;border:1px solid #334155;border-radius:6px;padding:12px;margin:8px 0}
    .nav{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap}
    .nav a{background:#1e293b;color:#93c5fd;padding:6px 14px;border-radius:20px;
           text-decoration:none;font-size:12px;border:1px solid #334155}
    .nav a:hover{background:#1e3a5f}
    summary{cursor:pointer;color:#60a5fa;font-weight:600;padding:4px 0}
    details{margin:4px 0}
  </style>
</head>
<body>
<h1>Define-XML v2.1 — <xsl:value-of select="//odm:Study/odm:GlobalVariables/odm:StudyName"/></h1>
<div class="nav">
  <a href="#datasets">Datasets</a>
  <a href="#variables">Variables</a>
  <a href="#codelists">Codelists</a>
  <a href="#valuelist">Value Lists</a>
  <a href="#whereclause">Where Clauses</a>
</div>

<!-- Study Info -->
<div class="card">
  <b>Study:</b> <xsl:value-of select="//odm:Study/odm:GlobalVariables/odm:StudyName"/><br/>
  <b>Standard:</b> <xsl:value-of select="//odm:MetaDataVersion/@def:StandardName"/>
  v<xsl:value-of select="//odm:MetaDataVersion/@def:StandardVersion"/><br/>
  <b>Define Version:</b> <xsl:value-of select="//odm:MetaDataVersion/@def:DefineVersion"/><br/>
  <b>Created:</b> <xsl:value-of select="//@CreationDateTime"/>
</div>

<!-- Datasets -->
<h2 id="datasets">Datasets</h2>
<table>
  <tr><th>Domain</th><th>Structure</th><th>Variables</th></tr>
  <xsl:for-each select="//odm:ItemGroupDef">
    <tr>
      <td class="tag"><xsl:value-of select="@Name"/></td>
      <td><xsl:value-of select="@def:Structure"/></td>
      <td><xsl:value-of select="count(odm:ItemRef)"/></td>
    </tr>
  </xsl:for-each>
</table>

<!-- Variables (first 200 for performance) -->
<h2 id="variables">Variables</h2>
<table>
  <tr><th>Domain</th><th>Variable</th><th>Label</th><th>Type</th><th>Length</th><th>Codelist</th></tr>
  <xsl:for-each select="//odm:ItemDef[position() &lt;= 500]">
    <tr>
      <td class="oid"><xsl:value-of select="substring-before(substring-after(@OID,'IT.'),'.')"/></td>
      <td class="tag"><xsl:value-of select="@Name"/></td>
      <td class="lbl"><xsl:value-of select="@def:Label"/></td>
      <td><xsl:value-of select="@DataType"/></td>
      <td><xsl:value-of select="@Length"/></td>
      <td><xsl:if test="odm:CodeListRef"><xsl:value-of select="substring-after(odm:CodeListRef/@CodeListOID,'CL.')"/></xsl:if></td>
    </tr>
  </xsl:for-each>
</table>

<!-- Codelists -->
<h2 id="codelists">Codelists</h2>
<xsl:for-each select="//odm:CodeList">
  <details>
    <summary><span class="tag"><xsl:value-of select="@Name"/></span>
      — <xsl:value-of select="count(odm:EnumeratedItem)"/> terms
      <xsl:if test="@def:ExtendedValue='Yes'"> (extensible)</xsl:if>
    </summary>
    <table>
      <tr><th>Code</th><th>Decode</th></tr>
      <xsl:for-each select="odm:EnumeratedItem">
        <tr>
          <td><xsl:value-of select="@CodedValue"/></td>
          <td><xsl:value-of select="odm:Decode/odm:TranslatedText"/></td>
        </tr>
      </xsl:for-each>
    </table>
  </details>
</xsl:for-each>

<!-- Value Lists -->
<h2 id="valuelist">Value-Level Metadata</h2>
<xsl:for-each select="//odm:def:ValueListDef">
  <div class="card">
    <b class="oid"><xsl:value-of select="@OID"/></b>
    — <xsl:value-of select="count(odm:ItemRef)"/> entries
  </div>
</xsl:for-each>

<!-- Where Clauses -->
<h2 id="whereclause">Where Clauses</h2>
<table>
  <tr><th>OID</th><th>Variable</th><th>Comparator</th><th>Value</th></tr>
  <xsl:for-each select="//odm:def:WhereClauseDef">
    <tr>
      <td class="oid"><xsl:value-of select="@OID"/></td>
      <td><xsl:value-of select="odm:RangeCheck/@def:ItemOID"/></td>
      <td><xsl:value-of select="odm:RangeCheck/@Comparator"/></td>
      <td class="pass"><xsl:value-of select="odm:RangeCheck/odm:CheckValue"/></td>
    </tr>
  </xsl:for-each>
</table>

</body>
</html>
</xsl:template>
</xsl:stylesheet>
