# pages/4_Date_Imputer.py  — v9: processes ALL uploaded AE datasets at once
import sys, warnings, io
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime, date
import pandas as pd
import numpy as np
import streamlit as st

from config.theme import get_palette, build_css, C as C_default
from core.date_imputer import impute_ae_dates, build_imputation_summary, RULE_LABELS

st.set_page_config(page_title="Date Imputer", layout="wide")

theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True, key="imp_theme")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)
st.markdown(f"""
<style>
.imp-table{{width:100%;border-collapse:collapse;font-size:12px;
           font-family:'Courier New',monospace;color:{C['text_main']}}}
.imp-table th{{background:{C['hdr_bg']};color:{C['hdr_fg']};padding:7px 10px;
              text-align:left;font-size:10px;font-weight:700;
              text-transform:uppercase;position:sticky;top:0;z-index:2;
              border-bottom:2px solid {C['border']}}}
.imp-table td{{padding:5px 10px;border-bottom:1px solid {C['border']};white-space:nowrap}}
.imp-table tr.pass td{{background:{C['pass_bg']};color:{C['pass_fg']}}}
.imp-table tr.part td{{background:{C['warn_bg']};color:{C['warn_fg']}}}
.imp-table tr.miss td{{background:{C['miss_bg']};color:{C['miss_fg']}}}
.imp-table tr.dt   td{{background:{C['dt_bg']};color:{C['dt_fg']}}}
.imp-table tr.even td{{background:{C['row_alt']}}}
.imp-table tr:hover td{{filter:brightness(1.1)}}
.imp-scroll{{max-height:450px;overflow:auto;
            border:1px solid {C['border']};border-radius:8px}}
</style>
""", unsafe_allow_html=True)

st.title("AE Date Imputer")
st.caption("Imputes partial/missing AE dates across ALL uploaded AE datasets. ADSL merged automatically.")

SAS_EP = pd.Timestamp("1960-01-01")

def _conv_sas_date(v):
    if pd.isna(v): return pd.NaT
    if isinstance(v, (pd.Timestamp, datetime, date)): return pd.Timestamp(v)
    s = str(v).strip()
    if "-" in s or "/" in s:
        try: return pd.Timestamp(s)
        except: pass
    try:
        n = float(s)
        if -5000 <= n <= 50000:
            return SAS_EP + pd.Timedelta(days=int(n))
    except: pass
    return pd.NaT

@st.cache_data(show_spinner=False)
def _load_df(fdata: bytes, fname: str) -> pd.DataFrame:
    if fname.lower().endswith(".sas7bdat"):
        try:
            import pyreadstat
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                df, _ = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
            df.columns = [c.upper() for c in df.columns]
            return df
        except Exception:
            pass
        try:
            df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
            df.columns = [c.upper() for c in df.columns]
            return df
        except Exception as exc:
            raise ValueError(f"Cannot read {fname}: {exc}")
    df = pd.read_csv(io.BytesIO(fdata))
    df.columns = [c.upper() for c in df.columns]
    return df

# ── Run toggle ─────────────────────────────────────────────────────────────
run_imp = st.toggle("Enable imputation", value=True)
st.divider()

# ── Check for uploaded files ───────────────────────────────────────────────
ae_store   = st.session_state.get("ae_files_store", {})
adsl_bytes = st.session_state.get("adsl_file_bytes")
adsl_name  = st.session_state.get("adsl_file_name","")

if not ae_store:
    st.warning("Upload AE/ADAE dataset(s) in the sidebar first."); st.stop()

ae_names = sorted(ae_store.keys())
st.info(f"**{len(ae_names)} AE dataset(s):** {', '.join(Path(n).stem.upper() for n in ae_names)}"
        + (f"  |  ADSL: **{adsl_name}**" if adsl_bytes else ""))

# ── Column configuration ───────────────────────────────────────────────────
col1, col2 = st.columns([2,1])
with col1:
    if len(ae_names) > 1:
        selected_ae = st.selectbox("Preview dataset", ae_names,
            help="Column config applies to all datasets. Preview shows the selected one.")
    else:
        selected_ae = ae_names[0]
with col2:
    startc = st.text_input("Start DTC",       value="AESTDTC")
    stopc  = st.text_input("Stop DTC",         value="AEENDTC")
    trtsdt = st.text_input("First dose date",  value="TRTSDT")
    prefix = st.text_input("Output prefix",    value="AE")
    skip_dt= st.checkbox("Pass datetime strings through", value=True)
    is_adae= st.checkbox("Input is ADAE (comparison mode)", value=False)

# ── Load ADSL once ─────────────────────────────────────────────────────────
adsl_df = None
if adsl_bytes:
    try:
        adsl_df = _load_df(adsl_bytes, adsl_name)
        st.success(f"ADSL loaded: {len(adsl_df):,} rows")
    except Exception as exc:
        st.warning(f"Cannot load ADSL: {exc}")

# ── Preview ────────────────────────────────────────────────────────────────
with st.expander("Input preview (first 10 rows of selected dataset)", expanded=False):
    try:
        prev_df = _load_df(ae_store[selected_ae], selected_ae)
        id_c  = [c for c in ["USUBJID","SUBJID","AESEQ"] if c in prev_df.columns]
        prev  = [c for c in [startc,stopc,trtsdt] if c in prev_df.columns]
        st.dataframe(prev_df[id_c+prev].head(10), use_container_width=True)
    except Exception as exc:
        st.warning(f"Preview error: {exc}")

st.divider()

btn_lbl = "Run Imputation on All Datasets" if run_imp else "Parse Dates Only (All Datasets)"
if st.button(btn_lbl, type="primary", use_container_width=True):
    all_results = {}
    progress    = st.progress(0)
    errors      = []

    for i, fname in enumerate(ae_names):
        ds_name = Path(fname).stem.upper()
        try:
            ae_df = _load_df(ae_store[fname], fname)

            # Merge TRTSDT from ADSL if needed
            if trtsdt not in ae_df.columns and adsl_df is not None:
                merge_cols = [c for c in ["USUBJID", trtsdt, "TRTSDTM"] if c in adsl_df.columns]
                if "USUBJID" in adsl_df.columns and trtsdt in adsl_df.columns:
                    ae_df = ae_df.merge(
                        adsl_df[merge_cols].drop_duplicates("USUBJID"),
                        on="USUBJID", how="left")

            # Check required columns
            missing = [c for c in [startc, stopc] if c not in ae_df.columns]
            if missing:
                errors.append(f"{ds_name}: columns not found: {missing}")
                continue
            if trtsdt not in ae_df.columns:
                errors.append(f"{ds_name}: '{trtsdt}' not found — skipped. Upload ADSL.")
                continue

            ae_df[trtsdt] = ae_df[trtsdt].apply(_conv_sas_date)

            result = impute_ae_dates(ae_df, startc=startc, stopc=stopc,
                                     trtsdt=trtsdt, prefix=prefix, skip_if_has_time=skip_dt)
            if not run_imp:
                rc_col = f"{prefix}_START_RULE"
                if rc_col in result.columns:
                    result[rc_col] = result[rc_col].apply(lambda r: r if r in(-1,0) else np.nan)

            all_results[ds_name] = {"result": result, "orig": ae_df, "fname": fname}
        except Exception as exc:
            errors.append(f"{ds_name}: {type(exc).__name__}: {exc}")

        progress.progress(int((i+1)/len(ae_names)*100))

    if errors:
        for e in errors: st.warning(e)

    st.session_state.update({
        "imputer_all_results": all_results,
        "imputer_prefix":      prefix,
        "imputer_startc":      startc,
        "imputer_stopc":       stopc,
        "imputer_trtsdt":      trtsdt,
        "imputer_is_adae":     is_adae,
    })
    progress.progress(100)

if "imputer_all_results" not in st.session_state:
    st.info("Click the button above to process."); st.stop()

all_results = st.session_state["imputer_all_results"]
p       = st.session_state.get("imputer_prefix","AE")
startc  = st.session_state.get("imputer_startc","AESTDTC")
stopc   = st.session_state.get("imputer_stopc","AEENDTC")
trtsdt  = st.session_state.get("imputer_trtsdt","TRTSDT")
is_adae = st.session_state.get("imputer_is_adae",False)

if not all_results:
    st.error("No datasets were successfully imputed."); st.stop()

# ── Dataset selector ──────────────────────────────────────────────────────
ds_names_done = sorted(all_results.keys())
if len(ds_names_done) > 1:
    sel_ds = st.selectbox("View results for dataset:", ds_names_done)
else:
    sel_ds = ds_names_done[0]

curr   = all_results[sel_ds]
result = curr["result"]
ae_orig= curr["orig"]
rc_col = f"{p}_START_RULE"

# ── Summary ───────────────────────────────────────────────────────────────
rsumm = build_imputation_summary(result, prefix=p)
st.subheader(f"Imputation Summary — {sel_ds} ({len(result):,} rows)")
items = [(l,c) for l,c in rsumm.items() if c>0]
if items:
    scols = st.columns(min(len(items),4))
    for sc,(lbl,cnt) in zip(scols,items):
        sc.metric(lbl[:38]+"..." if len(lbl)>38 else lbl, cnt)

# Cross-dataset summary if multiple
if len(ds_names_done) > 1:
    with st.expander("Summary across all datasets", expanded=False):
        summ_rows = []
        for ds, r in all_results.items():
            res = r["result"]
            rc  = f"{p}_START_RULE"
            summ_rows.append({
                "dataset": ds,
                "total_rows": len(res),
                "rule_m1 (datetime)": int((res[rc]==-1).sum()) if rc in res.columns else 0,
                "rule_0 (full)":      int((res[rc]==0).sum())  if rc in res.columns else 0,
                "rule_1_2 (partial)": int(res[rc].isin([1,2]).sum()) if rc in res.columns else 0,
                "rule_3_5 (missing)": int(res[rc].isin([3,4,5]).sum()) if rc in res.columns else 0,
            })
        st.dataframe(pd.DataFrame(summ_rows), use_container_width=True)

st.markdown(
    f'<div class="legend-row">'
    f'<span class="legend-chip" style="background:{C["dt_bg"]};color:{C["dt_fg"]};border:1px solid {C["dt_fg"]}33;">Blue = datetime passthrough</span>'
    f'<span class="legend-chip" style="background:{C["pass_bg"]};color:{C["pass_fg"]};border:1px solid {C["pass_fg"]}33;">Green = full date</span>'
    f'<span class="legend-chip" style="background:{C["warn_bg"]};color:{C["warn_fg"]};border:1px solid {C["warn_fg"]}33;">Amber = partial imputed</span>'
    f'<span class="legend-chip" style="background:{C["miss_bg"]};color:{C["miss_fg"]};border:1px solid {C["miss_fg"]}33;">Red = missing imputed</span>'
    f'</div>', unsafe_allow_html=True
)
st.divider()

# ── Output columns ────────────────────────────────────────────────────────
id_disp   = [c for c in ["USUBJID","SUBJID","AESEQ"] if c in result.columns]
inp_cols  = [c for c in [startc,stopc,trtsdt] if c in result.columns]
start_out = [c for c in ["ASTDT","ASTDTC","ASTDTF","ASTTM","ASTDTM"] if c in result.columns]
stop_out  = [c for c in ["AENDT","AENDTC","AENDTF","AENTM","AENDTM"] if c in result.columns]
flag_cols = [c for c in [f"{p}_START_RULE",f"{p}_STOP_IMPFL",
                          f"{p}_STOP_ONGOING",f"{p}_REL_STOP_TO_TRT"] if c in result.columns]
all_out   = id_disp + inp_cols + start_out + stop_out + flag_cols
if rc_col in result.columns:
    result["_rule_label"] = result[rc_col].map(RULE_LABELS).fillna("")
    all_out.append("_rule_label")
all_out = [c for c in all_out if c in result.columns]

def _row_cls(rv):
    try:    r=float(rv) if pd.notna(rv) else 0
    except: r=0
    if r==-1: return "dt"
    if r==0:  return "pass"
    if r in(1.,2.): return "part"
    return "miss"

def _fmt_val(v) -> str:
    if v is None or (isinstance(v,float) and v!=v): return ""
    if isinstance(v,pd.Timestamp):
        return v.strftime("%Y-%m-%d %H:%M") if (v.hour or v.minute) else v.strftime("%Y-%m-%d")
    return str(v)

def _render_imp(df, max_rows=500):
    cols   = [c for c in all_out if c in df.columns]
    hdr    = "".join(f"<th>{c}</th>" for c in cols)
    rows_h = []
    for i,(_,row) in enumerate(df.head(max_rows).iterrows()):
        rv  = row.get(rc_col, np.nan)
        cls = _row_cls(rv)
        if cls=="pass" and i%2==0: cls="even"
        cells = "".join(f"<td>{_fmt_val(row.get(c,''))}</td>" for c in cols)
        rows_h.append(f'<tr class="{cls}">{cells}</tr>')
    if len(df)>max_rows:
        rows_h.append(f'<tr><td colspan="{len(cols)}" style="text-align:center;color:{C["text_muted"]};padding:8px;">'
                       f'… {len(df)-max_rows:,} more rows in download</td></tr>')
    return (f'<div class="imp-scroll"><table class="imp-table">'
            f'<thead><tr>{hdr}</tr></thead><tbody>{"".join(rows_h)}</tbody></table></div>')

# ── Result tabs ───────────────────────────────────────────────────────────
imp_only = result[result[rc_col].notna() & (~result[rc_col].isin([0,-1]))] if rc_col in result.columns else result.head(0)
tab_labels = [f"All ({len(result):,})", f"Imputed Only ({len(imp_only):,})"]
if is_adae: tab_labels.append("ADAE Comparison")
tabs = st.tabs(tab_labels)

with tabs[0]:
    st.markdown(_render_imp(result), unsafe_allow_html=True)

with tabs[1]:
    if imp_only.empty:
        st.success("No records required imputation — all dates were complete.")
    else:
        st.markdown(_render_imp(imp_only), unsafe_allow_html=True)

if is_adae and len(tabs) > 2:
    with tabs[2]:
        existing = [c for c in ["ASTDT","ASTDTC","ASTDTF","AENDT","AENDTC","AENDTF"] if c in ae_orig.columns]
        if not existing:
            st.info("No existing ASTDT/AENDT columns found in the input.")
        else:
            comp_rows = []
            for col in existing:
                if col not in result.columns or col not in ae_orig.columns: continue
                orig_s  = ae_orig[col].apply(lambda v:
                    _conv_sas_date(v).strftime("%Y-%m-%d") if pd.notna(_conv_sas_date(v)) else ""
                    if not isinstance(v,str) else str(v).strip())
                new_s   = result[col].apply(_fmt_val)
                mm      = orig_s != new_s
                comp_rows.append({"Variable":col,"Matches":int((~mm).sum()),
                                   "Differences":int(mm.sum()),"Total":len(orig_s)})
            st.dataframe(pd.DataFrame(comp_rows), use_container_width=True)

# ── Downloads ─────────────────────────────────────────────────────────────
st.divider()

def _prep_csv(df):
    out = df[all_out].copy()
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = out[col].dt.strftime("%Y-%m-%dT%H:%M:%S").fillna("")
    return out.to_csv(index=False).encode("utf-8")

col_d1, col_d2, col_d3 = st.columns(3)
with col_d1:
    st.download_button("⬇ Download Selected Dataset (.csv)", data=_prep_csv(result),
        file_name=f"{sel_ds}_imputed_{datetime.now():%Y%m%d_%H%M}.csv",
        mime="text/csv", use_container_width=True)

with col_d2:
    if not imp_only.empty:
        st.download_button("⬇ Imputed Only (.csv)", data=_prep_csv(imp_only),
            file_name=f"{sel_ds}_imputed_only_{datetime.now():%Y%m%d_%H%M}.csv",
            mime="text/csv", use_container_width=True)

with col_d3:
    if len(all_results) > 1:
        combined = []
        for ds, r in all_results.items():
            tmp = r["result"][all_out].copy()
            tmp.insert(0, "_dataset", ds)
            for col in tmp.columns:
                if pd.api.types.is_datetime64_any_dtype(tmp[col]):
                    tmp[col] = tmp[col].dt.strftime("%Y-%m-%dT%H:%M:%S").fillna("")
            combined.append(tmp)
        combined_df = pd.concat(combined, ignore_index=True)
        st.download_button("⬇ Download ALL Datasets Combined (.csv)",
            data=combined_df.to_csv(index=False).encode("utf-8"),
            file_name=f"AE_imputed_all_{datetime.now():%Y%m%d_%H%M}.csv",
            mime="text/csv", use_container_width=True)
