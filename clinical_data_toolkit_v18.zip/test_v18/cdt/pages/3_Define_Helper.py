# pages/3_Define_Helper.py  v18
"""
FIX v18:
  - BUG: `columns_df or None` raises ValueError for DataFrame — fixed to
    `None if columns_df.empty else columns_df`
  - Value-level errors now shown as prominent st.warning (not collapsed expander)
  - Explicit per-file load-failure diagnostics surfaced in Value Level tab
  - Light/dark Plotly template driven by C['plotly_tpl']
  - Value Level tab: shows domain breakdown chart + improved empty-state guidance
  - Where Clause tab: shows full table with domain/variable filters
"""
import sys, warnings, io, traceback
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import (
    get_palette, build_css, render_table,
    render_kpi_cards, plotly_layout, status_colors, hex_to_rgba,
)
from core.define_helper import (
    get_column_metadata_from_store,
    get_value_level_from_store,
    build_where_clause_table,
    build_vlm_from_spec_and_data,
    compare_data_vs_codelist,
    generate_define_xml,
    _find_codelist_tab,
    _get_codelist_map_from_spec,
    _get_active_domains_from_toc,
    _supported_ext,
    _load_file,
)
from core.excel_export import export_define_results

st.set_page_config(page_title="Define Helper", layout="wide")
theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True, key="def_theme")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)

st.markdown(
    f'<div style="font-family:Space Grotesk,sans-serif;font-size:24px;font-weight:700;'
    f'letter-spacing:-.01em;color:{C["text_main"]};margin-bottom:2px;">📋 Define Helper</div>'
    f'<div style="font-size:12px;color:{C["text_muted"]};margin-bottom:16px;">'
    f'Variable metadata · VLM / CT comparison · Value Level · Where Clause · Define-XML v2.1</div>',
    unsafe_allow_html=True,
)

st.sidebar.markdown(
    "**Accepted formats:** `.sas7bdat` · `.xpt` · `.csv`\n\n"
    "Upload in the **main sidebar** above, or use the **in-page uploader** below."
)

# ── Get datasets ──────────────────────────────────────────────────────────────
sidebar_store = st.session_state.get("sdtm_files_store", {})
spec          = st.session_state.get("spec")
spec_name     = st.session_state.get("spec_name", "")

with st.expander("📂 Upload datasets directly here (.sas7bdat / .xpt / .csv)",
                 expanded=not sidebar_store):
    st.caption(
        "Use this uploader if your datasets did not load via the sidebar, "
        "or to upload files specifically for Define Helper."
    )
    inline_files = st.file_uploader(
        "Upload SDTM/ADaM datasets",
        type=["sas7bdat","xpt","csv"],
        accept_multiple_files=True,
        key="define_helper_inline_upload",
        help="Files uploaded here are merged with sidebar uploads.",
    )
    if inline_files:
        inline_store = {f.name: f.getvalue() for f in inline_files}
        st.success(f"✅ {len(inline_store)} file(s) ready from this uploader")
    else:
        inline_store = {}

sdtm_store = {**sidebar_store, **inline_store}

if not sdtm_store:
    st.warning("No datasets loaded. Upload SDTM/ADaM datasets in the sidebar or using the uploader above.")
    st.stop()

# ── Dataset info ──────────────────────────────────────────────────────────────
ds_names   = ", ".join(sorted(Path(k).stem.upper() for k in sdtm_store.keys()))
ext_counts: dict = {}
for k in sdtm_store:
    ext = Path(k).suffix.lower()
    ext_counts[ext] = ext_counts.get(ext, 0) + 1
ext_str = " · ".join(f"{v} {k}" for k, v in ext_counts.items())
st.info(f"**{len(sdtm_store)} dataset(s)** ({ext_str}): {ds_names[:220]}{'...' if len(ds_names)>220 else ''}")

# ── Spec status ───────────────────────────────────────────────────────────────
cl_tab = None; cl_map = {}; active_domains = []
if spec:
    cl_tab         = _find_codelist_tab(spec)
    cl_map         = _get_codelist_map_from_spec(spec)
    active_domains = _get_active_domains_from_toc(spec)
    cl_ok          = cl_tab is not None
    c1, c2 = st.columns(2)
    cl_msg = f"✅ Codelist tab found ({len(cl_tab):,} rows)" if cl_ok else "⚠️ Codelist tab NOT found"
    c1.info(f"**Spec:** {spec_name}  |  {cl_msg}")
    c2.info(f"**TOC active domains:** {len(active_domains)}  |  **Variables with codelist:** {len(cl_map)}")
else:
    st.warning("No mapping spec loaded. Upload spec in the sidebar for VLM and CT features.")

# ── Options ───────────────────────────────────────────────────────────────────
with st.expander("Options", expanded=False):
    col1, col2 = st.columns(2)
    with col1:
        mode     = st.radio("Mode", ["SDTM","ADaM"], horizontal=True,
                            help="SDTM: scans for TESTCD/QNAM columns. ADaM: scans for PARAMCD.")
        run_meta = st.checkbox("Extract variable metadata (PROC CONTENTS)", value=True)
        run_vlm  = st.checkbox("Build VLM from spec codelist column",
                               value=bool(spec and cl_tab is not None))
        run_ct   = st.checkbox("Run CT comparison (data vs codelist)",
                               value=bool(spec and cl_tab is not None))
    with col2:
        run_vl     = st.checkbox("Extract value-level (TESTCD/QNAM/PARAMCD)", value=True)
        run_xml    = st.checkbox("Generate Define-XML v2.1", value=False)
        study_name = st.text_input("Study name (for Define-XML)",
                                   value=spec_name.replace(".xlsx","").replace(".xls",""))
        st.caption("ℹ️ Value Level scans file headers directly — no metadata step required.")
        st.caption("ℹ️ Active=N in Codelist tab does NOT exclude CT values.")
        st.caption("ℹ️ MedDRA, WHODrug, result vars (--STRESC/ORRES) excluded from CT.")

# ── Generate ──────────────────────────────────────────────────────────────────
if st.button("Generate", type="primary", use_container_width=True):
    columns_df     = pd.DataFrame()
    vlm_df         = pd.DataFrame()
    ct_df          = pd.DataFrame()
    vl_df          = pd.DataFrame()
    wh_df          = pd.DataFrame()
    read_errors    = []
    vl_errors      = []
    define_xml_str = ""

    # Step 1 — Variable metadata
    if run_meta:
        with st.spinner("Extracting variable metadata..."):
            try:
                result     = get_column_metadata_from_store(sdtm_store)
                columns_df, read_errors = result if isinstance(result, tuple) else (result, [])
            except Exception as exc:
                read_errors = [f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"]
        if read_errors:
            with st.expander(f"⚠ {len(read_errors)} metadata issue(s)", expanded=False):
                for e in read_errors[:10]: st.code(str(e)[:500])

    # Step 2 — VLM
    if run_vlm and spec and cl_tab is not None:
        with st.spinner("Building VLM from spec codelist..."):
            try:
                vlm_df = build_vlm_from_spec_and_data(sdtm_store, spec)
            except Exception as exc:
                st.warning(f"VLM error: {type(exc).__name__}: {exc}")

    # Step 3 — CT comparison
    if run_ct and spec and cl_tab is not None:
        with st.spinner("Running CT comparison..."):
            try:
                ct_df = compare_data_vs_codelist(sdtm_store, spec)
            except Exception as exc:
                st.warning(f"CT error: {type(exc).__name__}: {exc}")

    # Step 4 — Value level
    # FIX: `columns_df or None` raises ValueError when columns_df is an empty DataFrame.
    # Correct test: `None if columns_df.empty else columns_df`
    if run_vl:
        with st.spinner("Extracting value-level (TESTCD/QNAM/PARAMCD)..."):
            try:
                cols_arg  = None if columns_df.empty else columns_df   # ← FIX
                result_vl = get_value_level_from_store(sdtm_store, cols_arg, mode)
                vl_df, vl_errors = result_vl if isinstance(result_vl, tuple) else (result_vl, [])
                if not vl_df.empty:
                    wh_df = build_where_clause_table(vl_df, mode)
            except Exception as exc:
                vl_errors = [f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"]

        # Surface errors prominently, not buried in collapsed expander
        if vl_errors:
            st.warning(
                f"⚠️ Value-level: {len(vl_errors)} file(s) had load issues. "
                f"See details below — other files were still processed."
            )
            with st.expander(f"Value-level load errors ({len(vl_errors)})", expanded=True):
                for e in vl_errors[:15]:
                    st.code(str(e)[:600])

    # Step 5 — Define-XML
    if run_xml:
        with st.spinner("Generating Define-XML v2.1..."):
            try:
                define_xml_str = generate_define_xml(
                    columns_df if not columns_df.empty else pd.DataFrame(),
                    vl_df      if not vl_df.empty      else pd.DataFrame(),
                    wh_df      if not wh_df.empty      else pd.DataFrame(),
                    spec       = spec,
                    study_name = study_name or "Study",
                )
            except Exception as exc:
                st.warning(f"Define-XML error: {type(exc).__name__}: {exc}")
                st.code(traceback.format_exc())

    st.session_state.update({
        "define_columns":      columns_df,
        "define_mode":         mode,
        "define_vlm":          vlm_df,
        "define_ct_compare":   ct_df,
        "define_value_level":  vl_df,
        "define_where_clause": wh_df,
        "define_xml":          define_xml_str,
        "define_meta_skipped": not run_meta,
        "define_meta_failed":  run_meta and columns_df.empty,
    })
    st.rerun()

# ── Guard: nothing generated yet ─────────────────────────────────────────────
if not any(k in st.session_state for k in (
        "define_columns","define_vlm","define_ct_compare","define_value_level")):
    st.info("Configure options above and click Generate.")
    st.stop()

columns_df   = st.session_state.get("define_columns",     pd.DataFrame())
vlm_df       = st.session_state.get("define_vlm",         pd.DataFrame())
ct_df        = st.session_state.get("define_ct_compare",  pd.DataFrame())
vl_df        = st.session_state.get("define_value_level", pd.DataFrame())
wh_df        = st.session_state.get("define_where_clause",pd.DataFrame())
mode         = st.session_state.get("define_mode",        "SDTM")
define_xml   = st.session_state.get("define_xml",         "")
meta_skipped = st.session_state.get("define_meta_skipped",False)
meta_failed  = st.session_state.get("define_meta_failed", False)

n_vars    = len(columns_df)
n_cl_vars = vlm_df["variable"].nunique() if not vlm_df.empty else 0
n_ct      = len(ct_df) if not ct_df.empty else 0
n_miss    = int((ct_df["status"]=="MISMATCH").sum())        if not ct_df.empty else 0
n_miss_v  = int(ct_df[ct_df["status"]=="MISMATCH"]["variable"].nunique()) if not ct_df.empty else 0
n_vl      = len(vl_df) if not vl_df.empty else 0
n_wh      = len(wh_df) if not wh_df.empty else 0

# ── KPI cards ─────────────────────────────────────────────────────────────────
kpi_metrics = [
    {"label": "Variables (metadata)", "value": f"{n_vars:,}",    "accent": 1, "sub": "PROC CONTENTS"},
    {"label": "VLM Vars (codelist)",  "value": f"{n_cl_vars:,}", "accent": 2, "sub": "from spec"},
    {"label": "CT Checked",           "value": f"{n_ct:,}",      "accent": 1, "sub": "value comparisons"},
    {"label": "CT Mismatches",        "value": f"{n_miss:,}",    "accent": 4,
     "sub": f"across {n_miss_v} var(s)",
     "pct": (n_miss / n_ct * 100) if n_ct else 0},
    {"label": "Value-Level Rows",     "value": f"{n_vl:,}",      "accent": 3,
     "sub": "TESTCD/QNAM/PARAMCD values",
     "pct": min(n_vl / 10, 100) if n_vl else 0},
    {"label": "Where-Clause Rows",    "value": f"{n_wh:,}",      "accent": 3, "sub": "from value level"},
]
st.markdown(render_kpi_cards(kpi_metrics, C), unsafe_allow_html=True)

# ── Downloads ─────────────────────────────────────────────────────────────────
dl_cols = st.columns(3)
with dl_cols[0]:
    excel_bytes = export_define_results(
        columns_df if not columns_df.empty else pd.DataFrame(),
        vl_df      if not vl_df.empty      else pd.DataFrame(),
        wh_df      if not wh_df.empty      else pd.DataFrame(),
        vlm_df     if not vlm_df.empty     else None,
        ct_df      if not ct_df.empty      else None,
    )
    st.download_button("⬇ Define Report (.xlsx)", data=excel_bytes,
        file_name=f"Define_{mode}_{datetime.now():%Y%m%d_%H%M}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True)
with dl_cols[1]:
    if define_xml:
        st.download_button("⬇ Define-XML v2.1 (.xml)", data=define_xml.encode("utf-8"),
            file_name=f"define_{datetime.now():%Y%m%d_%H%M}.xml",
            mime="application/xml", use_container_width=True)
    else:
        st.button("⬇ Define-XML v2.1 (.xml)", disabled=True,
            help="Enable 'Generate Define-XML v2.1' in Options and re-run.",
            use_container_width=True)
with dl_cols[2]:
    if not ct_df.empty:
        st.download_button("⬇ CT Comparison (.csv)",
            data=ct_df.to_csv(index=False).encode(),
            file_name=f"CT_{datetime.now():%Y%m%d_%H%M}.csv",
            mime="text/csv", use_container_width=True)

st.divider()

# ── Tabs ──────────────────────────────────────────────────────────────────────
tabs = st.tabs([
    f"Variable Metadata ({n_vars:,})",
    f"VLM / Codelist ({n_cl_vars:,} vars)",
    f"CT Comparison ({n_miss:,} mismatches / {n_ct:,} total)",
    f"Value Level ({n_vl:,} rows)",
    f"Where Clause ({n_wh:,} rows)",
])

# ── Tab 0 — Variable Metadata ─────────────────────────────────────────────────
with tabs[0]:
    if columns_df.empty:
        if meta_skipped:
            st.info("Metadata extraction was skipped — enable 'Extract variable metadata' and regenerate.")
        else:
            st.warning(
                "**Variable metadata could not be read.**\n\n"
                "This does NOT affect VLM, CT Comparison, Value Level, or Where Clause.\n\n"
                "Try: `pip install --upgrade pyreadstat`  \n"
                "Or export datasets as CSV for metadata extraction."
            )
    else:
        dom_opts = ["All"] + sorted(columns_df["domain"].unique().tolist())
        dom_sel  = st.selectbox("Domain", dom_opts, key="def_dom")
        disp     = columns_df if dom_sel=="All" else columns_df[columns_df["domain"]==dom_sel]
        st.caption(f"{len(disp):,} variables")
        st.dataframe(disp, use_container_width=True, height=450)

# ── Tab 1 — VLM ──────────────────────────────────────────────────────────────
with tabs[1]:
    if vlm_df.empty:
        if not spec: st.info("Load a mapping spec in the sidebar to enable VLM.")
        elif cl_tab is None:
            st.error(f"Codelist tab not found. Sheets: `{', '.join(spec.keys() if spec else [])}`")
        else:
            st.warning("VLM empty — check column U has codelist names in domain sheets.")
    else:
        cf1, cf2, cf3 = st.columns(3)
        dom_sel = cf1.selectbox("Domain",   ["All"]+sorted(vlm_df["domain"].unique()),        key="vlm_d")
        cl_sel  = cf2.selectbox("Codelist", ["All"]+sorted(vlm_df["spec_codelist"].unique()), key="vlm_c")
        st_sel  = cf3.selectbox("CT Status",["All","PASS","MISMATCH","SKIPPED (MedDRA)","NO DATA"], key="vlm_s")
        d = vlm_df.copy()
        if dom_sel!="All": d = d[d["domain"]==dom_sel]
        if cl_sel!="All":  d = d[d["spec_codelist"]==cl_sel]
        if st_sel!="All":  d = d[d["ct_status"].str.contains(st_sel, na=False, regex=False)]
        st.caption(f"Showing {len(d):,} of {len(vlm_df):,} rows")
        def _vlm_rc(r):
            s = str(r.get("ct_status",""))
            return "row-miss" if "MISMATCH" in s else "row-pass" if s=="PASS" else ""
        st.markdown(render_table(d, row_class_fn=_vlm_rc, C=C), unsafe_allow_html=True)

        if HAS_PLOTLY:
            sc_s = vlm_df["ct_status"].apply(
                lambda s: "PASS"          if s=="PASS"
                else      "MISMATCH"      if "MISMATCH" in str(s)
                else      "MedDRA/WHODrug" if "SKIP" in str(s)
                else      "NO DATA"
            ).value_counts().reset_index()
            sc_s.columns = ["status","count"]
            fig = go.Figure(go.Pie(
                labels=sc_s["status"], values=sc_s["count"], hole=.5,
                marker=dict(colors=[
                    C["accent3"], C["accent4"], C["text_muted"], C["border"]
                ]),
                textinfo="label+percent",
                textfont=dict(size=12, family="Space Grotesk"),
            ))
            lyt = plotly_layout(C, "CT Status Distribution", height=260)
            lyt.pop("xaxis", None); lyt.pop("yaxis", None)
            fig.update_layout(**lyt)
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

# ── Tab 2 — CT Comparison ─────────────────────────────────────────────────────
with tabs[2]:
    if ct_df.empty:
        if not spec: st.info("Load spec for CT comparison.")
        elif cl_tab is None: st.error("Codelist tab not found.")
        else:
            st.info(
                "CT comparison returned no results.\n\n"
                "Note: result variables (--STRESC/--ORRES), MedDRA, and WHODrug excluded.\n"
                "Check that domain sheets have codelist names in column U."
            )
    else:
        st.info(
            "ℹ️ **CT notes:** Blank SAS values excluded · Case-insensitive matching · "
            "Result vars (--STRESC/--ORRES) excluded · MedDRA/WHODrug excluded · "
            "Active=N values ARE valid CT terms"
        )
        n_p = int((ct_df["status"]=="PASS").sum())
        c1, c2, c3 = st.columns(3)
        c1.metric("Total checked", n_ct)
        c2.metric("PASS",          n_p)
        c3.metric("MISMATCH",      n_miss)
        cf1, cf2, cf3 = st.columns(3)
        show_miss = cf1.checkbox("Mismatches only", value=True, key="ct_m")
        dom_ct    = cf2.selectbox("Domain",  ["All"]+sorted(ct_df["domain"].unique()),   key="ct_d")
        var_ct    = cf3.selectbox("Variable",["All"]+sorted(ct_df["variable"].unique()), key="ct_v")
        d = ct_df[ct_df["status"]=="MISMATCH"] if show_miss else ct_df
        if dom_ct!="All": d = d[d["domain"]==dom_ct]
        if var_ct!="All": d = d[d["variable"]==var_ct]
        def _ct_rc(r): return "row-miss" if r.get("status","")=="MISMATCH" else "row-pass"
        st.caption(f"Showing {len(d):,} rows")
        st.markdown(render_table(d, row_class_fn=_ct_rc, C=C), unsafe_allow_html=True)
        if HAS_PLOTLY and n_miss > 0:
            mb = (ct_df[ct_df["status"]=="MISMATCH"]
                  .groupby(["domain","variable"])
                  .agg(n=("status","count")).reset_index()
                  .sort_values("n", ascending=False).head(20))
            mb["dv"] = mb["domain"] + "." + mb["variable"]
            fig2 = go.Figure(go.Bar(
                x=mb["dv"], y=mb["n"],
                marker=dict(
                    color=mb["n"],
                    colorscale=[[0, C["accent5"]], [1, C["accent4"]]],
                    showscale=False,
                ),
                hovertemplate="<b>%{x}</b><br>Mismatches: %{y}<extra></extra>",
            ))
            lyt2 = plotly_layout(C, "CT Mismatches by Variable (top 20)", height=260)
            lyt2["xaxis"]["tickangle"] = -40
            fig2.update_layout(**lyt2)
            st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

# ── Tab 3 — Value Level ───────────────────────────────────────────────────────
with tabs[3]:
    if vl_df is None or vl_df.empty:
        # Diagnostic: probe each file to see if any have TESTCD/QNAM/PARAMCD columns
        import re as _re
        pat = _re.compile(r"TESTCD|QNAM|PARAMCD", _re.IGNORECASE)
        found_cols: list = []
        load_fails: list = []
        for fname, fdata in sdtm_store.items():
            if not _supported_ext(fname):
                continue
            try:
                df_probe, _, err = _load_file(fdata, fname)
                if df_probe.empty and err:
                    load_fails.append(f"{Path(fname).stem.upper()}: {err[:200]}")
                    continue
                hits = [c for c in df_probe.columns if pat.search(c)]
                if hits:
                    found_cols.append(f"**{Path(fname).stem.upper()}**: {', '.join(hits)}")
            except Exception as exc:
                load_fails.append(f"{Path(fname).stem.upper()}: {type(exc).__name__}: {exc}")

        st.markdown(
            f'<div style="background:{C["warn_bg"]};border:1px solid {C["warn_fg"]}44;'
            f'border-radius:12px;padding:16px 20px;margin-bottom:12px;">'
            f'<div style="font-family:Space Grotesk,sans-serif;font-size:14px;font-weight:600;'
            f'color:{C["warn_fg"]};margin-bottom:8px;">⚠ Value-level is empty</div>'
            f'<div style="font-size:12px;color:{C["text_main"]};line-height:1.7;">'
            f'This tab scans column headers for <code>TESTCD</code>, <code>QNAM</code>, '
            f'or <code>PARAMCD</code> patterns (SDTM mode) or <code>PARAMCD</code> (ADaM mode).<br>'
            f'<b>SDTM domains with value level:</b> LB (LBTESTCD), VS (VSTESTCD), QS (QSTESTCD), '
            f'RS (RSTESTCD), EG (EGTESTCD), SUPP* (QNAM)<br>'
            f'<b>ADaM:</b> any domain with PARAMCD column'
            f'</div></div>',
            unsafe_allow_html=True,
        )

        if load_fails:
            st.error(f"**{len(load_fails)} file(s) failed to load** — this is likely why value-level is empty:")
            for msg in load_fails[:10]:
                st.code(msg)
            st.info("💡 Try exporting these files as `.csv` (SAS: `proc export`) and re-uploading.")
        elif found_cols:
            st.success(
                f"✅ Found TESTCD/QNAM/PARAMCD columns in {len(found_cols)} file(s) below, "
                f"but value-level extraction returned empty. Check the Mode setting "
                f"(SDTM / ADaM) in Options and regenerate."
            )
            for fc in found_cols:
                st.markdown(f"  • {fc}")
        else:
            st.info(
                "No TESTCD, QNAM, or PARAMCD columns found in any uploaded file.\n\n"
                "If this is unexpected:\n"
                "1. Try uploading datasets via the **in-page uploader** above (avoids sidebar caching)\n"
                "2. Check that the correct **Mode** is selected (SDTM → TESTCD/QNAM, ADaM → PARAMCD)\n"
                "3. Verify the files are not empty / metadata-only exports"
            )
    else:
        # Show value level with domain filter + chart
        vl_c1, vl_c2 = st.columns([2, 1])
        with vl_c1:
            d2 = st.selectbox("Domain", ["All"]+sorted(vl_df["dataset"].unique()), key="def_vl")
        with vl_c2:
            vl_var_opts = ["All"]
            if d2 != "All":
                vl_var_opts += sorted(vl_df[vl_df["dataset"]==d2]["variable"].unique().tolist())
            vl_var = st.selectbox("Variable", vl_var_opts, key="def_vl_var")

        disp2 = vl_df.copy()
        if d2     != "All": disp2 = disp2[disp2["dataset"]==d2]
        if vl_var != "All": disp2 = disp2[disp2["variable"]==vl_var]
        st.caption(f"{len(disp2):,} of {n_vl:,} value-level rows")
        st.dataframe(disp2, use_container_width=True, height=420)

        # Domain distribution chart
        if HAS_PLOTLY:
            vl_agg = vl_df.groupby(["dataset","variable"]).size().reset_index(name="n_values")
            dom_agg = vl_agg.groupby("dataset")["n_values"].sum().reset_index()
            dom_agg = dom_agg.sort_values("n_values", ascending=False).head(25)
            fig_vl = go.Figure(go.Bar(
                x=dom_agg["dataset"], y=dom_agg["n_values"],
                marker_color=C["accent2"],
                hovertemplate="<b>%{x}</b><br>%{y} unique values<extra></extra>",
            ))
            lyt_vl = plotly_layout(C, "Value-Level Rows by Domain", height=240)
            lyt_vl["xaxis"]["tickangle"] = -30
            fig_vl.update_layout(**lyt_vl)
            st.plotly_chart(fig_vl, use_container_width=True, config={"displayModeBar": False})

# ── Tab 4 — Where Clause ──────────────────────────────────────────────────────
with tabs[4]:
    if wh_df is None or wh_df.empty:
        st.info(
            "Where Clause is generated from Value Level data.\n\n"
            "If Value Level (tab above) is also empty, see the diagnostic messages there.\n\n"
            "Once Value Level is populated, Where Clause will auto-populate on the next Generate."
        )
    else:
        wh_c1, wh_c2 = st.columns(2)
        with wh_c1:
            wh_ds_opts = ["All"] + sorted(wh_df["dataset"].unique().tolist()) \
                if "dataset" in wh_df.columns else ["All"]
            wh_ds = st.selectbox("Dataset", wh_ds_opts, key="wh_ds")
        with wh_c2:
            wh_var_opts = ["All"]
            if "variable" in wh_df.columns:
                src = wh_df if wh_ds=="All" else wh_df[wh_df["dataset"]==wh_ds]
                wh_var_opts += sorted(src["variable"].dropna().unique().tolist())
            wh_var = st.selectbox("Variable", wh_var_opts, key="wh_var")

        disp_wh = wh_df.copy()
        if wh_ds  != "All" and "dataset"  in disp_wh.columns: disp_wh = disp_wh[disp_wh["dataset"]==wh_ds]
        if wh_var != "All" and "variable" in disp_wh.columns: disp_wh = disp_wh[disp_wh["variable"]==wh_var]
        st.caption(f"{len(disp_wh):,} of {n_wh:,} where-clause rows")
        st.dataframe(disp_wh, use_container_width=True, height=450)
