# pages/2_Raw_Coverage.py  v17 — Enhanced graphics
import sys, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import (
    get_palette, build_css, render_table, render_kpi_cards,
    plotly_layout, status_colors, hex_to_rgba, DARK as C_default,
)
from core.raw_coverage import run_raw_coverage_from_store
from core.excel_export import export_coverage_results

st.set_page_config(page_title="Raw Coverage", layout="wide")
theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True,
    key=f"theme_{__file__}", help="Switch display theme.")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)

st.markdown(
    f'<div style="font-family:Space Grotesk,sans-serif;font-size:24px;font-weight:700;'
    f'letter-spacing:-.01em;color:{C["text_main"]};margin-bottom:2px;">📊 Raw Variable Coverage</div>'
    f'<div style="font-size:12px;color:{C["text_muted"]};margin-bottom:16px;">'
    f'Validates at raw.DATASET.VARIABLE level · SUPP domain logic applied automatically</div>',
    unsafe_allow_html=True,
)

if "spec" not in st.session_state:
    st.warning("Upload a mapping specification in the sidebar first."); st.stop()
if "raw_files_store" not in st.session_state:
    st.warning("Upload raw CRF datasets (.sas7bdat) in the sidebar first."); st.stop()

spec      = st.session_state["spec"]
spec_name = st.session_state.get("spec_name","spec")
raw_store = st.session_state["raw_files_store"]

col1, col2 = st.columns([3,1])
with col1:
    ds_list = ", ".join(Path(k).stem.upper() for k in sorted(raw_store.keys()))
    st.info(f"Using {len(raw_store)} raw file(s): {ds_list[:120]}{'...' if len(ds_list)>120 else ''}")
with col2:
    active_filter = st.text_input("Active flag value", value="Y")
    extra_excl    = st.text_input("Extra exclude vars", value="", placeholder="VAR1,VAR2")

extra_set = {v.strip().upper() for v in extra_excl.split(",") if v.strip()} if extra_excl.strip() else set()

if st.button("Run Coverage Check", type="primary", use_container_width=True):
    with st.spinner(f"Analysing {len(raw_store)} file(s)..."):
        try:
            r = run_raw_coverage_from_store(raw_store, spec, active_filter=active_filter, exclude_vars=extra_set)
            st.session_state["cov_results"] = r
        except Exception as exc:
            st.error(f"Failed: {exc}"); st.exception(exc)

if "cov_results" not in st.session_state:
    st.info("Click 'Run Coverage Check' to begin."); st.stop()

cov_r    = st.session_state["cov_results"]
coverage = cov_r.get("coverage", pd.DataFrame())
summary  = cov_r.get("summary",  pd.DataFrame())
dom_map  = cov_r.get("domain_mapping", pd.DataFrame())

if coverage.empty:
    st.warning("No raw variables found."); st.stop()

total     = len(coverage)
n_exact   = int((coverage["status"]=="EXACT").sum())
n_partial = int((coverage["status"]=="PARTIAL").sum())
n_unmap   = int((coverage["status"]=="UNMAPPED").sum())
pct       = round((n_exact+n_partial)/total*100, 1) if total else 0

# ── KPI cards ─────────────────────────────────────────────────────────────────
metrics = [
    {"label": "Total Raw Vars",  "value": f"{total:,}",     "accent": 1, "sub": "across all datasets"},
    {"label": "Exact",           "value": f"{n_exact:,}",   "accent": 3, "sub": f"{n_exact/total*100:.0f}% of total", "pct": n_exact/total*100 if total else 0},
    {"label": "Partial",         "value": f"{n_partial:,}", "accent": 5, "sub": f"{n_partial/total*100:.0f}% of total", "pct": n_partial/total*100 if total else 0},
    {"label": "Unmapped",        "value": f"{n_unmap:,}",   "accent": 4, "sub": f"{n_unmap/total*100:.0f}% of total",  "pct": n_unmap/total*100 if total else 0},
    {"label": "% Covered",       "value": f"{pct}%",        "accent": 2, "sub": "Exact + Partial", "pct": pct},
]
st.markdown(render_kpi_cards(metrics, C), unsafe_allow_html=True)

# ── Charts row ────────────────────────────────────────────────────────────────
if HAS_PLOTLY:
    sc = status_colors(C)
    chart_col1, chart_col2 = st.columns(2, gap="medium")

    with chart_col1:
        # Donut
        labels = ["EXACT", "PARTIAL", "UNMAPPED"]
        values = [n_exact, n_partial, n_unmap]
        colors = [sc[l] for l in labels]
        fig_d = go.Figure(go.Pie(
            labels=labels, values=values, hole=.62,
            marker=dict(colors=colors, line=dict(color=C["chart_bg"], width=3)),
            textinfo="label+percent",
            textfont=dict(size=12, family="Space Grotesk"),
            hovertemplate="<b>%{label}</b><br>%{value:,} vars (%{percent})<extra></extra>",
        ))
        lyt = plotly_layout(C, "Coverage Status Distribution", height=300)
        lyt.pop("xaxis", None); lyt.pop("yaxis", None)
        lyt["annotations"] = [dict(
            text=f"<b>{pct}%</b><br>covered",
            x=.5, y=.5, showarrow=False,
            font=dict(size=16, family="Space Grotesk", color=C["text_main"]),
        )]
        fig_d.update_layout(**lyt)
        st.plotly_chart(fig_d, use_container_width=True, config={"displayModeBar": False})

    with chart_col2:
        # Stacked bar by dataset
        if not summary.empty:
            stat_cols = [c for c in ["EXACT","PARTIAL","UNMAPPED"] if c in summary.columns]
            ds_col    = next((c for c in summary.columns if "dataset" in c.lower()), None)
            if ds_col and stat_cols:
                chart_d = summary.melt(
                    id_vars=[ds_col], value_vars=stat_cols,
                    var_name="status", value_name="count",
                )
                color_map = {s: sc[s] for s in stat_cols}
                fig_b = go.Figure()
                for s in stat_cols:
                    sub = chart_d[chart_d["status"]==s]
                    fig_b.add_trace(go.Bar(
                        name=s, x=sub[ds_col], y=sub["count"],
                        marker_color=color_map[s],
                        hovertemplate=f"<b>%{{x}}</b><br>{s}: %{{y}}<extra></extra>",
                    ))
                lyt_b = plotly_layout(C, "Coverage by Raw Dataset", height=300)
                lyt_b["barmode"] = "stack"
                lyt_b["xaxis"]["tickangle"] = -30
                fig_b.update_layout(**lyt_b)
                st.plotly_chart(fig_b, use_container_width=True, config={"displayModeBar": False})

    # Domain heatmap (if coverage has sdtm_domain column)
    if "sdtm_domain" in coverage.columns and "status" in coverage.columns:
        heat_data = (
            coverage.groupby(["sdtm_domain","status"])
            .size().reset_index(name="n")
            .pivot(index="sdtm_domain", columns="status", values="n")
            .fillna(0).reset_index()
        )
        stat_cols_h = [c for c in ["EXACT","PARTIAL","UNMAPPED"] if c in heat_data.columns]
        if len(stat_cols_h) > 1:
            with st.expander("Coverage heatmap by SDTM domain", expanded=False):
                fig_h = go.Figure()
                for s in stat_cols_h:
                    fig_h.add_trace(go.Bar(
                        name=s, x=heat_data["sdtm_domain"], y=heat_data[s],
                        marker_color=sc.get(s, C["accent1"]),
                        hovertemplate=f"<b>%{{x}}</b><br>{s}: %{{y}}<extra></extra>",
                    ))
                lyt_h = plotly_layout(C, "Variable Status per SDTM Domain", height=300)
                lyt_h["barmode"] = "stack"
                lyt_h["xaxis"]["tickangle"] = -35
                fig_h.update_layout(**lyt_h)
                st.plotly_chart(fig_h, use_container_width=True, config={"displayModeBar": False})

# ── Download ──────────────────────────────────────────────────────────────────
excel_bytes = export_coverage_results(coverage, summary)
st.download_button(
    "⬇ Download Coverage Report (.xlsx)", data=excel_bytes,
    file_name=f"RawCoverage_{spec_name.replace('.xlsx','')}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)

st.divider()

# ── Tables ────────────────────────────────────────────────────────────────────
def _cov_row_class(row):
    s = str(row.get("status","")).upper()
    return {"EXACT":"row-exact","PARTIAL":"row-partial","UNMAPPED":"row-unmapped"}.get(s,"")

def _cov_cell(col, val, row):
    if col == "status":
        cls = {"EXACT":"badge-exact","PARTIAL":"badge-partial","UNMAPPED":"badge-unmapped"}.get(val,"")
        return f'<span class="badge {cls}">{val}</span>'
    return f'<span class="mono">{val}</span>' if col in ("raw_variable","mapped_to","sdtm_domain","raw_dataset") else val

tab1, tab2, tab3, tab4 = st.tabs([
    f"Variable Detail ({len(coverage):,})",
    "Dataset Summary",
    "Raw → SDTM Domain Map",
    f"Unmapped ({n_unmap:,})",
])

with tab1:
    cf1, cf2 = st.columns(2)
    sf     = cf1.selectbox("Status",     ["All","EXACT","PARTIAL","UNMAPPED"], key="cov_sf")
    ds_opts = ["All"] + sorted(coverage["raw_dataset"].dropna().unique().tolist())
    df_sel  = cf2.selectbox("Raw Dataset", ds_opts, key="cov_df")
    disp    = coverage.copy()
    if sf != "All":     disp = disp[disp["status"]==sf]
    if df_sel != "All": disp = disp[disp["raw_dataset"]==df_sel]
    show = [c for c in ["raw_dataset","raw_variable","status","sdtm_domain","mapped_to"] if c in disp.columns]
    st.markdown(
        f'<div class="legend-row"><span style="color:{C["text_muted"]};">Showing <b>{len(disp):,}</b> of <b>{len(coverage):,}</b></span></div>',
        unsafe_allow_html=True,
    )
    st.markdown(render_table(disp[show], row_class_fn=_cov_row_class, cell_fn=_cov_cell, C=C), unsafe_allow_html=True)

with tab2:
    st.dataframe(summary, use_container_width=True, height=400)

with tab3:
    st.caption("Each raw dataset and all SDTM domains it feeds into.")
    if dom_map.empty:
        st.info("No domain mapping data.")
    else:
        disp_dm = dom_map[["raw_dataset","sdtm_domains","n_sdtm_domains","n_variables"]].copy()
        disp_dm.columns = ["Raw Dataset","SDTM Domains","# SDTM Domains","# Spec Refs"]
        st.dataframe(disp_dm, use_container_width=True, height=400)
        if HAS_PLOTLY:
            fig2 = go.Figure(go.Bar(
                x=dom_map["raw_dataset"], y=dom_map["n_sdtm_domains"],
                marker=dict(
                    color=dom_map["n_sdtm_domains"],
                    colorscale=[[0, C["accent2"]],[1, C["accent1"]]],
                    showscale=True,
                    colorbar=dict(thickness=10, tickfont=dict(size=10)),
                ),
                hovertemplate="<b>%{x}</b><br>%{y} SDTM domains<extra></extra>",
            ))
            lyt2 = plotly_layout(C, "SDTM Domain Spread per Raw Dataset", height=260)
            lyt2["xaxis"]["tickangle"] = -30
            fig2.update_layout(**lyt2)
            st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

with tab4:
    unm = coverage[coverage["status"]=="UNMAPPED"].copy()
    if unm.empty:
        st.success("No unmapped variables!")
    else:
        ds_u_opts = ["All"] + sorted(unm["raw_dataset"].dropna().unique().tolist())
        ds_u = st.selectbox("Dataset", ds_u_opts, key="cov_unm_ds")
        if ds_u != "All": unm = unm[unm["raw_dataset"]==ds_u]
        show_u = [c for c in ["raw_dataset","raw_variable"] if c in unm.columns]
        st.markdown(render_table(unm[show_u], row_class_fn=_cov_row_class, cell_fn=_cov_cell, C=C), unsafe_allow_html=True)
