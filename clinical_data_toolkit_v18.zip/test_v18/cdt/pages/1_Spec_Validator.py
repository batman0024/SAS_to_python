# pages/1_Spec_Validator.py
import sys, warnings, io
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.check_rules import CHECK_RULES
from config.theme import get_palette, build_css, render_table, render_kpi_cards, plotly_layout, status_colors, hex_to_rgba, DARK as C_default
from core.spec_validator import run_spec_validation, build_domain_summary
from core.excel_export import export_validation_results

st.set_page_config(page_title="Spec Validator", layout="wide")
theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True,
    key=f"theme_{__file__}", help="Switch display theme.")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)
st.title("Spec Validator")
st.caption("Checks every active domain in the mapping spec for completeness and consistency.")

if "spec" not in st.session_state:
    st.warning("Upload a mapping specification in the sidebar (app page) first.")
    st.stop()

spec      = st.session_state["spec"]
spec_name = st.session_state.get("spec_name","spec")
spec_meta = st.session_state.get("spec_meta",{})
is_adam   = spec_meta.get("spec_type","") == "ADaM"

# ── Config ────────────────────────────────────────────────────────────────
with st.expander("Run configuration", expanded=False):
    col1, col2, col3 = st.columns(3)
    with col1:
        active_filter  = st.text_input("Active flag value", value="Y")
        explicit_input = st.text_area("Override datasets (comma-separated)", value="")
    with col2:
        st.write("Enable/disable checks:")
        enabled_checks = []
        for key, rule in CHECK_RULES.items():
            if st.checkbox(f"{rule['severity']}: {key}", value=rule["active"], key=f"chk_{key}"):
                enabled_checks.append(key)
    with col3:
        # ── SDTM Source check — especially relevant for ADaM ──────────
        sdtm_store = st.session_state.get("sdtm_files_store", {})
        st.write("SDTM Source check (ADaM → SDTM traceability):")
        if is_adam:
            # When ADaM is loaded, user needs a separate SDTM upload
            st.caption("ADaM spec detected — upload SDTM datasets for source variable check.")
            sdtm_extra = st.file_uploader(
                "Upload SDTM .sas7bdat files (for source check)",
                type=["sas7bdat","xpt","csv"], accept_multiple_files=True,
                key="sdtm_for_adam_check",
                help="Used to verify that SDTM-sourced ADaM variables exist in the SDTM library.",
            )
            if sdtm_extra:
                for uf in sdtm_extra:
                    sdtm_store[uf.name] = uf.read()
        else:
            if sdtm_store:
                st.caption(f"Using {len(sdtm_store)} SDTM file(s) from sidebar.")
            else:
                st.caption("Upload SDTM datasets in the sidebar to enable SDTM source check.")
        run_sdtm_check = st.checkbox("Run SDTM source check", value=bool(sdtm_store))

explicit_datasets = [d.strip().upper() for d in explicit_input.split(",") if d.strip()] or None

# ── Run ───────────────────────────────────────────────────────────────────
if st.button("Run Validation", type="primary", use_container_width=True):
    sdtm_var_index = None
    if run_sdtm_check and sdtm_store:
        try:
            from core.define_helper import _load_file, _supported_ext
            var_index = set()
            errors = []
            for fname, fdata in sdtm_store.items():
                if not _supported_ext(fname):
                    continue
                dom = Path(fname).stem.upper()
                df, meta, err = _load_file(fdata, fname)
                if err:
                    errors.append(err)
                if df.empty:
                    continue
                for col in df.columns:
                    var_index.add(f"{dom}.{col.upper()}")
            sdtm_var_index = var_index
            st.info(f"SDTM index: {len(var_index)} variables across {len(sdtm_store)} file(s).")
            if errors:
                with st.expander(f"⚠ {len(errors)} file(s) had read issues"):
                    for e in errors[:10]: st.code(e)
        except Exception as exc:
            st.warning(f"Cannot read SDTM files: {type(exc).__name__}: {exc}")

    with st.spinner("Running checks..."):
        try:
            results = run_spec_validation(
                spec,
                active_filter=active_filter,
                explicit_datasets=explicit_datasets,
                enabled_checks=enabled_checks or None,
                sdtm_var_index=sdtm_var_index,
            )
            st.session_state["validation_results"] = results
            history = st.session_state.get("run_history",[])
            history.append({"time": datetime.now().strftime("%H:%M:%S"),
                            "spec_name": spec_name,
                            "errors": results["summary"]["errors"],
                            "warnings": results["summary"]["warnings"]})
            st.session_state["run_history"] = history
        except Exception as exc:
            st.error(f"Validation failed: {exc}"); st.exception(exc)

if "validation_results" not in st.session_state:
    st.info("Configure options above and click 'Run Validation'.")
    st.stop()

results     = st.session_state["validation_results"]
summary     = results["summary"]
issues      = results["issues"]
cl_check    = results["codelist_check"]
cm_check    = results["compmethod_check"]
sdtm_source = results["sdtm_source"]

# ── Score banner ─────────────────────────────────────────────────────────
score = summary["health_score"]
grade = summary["grade"]
sc    = "#22c55e" if score>=90 else ("#f59e0b" if score>=75 else "#ef4444")

# Score banner now rendered as KPI cards in the chart section below

# ── Download ──────────────────────────────────────────────────────────────
if not issues.empty or not cl_check.empty:
    st.download_button("⬇ Download Full Report (.xlsx)",
        data=export_validation_results(results, spec_name),
        file_name=f"SpecValidation_{spec_name.replace('.xlsx','')}_{datetime.now():%Y%m%d_%H%M}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        type="secondary")

# ── Chart ─────────────────────────────────────────────────────────────────
if not issues.empty and HAS_PLOTLY:
    dom_sum = build_domain_summary(issues)
    if not dom_sum.empty:
        # ── KPI cards for validation summary ──────────────────────────────
        score = summary["health_score"]
        sc_color = C["accent3"] if score>=90 else (C["accent5"] if score>=75 else C["accent4"])
        kpi_metrics = [
            {"label": "Health Score", "value": f"{score}/100", "accent": 3 if score>=90 else (5 if score>=75 else 4),
             "sub": summary["grade"], "pct": score},
            {"label": "Errors",   "value": str(summary["errors"]),   "accent": 4, "sub": "validation errors"},
            {"label": "Warnings", "value": str(summary["warnings"]), "accent": 5, "sub": "validation warnings"},
            {"label": "Codelist", "value": str(summary["codelist_issues"]), "accent": 2, "sub": "codelist issues"},
            {"label": "CompMeth", "value": str(summary["comp_issues"]),     "accent": 1, "sub": "compmethod issues"},
        ]
        st.markdown(render_kpi_cards(kpi_metrics, C), unsafe_allow_html=True)

        # ── Charts ──────────────────────────────────────────────────────────
        chart_col1, chart_col2 = st.columns(2, gap="medium")
        with chart_col1:
            fig = go.Figure()
            if "errors" in dom_sum.columns:
                fig.add_trace(go.Bar(name="Errors", x=dom_sum["domain"], y=dom_sum["errors"],
                    marker_color=C["accent4"],
                    hovertemplate="<b>%{x}</b><br>Errors: %{y}<extra></extra>"))
            if "warnings" in dom_sum.columns:
                fig.add_trace(go.Bar(name="Warnings", x=dom_sum["domain"], y=dom_sum["warnings"],
                    marker_color=C["accent5"],
                    hovertemplate="<b>%{x}</b><br>Warnings: %{y}<extra></extra>"))
            lyt = plotly_layout(C, "Issues by Domain", height=300)
            lyt["barmode"] = "group"
            lyt["xaxis"]["tickangle"] = -30
            fig.update_layout(**lyt)
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

        with chart_col2:
            # Severity donut
            n_e = int(summary["errors"]); n_w = int(summary["warnings"])
            fig2 = go.Figure(go.Pie(
                labels=["Errors","Warnings","Pass"],
                values=[n_e, n_w, max(0, len(dom_sum)*3 - n_e - n_w)],
                hole=.60,
                marker=dict(colors=[C["accent4"], C["accent5"], C["accent3"]],
                            line=dict(color=C["chart_bg"], width=3)),
                textinfo="label+percent",
                textfont=dict(size=12, family="Space Grotesk"),
                hovertemplate="<b>%{label}</b>: %{value}<extra></extra>",
            ))
            lyt2 = plotly_layout(C, "Issue Severity Split", height=300)
            lyt2.pop("xaxis", None); lyt2.pop("yaxis", None)
            grade = summary["grade"]
            lyt2["annotations"] = [dict(
                text=f"<b>{grade}</b>", x=.5, y=.5, showarrow=False,
                font=dict(size=22, family="Space Grotesk", color=sc_color),
            )]
            fig2.update_layout(**lyt2)
            st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

st.divider()

# ── Row class functions ────────────────────────────────────────────────────
def _issue_row_class(row):
    sev = str(row.get("severity","")).upper()
    return "row-error" if sev=="ERROR" else "row-warning" if sev=="WARNING" else ""

def _issue_cell(col, val, row):
    if col == "severity":
        sev = val.upper()
        cls = "badge-error" if sev=="ERROR" else "badge-warning"
        return f'<span class="badge {cls}">{val}</span>'
    return f'<span class="mono">{val}</span>' if col in ("variable","check") else val

def _cl_row_class(row):
    if str(row.get("in_codelist_tab","")).startswith("NO"):
        return "row-miss"
    if str(row.get("active","")).upper() in ("N","NO"):
        return "row-warning"
    return ""

def _cm_row_class(row):
    if str(row.get("in_computation_tab","")).startswith("NO"):
        return "row-miss"
    src = str(row.get("comp_source","")).lower()
    if src == "inline":
        return "row-inline"
    fails = [v for k,v in row.items() if k.startswith("comp_") and str(v).startswith("FAIL")]
    return "row-error" if fails else ""

def _cm_cell(col, val, row):
    if col == "comp_source":
        cls = "badge-inline" if val=="inline" else "badge-pass"
        return f'<span class="badge {cls}">{val}</span>'
    if col.startswith("comp_") and str(val).startswith("FAIL"):
        return f'<span style="color:#f87171;font-weight:600;">{val}</span>'
    return f'<span class="mono">{val}</span>' if col in ("variable","compmethod_id","dataset") else val

# ── Tabs ──────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    f"Issues (Flat) {len(issues)}",
    "Issues by Domain",
    "Codelist",
    "CompMethod",
    "SDTM Source",
])

with tab1:
    if issues.empty:
        st.success("No issues found across all active domains.")
    else:
        cf1,cf2,cf3 = st.columns(3)
        sev_f = cf1.selectbox("Severity",  ["All"]+sorted(issues["severity"].unique().tolist()), key="sv_f")
        dom_f = cf2.selectbox("Domain",    ["All"]+sorted(issues["domain"].unique().tolist()),   key="dm_f")
        chk_f = cf3.selectbox("Check type",["All"]+sorted(issues["check"].unique().tolist()),    key="ck_f")

        filt = issues.copy()
        if sev_f != "All": filt = filt[filt["severity"]==sev_f]
        if dom_f != "All": filt = filt[filt["domain"]==dom_f]
        if chk_f != "All": filt = filt[filt["check"]==chk_f]

        disp_cols = [c for c in ["domain","variable","severity","check","description","suggestion","mapping_action","origin"] if c in filt.columns]
        st.markdown(f'<div class="legend-row"><span>Showing <b>{len(filt):,}</b> of <b>{len(issues):,}</b> issues</span></div>', unsafe_allow_html=True)
        st.markdown(render_table(filt[disp_cols], row_class_fn=_issue_row_class, cell_fn=_issue_cell, C=C), unsafe_allow_html=True)

with tab2:
    if issues.empty:
        st.success("No issues found.")
    else:
        dom_opts = sorted(issues["domain"].unique())
        dom_labels = []
        for d in dom_opts:
            g = issues[issues["domain"]==d]
            dom_labels.append(f"{d}  ({int((g['severity']=='ERROR').sum())}E / {int((g['severity']=='WARNING').sum())}W)")
        idx = st.selectbox("Domain", range(len(dom_opts)), format_func=lambda i: dom_labels[i], key="dom_bydom")
        dom_iss = issues[issues["domain"]==dom_opts[idx]]
        c1,c2,c3 = st.columns(3)
        c1.metric("Domain", dom_opts[idx])
        c2.metric("Errors", int((dom_iss["severity"]=="ERROR").sum()))
        c3.metric("Warnings", int((dom_iss["severity"]=="WARNING").sum()))
        d2cols = [c for c in ["variable","severity","check","description","suggestion","mapping_action","origin"] if c in dom_iss.columns]
        st.markdown(render_table(dom_iss[d2cols], row_class_fn=_issue_row_class, cell_fn=_issue_cell, C=C), unsafe_allow_html=True)

with tab3:
    if cl_check.empty:
        st.info("No codelist references found or Codelist tab missing.")
    else:
        miss_mask = cl_check.get("in_codelist_tab", pd.Series(dtype=str)).str.startswith("NO")
        inact_mask= cl_check.get("active", pd.Series(dtype=str)).str.upper().isin(["N","NO"])
        cc1,cc2,cc3 = st.columns(3)
        cc1.metric("Total Referenced", len(cl_check))
        cc2.metric("Not in Codelist tab", int(miss_mask.sum()))
        cc3.metric("Marked inactive", int(inact_mask.sum()))

        ct_stds = sorted(s for s in cl_check.get("ct_standard",pd.Series(dtype=str)).dropna().unique() if s and s.lower()!="nan")
        if ct_stds:
            chips = " &nbsp;|&nbsp; ".join(f'<code style="background:#1e3a5f;padding:2px 7px;border-radius:3px;color:#93c5fd;">{s}</code>' for s in ct_stds)
            st.markdown(f'<div style="font-size:12px;color:#94a3b8;margin:4px 0 8px;">CT Standards in spec: {chips}</div>', unsafe_allow_html=True)

        show_iss = st.checkbox("Show issues only", value=False, key="cl_issues_only")
        d_cl = cl_check[miss_mask | inact_mask] if show_iss else cl_check
        st.markdown(render_table(d_cl, row_class_fn=_cl_row_class, C=C), unsafe_allow_html=True)

with tab4:
    if cm_check.empty:
        st.info("No CompMethod references found or Computation tab missing.")
    else:
        fail_cols = [c for c in cm_check.columns if c.startswith("comp_") and c!="comp_source"]
        n_fails  = 0
        if fail_cols:
            n_fails = int(cm_check[fail_cols].apply(lambda c: c.astype(str).str.startswith("FAIL")).any(axis=1).sum())
        n_miss   = int(cm_check.get("in_computation_tab",pd.Series(dtype=str)).str.startswith("NO").sum())
        n_inline = int((cm_check.get("comp_source",pd.Series(dtype=str))=="inline").sum())
        m1,m2,m3,m4 = st.columns(4)
        m1.metric("Total Referenced", len(cm_check))
        m2.metric("Not in Computation tab", n_miss)
        m3.metric("Text check failures", n_fails)
        m4.metric("Inline (Comp:)", n_inline)

        show_f = st.checkbox("Show failures only", value=False, key="comp_fails")
        sel_id = st.selectbox("View algorithm:", ["(none)"]+sorted(cm_check["compmethod_id"].dropna().unique().tolist()), key="comp_detail")
        if sel_id != "(none)":
            row_c = cm_check[cm_check["compmethod_id"]==sel_id].iloc[0]
            st.text_area("Algorithm text", value=row_c.get("algorithm_preview",""), height=110, disabled=True)
            st.caption(f"Used by: {row_c.get('used_by_domains','')}")

        if show_f and fail_cols:
            fail_mask = cm_check[fail_cols].apply(lambda c: c.astype(str).str.startswith("FAIL")).any(axis=1)
            miss_mask_cm = cm_check.get("in_computation_tab",pd.Series(dtype=str)).str.startswith("NO")
            d_cm = cm_check[fail_mask | miss_mask_cm]
        else:
            d_cm = cm_check
        d_cm_disp = d_cm.drop(columns=["algorithm_preview"], errors="ignore")
        st.markdown(render_table(d_cm_disp, row_class_fn=_cm_row_class, cell_fn=_cm_cell, C=C), unsafe_allow_html=True)

with tab5:
    if sdtm_source is None or sdtm_source.empty:
        if is_adam:
            st.info("Upload SDTM .sas7bdat files in the Run Configuration → SDTM Source check section above, then re-run validation.")
        else:
            st.info("SDTM source check not run. Upload SDTM datasets in the sidebar and enable the check.")
    else:
        n_nf = int(sdtm_source.get("in_sdtm_lib",pd.Series(dtype=str)).str.startswith("NO").sum())
        s1,s2 = st.columns(2)
        s1.metric("Variables checked", len(sdtm_source))
        s2.metric("Not found in SDTM library", n_nf)
        def _sdtm_rc(row):
            return "row-miss" if str(row.get("in_sdtm_lib","")).startswith("NO") else ""
        st.markdown(render_table(sdtm_source, row_class_fn=_sdtm_rc, C=C), unsafe_allow_html=True)
