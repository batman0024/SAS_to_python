# pages/6_Dataset_Compare.py
"""
Dataset Comparison — compare two sets of datasets (raw, SDTM, or ADaM).
Supports uploading MULTIPLE files per side — matches by filename stem.
Provides metadata diff and value-level diff with charts + Excel report.
"""
import sys, warnings, io
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
from collections import defaultdict
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import BASE_CSS, C, render_table
from core.dataset_compare import (
    _load_from_bytes, compare_metadata, compare_values, export_comparison_report
)

st.set_page_config(page_title="Dataset Compare", layout="wide")
st.markdown(BASE_CSS, unsafe_allow_html=True)
st.title("Dataset Comparison")
st.caption(
    "Compare two sets of datasets (raw CRF, SDTM, or ADaM) at metadata and value level. "
    "Upload multiple files per side — matched by filename. "
    "Identifies variable changes, row additions/removals, and value differences."
)

# ── File upload — multiple files per side ─────────────────────────────────
col1, col2 = st.columns(2)
with col1:
    st.markdown("**Set A** — baseline / before (multiple files allowed)")
    files_a = st.file_uploader(
        "Upload Dataset(s) A (.sas7bdat or .csv)",
        type=["sas7bdat","csv"],
        accept_multiple_files=True,
        key="cmp_files_a",
        help="Upload one or more files. Each file is matched by name to a corresponding file in Set B."
    )
    if files_a:
        st.caption(f"{len(files_a)} file(s): " + ", ".join(Path(f.name).stem.upper() for f in files_a))

with col2:
    st.markdown("**Set B** — comparison / after (multiple files allowed)")
    files_b = st.file_uploader(
        "Upload Dataset(s) B (.sas7bdat or .csv)",
        type=["sas7bdat","csv"],
        accept_multiple_files=True,
        key="cmp_files_b",
        help="Files are matched to Set A by filename stem. Extra files in either set are reported."
    )
    if files_b:
        st.caption(f"{len(files_b)} file(s): " + ", ".join(Path(f.name).stem.upper() for f in files_b))

if not files_a or not files_b:
    st.info("Upload files in both Set A and Set B to begin comparison.")
    st.stop()

# ── Match files by stem ───────────────────────────────────────────────────
store_a = {Path(f.name).stem.upper(): (f.name, f.getvalue()) for f in files_a}
store_b = {Path(f.name).stem.upper(): (f.name, f.getvalue()) for f in files_b}

names_a   = set(store_a.keys())
names_b   = set(store_b.keys())
matched   = sorted(names_a & names_b)
only_in_a = sorted(names_a - names_b)
only_in_b = sorted(names_b - names_a)

st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">Matched datasets</div>'
    f'<div class="value" style="color:{C["pass_fg"]};">{len(matched)}</div></div>'
    f'<div class="metric-item"><div class="label">Only in A</div>'
    f'<div class="value" style="color:{C["warn_fg"]};">{len(only_in_a)}</div></div>'
    f'<div class="metric-item"><div class="label">Only in B</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{len(only_in_b)}</div></div>'
    f'</div>',
    unsafe_allow_html=True
)

if only_in_a:
    st.warning(f"Files in A not matched in B: **{', '.join(only_in_a)}**")
if only_in_b:
    st.info(f"Files in B not matched in A: **{', '.join(only_in_b)}**")

if not matched:
    st.error("No matching datasets found between Set A and Set B. Files are matched by name.")
    st.stop()

# ── Select which dataset to compare if multiple ───────────────────────────
if len(matched) == 1:
    selected_ds = matched[0]
else:
    selected_ds = st.selectbox(
        "Select dataset to compare",
        matched,
        help="Results are shown for one dataset at a time. Download report includes all."
    )

# ── Options ───────────────────────────────────────────────────────────────
with st.expander("Options", expanded=False):
    key_input  = st.text_input(
        "Key variables for row matching (comma-separated)",
        value="",
        placeholder="USUBJID, AESEQ — leave blank for auto-detect",
    )
    run_values = st.checkbox("Run value-level comparison", value=True,
        help="May be slow for large datasets.")

key_cols = [k.strip().upper() for k in key_input.split(",") if k.strip()] or None

if st.button("Run Comparison", type="primary", use_container_width=True):
    all_results = {}
    progress    = st.progress(0)

    for i, ds_name in enumerate(matched):
        fname_a, bytes_a = store_a[ds_name]
        fname_b, bytes_b = store_b[ds_name]

        try:
            df_a = _load_from_bytes(bytes_a, fname_a)
            df_b = _load_from_bytes(bytes_b, fname_b)
        except Exception as exc:
            st.warning(f"{ds_name}: cannot load — {exc}")
            all_results[ds_name] = None
            continue

        meta_diff     = compare_metadata(df_a, "A", df_b, "B")
        value_results = compare_values(df_a, "A", df_b, "B", key_cols=key_cols) if run_values else {}

        all_results[ds_name] = {
            "meta_diff":     meta_diff,
            "value_results": value_results,
            "shape_a":       df_a.shape,
            "shape_b":       df_b.shape,
        }
        progress.progress(int((i+1)/len(matched)*100))

    # Summary across all datasets
    summary_rows = []
    for ds, r in all_results.items():
        if r is None:
            summary_rows.append({"dataset":ds,"status":"LOAD_ERROR","vars_only_a":0,
                                  "vars_only_b":0,"dtype_changed":0,"rows_added":0,
                                  "rows_removed":0,"vars_with_diffs":0})
            continue
        md = r["meta_diff"]
        vr = r["value_results"]
        summary_rows.append({
            "dataset":        ds,
            "status":         "COMPARED",
            "rows_a":         r["shape_a"][0],
            "cols_a":         r["shape_a"][1],
            "rows_b":         r["shape_b"][0],
            "cols_b":         r["shape_b"][1],
            "vars_only_a":    int(md["status"].str.startswith("ONLY_IN_A").sum()) if not md.empty else 0,
            "vars_only_b":    int(md["status"].str.startswith("ONLY_IN_B").sum()) if not md.empty else 0,
            "dtype_changed":  int((md["status"]=="DTYPE_CHANGED").sum()) if not md.empty else 0,
            "rows_added":     vr.get("n_added",0),
            "rows_removed":   vr.get("n_removed",0),
            "vars_with_diffs":vr.get("n_vars_changed",0),
        })

    st.session_state.update({
        "cmp_all_results":  all_results,
        "cmp_summary":      pd.DataFrame(summary_rows),
        "cmp_selected":     selected_ds,
        "cmp_only_in_a":    only_in_a,
        "cmp_only_in_b":    only_in_b,
    })
    progress.progress(100)

if "cmp_all_results" not in st.session_state:
    st.stop()

all_results  = st.session_state["cmp_all_results"]
cmp_summary  = st.session_state["cmp_summary"]

# Allow switching datasets after run
if len(matched) > 1:
    selected_ds = st.selectbox("View results for:", matched, key="cmp_view_sel")
else:
    selected_ds = matched[0]

curr = all_results.get(selected_ds)
if curr is None:
    st.error(f"Could not load {selected_ds}.")
    st.stop()

meta_diff     = curr["meta_diff"]
value_results = curr["value_results"]
shape_a       = curr["shape_a"]
shape_b       = curr["shape_b"]
name_a, name_b = "A", "B"

n_same    = int((meta_diff["status"]=="SAME").sum()) if not meta_diff.empty else 0
n_dtype   = int((meta_diff["status"]=="DTYPE_CHANGED").sum()) if not meta_diff.empty else 0
n_only_a  = int(meta_diff["status"].str.startswith("ONLY_IN_A").sum()) if not meta_diff.empty else 0
n_only_b  = int(meta_diff["status"].str.startswith("ONLY_IN_B").sum()) if not meta_diff.empty else 0
n_added   = value_results.get("n_added",0)
n_removed = value_results.get("n_removed",0)
n_vchg    = value_results.get("n_vars_changed",0)

st.subheader(f"Results: {selected_ds}")
st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">A: {shape_a[0]:,} rows × {shape_a[1]} cols</div></div>'
    f'<div class="metric-item"><div class="label">B: {shape_b[0]:,} rows × {shape_b[1]} cols</div></div>'
    f'<div class="metric-item"><div class="label">Same vars</div>'
    f'<div class="value" style="color:{C["pass_fg"]};">{n_same}</div></div>'
    f'<div class="metric-item"><div class="label">Dtype changed</div>'
    f'<div class="value" style="color:{C["warn_fg"]};">{n_dtype}</div></div>'
    f'<div class="metric-item"><div class="label">Only in A</div>'
    f'<div class="value" style="color:{C["warn_fg"]};">{n_only_a}</div></div>'
    f'<div class="metric-item"><div class="label">Only in B</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{n_only_b}</div></div>'
    f'<div class="metric-item"><div class="label">Rows added</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{n_added:,}</div></div>'
    f'<div class="metric-item"><div class="label">Rows removed</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_removed:,}</div></div>'
    f'<div class="metric-item"><div class="label">Vars with diffs</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_vchg}</div></div>'
    f'</div>',
    unsafe_allow_html=True
)

# ── Download ──────────────────────────────────────────────────────────────
col_dl1, col_dl2 = st.columns(2)
with col_dl1:
    report_bytes = export_comparison_report(meta_diff, value_results, "A", "B")
    st.download_button(
        f"⬇ Download Report: {selected_ds} (.xlsx)",
        data=report_bytes,
        file_name=f"Compare_{selected_ds}_{datetime.now():%Y%m%d_%H%M}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True,
    )
with col_dl2:
    # Summary across all datasets
    summary_csv = cmp_summary.to_csv(index=False).encode()
    st.download_button(
        "⬇ Download All Datasets Summary (.csv)",
        data=summary_csv,
        file_name=f"Compare_Summary_{datetime.now():%Y%m%d_%H%M}.csv",
        mime="text/csv",
        use_container_width=True,
    )

st.divider()

# ── Charts ────────────────────────────────────────────────────────────────
if HAS_PLOTLY and len(matched) > 1:
    with st.expander("Cross-dataset summary", expanded=True):
        fig_sum = px.bar(
            cmp_summary[cmp_summary["status"]=="COMPARED"],
            x="dataset",
            y=["vars_only_a","vars_only_b","dtype_changed","vars_with_diffs"],
            barmode="group",
            title="Differences across all compared datasets",
            color_discrete_sequence=["#f59e0b","#60a5fa","#a78bfa","#f87171"],
            height=280,
        )
        fig_sum.update_layout(template="plotly_dark", margin=dict(l=0,r=0,t=36,b=0),
                               paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        fig_sum.update_xaxes(tickangle=-30)
        st.plotly_chart(fig_sum, use_container_width=True)

if HAS_PLOTLY:
    c1, c2 = st.columns(2)
    with c1:
        if not meta_diff.empty:
            vc = meta_diff["status"].value_counts().reset_index()
            vc.columns = ["status","count"]
            cmap = {"SAME":"#4ade80","DTYPE_CHANGED":"#fbbf24",
                    "ONLY_IN_A":"#f59e0b","ONLY_IN_B":"#60a5fa"}
            fig1 = px.pie(vc, names="status", values="count", color="status",
                          color_discrete_map=cmap, title="Metadata Changes",
                          hole=0.4, height=260)
            fig1.update_layout(template="plotly_dark", margin=dict(l=0,r=0,t=36,b=0),
                                paper_bgcolor="rgba(0,0,0,0)")
            st.plotly_chart(fig1, use_container_width=True)
    with c2:
        vr_summ = value_results.get("summary", pd.DataFrame())
        if not vr_summ.empty and n_vchg > 0:
            top_n = vr_summ[vr_summ["different"]>0].head(15)
            fig2 = px.bar(top_n, x="variable", y="different",
                          title="Top Variables by Value Differences",
                          color="pct_different", color_continuous_scale=["#4ade80","#ef4444"],
                          height=260)
            fig2.update_layout(template="plotly_dark", margin=dict(l=0,r=0,t=36,b=0),
                                paper_bgcolor="rgba(0,0,0,0)", showlegend=False)
            fig2.update_xaxes(tickangle=-35)
            st.plotly_chart(fig2, use_container_width=True)

# ── Tabs ──────────────────────────────────────────────────────────────────
tabs = st.tabs(["Metadata Diff","Value Summary","Changed Values","Added Rows","Removed Rows","All Datasets Summary"])

def _meta_rc(row):
    s = str(row.get("status",""))
    if s=="SAME": return "row-pass"
    if "ONLY_IN_A" in s: return "row-warning"
    if "ONLY_IN_B" in s: return "row-dt"
    if "DTYPE" in s: return "row-warning"
    return ""

def _val_rc(row):
    n = int(row.get("different",0))
    if n == 0: return "row-pass"
    return "row-miss" if float(row.get("pct_different",0))>50 else "row-warning"

with tabs[0]:
    sf = st.selectbox("Filter status",["All","SAME","DTYPE_CHANGED","ONLY_IN_A","ONLY_IN_B"], key="meta_sf6")
    dm = meta_diff if sf=="All" else meta_diff[meta_diff["status"]==sf]
    st.caption(f"{len(dm)} variables")
    st.markdown(render_table(dm, row_class_fn=_meta_rc), unsafe_allow_html=True)

with tabs[1]:
    summ = value_results.get("summary", pd.DataFrame())
    if summ.empty:
        st.info("Value comparison not run or no common variables.")
    else:
        show_d = st.checkbox("Show only variables with differences", value=True, key="val_d6")
        ds6    = summ[summ["different"]>0] if show_d else summ
        st.markdown(render_table(ds6, row_class_fn=_val_rc), unsafe_allow_html=True)

with tabs[2]:
    chg = value_results.get("changed_values", pd.DataFrame())
    if chg is None or chg.empty:
        st.info("No value differences found.")
    else:
        var_opts = ["All"] + sorted(chg["variable"].unique().tolist()) if "variable" in chg.columns else ["All"]
        vs = st.selectbox("Variable", var_opts, key="chg_var6")
        dc = chg if vs=="All" else chg[chg["variable"]==vs]
        st.markdown(render_table(dc, row_class_fn=lambda r: "row-miss", max_rows=500), unsafe_allow_html=True)

with tabs[3]:
    added = value_results.get("added_rows", pd.DataFrame())
    if added is None or added.empty:
        st.success("No added rows.")
    else:
        st.caption(f"{len(added):,} rows in B not in A")
        st.markdown(render_table(added, row_class_fn=lambda r: "row-dt", max_rows=500), unsafe_allow_html=True)

with tabs[4]:
    removed = value_results.get("removed_rows", pd.DataFrame())
    if removed is None or removed.empty:
        st.success("No removed rows.")
    else:
        st.caption(f"{len(removed):,} rows in A not in B")
        st.markdown(render_table(removed, row_class_fn=lambda r: "row-warning", max_rows=500), unsafe_allow_html=True)

with tabs[5]:
    st.caption("Summary across all compared datasets in this session")
    st.dataframe(cmp_summary, use_container_width=True, height=350)
