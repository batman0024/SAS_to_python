# pages/3_Define_Helper.py
"""
Define Helper page.
Extracts variable metadata and value-level from SAS datasets.
Ports Define.sas - supports SDTM and ADaM modes.
Uses file upload instead of path text input.
"""

import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from datetime import datetime

import pandas as pd
import streamlit as st

from core.define_helper import (
    get_column_metadata,
    get_value_level,
    build_where_clause_table,
)
from core.excel_export import export_define_results

st.set_page_config(page_title="Define Helper", layout="wide")
st.title("Define Helper")
st.caption(
    "Extracts variable list, value-level entries, and where-clause table "
    "from SAS datasets to assist Define-XML spec preparation."
)

col1, col2, col3 = st.columns([2, 1, 1])
with col1:
    lib_files = st.file_uploader(
        "Upload SAS datasets (.sas7bdat)",
        type=["sas7bdat"],
        accept_multiple_files=True,
        help="Upload all domain datasets from your SDTM or ADaM library. "
             "Variable metadata is read without loading data rows.",
    )
with col2:
    mode = st.radio("Mode", ["SDTM", "ADaM"], horizontal=True)
with col3:
    run_value_level = st.checkbox(
        "Extract value-level (loads data rows)",
        value=True,
        help="Value-level extraction reads actual dataset rows for TESTCD/QNAM/PARAMCD. "
             "Uncheck for variable metadata only.",
    )

if not lib_files:
    st.info("Upload one or more .sas7bdat files to generate the Define helper output.")
    st.stop()

if st.button("Generate", type="primary", use_container_width=True):
    with tempfile.TemporaryDirectory() as tmpdir:
        for uf in lib_files:
            dest_path = Path(tmpdir) / uf.name
            dest_path.write_bytes(uf.read())

        with st.spinner("Reading variable metadata..."):
            try:
                columns_df = get_column_metadata(tmpdir)
                st.session_state["define_columns"] = columns_df
            except Exception as exc:
                st.error(f"Cannot read files: {exc}")
                st.exception(exc)
                st.stop()

        if run_value_level and not columns_df.empty:
            with st.spinner("Extracting value-level data..."):
                try:
                    value_level = get_value_level(tmpdir, columns_df, mode)
                    where_clause = build_where_clause_table(value_level, mode)
                    st.session_state["define_value_level"] = value_level
                    st.session_state["define_where_clause"] = where_clause
                except Exception as exc:
                    st.warning(f"Value-level extraction failed: {exc}")
                    st.session_state["define_value_level"] = None
                    st.session_state["define_where_clause"] = None
        else:
            st.session_state["define_value_level"] = None
            st.session_state["define_where_clause"] = None

if "define_columns" not in st.session_state:
    st.info("Click 'Generate' to extract metadata from the uploaded files.")
    st.stop()

columns_df = st.session_state.get("define_columns")
value_level = st.session_state.get("define_value_level")
where_clause = st.session_state.get("define_where_clause")

if columns_df is None or columns_df.empty:
    st.warning("No variables found. Ensure .sas7bdat files were uploaded correctly.")
    st.stop()

# Metrics
n_domains = columns_df["domain"].nunique() if "domain" in columns_df.columns else 0
n_vars = len(columns_df)
n_vl = len(value_level) if value_level is not None else 0

m1, m2, m3 = st.columns(3)
m1.metric("Domains", n_domains)
m2.metric("Variables", n_vars)
m3.metric("Value-level rows", n_vl)

# Download
excel_bytes = export_define_results(
    columns_df,
    value_level if value_level is not None else pd.DataFrame(),
    where_clause if where_clause is not None else pd.DataFrame(),
)
st.download_button(
    label="Download Define Helper (.xlsx)",
    data=excel_bytes,
    file_name=f"Define_{mode}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)

st.divider()

tab1, tab2, tab3 = st.tabs(["Variable", "Value Level", "Where Clause"])

with tab1:
    dom_opts = ["All"] + sorted(columns_df["domain"].unique().tolist()) \
        if "domain" in columns_df.columns else ["All"]
    dom_sel = st.selectbox("Filter by domain", dom_opts, key="def_dom")
    disp = columns_df if dom_sel == "All" else columns_df[columns_df["domain"] == dom_sel]
    st.dataframe(disp, use_container_width=True, height=450)

with tab2:
    if value_level is None or value_level.empty:
        st.info("Value-level extraction was not run or returned no results.")
    else:
        dom_opts2 = ["All"] + sorted(value_level["dataset"].unique().tolist()) \
            if "dataset" in value_level.columns else ["All"]
        dom_sel2 = st.selectbox("Filter by domain", dom_opts2, key="def_vl_dom")
        disp2 = value_level if dom_sel2 == "All" else value_level[value_level["dataset"] == dom_sel2]
        st.dataframe(disp2, use_container_width=True, height=450)

with tab3:
    if where_clause is None or where_clause.empty:
        st.info("Where-clause table not generated.")
    else:
        st.dataframe(where_clause, use_container_width=True, height=450)
