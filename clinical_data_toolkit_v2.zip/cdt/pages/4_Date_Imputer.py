# pages/4_Date_Imputer.py
"""
AE Date Imputer page.
Imputes partial/missing AE dates per SAP rules.
Full datetime records (YYYY-MM-DDTHH:MM:SS) are passed through as-is.

FIXES vs original:
- ASTDTM, AENDTM, ASTTM, AENTM now included in output display and CSV download.
- TRTSDT SAS numeric date (days since 1960-01-01) is auto-detected and converted
  to a proper date before imputation.
- File upload instead of path input.
- Run toggle: OFF = parse only, no imputation rules applied.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import io
from datetime import datetime, date

import pandas as pd
import numpy as np
import streamlit as st

from core.date_imputer import impute_ae_dates, build_imputation_summary, RULE_LABELS

st.set_page_config(page_title="Date Imputer", layout="wide")

st.markdown("""
<style>
.imp-table { width:100%; border-collapse:collapse; font-size:12px; font-family:'Courier New',monospace; }
.imp-table th { background:#1e293b; color:#f1f5f9; padding:8px 10px; text-align:left; font-size:11px; position:sticky; top:0; }
.imp-table td { padding:6px 10px; border-bottom:1px solid rgba(148,163,184,.12); }
.imp-table tr.pass td  { background:#f0fdf4; }
.imp-table tr.part td  { background:#fffbeb; }
.imp-table tr.miss td  { background:#fff1f2; }
.imp-table tr.dt td    { background:#eff6ff; }
.imp-table tr.even td  { background:#f8fafc; }
.imp-scroll { max-height:440px; overflow-y:auto; border:1px solid rgba(148,163,184,.25); border-radius:8px; }
</style>
""", unsafe_allow_html=True)

st.title("AE Date Imputer")
st.caption(
    "Imputes partial/missing AE start and stop dates per SAP rules. "
    "Complete datetime strings (YYYY-MM-DDTHH:MM:SS) are kept as-is without imputation."
)

# ---- Run toggle ----
run_imputation = st.toggle(
    "Enable imputation",
    value=True,
    help="When OFF, the file is parsed and ISO dates extracted but no imputation rules are applied. "
         "Use this to verify the input dataset structure before running.",
)

st.divider()

# ---- File upload + column config ----
col1, col2 = st.columns([2, 1])
with col1:
    ae_file = st.file_uploader(
        "Upload AE dataset (.sas7bdat or .csv)",
        type=["sas7bdat", "csv"],
        help="The AE (Adverse Events) dataset. Must contain the start DTC, stop DTC, "
             "and treatment start date columns configured on the right.",
    )
with col2:
    st.markdown("**Column names**")
    startc  = st.text_input("Start date (char ISO)", value="AESTDTC",
                             help="Character variable in ISO 8601 format: YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS")
    stopc   = st.text_input("Stop date  (char ISO)", value="AEENDTC",
                             help="Character variable in ISO 8601 format.")
    trtsdt  = st.text_input("First dose date (numeric SAS date)", value="TRTSDT",
                             help="Numeric SAS date (days since 01Jan1960). Auto-converted before imputation.")
    prefix  = st.text_input("Output variable prefix", value="AE",
                             help="Prefix for derived output variables: {prefix}_START_RULE, etc.")
    skip_dt = st.checkbox(
        "Pass through datetime strings without imputation",
        value=True,
        help="When YYYY-MM-DDTHH:MM:SS is present in start/stop, keep as-is. "
             "This matches the intended SAS macro behaviour.",
    )

if ae_file is None:
    st.info("Upload an AE dataset (.sas7bdat or .csv) to begin.")
    st.stop()


# ---- SAS numeric date converter ----
SAS_EPOCH = pd.Timestamp("1960-01-01")

def _convert_sas_numeric_date(series: pd.Series) -> pd.Series:
    """
    Convert a SAS numeric date column (days since 1960-01-01) to pd.Timestamp.
    Handles: already-datetime, already-date string, raw SAS integer/float.
    """
    def _conv(v):
        if pd.isna(v):
            return pd.NaT
        # Already a Timestamp
        if isinstance(v, (pd.Timestamp, datetime, date)):
            return pd.Timestamp(v)
        # String that looks like a date
        s = str(v).strip()
        if "-" in s or "/" in s:
            try:
                return pd.Timestamp(s)
            except Exception:
                pass
        # Try as SAS numeric (days since 1960-01-01)
        try:
            n = float(s)
            # Sanity check: SAS dates for 1950-2050 range roughly 0-33000
            # A raw year like 2023 would be treated as days = year 7493 which is wrong
            # Only convert if value looks like a SAS offset (roughly -5000 to 40000)
            if -5000 <= n <= 50000:
                return SAS_EPOCH + pd.Timedelta(days=int(n))
            # Could be a year-as-integer edge case
            return pd.NaT
        except (ValueError, TypeError):
            return pd.NaT
    return series.apply(_conv)


# ---- Dataset loader ----
@st.cache_data
def load_ae_dataset(file_bytes: bytes, filename: str) -> pd.DataFrame:
    if filename.lower().endswith(".sas7bdat"):
        try:
            import pyreadstat
            df, _ = pyreadstat.read_sas7bdat(io.BytesIO(file_bytes))
            df.columns = [c.upper() for c in df.columns]
            return df
        except Exception as exc:
            raise ValueError(f"Cannot read SAS dataset: {exc}") from exc
    if filename.lower().endswith(".csv"):
        df = pd.read_csv(io.BytesIO(file_bytes))
        df.columns = [c.upper() for c in df.columns]
        return df
    raise ValueError("Unsupported file type. Upload .sas7bdat or .csv")


try:
    ae_bytes = ae_file.read()
    ae_df = load_ae_dataset(ae_bytes, ae_file.name)
except Exception as exc:
    st.error(str(exc))
    st.stop()

st.success(f"Loaded: **{ae_file.name}** — {len(ae_df):,} rows, {len(ae_df.columns)} columns")

# ---- Column presence check ----
missing_cols = [c for c in [startc, stopc, trtsdt] if c not in ae_df.columns]
if missing_cols:
    available = sorted(ae_df.columns.tolist())
    st.error(f"Column(s) not found: **{missing_cols}**")
    with st.expander("Available columns in uploaded file"):
        st.write(available)
    st.stop()

# ---- Convert TRTSDT from SAS numeric to Timestamp ----
ae_df[trtsdt] = _convert_sas_numeric_date(ae_df[trtsdt])

# ---- Preview ----
with st.expander("Preview input data (first 10 rows)", expanded=False):
    prev_cols = [c for c in [startc, stopc, trtsdt] if c in ae_df.columns]
    id_cols   = [c for c in ["USUBJID", "SUBJID", "AESEQ"] if c in ae_df.columns]
    other     = [c for c in ae_df.columns if c not in prev_cols + id_cols][:4]
    show_cols = id_cols + prev_cols + other
    st.dataframe(ae_df[show_cols].head(10), use_container_width=True)

st.divider()

# ---- Run button ----
run_btn = st.button(
    "Run Imputation" if run_imputation else "Parse Dates Only (Imputation OFF)",
    type="primary",
    use_container_width=True,
)

if run_btn:
    with st.spinner("Processing..."):
        try:
            result = impute_ae_dates(
                ae_df,
                startc=startc,
                stopc=stopc,
                trtsdt=trtsdt,
                prefix=prefix,
                skip_if_has_time=skip_dt,
            )
            # If imputation is toggled OFF, zero out rule labels but keep date parsing
            if not run_imputation:
                rule_col_name = f"{prefix}_START_RULE"
                if rule_col_name in result.columns:
                    result[rule_col_name] = result[rule_col_name].apply(
                        lambda r: r if r in (-1, 0) else np.nan
                    )
            st.session_state["imputer_result"] = result
            st.session_state["imputer_prefix"] = prefix
            st.session_state["imputer_startc"] = startc
            st.session_state["imputer_stopc"] = stopc
            st.session_state["imputer_trtsdt"] = trtsdt
        except Exception as exc:
            st.error(f"Processing failed: {exc}")
            st.exception(exc)

if "imputer_result" not in st.session_state:
    st.info("Click the button above to process the dataset.")
    st.stop()

result: pd.DataFrame = st.session_state["imputer_result"]
p       = st.session_state.get("imputer_prefix", "AE")
startc  = st.session_state.get("imputer_startc", "AESTDTC")
stopc   = st.session_state.get("imputer_stopc",  "AEENDTC")
trtsdt  = st.session_state.get("imputer_trtsdt", "TRTSDT")

# ---- Summary cards ----
rule_summary = build_imputation_summary(result, prefix=p)
st.subheader("Imputation Summary")

summary_items = [(lbl, cnt) for lbl, cnt in rule_summary.items() if cnt > 0]
if summary_items:
    cols_s = st.columns(min(len(summary_items), 4))
    for col_s, (label, count) in zip(cols_s, summary_items):
        short = label[:38] + "..." if len(label) > 38 else label
        col_s.metric(short, count)
else:
    st.info("No imputation was applied (all dates were full or passthrough).")

# Colour legend
st.markdown("""
<div style="display:flex;gap:18px;font-size:12px;margin:6px 0 4px;align-items:center;">
  <span style="background:#eff6ff;padding:2px 10px;border-radius:4px;border:1px solid #bfdbfe;">Blue = datetime passthrough</span>
  <span style="background:#f0fdf4;padding:2px 10px;border-radius:4px;border:1px solid #bbf7d0;">Green = full date, no change</span>
  <span style="background:#fffbeb;padding:2px 10px;border-radius:4px;border:1px solid #fde68a;">Amber = partial date imputed</span>
  <span style="background:#fff1f2;padding:2px 10px;border-radius:4px;border:1px solid #fecaca;">Red = missing/year imputed</span>
</div>
""", unsafe_allow_html=True)

st.divider()

# ---- Build output column list (ALL datetime variables included) ----
id_display   = [c for c in ["USUBJID", "SUBJID", "AESEQ"] if c in result.columns]
input_cols   = [c for c in [startc, stopc, trtsdt] if c in result.columns]

# Start date outputs
start_outputs = [c for c in ["ASTDT", "ASTDTC", "ASTDTF", "ASTTM", "ASTDTM"] if c in result.columns]
# Stop date outputs
stop_outputs  = [c for c in ["AENDT", "AENDTC", "AENDTF", "AENTM", "AENDTM"] if c in result.columns]
# Flags and rule
flag_cols     = [c for c in [
    f"{p}_START_RULE", f"{p}_STOP_IMPFL", f"{p}_STOP_ONGOING", f"{p}_REL_STOP_TO_TRT"
] if c in result.columns]

all_output_cols = id_display + input_cols + start_outputs + stop_outputs + flag_cols

# Add readable rule label
rule_col_disp = f"{p}_START_RULE"
if rule_col_disp in result.columns:
    result["_rule_label"] = result[rule_col_disp].map(RULE_LABELS).fillna("")
    all_output_cols.append("_rule_label")

all_output_cols = [c for c in all_output_cols if c in result.columns]


def _row_class(rule_val) -> str:
    try:
        r = float(rule_val) if pd.notna(rule_val) else 0
    except (TypeError, ValueError):
        r = 0
    if r == -1:
        return "dt"
    if r == 0:
        return "pass"
    if r in (1.0, 2.0):
        return "part"
    return "miss"


def _render_imp_table(df: pd.DataFrame, max_rows: int = 500) -> str:
    """Render imputation result as a styled HTML table."""
    cols = all_output_cols
    present = [c for c in cols if c in df.columns]
    header = "".join(f"<th>{c}</th>" for c in present)
    rows_html = []
    rule_c = f"{p}_START_RULE"
    for i, (_, row) in enumerate(df.head(max_rows).iterrows()):
        rv = row.get(rule_c, np.nan)
        row_cls = _row_class(rv)
        if row_cls == "pass" and i % 2 == 0:
            row_cls = "even"
        cells = []
        for col in present:
            v = row.get(col, "")
            if pd.isna(v) or v != v:
                v = ""
            elif isinstance(v, pd.Timestamp):
                v = v.strftime("%Y-%m-%d %H:%M") if v.hour or v.minute else v.strftime("%Y-%m-%d")
            else:
                v = str(v)
            cells.append(f"<td>{v}</td>")
        rows_html.append(f'<tr class="{row_cls}">{"".join(cells)}</tr>')

    if len(df) > max_rows:
        rows_html.append(
            f'<tr><td colspan="{len(present)}" style="text-align:center;color:#64748b;padding:10px;">'
            f'... {len(df)-max_rows} more rows in download</td></tr>'
        )
    return (
        '<div class="imp-scroll">'
        f'<table class="imp-table"><thead><tr>{header}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table></div>'
    )


tab1, tab2 = st.tabs([
    f"All Records ({len(result):,})",
    f"Imputed Only",
])

with tab1:
    st.markdown(_render_imp_table(result), unsafe_allow_html=True)

with tab2:
    rule_c2 = f"{p}_START_RULE"
    if rule_c2 in result.columns:
        imputed_only = result[
            result[rule_c2].notna() &
            (~result[rule_c2].isin([0, -1]))
        ]
    else:
        imputed_only = result.head(0)
    st.caption(f"{len(imputed_only):,} records had imputation applied (rule not 0 or passthrough)")
    if imputed_only.empty:
        st.success("No records required imputation — all dates were complete.")
    else:
        st.markdown(_render_imp_table(imputed_only), unsafe_allow_html=True)

# ---- Downloads ----
st.divider()
dl1, dl2 = st.columns(2)

# CSV — all output columns including datetime
csv_out = result[all_output_cols].copy()
# Format Timestamps to strings for CSV
for col in csv_out.columns:
    if pd.api.types.is_datetime64_any_dtype(csv_out[col]):
        csv_out[col] = csv_out[col].dt.strftime("%Y-%m-%dT%H:%M:%S").fillna("")

csv_bytes = csv_out.to_csv(index=False).encode("utf-8")
with dl1:
    st.download_button(
        label="Download Imputed Dataset (.csv)",
        data=csv_bytes,
        file_name=f"AE_imputed_{datetime.now():%Y%m%d_%H%M}.csv",
        mime="text/csv",
        use_container_width=True,
    )

# CSV — imputed-only rows
if not imputed_only.empty:
    csv_imp = imputed_only[all_output_cols].copy()
    for col in csv_imp.columns:
        if pd.api.types.is_datetime64_any_dtype(csv_imp[col]):
            csv_imp[col] = csv_imp[col].dt.strftime("%Y-%m-%dT%H:%M:%S").fillna("")
    csv_imp_bytes = csv_imp.to_csv(index=False).encode("utf-8")
    with dl2:
        st.download_button(
            label="Download Imputed-Only Rows (.csv)",
            data=csv_imp_bytes,
            file_name=f"AE_imputed_only_{datetime.now():%Y%m%d_%H%M}.csv",
            mime="text/csv",
            use_container_width=True,
        )
