# pages/2_Raw_Coverage.py
"""
Raw variable coverage page.
Maps raw CRF variables to SDTM spec input_variables references.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tempfile
from datetime import datetime

import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from core.raw_coverage import run_raw_coverage
from core.excel_export import export_coverage_results

st.set_page_config(page_title="Raw Coverage", layout="wide")
st.title("Raw Variable Coverage")
st.caption(
    "Maps raw CRF variables to SDTM spec input_variables references. "
    "Shows EXACT / PARTIAL / UNMAPPED per variable."
)

if "spec" not in st.session_state:
    st.warning("Upload a mapping specification in the sidebar first.")
    st.stop()

spec = st.session_state["spec"]
spec_name = st.session_state.get("spec_name", "spec")

col1, col2 = st.columns([2, 1])
with col1:
    raw_files = st.file_uploader(
        "Upload raw CRF datasets (.sas7bdat)",
        type=["sas7bdat"],
        accept_multiple_files=True,
        help="Upload all raw domain datasets. Variable names are collected from each file.",
    )
with col2:
    active_filter = st.text_input("Active flag value", value="Y")
    extra_excl = st.text_input(
        "Additional exclude vars (comma-separated)",
        value="",
        placeholder="SUBJIDNUM, PAGENO",
    )

extra_set = set()
if extra_excl.strip():
    extra_set = {v.strip().upper() for v in extra_excl.split(",") if v.strip()}

if not raw_files:
    st.info("Upload raw CRF .sas7bdat files to begin.")
    st.stop()

# Build a temporary directory-like structure from uploaded files
import tempfile, shutil

if st.button("Run Coverage Check", type="primary", use_container_width=True):
    with st.spinner("Scanning raw files and spec..."):
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                for uf in raw_files:
                    dest = Path(tmpdir) / uf.name
                    dest.write_bytes(uf.read())
                cov_results = run_raw_coverage(
                    tmpdir,
                    spec,
                    active_filter=active_filter,
                    exclude_vars=extra_set,
                )
            st.session_state["cov_results"] = cov_results
        except Exception as exc:
            st.error(f"Coverage check failed: {exc}")
            st.exception(exc)

if "cov_results" not in st.session_state:
    st.info("Click 'Run Coverage Check' to begin.")
    st.stop()

cov = st.session_state["cov_results"]
coverage: pd.DataFrame = cov.get("coverage", pd.DataFrame())
summary: pd.DataFrame = cov.get("summary", pd.DataFrame())

if coverage.empty:
    st.warning("No raw variables found. Check the library path.")
    st.stop()

# --- Metrics ---
total = len(coverage)
n_exact = int((coverage["status"] == "EXACT").sum())
n_partial = int((coverage["status"] == "PARTIAL").sum())
n_unmapped = int((coverage["status"] == "UNMAPPED").sum())
pct = round((n_exact + n_partial) / total * 100, 1) if total else 0

m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("Total Raw Vars", total)
m2.metric("EXACT", n_exact)
m3.metric("PARTIAL", n_partial)
m4.metric("UNMAPPED", n_unmapped)
m5.metric("% Covered", f"{pct}%")

# --- Chart ---
if HAS_PLOTLY and not summary.empty:
    with st.expander("Coverage by dataset", expanded=True):
        chart_data = summary.melt(
            id_vars=["raw_dataset"],
            value_vars=["EXACT", "PARTIAL", "UNMAPPED"],
            var_name="status",
            value_name="count",
        )
        fig = px.bar(
            chart_data, x="raw_dataset", y="count", color="status",
            color_discrete_map={
                "EXACT": "#22C55E",
                "PARTIAL": "#F59E0B",
                "UNMAPPED": "#EF4444",
            },
            barmode="stack",
            title="Variable coverage per raw dataset",
            height=320,
        )
        st.plotly_chart(fig, use_container_width=True)

# --- Download ---
excel_bytes = export_coverage_results(coverage, summary)
st.download_button(
    label="Download Coverage Report (.xlsx)",
    data=excel_bytes,
    file_name=f"RawCoverage_{spec_name.replace('.xlsx','')}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)

st.divider()

# --- Table ---
tab1, tab2 = st.tabs(["Variable Detail", "Dataset Summary"])

with tab1:
    col_f1, col_f2 = st.columns(2)
    with col_f1:
        status_filter = st.selectbox(
            "Filter by status",
            ["All", "EXACT", "PARTIAL", "UNMAPPED"],
            key="cov_status",
        )
    with col_f2:
        ds_options = ["All"] + sorted(coverage["raw_dataset"].unique().tolist())
        ds_filter = st.selectbox("Filter by dataset", ds_options, key="cov_ds")

    disp = coverage.copy()
    if status_filter != "All":
        disp = disp[disp["status"] == status_filter]
    if ds_filter != "All":
        disp = disp[disp["raw_dataset"] == ds_filter]

    def _colour_cov(row):
        s = row.get("status", "")
        if s == "EXACT":
            return ["background-color: #D1FAE5"] * len(row)
        if s == "PARTIAL":
            return ["background-color: #FEF3C7"] * len(row)
        if s == "UNMAPPED":
            return ["background-color: #FECACA"] * len(row)
        return [""] * len(row)

    st.caption(f"Showing {len(disp)} of {len(coverage)} variables")
    st.dataframe(
        disp.style.apply(_colour_cov, axis=1),
        use_container_width=True,
        height=450,
    )

with tab2:
    if summary.empty:
        st.info("No summary available.")
    else:
        st.dataframe(summary, use_container_width=True)
