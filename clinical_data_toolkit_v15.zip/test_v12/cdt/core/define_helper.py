# core/define_helper.py  v14
"""
Complete rebuild addressing all requirements:

1. METADATA (PROC CONTENTS equivalent)
   - Domain, Variable, Label, Type (char/numeric), Length, Format
   - Reads SAS7BDAT, XPT, CSV
   - Never raises, always returns (DataFrame, errors)

2. VLM / CODELIST  ← source of truth, DO NOT CHANGE LOGIC
   - Per (domain, variable) with codelist in spec
   - Actual data stats + CT values from Codelist tab
   - Active=N values ARE included (Active is codelist-level only)

3. CT COMPARISON  ← rebuilt using VLM matching logic
   - Dataset-level: all variables across all domains
   - Same matching as VLM (case-insensitive, original case preserved)
   - Excludes: MedDRA, WHODrug, result vars (--STRESC, --ORRES), free-text
   - mismatch_type: NOT_IN_CT / CASE_MISMATCH
   - Blank/empty SAS values excluded
   - Max 50 unique values per variable

4. VALUE LEVEL (TESTCD/QNAM/PARAMCD from data)
   - Scans file headers directly (no columns_df dependency)
   - Returns (DataFrame, errors) tuple
   - PARAMCD not PARMCD

5. DEFINE-XML v2.1 (full rebuild)
   - CDISC-compliant structure
   - ItemGroupDef, ItemDef, ValueListDef, WhereClauseDef, CodeListDef
   - Reads spec's own ValueList sheet (Image 4) for VLM entries
   - XSL stylesheet reference
   - No duplicates, proper hierarchy
"""
import io
import logging
import re
import warnings
from collections import defaultdict, OrderedDict
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import pandas as pd
import numpy as np

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)

# ── Constants ──────────────────────────────────────────────────────────────────
EXCLUDE_DOMAIN_PREFIXES  = ("_",)
MAX_CT_UNIQUE_PER_VAR    = 50
MAX_SAMPLE_DISPLAY       = 20

# MedDRA detection
MEDDRA_SOURCE_PATTERNS   = ["MEDDRA", "MEDDR"]
MEDDRA_CODELIST_PATTERNS = ["MEDDRA", "LLTCD", "HLGTCD", "HLTCD", "SOCCD", "PTCD"]

# WHODrug detection
WHODD_SOURCE_PATTERNS    = ["WHODD", "WHO DRUG", "WHO DD", "WHODRUG"]
WHODD_CODELIST_PATTERNS  = ["WHODD", "WHO_DD", "WHODRUG"]

# Result variables to exclude from CT comparison (free-text / numeric)
RESULT_VAR_SUFFIXES = (
    "ORRES", "STRESC", "STRESN", "STRESU", "LBORRES", "LBSTRESC", "LBSTRESN",
    "RSTRESN", "RSORRES", "VSSTRESC", "VSORRES", "EGSTRESN", "EGORRES",
    "PCSTRESN", "PPORRES", "PPSTRESN", "FAORRES",
)
# Patterns for free-text variables excluded from CT
FREETEXT_VAR_PATTERNS = re.compile(
    r"(REAS|SPECIFY|TEXT|COMM|NOTE|NARR|VERBATIM|TERM|MODIFY|DETAIL|DESCR|TITLE)",
    re.IGNORECASE
)


def _is_meddra_codelist(cl_name: str, source: str = "") -> bool:
    n = cl_name.upper(); s = source.upper()
    if any(p in s for p in MEDDRA_SOURCE_PATTERNS): return True
    for p in MEDDRA_CODELIST_PATTERNS:
        if n == p or n.startswith(p + "_") or n.endswith("_" + p): return True
    return False


def _is_whodd_codelist(cl_name: str, source: str = "") -> bool:
    n = cl_name.upper(); s = source.upper()
    if any(p in s for p in WHODD_SOURCE_PATTERNS): return True
    for p in WHODD_CODELIST_PATTERNS:
        if n == p or n.startswith(p + "_") or n.endswith("_" + p): return True
    return False


def _is_result_var(var: str) -> bool:
    """True if variable is a result/numeric/free-text variable to exclude from CT."""
    v = var.upper()
    if any(v.endswith(sfx.upper()) for sfx in RESULT_VAR_SUFFIXES): return True
    if FREETEXT_VAR_PATTERNS.search(v): return True
    return False


def _supported_ext(fname: str) -> bool:
    return fname.lower().endswith((".sas7bdat", ".xpt", ".v5", ".csv"))


# ══════════════════════════════════════════════════════════════════════════════
# FILE LOADING
# ══════════════════════════════════════════════════════════════════════════════

def _load_file(
    fdata: bytes,
    fname: str,
    usecols: Optional[List[str]] = None,
) -> Tuple[pd.DataFrame, Optional[Any], str]:
    """
    Load SAS7BDAT / XPT / CSV from bytes.
    Returns (df, meta_or_None, error_string). Never raises.
    """
    if not fdata:
        return pd.DataFrame(), None, f"[{Path(fname).stem.upper()}] empty bytes"

    fl  = fname.lower()
    dom = Path(fname).stem.upper()
    errors = []

    # ── SAS7BDAT ─────────────────────────────────────────────────────────────
    if fl.endswith(".sas7bdat"):
        try:
            import pyreadstat
        except ImportError:
            errors.append("pyreadstat not installed — install with: pip install pyreadstat")
        else:
            for strat, kwargs in [("meta+full", {"metadataonly": True}),
                                   ("row_limit",  {"row_limit": 1}),
                                   ("direct",     {})]:
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kwargs)
                    col_names = _extract_col_names(meta)
                    if col_names:
                        kw = {"usecols": usecols} if usecols else {}
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore")
                            df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
                        df.columns = [c.upper() for c in df.columns]
                        return df, meta, ""
                    if strat == "meta+full":
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore")
                            df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
                        if len(df.columns) > 0:
                            df.columns = [c.upper() for c in df.columns]
                            if usecols:
                                uc = [c.upper() for c in usecols]
                                df = df[[c for c in uc if c in df.columns]]
                            return df, meta, ""
                    errors.append(f"pyreadstat {strat}: 0 columns")
                except Exception as e:
                    errors.append(f"pyreadstat {strat}: {type(e).__name__}: {e}")

        # pandas fallback
        try:
            df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
            df.columns = [c.upper() for c in df.columns]
            if usecols:
                uc = [c.upper() for c in usecols]
                df = df[[c for c in uc if c in df.columns]]
            if len(df.columns) > 0:
                return df, None, ""
            errors.append("pandas sas7bdat: 0 columns")
        except Exception as e:
            errors.append(f"pandas sas7bdat: {type(e).__name__}: {e}")

    # ── XPT ──────────────────────────────────────────────────────────────────
    elif fl.endswith(".xpt") or fl.endswith(".v5"):
        try:
            df = pd.read_sas(io.BytesIO(fdata), format="xport", encoding="latin-1")
            df.columns = [c.upper() for c in df.columns]
            if usecols:
                uc = [c.upper() for c in usecols]
                df = df[[c for c in uc if c in df.columns]]
            if len(df.columns) > 0:
                return df, None, ""
            errors.append("pandas xport: 0 columns")
        except Exception as e:
            errors.append(f"pandas xport: {type(e).__name__}: {e}")
            # Try pyreadstat for XPT
            try:
                import pyreadstat
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df, meta = pyreadstat.read_xport(io.BytesIO(fdata))
                df.columns = [c.upper() for c in df.columns]
                if len(df.columns) > 0:
                    return df, meta, ""
            except Exception as e2:
                errors.append(f"pyreadstat xport: {type(e2).__name__}: {e2}")

    # ── CSV ───────────────────────────────────────────────────────────────────
    elif fl.endswith(".csv"):
        try:
            kw = {"usecols": usecols} if usecols else {}
            df = pd.read_csv(io.BytesIO(fdata), low_memory=False, **kw)
            df.columns = [c.upper() for c in df.columns]
            return df, None, ""
        except Exception as e:
            errors.append(f"CSV: {type(e).__name__}: {e}")
    else:
        errors.append(f"Unsupported format: {fl}")

    return pd.DataFrame(), None, f"[{dom}] all strategies failed: {'; '.join(errors)}"


def _extract_col_names(meta) -> List[str]:
    for attr in ("column_names", "column_names_to_labels",
                 "readstat_variable_names", "variable_names"):
        val = getattr(meta, attr, None)
        if isinstance(val, list) and val: return val
        if isinstance(val, dict) and val: return list(val.keys())
    return []


def _clean_str_col(series: pd.Series) -> pd.Series:
    """Convert to str, strip whitespace, remove blanks/NaN/SAS missing."""
    excl = {"", "nan", "NaN", "NAN", ".", ".  ", "<NA>", "None", "none"}
    result = series.fillna("").astype(str).str.strip()
    return result[~result.isin(excl)]


def _safe_unique_sorted(series: pd.Series) -> List[str]:
    """Get sorted unique values as pure Python strings, capped at MAX_CT_UNIQUE_PER_VAR."""
    cleaned = _clean_str_col(series)
    unique  = sorted({str(v) for v in cleaned.unique()})
    return unique


# ══════════════════════════════════════════════════════════════════════════════
# METADATA (PROC CONTENTS equivalent)
# ══════════════════════════════════════════════════════════════════════════════

def get_column_metadata_from_store(
    files_store: Dict[str, bytes],
) -> Tuple[pd.DataFrame, List[str]]:
    """
    PROC CONTENTS equivalent: domain, variable, label, data_type, length, format.
    Always returns (DataFrame, errors). Never raises.
    """
    rows = []; errors = []
    for fname, fdata in sorted(files_store.items()):
        if not _supported_ext(fname): continue
        dom = Path(fname).stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES): continue

        df, meta, err = _load_file(fdata, fname)
        if err: errors.append(err)
        if df.empty: continue

        # Extract SAS metadata from pyreadstat meta object
        col_labels = getattr(meta, "column_labels",    []) or [] if meta else []
        var_fmts   = getattr(meta, "variable_formats", {}) or {} if meta else {}
        var_types  = (getattr(meta, "original_variable_types", []) or
                      getattr(meta, "readstat_variable_types",  []) or []) if meta else []
        var_widths = getattr(meta, "variable_storage_width", {}) or {} if meta else {}

        for idx, col in enumerate(df.columns):
            col_up = col.upper()
            label  = str(col_labels[idx]) if idx < len(col_labels) and col_labels[idx] else ""
            fmt    = (var_fmts.get(col, "") or var_fmts.get(col_up, "")) if isinstance(var_fmts, dict) else ""
            t_raw  = str(var_types[idx]) if idx < len(var_types) and var_types[idx] else ""
            lgth   = (str(var_widths.get(col, "") or var_widths.get(col_up, ""))
                      if isinstance(var_widths, dict) else "")
            pd_dt  = str(df[col].dtype)

            # Map to CDISC data type
            if "char" in t_raw.lower():
                sas_type  = "Char"
                data_type = "text"
            elif "double" in t_raw.lower() or "float" in pd_dt or "int" in pd_dt:
                sas_type  = "Num"
                data_type = "integer"
            else:
                sas_type  = "Char"
                data_type = "text"

            # Detect datetime from format
            if any(h in str(fmt).upper() for h in ("DATE", "TIME", "MMDD", "YYMMDD", "DTIM")):
                data_type = "datetime"

            rows.append({
                "domain":    dom,
                "variable":  col_up,
                "label":     label,
                "sas_type":  sas_type,
                "data_type": data_type,
                "length":    lgth,
                "format":    fmt,
            })

    df_out = pd.DataFrame(rows)
    if df_out.empty:
        return pd.DataFrame(columns=["domain","variable","label","sas_type",
                                      "data_type","length","format"]), errors
    return df_out.drop_duplicates(subset=["domain","variable"]).reset_index(drop=True), errors


def get_column_metadata(lib_path: str) -> pd.DataFrame:
    store = {}
    lib   = Path(lib_path)
    for ext in ("*.sas7bdat", "*.xpt", "*.csv"):
        for fp in sorted(lib.glob(ext)):
            store[fp.name] = fp.read_bytes()
    df, _ = get_column_metadata_from_store(store)
    return df


# ══════════════════════════════════════════════════════════════════════════════
# SPEC PARSING HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _find_codelist_tab(spec: Dict[str, pd.DataFrame]) -> Optional[pd.DataFrame]:
    """Find Codelist sheet case-insensitively."""
    if not spec: return None
    for key in spec:
        kl = str(key).strip().lower().replace(" ", "").replace("_", "")
        if kl in ("codelist", "codelists", "codlst", "codes"):
            return spec[key]
    return None


def _get_active_domains_from_toc(spec: Dict[str, pd.DataFrame]) -> List[str]:
    """Return domain names with TOC Active == Y."""
    toc = None
    for key in spec:
        if str(key).strip().lower() == "toc":
            toc = spec[key]; break
    if toc is None or toc.empty: return []
    toc = toc.copy()
    toc.columns = [str(c).strip().lower().replace(" ","_") for c in toc.columns]
    ds_col  = next((c for c in toc.columns if c in ("dataset","domain")), None)
    act_col = next((c for c in toc.columns if c == "active"), None)
    if not ds_col: return []
    if act_col:
        mask = toc[act_col].astype(str).str.strip().str.upper() == "Y"
        return toc[mask][ds_col].dropna().str.strip().str.upper().tolist()
    return toc[ds_col].dropna().str.strip().str.upper().tolist()


def _get_codelist_from_spec(spec: Dict[str, pd.DataFrame]) -> Dict[str, List[dict]]:
    """
    Parse Codelist tab → {CODELIST_NAME_UPPER: [value_entries]}.
    *** SOURCE OF TRUTH — DO NOT CHANGE MATCHING LOGIC ***
    Includes ALL values regardless of Active column.
    Active=N means 'codelist not used in study', NOT 'value is invalid'.
    """
    cl_df = _find_codelist_tab(spec)
    if cl_df is None or cl_df.empty: return {}
    cl_df = cl_df.copy()
    cl_df.columns = [str(c).strip().lower().replace(" ","_") for c in cl_df.columns]

    name_col   = next((c for c in cl_df.columns if c == "codelist_name"), None)
    value_col  = next((c for c in cl_df.columns if c == "codelist_value"), None)
    if not value_col:
        value_col = next((c for c in cl_df.columns
                          if "codelist_value" in c and "decode" not in c
                          and c != "codelist_value_code"), None)
    decode_col = next((c for c in cl_df.columns if c == "codelist_value_decode"), None)
    vcode_col  = next((c for c in cl_df.columns if c == "codelist_value_code"), None)
    cl_code_col= next((c for c in cl_df.columns if c == "codelist_code"), None)
    ext_col    = next((c for c in cl_df.columns if "extensible" in c), None)
    source_col = next((c for c in cl_df.columns if c in ("codelist_source","source")), None)
    std_col    = next((c for c in cl_df.columns if c == "standard"), None)
    active_col = next((c for c in cl_df.columns if c == "active"), None)
    label_col  = next((c for c in cl_df.columns if c in ("codelist_label","label")), None)

    if not name_col or not value_col: return {}

    result: Dict[str, List[dict]] = {}
    for _, row in cl_df.iterrows():
        cl_name = str(row.get(name_col, "")).strip().upper()
        val     = str(row.get(value_col, "")).strip()
        if not cl_name or not val or val.lower() == "nan": continue
        source  = str(row.get(source_col, "")).strip() if source_col else ""
        entry = {
            "value":       val,
            "decode":      str(row.get(decode_col,   "")).strip() if decode_col   else "",
            "vcode":       str(row.get(vcode_col,    "")).strip() if vcode_col    else "",
            "cl_code":     str(row.get(cl_code_col,  "")).strip() if cl_code_col  else "",
            "cl_label":    str(row.get(label_col,    "")).strip() if label_col    else "",
            "active":      str(row.get(active_col,   "")).strip() if active_col   else "",
            "extensible":  str(row.get(ext_col,      "")).strip() if ext_col      else "",
            "source":      source,
            "standard":    str(row.get(std_col,      "")).strip() if std_col      else "",
        }
        result.setdefault(cl_name, []).append(entry)
    return result


def _get_codelist_map_from_spec(spec: Dict[str, pd.DataFrame]) -> Dict[tuple, str]:
    """
    Build {(DOMAIN, VARIABLE) -> CODELIST_NAME}.
    Rules: TOC Active=Y, mapping_action ≠ DROP/"", codelist from col U (index 20).
    """
    if not spec: return {}
    active_domains = set(_get_active_domains_from_toc(spec))
    SKIP = {"toc","codelist","codelists","computation","valuelist","maintenance",
            "study","standard","ig"}
    try:
        from core.spec_loader import EXCLUDE_DOMAINS; EXCLUDE = set(EXCLUDE_DOMAINS)
    except ImportError:
        EXCLUDE = {"TA","TE","TI","TV","TS","TD","TM"}

    result = {}
    for sheet, df in spec.items():
        if sheet.strip().lower() in SKIP: continue
        if not isinstance(df, pd.DataFrame) or df.empty: continue
        dom = sheet.upper()
        if active_domains and dom not in active_domains: continue
        if dom in EXCLUDE: continue

        var_col = next((c for c in df.columns if c.lower() == "variable"), None)
        if not var_col: continue
        ma_col  = next((c for c in df.columns if c.lower() in
                        ("mapping_action","mappingaction","action")), None)
        cl_col  = next((c for c in df.columns if c.lower() in
                        ("codelist","codelist_name","codelist_ref","hasnodet","hasnodeterministic")), None)
        if cl_col is None and len(df.columns) > 20:
            cl_col = df.columns[20]
        if not cl_col: continue

        for _, row in df.iterrows():
            var = str(row.get(var_col, "")).strip().upper()
            cl  = str(row.get(cl_col, "")).strip()
            if not var or not cl or cl.lower() in ("nan","","none"): continue
            if ma_col:
                ma = str(row.get(ma_col,"")).strip().upper()
                if ma in ("DROP",""): continue
            result[(dom, var)] = cl.upper()
    return result


def _get_spec_variable_meta(spec: Dict) -> Dict[tuple, dict]:
    """Extract label/type/length for each (domain,variable) from spec domain sheets."""
    SKIP = {"toc","codelist","codelists","computation","valuelist","maintenance","study","standard","ig"}
    out = {}
    for sheet, df in spec.items():
        if sheet.strip().lower() in SKIP: continue
        if not isinstance(df, pd.DataFrame) or df.empty: continue
        dom = sheet.upper()
        var_col   = next((c for c in df.columns if c.lower() == "variable"), None)
        label_col = next((c for c in df.columns if c.lower() in ("label","variable_label")), None)
        type_col  = next((c for c in df.columns if c.lower() in ("sas_type","type","sastype")), None)
        len_col   = next((c for c in df.columns if c.lower() in ("sas_length","length","saslength")), None)
        if not var_col: continue
        for _, row in df.iterrows():
            var = str(row.get(var_col,"")).strip().upper()
            if not var: continue
            out[(dom,var)] = {
                "label":      str(row.get(label_col,"")).strip() if label_col else "",
                "sas_type":   str(row.get(type_col, "")).strip() if type_col  else "",
                "sas_length": str(row.get(len_col,  "")).strip() if len_col   else "",
            }
    return out


def _get_spec_valuelist(spec: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """
    Parse the spec's own ValueList sheet (Image 4 structure).
    Returns DataFrame with: active, vlm_id, dataset, variable,
    cond_dataset, cond_variable, comparator, cond_value
    """
    vl_tab = None
    for key in spec:
        kl = str(key).strip().lower().replace(" ","").replace("_","")
        if kl in ("valuelist","valuelevel","vlm","valuelvl"):
            vl_tab = spec[key]; break
    if vl_tab is None or vl_tab.empty:
        return pd.DataFrame()

    df = vl_tab.copy()
    df.columns = [str(c).strip().lower().replace(" ","_") for c in df.columns]

    # Map columns
    col_map = {
        "active":       next((c for c in df.columns if c == "active"), None),
        "vlm_id":       next((c for c in df.columns if "vlm" in c and "id" in c), None),
        "dataset":      next((c for c in df.columns if c in ("dataset","domain")), None),
        "variable":     next((c for c in df.columns if c == "variable"), None),
        "cond_dataset": next((c for c in df.columns if "conditional_dataset" in c or "cond_dataset" in c or c.endswith("dataset1")), None),
        "cond_variable":next((c for c in df.columns if "conditional_variable" in c or c.endswith("variable1")), None),
        "comparator":   next((c for c in df.columns if "comparator" in c), None),
        "cond_value":   next((c for c in df.columns if "conditional_value" in c or c.endswith("value1")), None),
    }

    result_rows = []
    for _, row in df.iterrows():
        r = {}
        for out_col, src_col in col_map.items():
            r[out_col] = str(row.get(src_col,"")).strip() if src_col else ""
        if r.get("dataset") and r.get("variable"):
            result_rows.append(r)
    return pd.DataFrame(result_rows) if result_rows else pd.DataFrame()


# ══════════════════════════════════════════════════════════════════════════════
# VLM / CODELIST  ← SOURCE OF TRUTH — DO NOT CHANGE MATCHING LOGIC
# ══════════════════════════════════════════════════════════════════════════════

def build_vlm_from_spec_and_data(
    files_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """
    Variable Level Metadata: one row per (domain, variable) with codelist in spec.
    Combines spec metadata + actual data statistics + CT values from Codelist tab.
    *** THIS IS THE SOURCE OF TRUTH FOR MATCHING LOGIC ***
    """
    if not spec: return pd.DataFrame()

    cl_map    = _get_codelist_map_from_spec(spec)
    cl_lookup = _get_codelist_from_spec(spec)
    spec_meta = _get_spec_variable_meta(spec)
    if not cl_map: return pd.DataFrame()

    dom_store = {Path(k).stem.upper(): (k, v)
                 for k, v in files_store.items() if _supported_ext(k)}

    domain_vars: Dict[str, List[str]] = defaultdict(list)
    for (dom, var) in cl_map: domain_vars[dom].append(var)

    domain_data: Dict[str, pd.DataFrame] = {}
    for dom in domain_vars:
        if dom not in dom_store: continue
        fname, fdata = dom_store[dom]
        df_d, _, _ = _load_file(fdata, fname)
        if not df_d.empty: domain_data[dom] = df_d

    rows = []
    for (dom, var), cl_name in sorted(cl_map.items()):
        sm         = spec_meta.get((dom, var), {})
        label      = sm.get("label","")
        sas_type   = sm.get("sas_type","")
        sas_length = sm.get("sas_length","")

        ct_entries    = cl_lookup.get(cl_name, [])
        src           = ct_entries[0].get("source","") if ct_entries else ""
        is_meddra     = _is_meddra_codelist(cl_name, src)
        is_whodd      = _is_whodd_codelist(cl_name, src)
        ct_vals_all   = sorted({e["value"] for e in ct_entries})
        ct_ext        = ct_entries[0]["extensible"] if ct_entries else ""
        ct_src        = ct_entries[0]["source"]     if ct_entries else ""
        ct_std        = ct_entries[0]["standard"]   if ct_entries else ""
        n             = len(ct_vals_all)
        ct_vals_disp  = ("; ".join(ct_vals_all) if n <= MAX_SAMPLE_DISPLAY
                         else "; ".join(ct_vals_all[:MAX_SAMPLE_DISPLAY]) + f" ... (+{n-MAX_SAMPLE_DISPLAY} more)")

        actual_max_len=""; n_distinct=""; has_decimals=""
        sample_vals=""; mismatch_vals=""; mismatch_count=""
        ct_status="NO DATA"; actual_data_type="text"

        df_dom = domain_data.get(dom)
        if df_dom is not None and var in df_dom.columns:
            cleaned    = _clean_str_col(df_dom[var])
            n_uniq     = cleaned.nunique()
            n_distinct = str(n_uniq)
            uniq_vals  = sorted({str(v) for v in cleaned.unique()})
            sample_vals = ("; ".join(uniq_vals) if n_uniq <= MAX_SAMPLE_DISPLAY
                           else "; ".join(uniq_vals[:5]) + f" ... (+{n_uniq-5} more)")

            if sas_type.upper() in ("CHAR","C","CHARACTER","TEXT"):
                actual_max_len   = str(cleaned.str.len().max()) if not cleaned.empty else "0"
                has_decimals     = "N/A"
                actual_data_type = "text"
            else:
                try:
                    numeric = pd.to_numeric(df_dom[var], errors="coerce").dropna()
                    if not numeric.empty:
                        actual_max_len = str(int(numeric.abs().max()))
                        dec = numeric[numeric != numeric.round()]
                        has_decimals   = f"Y (max {int(numeric.apply(lambda x: len(str(x).split('.')[-1]) if '.' in str(x) else 0).max())} dp)" if len(dec) > 0 else "N"
                        actual_data_type = "float" if len(dec) > 0 else "integer"
                except Exception: pass

            if is_meddra: ct_status = "SKIPPED (MedDRA)"
            elif is_whodd: ct_status = "SKIPPED (WHODrug)"
            elif ct_entries:
                # *** MATCHING LOGIC — REUSED BY CT COMPARISON ***
                allowed_upper = {e["value"].upper() for e in ct_entries}
                check_vals    = uniq_vals[:MAX_CT_UNIQUE_PER_VAR]
                mismatches    = [v for v in check_vals if v.upper() not in allowed_upper]
                mismatch_count = str(len(mismatches))
                mismatch_vals  = "; ".join(mismatches[:10])
                suffix = f" (first {MAX_CT_UNIQUE_PER_VAR} checked)" if n_uniq > MAX_CT_UNIQUE_PER_VAR else ""
                ct_status = "PASS" if not mismatches else f"MISMATCH ({len(mismatches)} values){suffix}"
            else:
                ct_status = "NO CT VALUES IN SPEC"

        rows.append({
            "domain":             dom,
            "variable":           var,
            "label":              label,
            "sas_type":           sas_type,
            "sas_length":         sas_length,
            "spec_codelist":      cl_name,
            "is_meddra":          "YES" if is_meddra else "",
            "is_whodd":           "YES" if is_whodd else "",
            "actual_data_type":   actual_data_type,
            "actual_max_length":  actual_max_len,
            "n_distinct_values":  n_distinct,
            "has_decimals":       has_decimals,
            "sample_values":      sample_vals,
            "ct_values_allowed":  ct_vals_disp,
            "n_ct_values":        str(n),
            "ct_extensible":      ct_ext,
            "ct_source":          ct_src,
            "ct_standard":        ct_std,
            "ct_mismatch_values": mismatch_vals,
            "ct_mismatch_count":  mismatch_count,
            "ct_status":          ct_status,
        })
    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# CT COMPARISON — rebuilt using VLM matching logic
# ══════════════════════════════════════════════════════════════════════════════

def compare_data_vs_codelist(
    files_store: Dict[str, bytes],
    spec: Dict[str, pd.DataFrame],
    max_unique_per_var: int = MAX_CT_UNIQUE_PER_VAR,
) -> pd.DataFrame:
    """
    Dataset-level CT comparison using the SAME matching logic as VLM.
    VLM = per variable with its assigned codelist.
    CT  = same, but also includes mismatch_type, ct_decode, ct_vcode, ct_standard.

    Exclusions:
    - MedDRA codelists (source=MEDDRA)
    - WHODrug codelists (source=WHODD)
    - Result variables (--STRESC, --ORRES, --STRESN)
    - Free-text variables (contain REASON, SPECIFY, TEXT, COMMENT etc.)
    - Blank/empty SAS values

    Returns one row per unique actual value per variable.
    """
    if not spec or not files_store: return pd.DataFrame()

    cl_map    = _get_codelist_map_from_spec(spec)
    cl_lookup = _get_codelist_from_spec(spec)
    if not cl_map: return pd.DataFrame()

    dom_store = {Path(k).stem.upper(): (k, v)
                 for k, v in files_store.items() if _supported_ext(k)}

    domain_vars: Dict[str, List[str]] = defaultdict(list)
    for (dom, var) in cl_map: domain_vars[dom].append(var)

    rows = []
    for dom, vars_list in sorted(domain_vars.items()):
        if dom not in dom_store: continue
        fname, fdata = dom_store[dom]
        df_dom, _, load_err = _load_file(fdata, fname)
        if df_dom.empty:
            if load_err: log.debug("CT load: %s", load_err)
            continue

        for var in vars_list:
            if var not in df_dom.columns: continue

            # Skip result/free-text variables
            if _is_result_var(var): continue

            cl_name    = cl_map.get((dom, var), "")
            ct_entries = cl_lookup.get(cl_name, [])
            if not ct_entries: continue

            src = ct_entries[0].get("source","") if ct_entries else ""

            # Skip MedDRA and WHODrug codelists
            if _is_meddra_codelist(cl_name, src): continue
            if _is_whodd_codelist(cl_name, src): continue

            # Build allowed lookup from ALL entries (VLM matching logic)
            allowed: Dict[str, dict] = {e["value"].upper(): e for e in ct_entries}

            # Get unique values (blank-filtered, original case)
            cleaned    = _clean_str_col(df_dom[var])
            if cleaned.empty: continue

            unique_vals  = sorted({str(v) for v in cleaned.unique()})
            n_total_uniq = len(unique_vals)
            truncated    = n_total_uniq > max_unique_per_var
            if truncated: unique_vals = unique_vals[:max_unique_per_var]

            for val in unique_vals:
                val_upper = val.upper()
                n_obs     = int((cleaned == val).sum())

                if val_upper in allowed:
                    entry        = allowed[val_upper]
                    status       = "PASS"
                    mismatch_type = ""
                else:
                    entry         = {}
                    status        = "MISMATCH"
                    mismatch_type = "NOT_IN_CT"

                rows.append({
                    "domain":        dom,
                    "variable":      var,
                    "codelist":      cl_name,
                    "value":         val,           # original case
                    "n_obs":         n_obs,
                    "in_ct":         "YES" if status == "PASS" else "NO",
                    "ct_decode":     entry.get("decode",   ""),
                    "ct_vcode":      entry.get("vcode",    ""),
                    "ct_standard":   entry.get("standard", ""),
                    "ct_source":     entry.get("source",   ""),
                    "mismatch_type": mismatch_type,
                    "status":        status,
                    "note":          f"First {max_unique_per_var} of {n_total_uniq}" if truncated else "",
                })

    if not rows: return pd.DataFrame()
    return (pd.DataFrame(rows)
            .sort_values(["domain","variable","status","value"])
            .reset_index(drop=True))


# ══════════════════════════════════════════════════════════════════════════════
# VALUE LEVEL (TESTCD/QNAM/PARAMCD)
# ══════════════════════════════════════════════════════════════════════════════

def get_value_level_from_store(
    files_store: Dict[str, bytes],
    columns_df: Optional[pd.DataFrame] = None,
    mode: str = "SDTM",
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Extract value-level entries from TESTCD/QNAM (SDTM) or PARAMCD (ADaM).
    Scans file headers directly — independent of columns_df.
    Returns (DataFrame, errors). Never raises.
    FIXED: PARMCD → PARAMCD
    """
    mode  = mode.upper()
    EMPTY = (pd.DataFrame(columns=["dataset","variable","result_variable",
                                    "value","where_clause","data_type"]), [])
    if not files_store: return EMPTY

    dom_store = {Path(k).stem.upper(): (k, v)
                 for k, v in files_store.items() if _supported_ext(k)}

    pat_sdtm = re.compile(r"TESTCD|QNAM|PARAMCD", re.IGNORECASE)   # FIXED: PARAMCD not PARMCD
    pat_adam = re.compile(r"^PARAMCD$", re.IGNORECASE)

    rows = []; domain_errors = []
    for dom, (fname, fdata) in sorted(dom_store.items()):
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES): continue

        try:
            if fname.lower().endswith(".csv"):
                df_hdr     = pd.read_csv(io.BytesIO(fdata), nrows=0)
                col_names  = [c.upper() for c in df_hdr.columns]
                df_full    = None
            else:
                df_full, _, err = _load_file(fdata, fname)
                if df_full.empty:
                    if err: domain_errors.append(err)
                    continue
                col_names = list(df_full.columns)
        except Exception as exc:
            domain_errors.append(f"[{dom}] header read: {type(exc).__name__}: {exc}")
            continue

        if mode == "ADAM":
            testcd_cols = [(c, "AVAL", f"{dom}.{c}.") for c in col_names if pat_adam.match(c)]
        else:
            testcd_cols = []
            for c in col_names:
                if pat_sdtm.search(c):
                    if "TESTCD" in c.upper():  orres = dom + "ORRES"
                    elif "QNAM" in c.upper():   orres = "QVAL"
                    else:                        orres = "AVAL"
                    testcd_cols.append((c, orres, f"{dom}.{c}."))

        if not testcd_cols: continue

        try:
            if fname.lower().endswith(".csv"):
                df_full = pd.read_csv(io.BytesIO(fdata), low_memory=False)
                df_full.columns = [c.upper() for c in df_full.columns]
        except Exception as exc:
            domain_errors.append(f"[{dom}] data load: {type(exc).__name__}: {exc}")
            continue

        for (col, orres, where_prefix) in testcd_cols:
            if col not in df_full.columns: continue
            for val in df_full[col].dropna().unique():
                vs = str(val).strip()
                if not vs or vs.lower() in ("nan", ".", "<na>"): continue
                rows.append({
                    "dataset":         dom,
                    "variable":        col,
                    "result_variable": orres,
                    "value":           vs,
                    "where_clause":    where_prefix + vs,
                    "data_type":       _infer_dtype(vs),
                })

    if not rows: return EMPTY
    return (pd.DataFrame(rows)
            .drop_duplicates(subset=["dataset","variable","value"])
            .reset_index(drop=True),
            domain_errors)


def build_where_clause_table(value_level: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    if value_level is None or value_level.empty:
        return pd.DataFrame(columns=["id","dataset","variable","comparator","value","where_clause"])
    wh = value_level[["dataset","variable","value","where_clause"]].copy()
    wh["comparator"] = "EQ"
    wh["id"]         = wh["where_clause"]
    if "result_variable" in value_level.columns:
        wh["result_variable"] = value_level["result_variable"].values
    return wh[["id","dataset","variable","comparator","value","where_clause"]].reset_index(drop=True)


def _infer_dtype(val: str) -> str:
    try:
        n = float(val); return "integer" if n == int(n) else "float"
    except (ValueError, TypeError): pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T", val): return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$",  val): return "Date"
    return "text"


def validate_ct_values(value_level: pd.DataFrame, spec: Dict) -> pd.DataFrame:
    """Legacy wrapper."""
    if value_level is None or value_level.empty: return pd.DataFrame()
    cl_lookup = _get_codelist_from_spec(spec)
    cl_map    = _get_codelist_map_from_spec(spec)
    rows = []
    for _, vrow in value_level.iterrows():
        ds  = str(vrow["dataset"]).upper()
        var = str(vrow["variable"]).upper()
        val = str(vrow["value"]).strip()
        cl_name = cl_map.get((ds, var))
        if not cl_name: continue
        allowed = {e["value"].upper() for e in cl_lookup.get(cl_name, [])}
        if not allowed: continue
        in_ct = val.upper() in allowed
        rows.append({"dataset":ds,"variable":var,"value":val,"codelist":cl_name,
                     "in_ct":"YES" if in_ct else "NO",
                     "status":"PASS" if in_ct else "MISMATCH"})
    return pd.DataFrame(rows).reset_index(drop=True)


# ══════════════════════════════════════════════════════════════════════════════
# DEFINE-XML v2.1 — Full rebuild
# ══════════════════════════════════════════════════════════════════════════════

def generate_define_xml(
    columns_df:    pd.DataFrame,
    value_level:   pd.DataFrame,
    where_clause:  pd.DataFrame,
    spec:          Optional[Dict] = None,
    study_name:    str = "Study",
    study_description: str = "",
    standard_name: str = "SDTM",
    standard_ver:  str = "1.7",
) -> str:
    """
    Generate CDISC Define-XML v2.1 compliant output.

    Structure:
    ODM
      Study
        GlobalVariables
        MetaDataVersion
          def:AnnotatedCRF
          def:SupplementalDoc
          def:ValueListDef (per TESTCD variable)
          def:WhereClauseDef (per where-clause condition)
          ItemGroupDef (per domain)
          ItemDef (per variable)
          CodeList (per codelist, MedDRA excluded)
          def:ComputationMethod (placeholder)
          def:leaf (document references)
    """
    from datetime import datetime as _dt
    import xml.etree.ElementTree as ET

    now = _dt.utcnow().strftime("%Y-%m-%dT%H:%M:%S")

    cl_lookup:  Dict[str, list]     = {}
    cl_refs:    Dict[str, str]      = {}  # "DOM.VAR" -> cl_name
    spec_vlm:   pd.DataFrame        = pd.DataFrame()

    if spec:
        cl_lookup = _get_codelist_from_spec(spec)
        cl_map    = _get_codelist_map_from_spec(spec)
        cl_refs   = {f"{d}.{v}": cl for (d,v), cl in cl_map.items()}
        spec_vlm  = _get_spec_valuelist(spec)

    # ── Build XML using string lines (most readable/portable) ────────────────
    L = []  # lines

    # ── XML declaration + ODM root ────────────────────────────────────────────
    L.append('<?xml version="1.0" encoding="UTF-8"?>')
    L.append('<?xml-stylesheet type="text/xsl" href="define2-0-0.xsl"?>')
    L.append('<ODM')
    L.append('  xmlns="http://www.cdisc.org/ns/odm/v1.3"')
    L.append('  xmlns:def="http://www.cdisc.org/ns/def/v2.1"')
    L.append('  xmlns:xlink="http://www.w3.org/1999/xlink"')
    L.append('  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"')
    L.append('  xsi:schemaLocation="http://www.cdisc.org/ns/odm/v1.3 '
             'http://www.cdisc.org/ns/odm/v1.3/ODM1-3-2.xsd '
             'http://www.cdisc.org/ns/def/v2.1 '
             'http://www.cdisc.org/ns/def/v2.1/define2-1-0.xsd"')
    L.append(f'  FileType="Snapshot"')
    L.append(f'  FileOID="www.define.xml/1"')
    L.append(f'  CreationDateTime="{now}"')
    L.append(f'  AsOfDateTime="{now}"')
    L.append(f'  ODMVersion="1.3.2"')
    L.append(f'  def:Context="Other">')

    # ── Study ─────────────────────────────────────────────────────────────────
    study_oid = f"ST.{_xml_id(study_name)}"
    L.append(f'  <Study OID="{study_oid}">')
    L.append(f'    <GlobalVariables>')
    L.append(f'      <StudyName>{_xe(study_name)}</StudyName>')
    L.append(f'      <StudyDescription>{_xe(study_description or study_name)}</StudyDescription>')
    L.append(f'      <ProtocolName>{_xe(study_name)}</ProtocolName>')
    L.append(f'    </GlobalVariables>')

    # ── MetaDataVersion ───────────────────────────────────────────────────────
    L.append(f'  <MetaDataVersion OID="MDV.1"')
    L.append(f'    Name="{_xe(study_name)}"')
    L.append(f'    def:DefineVersion="2.1.0"')
    L.append(f'    def:StandardName="{_xe(standard_name)}"')
    L.append(f'    def:StandardVersion="{_xe(standard_ver)}">')

    # ── def:ValueListDef — one per TESTCD/QNAM variable ──────────────────────
    # Build from: (1) spec's own ValueList sheet, (2) value_level data
    written_vl_oids: set = set()

    # From spec ValueList sheet (Image 4)
    if not spec_vlm.empty:
        for (ds, var), grp in spec_vlm.groupby(["dataset","variable"]):
            vl_oid = f"VL.{_xml_id(ds)}.{_xml_id(var)}"
            if vl_oid in written_vl_oids: continue
            written_vl_oids.add(vl_oid)
            L.append(f'    <def:ValueListDef OID="{vl_oid}">')
            for i, (_, vrow) in enumerate(grp.iterrows(), 1):
                cond_ds  = str(vrow.get("cond_dataset","")).strip()
                cond_var = str(vrow.get("cond_variable","")).strip()
                comp     = str(vrow.get("comparator","EQ")).strip() or "EQ"
                cond_val = str(vrow.get("cond_value","")).strip()
                if not cond_val: continue
                wc_oid   = f"WC.{_xml_id(ds)}.{_xml_id(var)}.{_xml_id(cond_val)}"
                item_oid = f"IT.{_xml_id(cond_ds or ds)}.{_xml_id(cond_var or var)}.{_xml_id(cond_val)}"
                L.append(f'      <ItemRef ItemOID="{item_oid}"')
                L.append(f'               OrderNumber="{i}"')
                L.append(f'               Mandatory="No"')
                L.append(f'               def:WhereClauseOID="{wc_oid}"/>')
            L.append(f'    </def:ValueListDef>')

    # From extracted value_level data
    if not value_level.empty:
        for (ds, var), grp in value_level.groupby(["dataset","variable"]):
            vl_oid = f"VL.{_xml_id(str(ds))}.{_xml_id(str(var))}"
            if vl_oid in written_vl_oids: continue
            written_vl_oids.add(vl_oid)
            L.append(f'    <def:ValueListDef OID="{vl_oid}">')
            for i, (_, row) in enumerate(grp.iterrows(), 1):
                val_id   = _xml_id(str(row["value"]))
                wc_oid   = f"WC.{_xml_id(str(ds))}.{_xml_id(str(var))}.{val_id}"
                res_var  = str(row.get("result_variable", ""))
                item_oid = f"IT.{_xml_id(str(ds))}.{res_var or _xml_id(str(var))}"
                L.append(f'      <ItemRef ItemOID="{item_oid}"')
                L.append(f'               OrderNumber="{i}"')
                L.append(f'               Mandatory="No"')
                L.append(f'               def:WhereClauseOID="{wc_oid}"/>')
            L.append(f'    </def:ValueListDef>')

    # ── def:WhereClauseDef ────────────────────────────────────────────────────
    written_wc_oids: set = set()

    # From spec ValueList
    if not spec_vlm.empty:
        for _, vrow in spec_vlm.iterrows():
            ds       = str(vrow.get("dataset","")).strip()
            var      = str(vrow.get("variable","")).strip()
            cond_ds  = str(vrow.get("cond_dataset","")).strip()
            cond_var = str(vrow.get("cond_variable","")).strip()
            comp     = str(vrow.get("comparator","EQ")).strip() or "EQ"
            cond_val = str(vrow.get("cond_value","")).strip()
            if not cond_val: continue
            wc_oid = f"WC.{_xml_id(ds)}.{_xml_id(var)}.{_xml_id(cond_val)}"
            if wc_oid in written_wc_oids: continue
            written_wc_oids.add(wc_oid)
            it_oid = f"IT.{_xml_id(cond_ds or ds)}.{_xml_id(cond_var or var)}"
            L.append(f'    <def:WhereClauseDef OID="{wc_oid}">')
            L.append(f'      <RangeCheck Comparator="{_xe(comp)}" SoftHard="Soft"')
            L.append(f'                  def:ItemOID="{it_oid}">')
            L.append(f'        <CheckValue>{_xe(cond_val)}</CheckValue>')
            L.append(f'      </RangeCheck>')
            L.append(f'    </def:WhereClauseDef>')

    # From where_clause table
    if not where_clause.empty:
        for _, row in where_clause.iterrows():
            ds   = str(row["dataset"]); var = str(row["variable"])
            val  = str(row["value"]);   comp = str(row.get("comparator","EQ"))
            wc_oid = f"WC.{_xml_id(ds)}.{_xml_id(var)}.{_xml_id(val)}"
            if wc_oid in written_wc_oids: continue
            written_wc_oids.add(wc_oid)
            it_oid = f"IT.{_xml_id(ds)}.{_xml_id(var)}"
            L.append(f'    <def:WhereClauseDef OID="{wc_oid}">')
            L.append(f'      <RangeCheck Comparator="{_xe(comp)}" SoftHard="Soft"')
            L.append(f'                  def:ItemOID="{it_oid}">')
            L.append(f'        <CheckValue>{_xe(val)}</CheckValue>')
            L.append(f'      </RangeCheck>')
            L.append(f'    </def:WhereClauseDef>')

    # ── ItemGroupDef per domain ────────────────────────────────────────────────
    if not columns_df.empty:
        for dom, dom_df in columns_df.groupby("domain"):
            ig_oid  = f"IG.{_xml_id(dom)}"
            n_recs  = f"One record per {dom.lower()} per subject"
            L.append(f'    <ItemGroupDef OID="{ig_oid}"')
            L.append(f'      Name="{_xe(dom)}"')
            L.append(f'      Repeating="Yes"')
            L.append(f'      IsReferenceData="No"')
            L.append(f'      SASDatasetName="{_xe(dom)}"')
            L.append(f'      def:Structure="{n_recs}"')
            L.append(f'      def:Purpose="Tabulation"')
            L.append(f'      def:Label="{_xe(dom)}">')
            for order, (_, row) in enumerate(dom_df.iterrows(), 1):
                var     = str(row["variable"])
                it_oid  = f"IT.{_xml_id(dom)}.{_xml_id(var)}"
                has_vl  = f"VL.{_xml_id(dom)}.{_xml_id(var)}" in written_vl_oids
                mand    = "Yes" if var in ("STUDYID","DOMAIN","USUBJID") else "No"
                vl_attr = f' def:ValueListOID="VL.{_xml_id(dom)}.{_xml_id(var)}"' if has_vl else ""
                L.append(f'      <ItemRef ItemOID="{it_oid}"')
                L.append(f'               OrderNumber="{order}"')
                L.append(f'               Mandatory="{mand}"{vl_attr}/>')
            L.append(f'    </ItemGroupDef>')

        # ── ItemDef per variable ───────────────────────────────────────────────
        # Deduplicate: each ItemDef OID appears only once
        written_item_oids: set = set()
        for _, row in columns_df.iterrows():
            dom     = str(row["domain"])
            var     = str(row["variable"])
            it_oid  = f"IT.{_xml_id(dom)}.{_xml_id(var)}"
            if it_oid in written_item_oids: continue
            written_item_oids.add(it_oid)

            label    = str(row.get("label",var))
            sas_type = str(row.get("sas_type","Char"))
            length   = str(row.get("length",""))
            fmt      = str(row.get("format",""))
            xml_type = _map_datatype(str(row.get("data_type","text")))
            len_attr = f' Length="{length}"' if length and str(length).isdigit() else ' Length="200"'

            cl_key  = f"{dom}.{var}"
            cl_name = cl_refs.get(cl_key, "")

            L.append(f'    <ItemDef OID="{it_oid}"')
            L.append(f'             Name="{_xe(var)}"')
            L.append(f'             DataType="{xml_type}"{len_attr}')
            L.append(f'             SASFieldName="{_xe(var)}"')
            L.append(f'             def:Label="{_xe(label)}">')
            if fmt:
                L.append(f'      <def:Origin Type="CRF"/>')
            else:
                L.append(f'      <def:Origin Type="Derived"/>')
            if cl_name:
                cl_entries = cl_lookup.get(cl_name, [])
                cl_src = cl_entries[0].get("source","") if cl_entries else ""
                if not _is_meddra_codelist(cl_name, cl_src) and not _is_whodd_codelist(cl_name, cl_src):
                    L.append(f'      <CodeListRef CodeListOID="CL.{_xml_id(cl_name)}"/>')
            L.append(f'    </ItemDef>')

    # ── CodeListDef ────────────────────────────────────────────────────────────
    written_cl_oids: set = set()
    for cl_name, entries in sorted(cl_lookup.items()):
        if not entries: continue
        src = entries[0].get("source","")
        # Exclude MedDRA and WHODrug from Define-XML codelists
        if _is_meddra_codelist(cl_name, src): continue
        if _is_whodd_codelist(cl_name, src):  continue

        cl_oid = f"CL.{_xml_id(cl_name)}"
        if cl_oid in written_cl_oids: continue
        written_cl_oids.add(cl_oid)

        ext     = entries[0].get("extensible","")
        ext_val = "Yes" if str(ext).upper() in ("Y","YES","TRUE") else "No"
        std     = entries[0].get("standard","")
        cl_lbl  = entries[0].get("cl_label","") or cl_name

        L.append(f'    <CodeList OID="{cl_oid}"')
        L.append(f'              Name="{_xe(cl_name)}"')
        L.append(f'              DataType="text"')
        L.append(f'              def:ExtendedValue="{ext_val}">')
        if std:
            L.append(f'      <Alias Context="nci:ExtCodeID" Name="{_xe(std)}"/>')

        # Deduplicate entries by value
        seen_vals: set = set()
        for e in entries:
            val_u = e["value"].upper()
            if val_u in seen_vals: continue
            seen_vals.add(val_u)
            val    = _xe(e["value"])
            decode = _xe(e.get("decode",""))
            vcode  = e.get("vcode","")
            if decode:
                L.append(f'      <EnumeratedItem CodedValue="{val}" def:ExtendedValue="No">')
                L.append(f'        <Decode>')
                L.append(f'          <TranslatedText xml:lang="en">{decode}</TranslatedText>')
                L.append(f'        </Decode>')
                if vcode:
                    L.append(f'        <Alias Context="nci:ExtCodeID" Name="{_xe(vcode)}"/>')
                L.append(f'      </EnumeratedItem>')
            else:
                L.append(f'      <EnumeratedItem CodedValue="{val}" def:ExtendedValue="No"/>')
        L.append(f'    </CodeList>')

    # ── Close MetaDataVersion, Study, ODM ─────────────────────────────────────
    L.append(f'  </MetaDataVersion>')
    L.append(f'  </Study>')
    L.append(f'</ODM>')

    return "\n".join(L)


def _xe(s: str) -> str:
    """Escape XML special characters."""
    return (str(s)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&apos;"))


def _xml_id(s: str) -> str:
    """Safe XML OID segment."""
    return re.sub(r"[^A-Za-z0-9._\-]", "_", str(s))[:64]


def _map_datatype(dt: str) -> str:
    d = dt.lower()
    if d in ("text","char","character","varchar"): return "text"
    if d in ("integer","int"):                     return "integer"
    if d in ("float","number","double"):           return "float"
    if d in ("datetime",):                         return "datetime"
    if d in ("date",):                             return "date"
    if d in ("time",):                             return "time"
    return "text"
