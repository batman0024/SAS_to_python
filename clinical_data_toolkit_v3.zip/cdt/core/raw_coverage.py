# core/raw_coverage.py
"""
Raw variable coverage checker.
Maps raw CRF variables to SDTM spec input_variables references.
Produces EXACT / PARTIAL / UNMAPPED classification per variable.
Ports rawdata_perdomain_616.sas with dead code removed and bugs fixed.
"""

import logging
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Set

import pandas as pd

from core.spec_loader import get_active_domains

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)
log.setLevel(logging.ERROR)

DEFAULT_EXCLUDE_VARS: Set[str] = {
    "RECORDPOSITION", "INSTANCEID", "INSTANCEID_NSV", "INSTANCENAME_NSV",
    "INSTANCEREPEATNUMBER", "INSTANCEREPEATNUMBER_NSV", "MATRIX",
    "MAXUPDATED", "MAXUPDATED_NSV", "MINCREATED", "MINCREATED_NSV",
    "PAGEREPEATNUMBER_NSV", "Z_AGEU", "Z_AGEU_STD", "Z_AGE_REP",
    "Z_AGE_REP_RAW", "Z_SUBID", "DATAPAGENAME", "FOLDERNAME", "FOLDER",
    "X_SUBJID", "SUBJID", "STUDYID", "RECORDID", "SUBJECTID",
    "DLASTMOD", "INVID", "SCRNID", "DATAPAGEID", "PAGEREPEATNUMBER",
    "PROJECT", "QUERY", "STUDYENVSITENUMBER",
}


def collect_raw_vars(
    raw_lib_path: str,
    exclude_vars: Optional[Set[str]] = None,
    exclude_datasets: Optional[Set[str]] = None,
) -> pd.DataFrame:
    """
    Scan raw library and return a DataFrame of all variable names.
    Columns: raw_dataset, raw_variable
    Uses safe getattr() for all pyreadstat metadata attributes.
    """
    excl_vars = {v.upper() for v in ((exclude_vars or set()) | DEFAULT_EXCLUDE_VARS)}
    excl_ds = {d.upper() for d in (exclude_datasets or set())}

    rows = []
    lib = Path(raw_lib_path)
    for fp in sorted(lib.glob("*.sas7bdat")):
        ds = fp.stem.upper()
        if ds in excl_ds:
            continue
        try:
            import pyreadstat
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                _, meta = pyreadstat.read_sas7bdat(str(fp), metadataonly=True)
            # Safe access — column_names is reliable across all pyreadstat builds
            col_names = getattr(meta, "column_names", []) or []
            for col in col_names:
                if col.upper() not in excl_vars:
                    rows.append({"raw_dataset": ds, "raw_variable": col.upper()})
        except Exception as exc:
            log.debug("Cannot read metadata for %s: %s", fp.name, exc)

    return pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)


def collect_spec_input_refs(
    spec: Dict[str, pd.DataFrame],
    active_filter: str = "Y",
) -> pd.DataFrame:
    """
    Parse all INPUT_VARIABLES columns from active domain sheets.
    Extracts RAW.DATASET.VARIABLE patterns.
    Returns: domain, sdtm_variable, raw_dataset, raw_variable
    """
    domains = get_active_domains(spec, active_filter)
    rows = []
    for domain in domains:
        if domain not in spec:
            continue
        df = spec[domain]
        if "input_variables" not in df.columns or "variable" not in df.columns:
            continue
        for _, row in df.iterrows():
            inp = str(row.get("input_variables", "")).strip()
            sdtm_var = str(row.get("variable", "")).strip()
            if not inp:
                continue
            for token in inp.split(","):
                token = token.strip().upper()
                if token.startswith("RAW."):
                    parts = token.split(".")
                    if len(parts) >= 3:
                        rows.append({
                            "domain": domain,
                            "sdtm_variable": sdtm_var,
                            "raw_dataset": parts[1],
                            "raw_variable": parts[2],
                        })

    return pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)


def run_raw_coverage(
    raw_lib_path: str,
    spec: Dict[str, pd.DataFrame],
    active_filter: str = "Y",
    exclude_vars: Optional[Set[str]] = None,
    exclude_datasets: Optional[Set[str]] = None,
) -> Dict[str, pd.DataFrame]:
    """
    Main entry point for raw coverage analysis.
    Returns dict with: coverage, summary, unmapped
    """
    raw_vars = collect_raw_vars(raw_lib_path, exclude_vars, exclude_datasets)
    if raw_vars.empty:
        log.debug("No raw variables found in %s", raw_lib_path)
        return {"coverage": pd.DataFrame(), "summary": pd.DataFrame(),
                "unmapped": pd.DataFrame()}

    spec_refs = collect_spec_input_refs(spec, active_filter)
    spec_set_exact = set(spec_refs["raw_variable"].str.upper()) if not spec_refs.empty else set()

    def classify(rv: str) -> str:
        rv_up = rv.upper()
        if rv_up in spec_set_exact:
            return "EXACT"
        for ref in spec_set_exact:
            if rv_up in ref or ref in rv_up:
                return "PARTIAL"
        return "UNMAPPED"

    raw_vars["status"] = raw_vars["raw_variable"].apply(classify)

    if not spec_refs.empty:
        exact_lookup = (
            spec_refs.groupby("raw_variable")
            .apply(lambda g: "; ".join(
                f"{r['domain']}.{r['sdtm_variable']}" for _, r in g.iterrows()
            ))
            .reset_index()
            .rename(columns={0: "mapped_to"})
        )
        coverage = raw_vars.merge(exact_lookup, on="raw_variable", how="left")
    else:
        coverage = raw_vars.copy()
        coverage["mapped_to"] = ""

    coverage["mapped_to"] = coverage["mapped_to"].fillna("")

    summary = (
        coverage.groupby(["raw_dataset", "status"])
        .size()
        .unstack(fill_value=0)
        .reset_index()
    )
    for col in ["EXACT", "PARTIAL", "UNMAPPED"]:
        if col not in summary.columns:
            summary[col] = 0
    summary["total"] = summary[["EXACT", "PARTIAL", "UNMAPPED"]].sum(axis=1)
    summary["pct_mapped"] = (
        (summary["EXACT"] + summary["PARTIAL"]) / summary["total"] * 100
    ).round(1)

    unmapped = coverage[coverage["status"] == "UNMAPPED"].copy()

    return {"coverage": coverage, "summary": summary, "unmapped": unmapped}

