# core/define_helper.py
"""
Define helper: extracts Variable metadata and Value-Level entries
from SAS datasets (or CSV fallback).
Ports Define.sas - handles both SDTM and ADaM modes.

pyreadstat compatibility note:
  Different versions and OS builds of pyreadstat expose different attributes
  on the metadata_container object. ALL attribute accesses use getattr() with
  a safe fallback so the tool never crashes on 'object has no attribute' errors.
  Warnings from pyreadstat (e.g. encoding issues) are suppressed at module level.
"""

import logging
import re
import warnings
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

# Suppress pyreadstat and other noisy library warnings globally
warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)
# Suppress WARNING level from this module's logger in console output
log.setLevel(logging.ERROR)

EXCLUDE_DOMAIN_PREFIXES = ("_",)


def _safe_meta_attr(meta, attr: str, default=None):
    """Safely get a pyreadstat metadata attribute with a fallback default."""
    return getattr(meta, attr, default)


def get_column_metadata(lib_path: str) -> pd.DataFrame:
    """
    Read variable metadata from all datasets in a SAS library.
    Equivalent to PROC CONTENTS data=lib._all_.
    Uses metadataonly=True so no data rows are loaded.
    """
    rows = []
    lib = Path(lib_path)
    files = sorted(lib.glob("*.sas7bdat"))
    if not files:
        files = sorted(lib.glob("*.csv"))

    for fp in files:
        dom = fp.stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES):
            continue
        if fp.suffix.lower() == ".sas7bdat":
            rows.extend(_meta_from_sas(str(fp), dom))
        else:
            rows.extend(_meta_from_csv(str(fp), dom))

    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=[
            "domain", "variable", "label", "data_type", "length", "format"
        ])
    return df.drop_duplicates(subset=["domain", "variable"]).reset_index(drop=True)


def _meta_from_sas(path: str, domain: str) -> list:
    try:
        import pyreadstat
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            _, meta = pyreadstat.read_sas7bdat(path, metadataonly=True)

        column_names   = _safe_meta_attr(meta, "column_names", []) or []
        column_labels  = _safe_meta_attr(meta, "column_labels", []) or []
        var_formats    = _safe_meta_attr(meta, "variable_formats", {}) or {}
        var_types      = _safe_meta_attr(meta, "original_variable_types", []) or []
        # Some pyreadstat builds use readstat_variable_types instead
        if not var_types:
            var_types = _safe_meta_attr(meta, "readstat_variable_types", []) or []
        var_widths     = _safe_meta_attr(meta, "variable_storage_width", {}) or {}
        # Fallback: variable_value_labels carries type info in some builds
        col_types_map  = _safe_meta_attr(meta, "column_names_to_types", {}) or {}

        rows = []
        for idx, col in enumerate(column_names):
            label = ""
            if idx < len(column_labels) and column_labels[idx]:
                label = str(column_labels[idx])

            fmt = var_formats.get(col, "") if isinstance(var_formats, dict) else ""

            # Type inference: try multiple attribute sources
            typ_raw = ""
            if idx < len(var_types) and var_types[idx]:
                typ_raw = str(var_types[idx])
            elif col in col_types_map:
                typ_raw = str(col_types_map[col])

            if "char" in typ_raw.lower() and "date" in label.lower():
                dtype = "datetime"
            elif "char" in typ_raw.lower():
                dtype = "text"
            elif any(fmt_hint in str(fmt).upper() for fmt_hint in ("DATE", "TIME", "MMDD", "YYMMDD")):
                dtype = "datetime"
            else:
                dtype = "integer"

            lgth = var_widths.get(col, "") if isinstance(var_widths, dict) else ""

            rows.append({
                "domain": domain,
                "variable": col.upper(),
                "label": label,
                "data_type": dtype,
                "length": lgth,
                "format": fmt,
            })
        return rows
    except Exception as exc:
        # Only log at DEBUG level — shown in Streamlit warnings are suppressed
        log.debug("Cannot read SAS metadata for %s: %s", path, exc)
        return []


def _meta_from_csv(path: str, domain: str) -> list:
    try:
        df = pd.read_csv(path, nrows=0)
        return [
            {"domain": domain, "variable": col.upper(),
             "label": "", "data_type": "text", "length": "", "format": ""}
            for col in df.columns
        ]
    except Exception as exc:
        log.debug("Cannot read CSV metadata for %s: %s", path, exc)
        return []


def get_value_level(
    lib_path: str,
    columns_df: pd.DataFrame,
    mode: str = "SDTM",
) -> pd.DataFrame:
    """
    Extract distinct TESTCD/QNAM/PARAMCD values from SAS datasets
    to build the value-level (where-clause) table for Define-XML prep.
    Only loads data rows for domains that have the relevant columns.
    """
    mode = mode.upper()
    lib = Path(lib_path)

    if mode == "ADAM":
        cands = columns_df[
            columns_df["variable"].str.upper().isin(["PARAMCD"])
        ][["domain", "variable"]].copy()
        cands["orres"] = "AVAL"
        cands["where_prefix"] = cands["domain"] + ".PARAMCD."
    else:
        pattern = re.compile(r"TESTCD|QNAM|PARMCD", re.IGNORECASE)
        cands = columns_df[
            columns_df["variable"].str.match(pattern, na=False)
        ][["domain", "variable"]].copy()

        def _orres(v: str) -> str:
            v = v.upper()
            if "TESTCD" in v:
                return ""
            return "QVAL"

        cands["orres"] = cands["variable"].apply(_orres)
        cands["where_prefix"] = cands.apply(
            lambda r: r["domain"] + "." + r["variable"] + ".", axis=1
        )

    rows = []
    for _, cand in cands.iterrows():
        dom = cand["domain"]
        var = cand["variable"]
        fp = (next(lib.glob(f"{dom.lower()}.sas7bdat"), None)
              or next(lib.glob(f"{dom.upper()}.sas7bdat"), None)
              or next(lib.glob(f"{dom.lower()}.csv"), None))
        if fp is None:
            continue

        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                if str(fp).endswith(".sas7bdat"):
                    import pyreadstat
                    df, _ = pyreadstat.read_sas7bdat(str(fp), usecols=[var])
                else:
                    df = pd.read_csv(str(fp), usecols=[var])
            df.columns = [c.upper() for c in df.columns]
            if var not in df.columns:
                continue

            orres = cand["orres"]
            if not orres and "TESTCD" in var:
                orres = dom.upper() + "ORRES"

            for val in df[var].dropna().unique():
                val_str = str(val).strip()
                if not val_str:
                    continue
                where_c = cand["where_prefix"] + val_str
                rows.append({
                    "dataset": dom,
                    "variable": var,
                    "result_variable": orres,
                    "value": val_str,
                    "where_clause": where_c,
                    "data_type": _infer_dtype(val_str),
                })
        except Exception as exc:
            log.debug("Cannot read %s for value-level: %s", fp.name, exc)

    if not rows:
        return pd.DataFrame(columns=[
            "dataset", "variable", "result_variable", "value",
            "where_clause", "data_type"
        ])

    return pd.DataFrame(rows).drop_duplicates(
        subset=["dataset", "variable", "value"]
    ).reset_index(drop=True)


def _infer_dtype(val: str) -> str:
    try:
        n = float(val)
        if n == int(n):
            return "integer"
        return "float"
    except (ValueError, TypeError):
        pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T", val):
        return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$", val):
        return "Date"
    return "text"


def build_where_clause_table(value_level: pd.DataFrame, mode: str = "SDTM") -> pd.DataFrame:
    """Build the Where-Clause tab for Define-XML prep."""
    if value_level.empty:
        return pd.DataFrame(columns=["id", "dataset", "var", "comparator", "value"])
    wh = value_level[["dataset", "variable", "value", "where_clause"]].copy()
    wh["var"] = "PARAMCD" if mode.upper() == "ADAM" else wh["variable"]
    wh["comparator"] = "EQ"
    wh["id"] = wh["where_clause"]
    return wh[["id", "dataset", "var", "comparator", "value"]].reset_index(drop=True)

