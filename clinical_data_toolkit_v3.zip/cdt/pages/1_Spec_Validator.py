# pages/1_Spec_Validator.py
"""
Spec Validator page.
Runs per-variable checks on every active domain sheet.
Outputs: Issues (flat + by domain), Codelist check, CompMethod check, SDTM source.

TABLE RENDERING: Uses st.dataframe with column_config and a separate HTML
legend instead of pandas Styler, which caused washed-out background colours
in dark mode and made text unreadable (as seen in screenshot).
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import warnings
warnings.filterwarnings("ignore")

import io
from datetime import datetime

import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.check_rules import CHECK_RULES
from core.spec_validator import run_spec_validation, build_domain_summary
from core.excel_export import export_validation_results

st.set_page_config(page_title="Spec Validator", layout="wide")

# ---- Custom CSS: clean table styling that works in light AND dark mode ----
st.markdown("""
<style>
/* Severity badge pills */
.sev-error {
    display: inline-block;
    background: #dc2626;
    color: #fff;
    font-weight: 700;
    font-size: 11px;
    padding: 2px 8px;
    border-radius: 10px;
    letter-spacing: .04em;
}
.sev-warning {
    display: inline-block;
    background: #d97706;
    color: #fff;
    font-weight: 700;
    font-size: 11px;
    padding: 2px 8px;
    border-radius: 10px;
    letter-spacing: .04em;
}
/* Issue table HTML rendering */
.issue-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    font-family: 'Segoe UI', system-ui, sans-serif;
}
.issue-table th {
    background: #1e293b;
    color: #f1f5f9;
    padding: 9px 12px;
    text-align: left;
    font-weight: 600;
    font-size: 12px;
    letter-spacing: .04em;
    position: sticky;
    top: 0;
    z-index: 1;
}
.issue-table td {
    padding: 8px 12px;
    border-bottom: 1px solid rgba(148,163,184,.15);
    vertical-align: top;
    color: #1e293b;
    line-height: 1.45;
}
.issue-table tr.row-error td   { background: #fff1f2; }
.issue-table tr.row-warning td { background: #fffbeb; }
.issue-table tr.row-even td    { background: #f8fafc; }
.issue-table tr:hover td       { filter: brightness(.96); }
.issue-table .col-domain   { font-weight: 600; white-space: nowrap; color: #0f172a; }
.issue-table .col-variable { font-family: monospace; font-size: 12px; color: #1d4ed8; white-space: nowrap; }
.issue-table .col-desc     { max-width: 320px; }
.issue-table .col-sug      { max-width: 280px; color: #374151; }
.issue-table .col-small    { white-space: nowrap; font-size: 12px; color: #64748b; }
.scroll-wrap {
    max-height: 480px;
    overflow-y: auto;
    border: 1px solid rgba(148,163,184,.3);
    border-radius: 8px;
}
.legend-row {
    display: flex;
    gap: 16px;
    align-items: center;
    margin: 8px 0 6px;
    font-size: 12px;
}
.legend-dot {
    width: 12px; height: 12px;
    border-radius: 3px;
    display: inline-block;
    margin-right: 4px;
}
</style>
""", unsafe_allow_html=True)

st.title("Spec Validator")
st.caption(
    "Checks every active domain in the mapping spec for completeness "
    "and consistency issues before sponsor review."
)

if "spec" not in st.session_state:
    st.warning("Upload a mapping specification in the sidebar first.")
    st.stop()

spec = st.session_state["spec"]
spec_name = st.session_state.get("spec_name", "spec")
domains = st.session_state.get("spec_domains", [])


# ---- Helper: render issues as a clean readable HTML table ----
def _render_issues_html(df: pd.DataFrame, max_rows: int = 500) -> str:
    """Render an issues DataFrame as a readable HTML table with colour rows."""
    display_cols = [
        ("domain",         "Domain",      "col-domain"),
        ("variable",       "Variable",    "col-variable"),
        ("severity",       "Severity",    ""),
        ("check",          "Check",       "col-small"),
        ("description",    "Description", "col-desc"),
        ("suggestion",     "Suggestion",  "col-sug"),
        ("mapping_action", "Action",      "col-small"),
        ("origin",         "Origin",      "col-small"),
    ]
    present = [(col, lbl, cls) for col, lbl, cls in display_cols if col in df.columns]

    header = "".join(f"<th>{lbl}</th>" for _, lbl, _ in present)
    rows_html = []
    for i, (_, row) in enumerate(df.head(max_rows).iterrows()):
        sev = str(row.get("severity", "")).upper()
        row_cls = "row-error" if sev == "ERROR" else (
            "row-warning" if sev == "WARNING" else (
                "row-even" if i % 2 == 0 else ""
            )
        )
        cells = []
        for col, _, cls in present:
            val = str(row.get(col, ""))
            if col == "severity":
                pill_cls = "sev-error" if sev == "ERROR" else "sev-warning"
                cell = f'<td><span class="{pill_cls}">{val}</span></td>'
            else:
                cell = f'<td class="{cls}">{val}</td>'
            cells.append(cell)
        rows_html.append(f'<tr class="{row_cls}">{"".join(cells)}</tr>')

    if len(df) > max_rows:
        rows_html.append(
            f'<tr><td colspan="{len(present)}" style="text-align:center;'
            f'color:#64748b;padding:10px;">'
            f'... {len(df) - max_rows} more rows. Download Excel for full list.</td></tr>'
        )

    return (
        '<div class="scroll-wrap">'
        f'<table class="issue-table"><thead><tr>{header}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table></div>'
    )


def _render_generic_html(df: pd.DataFrame,
                          highlight_col: str = "",
                          highlight_neg: str = "NO",
                          max_rows: int = 500) -> str:
    """Render any DataFrame as a clean HTML table."""
    cols = list(df.columns)
    header = "".join(f"<th>{c.replace('_',' ').title()}</th>" for c in cols)
    rows_html = []
    for i, (_, row) in enumerate(df.head(max_rows).iterrows()):
        needs_hl = (
            highlight_col
            and highlight_col in row.index
            and str(row[highlight_col]).startswith(highlight_neg)
        )
        row_cls = "row-error" if needs_hl else ("row-even" if i % 2 == 0 else "")
        cells = []
        for col in cols:
            val = str(row.get(col, ""))
            if val == "nan":
                val = ""
            cells.append(f"<td>{val}</td>")
        rows_html.append(f'<tr class="{row_cls}">{"".join(cells)}</tr>')

    if len(df) > max_rows:
        rows_html.append(
            f'<tr><td colspan="{len(cols)}" style="text-align:center;color:#64748b;padding:10px;">'
            f'... {len(df) - max_rows} more rows. Download Excel for full list.</td></tr>'
        )
    return (
        '<div class="scroll-wrap">'
        f'<table class="issue-table"><thead><tr>{header}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table></div>'
    )


# ---- Configuration ----
with st.expander("Run configuration", expanded=False):
    col1, col2, col3 = st.columns(3)
    with col1:
        active_filter = st.text_input(
            "Active flag value (TOC column)",
            value="Y",
            help="Value in the 'active' column of the TOC sheet that marks a domain as active.",
        )
        explicit_input = st.text_area(
            "Override: explicit dataset list (comma-separated)",
            value="",
            help="Leave blank to use the active flag. Enter e.g. ADAE,ADSL,ADLB.",
        )
    with col2:
        st.write("Enable/disable checks:")
        enabled_checks = []
        for key, rule in CHECK_RULES.items():
            default = rule["active"]
            label = f"{rule['severity']}: {key}"
            if st.checkbox(label, value=default, key=f"chk_{key}"):
                enabled_checks.append(key)
    with col3:
        st.write("SDTM source check (optional):")
        st.caption("Upload SDTM datasets to check that SDTM-sourced variables exist.")
        sdtm_files = st.file_uploader(
            "Upload SDTM .sas7bdat files",
            type=["sas7bdat"],
            accept_multiple_files=True,
            key="sdtm_upload_validator",
            help="Upload one or more SDTM domain datasets. Used only for SDTM source variable check.",
        )
        run_sdtm_check = st.checkbox(
            "Run SDTM source check",
            value=bool(sdtm_files),
        )

# Parse explicit dataset list
explicit_datasets = None
if explicit_input.strip():
    explicit_datasets = [d.strip().upper() for d in explicit_input.split(",") if d.strip()]

# ---- Run button ----
if st.button("Run Validation", type="primary", use_container_width=True):
    sdtm_var_index = None
    if run_sdtm_check and sdtm_files:
        try:
            import pyreadstat
            var_index = set()
            for uf in sdtm_files:
                file_bytes = uf.read()
                buf = io.BytesIO(file_bytes)
                _, meta = pyreadstat.read_sas7bdat(buf, metadataonly=True)
                dom = Path(uf.name).stem.upper()
                for col in meta.column_names:
                    var_index.add(f"{dom}.{col.upper()}")
            sdtm_var_index = var_index
            st.info(f"Loaded SDTM variable index: {len(var_index)} variables from {len(sdtm_files)} file(s).")
        except Exception as exc:
            st.warning(f"Cannot read SDTM files: {exc}")

    with st.spinner("Running checks..."):
        progress = st.progress(0)
        try:
            results = run_spec_validation(
                spec,
                active_filter=active_filter,
                explicit_datasets=explicit_datasets,
                enabled_checks=enabled_checks if enabled_checks else None,
                sdtm_var_index=sdtm_var_index,
            )
            progress.progress(100)
            st.session_state["validation_results"] = results

            history = st.session_state.get("run_history", [])
            history.append({
                "time": datetime.now().strftime("%H:%M:%S"),
                "spec_name": spec_name,
                "errors": results["summary"]["errors"],
                "warnings": results["summary"]["warnings"],
            })
            st.session_state["run_history"] = history

        except Exception as exc:
            st.error(f"Validation failed: {exc}")
            st.exception(exc)

# ---- Display results ----
if "validation_results" not in st.session_state:
    st.info("Configure options above and click 'Run Validation'.")
    st.stop()

results = st.session_state["validation_results"]
summary = results["summary"]
issues: pd.DataFrame = results["issues"]
codelist_check: pd.DataFrame = results["codelist_check"]
compmethod_check: pd.DataFrame = results["compmethod_check"]
sdtm_source: pd.DataFrame = results["sdtm_source"]

# ---- Score banner ----
score = summary["health_score"]
grade = summary["grade"]
score_color = "#22c55e" if score >= 90 else ("#f59e0b" if score >= 75 else "#ef4444")

st.markdown(
    f"""<div style="background:{score_color}18;border:1px solid {score_color}44;
    border-radius:10px;padding:14px 20px;margin-bottom:4px;display:flex;
    align-items:center;gap:32px;">
    <div>
        <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.06em;">Health Score</div>
        <div style="font-size:28px;font-weight:800;color:{score_color};">{score}<span style="font-size:16px;font-weight:400;color:#94a3b8;">/100</span>
        &nbsp;<span style="font-size:18px;font-weight:700;color:{score_color};">{grade}</span></div>
    </div>
    <div style="display:flex;gap:24px;flex-wrap:wrap;">
        <div><div style="font-size:11px;color:#64748b;">Errors</div>
             <div style="font-size:22px;font-weight:700;color:#dc2626;">{summary['errors']}</div></div>
        <div><div style="font-size:11px;color:#64748b;">Warnings</div>
             <div style="font-size:22px;font-weight:700;color:#d97706;">{summary['warnings']}</div></div>
        <div><div style="font-size:11px;color:#64748b;">Codelist Issues</div>
             <div style="font-size:22px;font-weight:700;color:#7c3aed;">{summary['codelist_issues']}</div></div>
        <div><div style="font-size:11px;color:#64748b;">CompMethod Issues</div>
             <div style="font-size:22px;font-weight:700;color:#0891b2;">{summary['comp_issues']}</div></div>
    </div>
    </div>""",
    unsafe_allow_html=True,
)

st.divider()

# ---- Download ----
if not issues.empty or not codelist_check.empty:
    excel_bytes = export_validation_results(results, spec_name)
    st.download_button(
        label="Download Full Report (.xlsx)",
        data=excel_bytes,
        file_name=f"SpecValidation_{spec_name.replace('.xlsx','')}_{datetime.now():%Y%m%d_%H%M}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        type="secondary",
    )

# ---- Domain summary chart ----
if not issues.empty and HAS_PLOTLY:
    dom_summary = build_domain_summary(issues)
    if not dom_summary.empty:
        with st.expander("Issue distribution by domain", expanded=True):
            fig = px.bar(
                dom_summary,
                x="domain", y=["errors", "warnings"],
                barmode="stack",
                color_discrete_map={"errors": "#dc2626", "warnings": "#d97706"},
                labels={"value": "Count", "domain": "Domain"},
                title="Issues per Domain",
                height=280,
            )
            fig.update_layout(
                legend_title="Severity",
                margin=dict(l=0, r=0, t=36, b=0),
                plot_bgcolor="rgba(0,0,0,0)",
                paper_bgcolor="rgba(0,0,0,0)",
                font=dict(size=12),
            )
            fig.update_xaxes(tickangle=-30)
            st.plotly_chart(fig, use_container_width=True)

# ---- Tabs ----
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    f"Issues (Flat)  {len(issues)}",
    "Issues by Domain",
    "Codelist",
    "CompMethod",
    "SDTM Source",
])

with tab1:
    if issues.empty:
        st.success("No issues found across all active domains.")
    else:
        # Filters row
        col_f1, col_f2, col_f3 = st.columns(3)
        sev_options = ["All"] + sorted(issues["severity"].unique().tolist())
        dom_options = ["All"] + sorted(issues["domain"].unique().tolist())
        chk_options = ["All"] + sorted(issues["check"].unique().tolist())

        with col_f1:
            sev_filter = st.selectbox("Severity", sev_options, key="sev_flat")
        with col_f2:
            dom_filter = st.selectbox("Domain", dom_options, key="dom_flat")
        with col_f3:
            chk_filter = st.selectbox("Check type", chk_options, key="chk_flat")

        filtered = issues.copy()
        if sev_filter != "All":
            filtered = filtered[filtered["severity"] == sev_filter]
        if dom_filter != "All":
            filtered = filtered[filtered["domain"] == dom_filter]
        if chk_filter != "All":
            filtered = filtered[filtered["check"] == chk_filter]

        # Legend + count
        st.markdown(
            f'<div class="legend-row">'
            f'<span style="font-size:13px;color:#64748b;">Showing <b>{len(filtered)}</b> of <b>{len(issues)}</b> issues</span>'
            f'&nbsp;&nbsp;'
            f'<span class="legend-dot" style="background:#fff1f2;border:1px solid #fca5a5;"></span>Error row'
            f'&nbsp;&nbsp;'
            f'<span class="legend-dot" style="background:#fffbeb;border:1px solid #fcd34d;"></span>Warning row'
            f'</div>',
            unsafe_allow_html=True,
        )
        st.markdown(_render_issues_html(filtered), unsafe_allow_html=True)

with tab2:
    if issues.empty:
        st.success("No issues found.")
    else:
        all_domains_list = sorted(issues["domain"].unique())

        # Domain selector with issue count labels
        domain_labels = []
        for d in all_domains_list:
            g = issues[issues["domain"] == d]
            ne = int((g["severity"] == "ERROR").sum())
            nw = int((g["severity"] == "WARNING").sum())
            domain_labels.append(f"{d}  ({ne}E / {nw}W)")

        selected_idx = st.selectbox(
            "Select domain",
            range(len(all_domains_list)),
            format_func=lambda i: domain_labels[i],
            key="dom_bydom",
        )
        selected_domain = all_domains_list[selected_idx]
        dom_issues = issues[issues["domain"] == selected_domain]
        n_e = int((dom_issues["severity"] == "ERROR").sum())
        n_w = int((dom_issues["severity"] == "WARNING").sum())

        col_a, col_b, col_c = st.columns(3)
        col_a.metric("Domain", selected_domain)
        col_b.metric("Errors", n_e)
        col_c.metric("Warnings", n_w)

        display_cols_d2 = [c for c in [
            "variable", "severity", "check", "description", "suggestion",
        ] if c in dom_issues.columns]

        st.markdown(_render_issues_html(dom_issues[display_cols_d2 + [
            c for c in ["mapping_action","origin"] if c in dom_issues.columns
        ]]), unsafe_allow_html=True)

with tab3:
    if codelist_check.empty:
        st.info("No codelist references found in spec, or Codelist tab is missing.")
    else:
        missing_mask = codelist_check.get("in_codelist_tab", pd.Series(dtype=str)).str.startswith("NO")
        inactive_mask = codelist_check.get("active", pd.Series(dtype=str)).str.upper().isin(
            ["N", "NO", "FALSE", "0"]
        )
        n_missing  = int(missing_mask.sum())
        n_inactive = int(inactive_mask.sum())

        # Show unique CT standards found in this spec's Codelist tab
        ct_stds = []
        if "ct_standard" in codelist_check.columns:
            ct_stds = sorted(
                s for s in codelist_check["ct_standard"].dropna().unique()
                if s and s.lower() not in ("", "nan")
            )

        cc1, cc2, cc3 = st.columns(3)
        cc1.metric("Total Referenced", len(codelist_check))
        cc2.metric("Not in Codelist tab", n_missing)
        cc3.metric("Marked inactive", n_inactive)

        if ct_stds:
            st.markdown(
                "<div style='font-size:12px;color:#64748b;margin:4px 0 8px;'>"
                f"CT Standards in spec: "
                + " &nbsp;|&nbsp; ".join(
                    f"<code style='background:#e0f2fe;padding:2px 6px;border-radius:3px;"
                    f"color:#0369a1;'>{s}</code>" for s in ct_stds
                )
                + "</div>",
                unsafe_allow_html=True,
            )

        show_issues_only = st.checkbox("Show issues only", value=False, key="cl_issues_only")
        display_cl = codelist_check[missing_mask | inactive_mask] if show_issues_only else codelist_check

        st.markdown(
            _render_generic_html(display_cl, highlight_col="in_codelist_tab", highlight_neg="NO"),
            unsafe_allow_html=True,
        )

with tab4:
    if compmethod_check.empty:
        st.info("No CompMethod references found in spec, or Computation tab is missing.")
    else:
        fail_cols = [c for c in compmethod_check.columns if c.startswith("comp_")]

        # Count rows with any FAIL
        if fail_cols:
            fail_mask_tab4 = compmethod_check[fail_cols].apply(
                lambda col: col.astype(str).str.startswith("FAIL")
            ).any(axis=1)
            n_fails = int(fail_mask_tab4.sum())
        else:
            n_fails = 0
            fail_mask_tab4 = pd.Series(False, index=compmethod_check.index)

        n_missing_tab4 = int(
            compmethod_check["in_computation_tab"].str.startswith("NO").sum()
        ) if "in_computation_tab" in compmethod_check.columns else 0

        cm1, cm2, cm3 = st.columns(3)
        cm1.metric("Total Referenced", len(compmethod_check))
        cm2.metric("Not in Computation tab", n_missing_tab4)
        cm3.metric("Text check failures", n_fails)

        show_fails = st.checkbox("Show failures only", value=False, key="comp_fails")
        if show_fails:
            miss_mask_tab4 = compmethod_check.get("in_computation_tab", pd.Series(dtype=str)).str.startswith("NO")
            display_comp = compmethod_check[fail_mask_tab4 | miss_mask_tab4]
        else:
            display_comp = compmethod_check

        # Expandable detail view for algorithm text
        sel_opts = ["(none)"] + sorted(compmethod_check["compmethod_id"].dropna().unique().tolist())
        selected_comp = st.selectbox("View algorithm text:", sel_opts, key="comp_detail")
        if selected_comp != "(none)":
            comp_row = compmethod_check[compmethod_check["compmethod_id"] == selected_comp].iloc[0]
            st.text_area(
                "Algorithm text",
                value=comp_row.get("algorithm_preview", ""),
                height=110,
                disabled=True,
            )
            st.caption(f"Used by domains: {comp_row.get('used_by_domains', '')}")

        st.markdown(
            _render_generic_html(
                display_comp.drop(columns=["algorithm_preview"], errors="ignore"),
                highlight_col="in_computation_tab",
                highlight_neg="NO",
            ),
            unsafe_allow_html=True,
        )

with tab5:
    if sdtm_source.empty:
        st.info(
            "SDTM source check was not run. "
            "Upload SDTM .sas7bdat files in the Run Configuration section and enable the check."
        )
    else:
        n_not_found = int(
            sdtm_source["in_sdtm_lib"].str.startswith("NO").sum()
        ) if "in_sdtm_lib" in sdtm_source.columns else 0
        s1, s2 = st.columns(2)
        s1.metric("Variables checked", len(sdtm_source))
        s2.metric("Not found in SDTM library", n_not_found)

        st.markdown(
            _render_generic_html(sdtm_source, highlight_col="in_sdtm_lib", highlight_neg="NO"),
            unsafe_allow_html=True,
        )
