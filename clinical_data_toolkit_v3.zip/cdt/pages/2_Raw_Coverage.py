# pages/2_Raw_Coverage.py
"""
Raw variable coverage page.
Maps raw CRF variables to SDTM spec input_variables references.
Uses HTML table rendering (not pandas Styler) for proper colour display.
"""

import sys
import tempfile
import warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

warnings.filterwarnings("ignore")

from datetime import datetime

import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from core.raw_coverage import run_raw_coverage
from core.excel_export import export_coverage_results

st.set_page_config(page_title="Raw Coverage", layout="wide")

st.markdown("""
<style>
.cov-table { width:100%; border-collapse:collapse; font-size:13px; font-family:'Segoe UI',system-ui,sans-serif; }
.cov-table th { background:#1e293b; color:#f1f5f9; padding:9px 12px; text-align:left;
                font-size:12px; letter-spacing:.04em; position:sticky; top:0; z-index:1; }
.cov-table td { padding:7px 12px; border-bottom:1px solid rgba(148,163,184,.12);
                vertical-align:middle; }
.cov-table tr.exact   td { background:#f0fdf4; color:#14532d; }
.cov-table tr.partial td { background:#fffbeb; color:#713f12; }
.cov-table tr.unmapped td{ background:#fff1f2; color:#881337; }
.cov-table tr.even    td { background:#f8fafc; }
.cov-table tr:hover   td { filter:brightness(.96); }
.cov-table .mono { font-family:monospace; font-size:12px; }
.status-badge {
    display:inline-block; padding:2px 9px; border-radius:10px;
    font-size:11px; font-weight:700; letter-spacing:.04em;
}
.badge-exact   { background:#dcfce7; color:#166534; }
.badge-partial { background:#fef9c3; color:#854d0e; }
.badge-unmapped{ background:#ffe4e6; color:#9f1239; }
.cov-scroll { max-height:480px; overflow-y:auto;
              border:1px solid rgba(148,163,184,.25); border-radius:8px; }
</style>
""", unsafe_allow_html=True)

st.title("Raw Variable Coverage")
st.caption(
    "Maps raw CRF variables to SDTM spec input_variables references. "
    "Shows EXACT / PARTIAL / UNMAPPED status per variable."
)

if "spec" not in st.session_state:
    st.warning("Upload a mapping specification in the sidebar first.")
    st.stop()

spec = st.session_state["spec"]
spec_name = st.session_state.get("spec_name", "spec")


def _render_cov_table(df: pd.DataFrame, max_rows: int = 1000) -> str:
    """Render coverage DataFrame as a readable, colour-coded HTML table."""
    cols = list(df.columns)
    header = "".join(f"<th>{c.replace('_',' ').title()}</th>" for c in cols)
    rows_html = []
    for i, (_, row) in enumerate(df.head(max_rows).iterrows()):
        status = str(row.get("status", "")).upper()
        row_cls = {"EXACT": "exact", "PARTIAL": "partial", "UNMAPPED": "unmapped"}.get(
            status, "even" if i % 2 == 0 else ""
        )
        cells = []
        for col in cols:
            val = row.get(col, "")
            if col == "status":
                badge_cls = {"EXACT": "badge-exact", "PARTIAL": "badge-partial",
                             "UNMAPPED": "badge-unmapped"}.get(status, "")
                cell = f'<td><span class="status-badge {badge_cls}">{val}</span></td>'
            elif col in ("raw_variable", "mapped_to"):
                cell = f'<td class="mono">{val}</td>'
            else:
                cell = f"<td>{val}</td>"
            cells.append(cell)
        rows_html.append(f'<tr class="{row_cls}">{"".join(cells)}</tr>')

    if len(df) > max_rows:
        rows_html.append(
            f'<tr><td colspan="{len(cols)}" style="text-align:center;'
            f'color:#64748b;padding:10px;font-style:italic;">'
            f'Showing {max_rows} of {len(df)} rows &mdash; download Excel for full list'
            f'</td></tr>'
        )
    return (
        '<div class="cov-scroll">'
        f'<table class="cov-table"><thead><tr>{header}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table></div>'
    )


# ---- Upload + config ----
col1, col2 = st.columns([2, 1])
with col1:
    raw_files = st.file_uploader(
        "Upload raw CRF datasets (.sas7bdat)",
        type=["sas7bdat"],
        accept_multiple_files=True,
        help="Upload all raw domain datasets. Variable names are read from metadata (no data rows loaded).",
    )
with col2:
    active_filter = st.text_input(
        "Active flag value", value="Y",
        help="Value in the TOC 'active' column that marks a domain as active."
    )
    extra_excl = st.text_input(
        "Additional exclude vars (comma-separated)",
        value="",
        placeholder="SUBJIDNUM, PAGENO",
    )

extra_set = set()
if extra_excl.strip():
    extra_set = {v.strip().upper() for v in extra_excl.split(",") if v.strip()}

if not raw_files:
    st.info("Upload raw CRF .sas7bdat files to begin.")
    st.stop()

if st.button("Run Coverage Check", type="primary", use_container_width=True):
    with st.spinner(f"Scanning {len(raw_files)} file(s)..."):
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                for uf in raw_files:
                    data = uf.read()
                    (Path(tmpdir) / uf.name).write_bytes(data)
                cov_results = run_raw_coverage(
                    tmpdir, spec,
                    active_filter=active_filter,
                    exclude_vars=extra_set,
                )
            st.session_state["cov_results"] = cov_results
        except Exception as exc:
            st.error(f"Coverage check failed: {exc}")
            st.exception(exc)

if "cov_results" not in st.session_state:
    st.info("Click 'Run Coverage Check' to begin.")
    st.stop()

cov = st.session_state["cov_results"]
coverage: pd.DataFrame = cov.get("coverage", pd.DataFrame())
summary: pd.DataFrame = cov.get("summary", pd.DataFrame())

if coverage.empty:
    st.warning("No raw variables found. Ensure the uploaded files are valid SAS datasets.")
    st.stop()

# ---- Metrics banner ----
total      = len(coverage)
n_exact    = int((coverage["status"] == "EXACT").sum())
n_partial  = int((coverage["status"] == "PARTIAL").sum())
n_unmapped = int((coverage["status"] == "UNMAPPED").sum())
pct        = round((n_exact + n_partial) / total * 100, 1) if total else 0

st.markdown(
    f"""<div style="background:#1e293b;border-radius:10px;padding:16px 24px;
    display:flex;gap:32px;align-items:center;flex-wrap:wrap;margin-bottom:4px;">
    <div><div style="font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:.06em;">Total Raw Vars</div>
         <div style="font-size:26px;font-weight:800;color:#f1f5f9;">{total:,}</div></div>
    <div><div style="font-size:11px;color:#94a3b8;">EXACT</div>
         <div style="font-size:26px;font-weight:700;color:#4ade80;">{n_exact:,}</div></div>
    <div><div style="font-size:11px;color:#94a3b8;">PARTIAL</div>
         <div style="font-size:26px;font-weight:700;color:#fbbf24;">{n_partial:,}</div></div>
    <div><div style="font-size:11px;color:#94a3b8;">UNMAPPED</div>
         <div style="font-size:26px;font-weight:700;color:#f87171;">{n_unmapped:,}</div></div>
    <div><div style="font-size:11px;color:#94a3b8;">% Covered</div>
         <div style="font-size:26px;font-weight:800;color:#38bdf8;">{pct}%</div></div>
    </div>""",
    unsafe_allow_html=True,
)

# ---- Chart ----
if HAS_PLOTLY and not summary.empty:
    with st.expander("Coverage by dataset", expanded=True):
        chart_data = summary.melt(
            id_vars=["raw_dataset"],
            value_vars=[c for c in ["EXACT", "PARTIAL", "UNMAPPED"] if c in summary.columns],
            var_name="status", value_name="count",
        )
        fig = px.bar(
            chart_data, x="raw_dataset", y="count", color="status",
            color_discrete_map={"EXACT": "#22c55e", "PARTIAL": "#f59e0b", "UNMAPPED": "#ef4444"},
            barmode="stack",
            title="Variable coverage per raw dataset",
            height=300,
        )
        fig.update_layout(
            margin=dict(l=0, r=0, t=36, b=0),
            plot_bgcolor="rgba(0,0,0,0)",
            paper_bgcolor="rgba(0,0,0,0)",
            font=dict(size=12),
        )
        fig.update_xaxes(tickangle=-30)
        st.plotly_chart(fig, use_container_width=True)

# ---- Download ----
excel_bytes = export_coverage_results(coverage, summary)
st.download_button(
    label="Download Coverage Report (.xlsx)",
    data=excel_bytes,
    file_name=f"RawCoverage_{spec_name.replace('.xlsx','')}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)

st.divider()

# ---- Tabs ----
tab1, tab2 = st.tabs([
    f"Variable Detail  ({len(coverage):,})",
    "Dataset Summary",
])

with tab1:
    col_f1, col_f2 = st.columns(2)
    with col_f1:
        status_filter = st.selectbox(
            "Filter by status",
            ["All", "EXACT", "PARTIAL", "UNMAPPED"],
            key="cov_status",
        )
    with col_f2:
        ds_opts = ["All"] + sorted(coverage["raw_dataset"].dropna().unique().tolist())
        ds_filter = st.selectbox("Filter by dataset", ds_opts, key="cov_ds")

    disp = coverage.copy()
    if status_filter != "All":
        disp = disp[disp["status"] == status_filter]
    if ds_filter != "All":
        disp = disp[disp["raw_dataset"] == ds_filter]

    # Legend
    st.markdown(
        '<div style="display:flex;gap:14px;font-size:12px;margin:6px 0 6px;align-items:center;">'
        '<span style="background:#f0fdf4;padding:2px 10px;border-radius:4px;border:1px solid #86efac;color:#14532d;">EXACT - direct match</span>'
        '<span style="background:#fffbeb;padding:2px 10px;border-radius:4px;border:1px solid #fde68a;color:#713f12;">PARTIAL - substring match</span>'
        '<span style="background:#fff1f2;padding:2px 10px;border-radius:4px;border:1px solid #fecdd3;color:#881337;">UNMAPPED - no match</span>'
        f'<span style="margin-left:auto;color:#64748b;">Showing {len(disp):,} of {len(coverage):,}</span>'
        '</div>',
        unsafe_allow_html=True,
    )
    st.markdown(_render_cov_table(disp), unsafe_allow_html=True)

with tab2:
    if summary.empty:
        st.info("No summary available.")
    else:
        st.dataframe(summary, use_container_width=True, height=400)
