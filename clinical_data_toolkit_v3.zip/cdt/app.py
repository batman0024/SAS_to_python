# app.py
"""
Clinical Data Toolkit - Streamlit application entry point.
Provides sidebar navigation and shared spec upload.
"""

import sys
import warnings
from pathlib import Path

# Suppress all library warnings (pyreadstat encoding warnings, pandas FutureWarnings etc.)
warnings.filterwarnings("ignore")

sys.path.insert(0, str(Path(__file__).parent))

import streamlit as st

st.set_page_config(
    page_title="Clinical Data Toolkit",
    page_icon="flask",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Sidebar: spec upload lives here, persists across all pages ---
with st.sidebar:
    st.title("Clinical Data Toolkit")
    st.caption("Pre-Sponsor Review QC | v1.0")
    st.divider()

    uploaded = st.file_uploader(
        "Upload Mapping Spec (.xlsx)",
        type=["xlsx"],
        help="Primary mapping specification Excel file. "
             "Must contain a 'toc' sheet and per-domain sheets.",
    )

    if uploaded is not None:
        spec_bytes = uploaded.read()
        spec_key = f"spec__{uploaded.name}__{len(spec_bytes)}"

        if st.session_state.get("_loaded_spec_key") != spec_key:
            with st.spinner("Loading spec..."):
                try:
                    from core.spec_loader import load_spec_from_bytes, get_active_domains, get_spec_metadata
                    spec = load_spec_from_bytes(spec_bytes)
                    meta = get_spec_metadata(spec)
                    domains = get_active_domains(spec)
                    st.session_state["spec"] = spec
                    st.session_state["spec_bytes"] = spec_bytes
                    st.session_state["spec_name"] = uploaded.name
                    st.session_state["spec_meta"] = meta
                    st.session_state["spec_domains"] = domains
                    st.session_state["_loaded_spec_key"] = spec_key
                    # Clear any prior validation results
                    for k in ["validation_results", "run_history"]:
                        st.session_state.pop(k, None)
                except Exception as exc:
                    st.error(f"Cannot load spec: {exc}")

        if "spec" in st.session_state:
            st.success(f"{uploaded.name}")
            meta = st.session_state.get("spec_meta", {})
            domains = st.session_state.get("spec_domains", [])
            col1, col2 = st.columns(2)
            col1.metric("Domains", len(domains))
            col2.metric("Type", meta.get("spec_type", "?"))
            if meta.get("ig_version"):
                st.caption(f"IG: {meta['ig_version']}")
            if meta.get("ct_version"):
                st.caption(f"CT: {meta['ct_version']}")
            elif meta.get("ct_from_codelist"):
                st.caption(f"CT (from Codelist tab): {meta['ct_from_codelist'][0]}")
            if meta.get("study_name"):
                st.caption(f"Study: {meta['study_name']}")
    else:
        st.info("Upload a spec file to begin")
        st.session_state.pop("spec", None)

    st.divider()
    st.caption("Each tool has its own file uploader for SAS datasets.")
    st.caption("Spec Diff: upload a second spec on page 5.")

    # Keep ct_path for future CT validation use
    with st.expander("Optional: CDISC CT file path", expanded=False):
        ct_path = st.text_input(
            "CDISC CT Excel path (optional)",
            value=st.session_state.get("ct_path", ""),
            placeholder="/path/to/ct_2024.xlsx",
            help="Path to CDISC Controlled Terminology Excel file for codelist validation.",
        )
        if ct_path:
            st.session_state["ct_path"] = ct_path

    # Run history
    if st.session_state.get("run_history"):
        st.divider()
        st.caption("Recent runs")
        for run in reversed(st.session_state["run_history"][-5:]):
            icon = "red_circle" if run["errors"] > 0 else (
                "large_yellow_circle" if run["warnings"] > 0 else "large_green_circle"
            )
            st.caption(
                f":{icon}: {run['time']}  "
                f"{run['errors']}E / {run['warnings']}W"
            )

# --- Home page ---
st.title("Clinical Data Toolkit")
st.write(
    "A modular QC toolkit for clinical data programming. "
    "Upload a mapping specification in the sidebar to begin."
)

st.divider()

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.subheader("Spec Validator")
    st.write(
        "Check mapping spec completeness: missing origins, "
        "input variables, comments, computation methods. "
        "Issues grouped by domain with severity levels."
    )
with col2:
    st.subheader("Raw Coverage")
    st.write(
        "Map raw CRF variables to SDTM spec input references. "
        "Shows EXACT / PARTIAL / UNMAPPED status per variable."
    )
with col3:
    st.subheader("Define Helper")
    st.write(
        "Extract variable metadata and value-level entries "
        "from SAS datasets. Supports SDTM and ADaM libraries."
    )
with col4:
    st.subheader("Date Imputer")
    st.write(
        "Impute partial/missing AE dates per SAP rules. "
        "Full datetime records are passed through as-is. "
        "Preview before download."
    )

st.divider()
col5, col6, _ = st.columns(3)
with col5:
    st.subheader("Spec Diff")
    st.write(
        "Compare two spec files (e.g. core standard vs study) "
        "field by field. Filter to see only changed variables."
    )
with col6:
    st.subheader("Codelist Check")
    st.write(
        "Validate codelist references in the spec against the "
        "Codelist and Computation tabs. "
        "Included in Spec Validator as a dedicated tab."
    )

if "spec" not in st.session_state:
    st.info("Use the sidebar to upload a mapping specification and navigate to a tool.")
