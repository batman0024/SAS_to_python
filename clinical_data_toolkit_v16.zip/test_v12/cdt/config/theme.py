# config/theme.py
"""
Shared CSS and HTML table renderer. Supports light and dark modes.
"""

# ── Dark mode palette ─────────────────────────────────────────────────────
DARK = {
    "bg_card":    "#1e293b",
    "border":     "rgba(148,163,184,.2)",
    "hdr_bg":     "#1e293b",  "hdr_fg":    "#f1f5f9",
    "text_main":  "#f1f5f9",  "text_muted":"#94a3b8",
    "exact_bg":   "#052e16",  "exact_fg":   "#4ade80",
    "partial_bg": "#422006",  "partial_fg": "#fbbf24",
    "unmap_bg":   "#450a0a",  "unmap_fg":   "#f87171",
    "error_bg":   "#450a0a",  "error_fg":   "#fca5a5",
    "warn_bg":    "#451a03",  "warn_fg":    "#fcd34d",
    "pass_bg":    "#052e16",  "pass_fg":    "#4ade80",
    "miss_bg":    "#450a0a",  "miss_fg":    "#fca5a5",
    "dt_bg":      "#0c1a3a",  "dt_fg":      "#93c5fd",
    "inline_bg":  "#0c2340",  "inline_fg":  "#7dd3fc",
    "row_alt":    "#1e293b",
    "badge_error_bg":"#dc2626","badge_error_fg":"#fff",
    "badge_warn_bg": "#d97706","badge_warn_fg": "#fff",
    "badge_inline_bg":"#0369a1","badge_inline_fg":"#fff",
}

# ── Light mode palette ────────────────────────────────────────────────────
LIGHT = {
    "bg_card":    "#f1f5f9",
    "border":     "rgba(100,116,139,.25)",
    "hdr_bg":     "#1e3a5f",  "hdr_fg":    "#ffffff",
    "text_main":  "#0f172a",  "text_muted":"#475569",
    "exact_bg":   "#dcfce7",  "exact_fg":   "#14532d",
    "partial_bg": "#fef9c3",  "partial_fg": "#713f12",
    "unmap_bg":   "#fee2e2",  "unmap_fg":   "#7f1d1d",
    "error_bg":   "#fee2e2",  "error_fg":   "#7f1d1d",
    "warn_bg":    "#fef3c7",  "warn_fg":    "#78350f",
    "pass_bg":    "#dcfce7",  "pass_fg":    "#14532d",
    "miss_bg":    "#fee2e2",  "miss_fg":    "#7f1d1d",
    "dt_bg":      "#dbeafe",  "dt_fg":      "#1e3a5f",
    "inline_bg":  "#e0f2fe",  "inline_fg":  "#075985",
    "row_alt":    "#f8fafc",
    "badge_error_bg":"#dc2626","badge_error_fg":"#fff",
    "badge_warn_bg": "#d97706","badge_warn_fg": "#fff",
    "badge_inline_bg":"#0369a1","badge_inline_fg":"#fff",
}

# Active palette — set by app.py from session_state
def get_palette(mode: str = "dark") -> dict:
    return LIGHT if mode == "light" else DARK


def build_css(C: dict) -> str:
    return f"""
<style>
.cdt-table {{
    width:100%; border-collapse:collapse; font-size:13px;
    font-family:'Segoe UI',system-ui,sans-serif; color:{C['text_main']};
}}
.cdt-table th {{
    background:{C['hdr_bg']}; color:{C['hdr_fg']}; padding:9px 12px;
    text-align:left; font-size:11px; font-weight:700; letter-spacing:.05em;
    text-transform:uppercase; position:sticky; top:0; z-index:2;
    border-bottom:2px solid {C['border']};
}}
.cdt-table td {{
    padding:7px 12px; border-bottom:1px solid {C['border']};
    vertical-align:top; line-height:1.45;
}}
.cdt-table tr.row-exact    td {{ background:{C['exact_bg']};   color:{C['exact_fg']}; }}
.cdt-table tr.row-partial  td {{ background:{C['partial_bg']}; color:{C['partial_fg']}; }}
.cdt-table tr.row-unmapped td {{ background:{C['unmap_bg']};   color:{C['unmap_fg']}; }}
.cdt-table tr.row-error    td {{ background:{C['error_bg']};   color:{C['error_fg']}; }}
.cdt-table tr.row-warning  td {{ background:{C['warn_bg']};    color:{C['warn_fg']}; }}
.cdt-table tr.row-pass     td {{ background:{C['pass_bg']};    color:{C['pass_fg']}; }}
.cdt-table tr.row-miss     td {{ background:{C['miss_bg']};    color:{C['miss_fg']}; }}
.cdt-table tr.row-dt       td {{ background:{C['dt_bg']};      color:{C['dt_fg']}; }}
.cdt-table tr.row-inline   td {{ background:{C['inline_bg']};  color:{C['inline_fg']}; }}
.cdt-table tr.row-alt      td {{ background:{C['row_alt']}; }}
.cdt-table tr:hover        td {{ filter:brightness(1.06); }}
.cdt-table .mono {{ font-family:'Courier New',monospace; font-size:12px; }}
.cdt-scroll {{
    max-height:500px; overflow-y:auto;
    border:1px solid {C['border']}; border-radius:8px;
}}
.badge {{
    display:inline-block; padding:2px 9px; border-radius:10px;
    font-size:11px; font-weight:700; letter-spacing:.04em;
}}
.badge-error   {{ background:{C['badge_error_bg']};  color:{C['badge_error_fg']}; }}
.badge-warning {{ background:{C['badge_warn_bg']};   color:{C['badge_warn_fg']}; }}
.badge-exact   {{ background:{C['exact_bg']};  color:{C['exact_fg']}; border:1px solid {C['exact_fg']}33; }}
.badge-partial {{ background:{C['partial_bg']}; color:{C['partial_fg']}; border:1px solid {C['partial_fg']}33; }}
.badge-unmapped{{ background:{C['unmap_bg']};  color:{C['unmap_fg']}; border:1px solid {C['unmap_fg']}33; }}
.badge-pass    {{ background:{C['pass_bg']};   color:{C['pass_fg']}; border:1px solid {C['pass_fg']}33; }}
.badge-miss    {{ background:{C['miss_bg']};   color:{C['miss_fg']}; border:1px solid {C['miss_fg']}33; }}
.badge-inline  {{ background:{C['inline_bg']}; color:{C['inline_fg']}; border:1px solid {C['inline_fg']}33; }}
.metric-bar {{
    background:{C['bg_card']}; border-radius:10px; padding:14px 24px;
    display:flex; gap:32px; flex-wrap:wrap; align-items:center; margin-bottom:8px;
}}
.metric-item .label {{
    font-size:11px; color:{C['text_muted']};
    text-transform:uppercase; letter-spacing:.06em;
}}
.metric-item .value {{ font-size:24px; font-weight:800; }}
.score-banner {{
    border-radius:10px; padding:14px 20px; margin-bottom:4px;
    display:flex; align-items:center; gap:32px; flex-wrap:wrap;
}}
.legend-row {{
    display:flex; gap:12px; font-size:12px; margin:6px 0;
    align-items:center; flex-wrap:wrap; color:{C['text_muted']};
}}
.legend-chip {{ padding:2px 10px; border-radius:4px; font-size:12px; }}
</style>
"""

# Defaults
C        = DARK
BASE_CSS = build_css(C)


def get_theme_css(mode: str = "dark") -> str:
    return build_css(get_palette(mode))


def render_table(
    df,
    row_class_fn=None,
    cell_fn=None,
    max_rows: int = 1000,
    id_str: str = "",
    C: dict = None,
) -> str:
    if C is None:
        from config.theme import DARK
        C = DARK
    if df is None or df.empty:
        return f"<p style='color:{C['text_muted']};font-style:italic;padding:8px;'>No data.</p>"

    cols = list(df.columns)
    header = "".join(f"<th>{c.replace('_',' ').title()}</th>" for c in cols)

    rows_html = []
    for i, (_, row) in enumerate(df.head(max_rows).iterrows()):
        row_d = row.to_dict()
        rc = row_class_fn(row_d) if row_class_fn else ("row-alt" if i % 2 == 0 else "")
        cells = []
        for col in cols:
            val = row_d.get(col, "")
            if val is None or (isinstance(val, float) and val != val):
                val = ""
            if cell_fn:
                cells.append(f"<td>{cell_fn(col, str(val), row_d)}</td>")
            else:
                mono = "mono" if col.lower() in (
                    "variable","raw_variable","mapped_to","compmethod_id",
                    "where_clause","raw_dataset","value","ct_values_allowed",
                    "sample_values","ct_mismatch_values") else ""
                cells.append(f'<td class="{mono}">{val}</td>')
        rows_html.append(f'<tr class="{rc}">{"".join(cells)}</tr>')

    if len(df) > max_rows:
        rows_html.append(
            f'<tr><td colspan="{len(cols)}" style="text-align:center;'
            f'color:{C["text_muted"]};padding:10px;font-style:italic;">'
            f'Showing {max_rows:,} of {len(df):,} rows — download Excel for full list'
            f'</td></tr>'
        )

    return (
        f'<div class="cdt-scroll" id="{id_str}">'
        f'<table class="cdt-table"><thead><tr>{header}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table></div>'
    )
