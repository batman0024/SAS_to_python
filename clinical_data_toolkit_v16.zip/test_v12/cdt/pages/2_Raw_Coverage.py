# pages/2_Raw_Coverage.py
import sys, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import get_palette, build_css, render_table, DARK as C_default
from core.raw_coverage import run_raw_coverage_from_store
from core.excel_export import export_coverage_results

st.set_page_config(page_title="Raw Coverage", layout="wide")
theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True,
    key=f"theme_{__file__}", help="Switch display theme.")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)
st.title("Raw Variable Coverage")
st.caption("Validates at raw.DATASET.VARIABLE level. SUPP domain logic applied automatically.")

if "spec" not in st.session_state:
    st.warning("Upload a mapping specification in the sidebar first."); st.stop()
if "raw_files_store" not in st.session_state:
    st.warning("Upload raw CRF datasets (.sas7bdat) in the sidebar first."); st.stop()

spec      = st.session_state["spec"]
spec_name = st.session_state.get("spec_name","spec")
raw_store = st.session_state["raw_files_store"]

col1,col2 = st.columns([3,1])
with col1:
    ds_list = ", ".join(Path(k).stem.upper() for k in sorted(raw_store.keys()))
    st.info(f"Using {len(raw_store)} raw file(s): {ds_list[:120]}{'...' if len(ds_list)>120 else ''}")
with col2:
    active_filter = st.text_input("Active flag value", value="Y")
    extra_excl    = st.text_input("Extra exclude vars", value="", placeholder="VAR1,VAR2")

extra_set = {v.strip().upper() for v in extra_excl.split(",") if v.strip()} if extra_excl.strip() else set()

if st.button("Run Coverage Check", type="primary", use_container_width=True):
    with st.spinner(f"Analysing {len(raw_store)} file(s)..."):
        try:
            r = run_raw_coverage_from_store(raw_store, spec, active_filter=active_filter, exclude_vars=extra_set)
            st.session_state["cov_results"] = r
        except Exception as exc:
            st.error(f"Failed: {exc}"); st.exception(exc)

if "cov_results" not in st.session_state:
    st.info("Click 'Run Coverage Check' to begin."); st.stop()

cov_r    = st.session_state["cov_results"]
coverage = cov_r.get("coverage", pd.DataFrame())
summary  = cov_r.get("summary",  pd.DataFrame())
dom_map  = cov_r.get("domain_mapping", pd.DataFrame())

if coverage.empty:
    st.warning("No raw variables found."); st.stop()

total     = len(coverage)
n_exact   = int((coverage["status"]=="EXACT").sum())
n_partial = int((coverage["status"]=="PARTIAL").sum())
n_unmap   = int((coverage["status"]=="UNMAPPED").sum())
pct       = round((n_exact+n_partial)/total*100,1) if total else 0

st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">Total Raw Vars</div><div class="value" style="color:{C["text_main"]};">{total:,}</div></div>'
    f'<div class="metric-item"><div class="label">EXACT</div><div class="value" style="color:{C["exact_fg"]};">{n_exact:,}</div></div>'
    f'<div class="metric-item"><div class="label">PARTIAL</div><div class="value" style="color:{C["partial_fg"]};">{n_partial:,}</div></div>'
    f'<div class="metric-item"><div class="label">UNMAPPED</div><div class="value" style="color:{C["unmap_fg"]};">{n_unmap:,}</div></div>'
    f'<div class="metric-item"><div class="label">% Covered</div><div class="value" style="color:#38bdf8;">{pct}%</div></div>'
    f'</div>',
    unsafe_allow_html=True
)

if HAS_PLOTLY and not summary.empty:
    with st.expander("Coverage by raw dataset", expanded=True):
        chart_d = summary.melt(id_vars=["raw_dataset"],
            value_vars=[c for c in ["EXACT","PARTIAL","UNMAPPED"] if c in summary.columns],
            var_name="status", value_name="count")
        fig = px.bar(chart_d, x="raw_dataset", y="count", color="status",
                     color_discrete_map={"EXACT":"#4ade80","PARTIAL":"#fbbf24","UNMAPPED":"#f87171"},
                     barmode="stack", height=260,
                     template="plotly_dark")
        fig.update_layout(margin=dict(l=0,r=0,t=20,b=0),
                           plot_bgcolor="rgba(0,0,0,0)",paper_bgcolor="rgba(0,0,0,0)")
        fig.update_xaxes(tickangle=-30)
        st.plotly_chart(fig, use_container_width=True)

excel_bytes = export_coverage_results(coverage, summary)
st.download_button("⬇ Download Coverage Report (.xlsx)", data=excel_bytes,
    file_name=f"RawCoverage_{spec_name.replace('.xlsx','')}_{datetime.now():%Y%m%d_%H%M}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

st.divider()

def _cov_row_class(row):
    s = str(row.get("status","")).upper()
    return {"EXACT":"row-exact","PARTIAL":"row-partial","UNMAPPED":"row-unmapped"}.get(s,"")

def _cov_cell(col, val, row):
    if col == "status":
        cls = {"EXACT":"badge-exact","PARTIAL":"badge-partial","UNMAPPED":"badge-unmapped"}.get(val,"")
        return f'<span class="badge {cls}">{val}</span>'
    return f'<span class="mono">{val}</span>' if col in ("raw_variable","mapped_to","sdtm_domain","raw_dataset") else val

tab1, tab2, tab3, tab4 = st.tabs([
    f"Variable Detail ({len(coverage):,})",
    "Dataset Summary",
    "Raw → SDTM Domain Map",
    f"Unmapped ({n_unmap:,})",
])

with tab1:
    cf1,cf2 = st.columns(2)
    sf = cf1.selectbox("Status", ["All","EXACT","PARTIAL","UNMAPPED"], key="cov_sf")
    ds_opts = ["All"] + sorted(coverage["raw_dataset"].dropna().unique().tolist())
    df_sel  = cf2.selectbox("Raw Dataset", ds_opts, key="cov_df")
    disp = coverage.copy()
    if sf != "All":     disp = disp[disp["status"]==sf]
    if df_sel != "All": disp = disp[disp["raw_dataset"]==df_sel]
    show = [c for c in ["raw_dataset","raw_variable","status","sdtm_domain","mapped_to"] if c in disp.columns]
    st.markdown(f'<div class="legend-row"><span style="color:{C["text_muted"]};">Showing <b>{len(disp):,}</b> of <b>{len(coverage):,}</b></span></div>', unsafe_allow_html=True)
    st.markdown(render_table(disp[show], row_class_fn=_cov_row_class, cell_fn=_cov_cell, C=C), unsafe_allow_html=True)

with tab2:
    st.dataframe(summary, use_container_width=True, height=400)

with tab3:
    st.caption("Each raw dataset and all SDTM domains it feeds into.")
    if dom_map.empty:
        st.info("No domain mapping data.")
    else:
        disp_dm = dom_map[["raw_dataset","sdtm_domains","n_sdtm_domains","n_variables"]].copy()
        disp_dm.columns = ["Raw Dataset","SDTM Domains","# SDTM Domains","# Spec Refs"]
        st.dataframe(disp_dm, use_container_width=True, height=400)
        if HAS_PLOTLY:
            fig2 = px.bar(dom_map, x="raw_dataset", y="n_sdtm_domains",
                          labels={"raw_dataset":"Raw Dataset","n_sdtm_domains":"# SDTM Domains"},
                          color="n_sdtm_domains", color_continuous_scale="Blues",
                          height=230, template="plotly_dark")
            fig2.update_layout(margin=dict(l=0,r=0,t=20,b=0),
                                plot_bgcolor="rgba(0,0,0,0)",paper_bgcolor="rgba(0,0,0,0)",showlegend=False)
            fig2.update_xaxes(tickangle=-30)
            st.plotly_chart(fig2, use_container_width=True)

with tab4:
    unm = coverage[coverage["status"]=="UNMAPPED"].copy()
    if unm.empty:
        st.success("No unmapped variables!")
    else:
        ds_u_opts = ["All"] + sorted(unm["raw_dataset"].dropna().unique().tolist())
        ds_u = st.selectbox("Dataset", ds_u_opts, key="cov_unm_ds")
        if ds_u != "All": unm = unm[unm["raw_dataset"]==ds_u]
        show_u = [c for c in ["raw_dataset","raw_variable"] if c in unm.columns]
        st.markdown(render_table(unm[show_u], row_class_fn=_cov_row_class, cell_fn=_cov_cell, C=C), unsafe_allow_html=True)
