# pages/3_Define_Helper.py  v15
import sys, warnings, io, traceback
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
warnings.filterwarnings("ignore")

from datetime import datetime
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from config.theme import get_palette, build_css, render_table
from core.define_helper import (
    get_column_metadata_from_store,
    get_value_level_from_store,
    build_where_clause_table,
    build_vlm_from_spec_and_data,
    compare_data_vs_codelist,
    generate_define_xml,
    _find_codelist_tab,
    _get_codelist_map_from_spec,
    _get_active_domains_from_toc,
    _supported_ext,
)
from core.excel_export import export_define_results

st.set_page_config(page_title="Define Helper", layout="wide")
theme_mode = st.sidebar.radio("Theme", ["dark","light"], horizontal=True, key="def_theme")
C = get_palette(theme_mode)
st.markdown(build_css(C), unsafe_allow_html=True)

st.title("Define Helper")
st.caption("Variable metadata · VLM / CT comparison · Value Level · Where Clause · Define-XML v2.1")

# ── Sidebar info ─────────────────────────────────────────────────────────────
st.sidebar.markdown(
    "**Accepted formats:** `.sas7bdat` · `.xpt` · `.csv`\n\n"
    "Upload in the **main sidebar** above, or use the **in-page uploader** below."
)

# ── Get datasets from sidebar ─────────────────────────────────────────────────
sidebar_store = st.session_state.get("sdtm_files_store", {})
spec          = st.session_state.get("spec")
spec_name     = st.session_state.get("spec_name", "")

# ── IN-PAGE UPLOADER (always visible, supplements sidebar uploads) ─────────────
with st.expander("📂 Upload datasets directly here (.sas7bdat / .xpt / .csv)", expanded=not sidebar_store):
    st.caption(
        "Use this uploader if your datasets did not load via the sidebar, "
        "or if you want to upload files specifically for Define Helper."
    )
    inline_files = st.file_uploader(
        "Upload SDTM/ADaM datasets",
        type=["sas7bdat", "xpt", "csv"],
        accept_multiple_files=True,
        key="define_helper_inline_upload",
        help="Files uploaded here are merged with sidebar uploads.",
    )
    if inline_files:
        inline_store = {f.name: f.getvalue() for f in inline_files}
        n_inline = len(inline_store)
        st.success(f"✅ {n_inline} file(s) ready from this uploader")
    else:
        inline_store = {}

# Merge sidebar + inline uploads
sdtm_store = {**sidebar_store, **inline_store}

if not sdtm_store:
    st.warning("No datasets loaded. Upload SDTM/ADaM datasets in the sidebar or using the uploader above.")
    st.stop()

# ── Dataset info ──────────────────────────────────────────────────────────────
ds_names  = ", ".join(sorted(Path(k).stem.upper() for k in sdtm_store.keys()))
ext_counts= {}
for k in sdtm_store:
    ext = Path(k).suffix.lower()
    ext_counts[ext] = ext_counts.get(ext, 0) + 1
ext_str = " · ".join(f"{v} {k}" for k, v in ext_counts.items())
st.info(f"**{len(sdtm_store)} dataset(s)** ({ext_str}): {ds_names[:200]}{'...' if len(ds_names)>200 else ''}")

# ── Spec status ────────────────────────────────────────────────────────────────
cl_tab = None; cl_map = {}; active_domains = []
if spec:
    cl_tab         = _find_codelist_tab(spec)
    cl_map         = _get_codelist_map_from_spec(spec)
    active_domains = _get_active_domains_from_toc(spec)
    cl_ok          = cl_tab is not None
    c1, c2 = st.columns(2)
    cl_msg = f"✅ Codelist tab found ({len(cl_tab):,} rows)" if cl_ok else "⚠️ Codelist tab NOT found"
    c1.info(f"**Spec:** {spec_name}  |  {cl_msg}")
    c2.info(f"**TOC active domains:** {len(active_domains)}  |  **Variables with codelist:** {len(cl_map)}")
else:
    st.warning("No mapping spec loaded. Upload spec in the sidebar for VLM and CT features.")

# ── Options ────────────────────────────────────────────────────────────────────
with st.expander("Options", expanded=False):
    col1, col2 = st.columns(2)
    with col1:
        mode     = st.radio("Mode", ["SDTM","ADaM"], horizontal=True,
                            help="SDTM: scans for TESTCD/QNAM columns. ADaM: scans for PARAMCD.")
        run_meta = st.checkbox("Extract variable metadata (PROC CONTENTS)", value=True)
        run_vlm  = st.checkbox("Build VLM from spec codelist column",
                               value=bool(spec and cl_tab is not None))
        run_ct   = st.checkbox("Run CT comparison (data vs codelist)",
                               value=bool(spec and cl_tab is not None))
    with col2:
        run_vl   = st.checkbox("Extract value-level (TESTCD/QNAM/PARAMCD)", value=True)
        run_xml  = st.checkbox("Generate Define-XML v2.1", value=False)
        study_name = st.text_input("Study name (for Define-XML)",
                                   value=spec_name.replace(".xlsx","").replace(".xls",""))
        st.caption("ℹ️ Value Level scans file headers directly — no metadata step required.")
        st.caption("ℹ️ Active=N in Codelist tab does NOT exclude CT values.")
        st.caption("ℹ️ MedDRA, WHODrug, result vars (--STRESC/ORRES) excluded from CT.")

# ── Generate button ────────────────────────────────────────────────────────────
if st.button("Generate", type="primary", use_container_width=True):
    columns_df = pd.DataFrame(); vlm_df = pd.DataFrame()
    ct_df = pd.DataFrame(); vl_df = pd.DataFrame()
    wh_df = pd.DataFrame(); read_errors = []
    vl_errors = []; define_xml_str = ""

    # Step 1 — Variable metadata
    if run_meta:
        with st.spinner("Extracting variable metadata..."):
            try:
                result = get_column_metadata_from_store(sdtm_store)
                columns_df, read_errors = result if isinstance(result, tuple) else (result, [])
            except Exception as exc:
                read_errors = [f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"]
        if read_errors:
            with st.expander(f"⚠ {len(read_errors)} metadata issue(s)", expanded=False):
                for e in read_errors[:10]: st.code(str(e)[:500])

    # Step 2 — VLM
    if run_vlm and spec and cl_tab is not None:
        with st.spinner("Building VLM from spec codelist..."):
            try:
                vlm_df = build_vlm_from_spec_and_data(sdtm_store, spec)
            except Exception as exc:
                st.warning(f"VLM error: {type(exc).__name__}: {exc}")

    # Step 3 — CT comparison
    if run_ct and spec and cl_tab is not None:
        with st.spinner("Running CT comparison..."):
            try:
                ct_df = compare_data_vs_codelist(sdtm_store, spec)
            except Exception as exc:
                st.warning(f"CT error: {type(exc).__name__}: {exc}")

    # Step 4 — Value level
    if run_vl:
        with st.spinner("Extracting value-level (TESTCD/QNAM/PARAMCD)..."):
            try:
                result_vl = get_value_level_from_store(sdtm_store, columns_df or None, mode)
                vl_df, vl_errors = result_vl if isinstance(result_vl, tuple) else (result_vl, [])
                if not vl_df.empty:
                    wh_df = build_where_clause_table(vl_df, mode)
            except Exception as exc:
                vl_errors = [f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"]
        if vl_errors:
            with st.expander(f"⚠ Value-level errors ({len(vl_errors)})", expanded=False):
                for e in vl_errors[:10]: st.code(str(e)[:400])

    # Step 5 — Define-XML
    if run_xml:
        with st.spinner("Generating Define-XML v2.1..."):
            try:
                define_xml_str = generate_define_xml(
                    columns_df if not columns_df.empty else pd.DataFrame(),
                    vl_df      if not vl_df.empty      else pd.DataFrame(),
                    wh_df      if not wh_df.empty       else pd.DataFrame(),
                    spec       = spec,
                    study_name = study_name or "Study",
                )
            except Exception as exc:
                st.warning(f"Define-XML error: {type(exc).__name__}: {exc}")
                st.code(traceback.format_exc())

    st.session_state.update({
        "define_columns":      columns_df,
        "define_mode":         mode,
        "define_vlm":          vlm_df,
        "define_ct_compare":   ct_df,
        "define_value_level":  vl_df,
        "define_where_clause": wh_df,
        "define_xml":          define_xml_str,
        "define_meta_skipped": not run_meta,
        "define_meta_failed":  run_meta and columns_df.empty,
    })
    st.rerun()

# ── Nothing generated ─────────────────────────────────────────────────────────
if not any(k in st.session_state for k in (
        "define_columns","define_vlm","define_ct_compare","define_value_level")):
    st.info("Configure options and click Generate.")
    st.stop()

columns_df   = st.session_state.get("define_columns",     pd.DataFrame())
vlm_df       = st.session_state.get("define_vlm",         pd.DataFrame())
ct_df        = st.session_state.get("define_ct_compare",  pd.DataFrame())
vl_df        = st.session_state.get("define_value_level", pd.DataFrame())
wh_df        = st.session_state.get("define_where_clause",pd.DataFrame())
mode         = st.session_state.get("define_mode",        "SDTM")
define_xml   = st.session_state.get("define_xml",         "")
meta_skipped = st.session_state.get("define_meta_skipped",False)
meta_failed  = st.session_state.get("define_meta_failed", False)

n_vars   = len(columns_df)
n_cl_vars= vlm_df["variable"].nunique() if not vlm_df.empty else 0
n_ct     = len(ct_df) if not ct_df.empty else 0
n_miss   = int((ct_df["status"]=="MISMATCH").sum())        if not ct_df.empty else 0
n_miss_v = int(ct_df[ct_df["status"]=="MISMATCH"]["variable"].nunique()) if not ct_df.empty else 0
n_vl     = len(vl_df) if not vl_df.empty else 0
n_wh     = len(wh_df) if not wh_df.empty else 0

# ── Metrics ────────────────────────────────────────────────────────────────────
st.markdown(
    f'<div class="metric-bar">'
    f'<div class="metric-item"><div class="label">Variables (metadata)</div>'
    f'<div class="value" style="color:{C["text_main"]};">{n_vars:,}</div></div>'
    f'<div class="metric-item"><div class="label">VLM vars (codelist)</div>'
    f'<div class="value" style="color:{C["dt_fg"]};">{n_cl_vars:,}</div></div>'
    f'<div class="metric-item"><div class="label">CT checked</div>'
    f'<div class="value" style="color:{C["text_main"]};">{n_ct:,}</div></div>'
    f'<div class="metric-item"><div class="label">CT mismatches</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_miss:,}</div></div>'
    f'<div class="metric-item"><div class="label">CT mismatch vars</div>'
    f'<div class="value" style="color:{C["unmap_fg"]};">{n_miss_v:,}</div></div>'
    f'<div class="metric-item"><div class="label">Value-level rows</div>'
    f'<div class="value" style="color:{C["pass_fg"]};">{n_vl:,}</div></div>'
    f'<div class="metric-item"><div class="label">Where-clause rows</div>'
    f'<div class="value" style="color:{C["pass_fg"]};">{n_wh:,}</div></div>'
    f'</div>', unsafe_allow_html=True
)

# ── Downloads ──────────────────────────────────────────────────────────────────
dl_cols = st.columns(3)
with dl_cols[0]:
    excel_bytes = export_define_results(
        columns_df if not columns_df.empty else pd.DataFrame(),
        vl_df      if not vl_df.empty      else pd.DataFrame(),
        wh_df      if not wh_df.empty      else pd.DataFrame(),
        vlm_df     if not vlm_df.empty     else None,
        ct_df      if not ct_df.empty      else None,
    )
    st.download_button("⬇ Define Report (.xlsx)", data=excel_bytes,
        file_name=f"Define_{mode}_{datetime.now():%Y%m%d_%H%M}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True)

with dl_cols[1]:
    if define_xml:
        st.download_button("⬇ Define-XML v2.1 (.xml)", data=define_xml.encode("utf-8"),
            file_name=f"define_{datetime.now():%Y%m%d_%H%M}.xml",
            mime="application/xml", use_container_width=True)
    else:
        st.button("⬇ Define-XML v2.1 (.xml)", disabled=True,
            help="Enable 'Generate Define-XML v2.1' in Options and re-run.",
            use_container_width=True)

with dl_cols[2]:
    if not ct_df.empty:
        st.download_button("⬇ CT Comparison (.csv)",
            data=ct_df.to_csv(index=False).encode(),
            file_name=f"CT_{datetime.now():%Y%m%d_%H%M}.csv",
            mime="text/csv", use_container_width=True)

st.divider()

# ── Tabs ───────────────────────────────────────────────────────────────────────
tabs = st.tabs([
    f"Variable Metadata ({n_vars:,})",
    f"VLM / Codelist ({n_cl_vars:,} vars)",
    f"CT Comparison ({n_miss:,} mismatches / {n_ct:,} total)",
    f"Value Level ({n_vl:,} rows)",
    f"Where Clause ({n_wh:,} rows)",
])

# Tab 0 — Variable Metadata
with tabs[0]:
    if columns_df.empty:
        if meta_skipped:
            st.info("Metadata extraction was skipped — check 'Extract variable metadata' and regenerate.")
        else:
            st.warning(
                "**Variable metadata could not be read from .sas7bdat files.**\n\n"
                "This does NOT affect VLM, CT Comparison, Value Level, or Where Clause.\n\n"
                "Try upgrading pyreadstat: `pip install --upgrade pyreadstat`  \n"
                "Or export datasets as CSV for metadata extraction."
            )
    else:
        dom_opts = ["All"] + sorted(columns_df["domain"].unique().tolist())
        dom_sel  = st.selectbox("Domain", dom_opts, key="def_dom")
        disp     = columns_df if dom_sel=="All" else columns_df[columns_df["domain"]==dom_sel]
        st.caption(f"{len(disp):,} variables")
        st.dataframe(disp, use_container_width=True, height=450)

# Tab 1 — VLM
with tabs[1]:
    if vlm_df.empty:
        if not spec: st.info("Load a mapping spec in the sidebar to enable VLM.")
        elif cl_tab is None: st.error(f"Codelist tab not found. Sheets: `{', '.join(spec.keys() if spec else [])}`")
        else: st.warning("VLM empty — check column U has codelist names in domain sheets.")
    else:
        cf1,cf2,cf3 = st.columns(3)
        dom_sel = cf1.selectbox("Domain", ["All"]+sorted(vlm_df["domain"].unique()), key="vlm_d")
        cl_sel  = cf2.selectbox("Codelist", ["All"]+sorted(vlm_df["spec_codelist"].unique()), key="vlm_c")
        st_sel  = cf3.selectbox("CT Status", ["All","PASS","MISMATCH","SKIPPED (MedDRA)","NO DATA"], key="vlm_s")
        d = vlm_df.copy()
        if dom_sel!="All": d=d[d["domain"]==dom_sel]
        if cl_sel!="All":  d=d[d["spec_codelist"]==cl_sel]
        if st_sel!="All":  d=d[d["ct_status"].str.contains(st_sel,na=False,regex=False)]
        st.caption(f"Showing {len(d):,} of {len(vlm_df):,} rows")
        def _vlm_rc(r): s=str(r.get("ct_status","")); return "row-miss" if "MISMATCH" in s else "row-pass" if s=="PASS" else ""
        st.markdown(render_table(d,row_class_fn=_vlm_rc,C=C), unsafe_allow_html=True)

        if HAS_PLOTLY:
            sc = vlm_df["ct_status"].apply(
                lambda s:"PASS" if s=="PASS" else "MISMATCH" if "MISMATCH" in str(s)
                         else "MedDRA/WHODrug" if "SKIP" in str(s) else "NO DATA"
            ).value_counts().reset_index(); sc.columns=["status","count"]
            tpl="plotly" if theme_mode=="light" else "plotly_dark"
            fig=px.pie(sc,names="status",values="count",hole=0.4,height=220,title="CT Status",
                       color="status",color_discrete_map={"PASS":"#4ade80","MISMATCH":"#f87171",
                                                           "MedDRA/WHODrug":"#94a3b8","NO DATA":"#64748b"})
            fig.update_layout(template=tpl,margin=dict(l=0,r=0,t=36,b=0),
                               paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)")
            st.plotly_chart(fig,use_container_width=True)

# Tab 2 — CT Comparison
with tabs[2]:
    if ct_df.empty:
        if not spec: st.info("Load spec for CT comparison.")
        elif cl_tab is None: st.error("Codelist tab not found.")
        else:
            st.info(
                "CT comparison returned no results.\n\n"
                "Note: Result variables (--STRESC/--ORRES), MedDRA, and WHODrug codelists are excluded.\n"
                "Check that domain sheets have codelist names in column U."
            )
    else:
        st.info(
            "ℹ️ **CT notes:** Blank SAS values excluded · Case-insensitive matching · "
            "Result vars (--STRESC/--ORRES) excluded · MedDRA/WHODrug excluded · "
            "Active=N values ARE valid CT terms"
        )
        n_p=int((ct_df["status"]=="PASS").sum())
        c1,c2,c3=st.columns(3)
        c1.metric("Total checked",n_ct); c2.metric("PASS",n_p); c3.metric("MISMATCH",n_miss)
        cf1,cf2,cf3=st.columns(3)
        show_miss=cf1.checkbox("Mismatches only",value=True,key="ct_m")
        dom_ct=cf2.selectbox("Domain",["All"]+sorted(ct_df["domain"].unique()),key="ct_d")
        var_ct=cf3.selectbox("Variable",["All"]+sorted(ct_df["variable"].unique()),key="ct_v")
        d=ct_df[ct_df["status"]=="MISMATCH"] if show_miss else ct_df
        if dom_ct!="All": d=d[d["domain"]==dom_ct]
        if var_ct!="All": d=d[d["variable"]==var_ct]
        def _ct_rc(r): return "row-miss" if r.get("status","")=="MISMATCH" else "row-pass"
        st.caption(f"Showing {len(d):,} rows")
        st.markdown(render_table(d,row_class_fn=_ct_rc,C=C), unsafe_allow_html=True)
        if HAS_PLOTLY and n_miss>0:
            mb=(ct_df[ct_df["status"]=="MISMATCH"]
                .groupby(["domain","variable"]).agg(n=("status","count")).reset_index()
                .sort_values("n",ascending=False).head(20))
            mb["dv"]=mb["domain"]+"."+mb["variable"]
            tpl="plotly" if theme_mode=="light" else "plotly_dark"
            fig2=px.bar(mb,x="dv",y="n",title="CT Mismatches by Variable (top 20)",
                        color="n",color_continuous_scale=["#fbbf24","#ef4444"],height=250)
            fig2.update_layout(template=tpl,margin=dict(l=0,r=0,t=36,b=0),
                                paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
                                showlegend=False,coloraxis_showscale=False)
            fig2.update_xaxes(tickangle=-40)
            st.plotly_chart(fig2,use_container_width=True)

# Tab 3 — Value Level
with tabs[3]:
    if vl_df is None or vl_df.empty:
        st.info(
            "**Value-level is empty.**\n\n"
            "This tab scans uploaded file column headers for `TESTCD`, `QNAM`, or `PARAMCD` patterns.\n\n"
            "**If your datasets contain these columns but nothing appears:**\n"
            "1. Try uploading the same datasets via the **in-page uploader** above\n"
            "2. Ensure the correct Mode is selected (SDTM → TESTCD/QNAM · ADaM → PARAMCD)\n"
            "3. Check the value-level errors expander above for load failures\n\n"
            "**SDTM domains with value level:** LB (LBTESTCD), VS (VSTESTCD), QS (QSTESTCD), "
            "RS (RSTESTCD), EG (EGTESTCD), SUPP* (QNAM)  \n"
            "**ADaM:** Any domain with PARAMCD column"
        )
    else:
        d2=st.selectbox("Domain",["All"]+sorted(vl_df["dataset"].unique()),key="def_vl")
        disp2=vl_df if d2=="All" else vl_df[vl_df["dataset"]==d2]
        st.caption(f"{len(disp2):,} value-level rows")
        st.dataframe(disp2,use_container_width=True,height=450)

# Tab 4 — Where Clause
with tabs[4]:
    if wh_df is None or wh_df.empty:
        st.info("Where clause requires value-level data (Tab 4) to be populated first.")
    else:
        st.caption(f"{len(wh_df):,} where-clause rows")
        st.dataframe(wh_df,use_container_width=True,height=450)
