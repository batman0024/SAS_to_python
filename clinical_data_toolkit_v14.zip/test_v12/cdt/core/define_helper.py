# core/define_helper.py  v13 — all issues fixed
"""
FIXES IN v13:
1. PARMCD → PARAMCD typo fixed in value-level pattern
2. Blank/empty SAS values filtered from CT comparison (SAS missing = '' after str())
3. Case-sensitive value display with case-insensitive CT matching
   (show actual value as-is, match against CT uppercase)
4. Value-level error surfacing — no more silent exception swallowing
5. CT comparison mismatch_type column added (BLANK_VALUE / NOT_IN_CT / CASE_MISMATCH)
6. XPT reading robustness improved for large files
7. Define-XML v2.1 generation function added
"""
import io
import logging
import re
import warnings
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import pandas as pd
import numpy as np

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)

EXCLUDE_DOMAIN_PREFIXES = ("_",)
MAX_CT_UNIQUE_PER_VAR    = 50
MAX_SAMPLE_DISPLAY       = 20

MEDDRA_SOURCE_PATTERNS   = ["MEDDRA", "MEDDR"]
MEDDRA_CODELIST_PATTERNS = [
    "MEDDRA", "LLTCD", "HLGTCD", "HLTCD", "SOCCD", "PTCD",
]


def _is_meddra_codelist(cl_name: str, source: str = "") -> bool:
    n = cl_name.upper(); s = source.upper()
    if any(p in s for p in MEDDRA_SOURCE_PATTERNS): return True
    for p in MEDDRA_CODELIST_PATTERNS:
        if n == p or n.startswith(p + "_") or n.endswith("_" + p): return True
    return False


def _supported_ext(fname: str) -> bool:
    return fname.lower().endswith((".sas7bdat", ".xpt", ".v5", ".csv"))


# ─── File loading ─────────────────────────────────────────────────────────────

def _load_file(
    fdata: bytes,
    fname: str,
    usecols: Optional[List[str]] = None,
) -> Tuple[pd.DataFrame, Optional[Any], str]:
    """Load SAS7BDAT/XPT/CSV. Returns (df, meta, error). Never raises."""
    if not fdata:
        return pd.DataFrame(), None, f"[{Path(fname).stem.upper()}] empty bytes"

    fl  = fname.lower()
    dom = Path(fname).stem.upper()
    errors = []

    if fl.endswith(".sas7bdat"):
        try:
            import pyreadstat
        except ImportError:
            errors.append("pyreadstat not installed")
        else:
            for strat, kwargs in [
                ("meta+full",  {"metadataonly": True}),
                ("row_limit",  {"row_limit": 1}),
                ("direct",     {}),
            ]:
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        _, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kwargs)
                    col_names = _extract_col_names(meta)
                    if col_names:
                        kw = {"usecols": usecols} if usecols else {}
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore")
                            df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata), **kw)
                        df.columns = [c.upper() for c in df.columns]
                        return df, meta, ""
                    # Try full read if meta gave 0 cols
                    if strat == "meta+full":
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore")
                            df, meta = pyreadstat.read_sas7bdat(io.BytesIO(fdata))
                        if len(df.columns) > 0:
                            df.columns = [c.upper() for c in df.columns]
                            if usecols:
                                uc = [c.upper() for c in usecols]
                                df = df[[c for c in uc if c in df.columns]]
                            return df, meta, ""
                    errors.append(f"pyreadstat {strat}: 0 columns")
                except Exception as e:
                    errors.append(f"pyreadstat {strat}: {type(e).__name__}: {e}")

        # pandas fallback for SAS7BDAT
        try:
            df = pd.read_sas(io.BytesIO(fdata), format="sas7bdat", encoding="latin-1")
            df.columns = [c.upper() for c in df.columns]
            if usecols:
                uc = [c.upper() for c in usecols]
                df = df[[c for c in uc if c in df.columns]]
            if len(df.columns) > 0:
                return df, None, ""
            errors.append("pandas sas7bdat: 0 columns")
        except Exception as e:
            errors.append(f"pandas sas7bdat: {type(e).__name__}: {e}")

    elif fl.endswith(".xpt") or fl.endswith(".v5"):
        try:
            df = pd.read_sas(io.BytesIO(fdata), format="xport", encoding="latin-1")
            df.columns = [c.upper() for c in df.columns]
            if usecols:
                uc = [c.upper() for c in usecols]
                df = df[[c for c in uc if c in df.columns]]
            if len(df.columns) > 0:
                return df, None, ""
            errors.append("pandas xport: 0 columns")
        except Exception as e:
            errors.append(f"pandas xport: {type(e).__name__}: {e}")

    elif fl.endswith(".csv"):
        try:
            kw = {"usecols": usecols} if usecols else {}
            df = pd.read_csv(io.BytesIO(fdata), **kw)
            df.columns = [c.upper() for c in df.columns]
            return df, None, ""
        except Exception as e:
            errors.append(f"CSV: {type(e).__name__}: {e}")
    else:
        errors.append(f"Unsupported format: {fl}")

    return pd.DataFrame(), None, f"[{dom}] all strategies failed: {'; '.join(errors)}"


def _extract_col_names(meta) -> List[str]:
    for attr in ("column_names","column_names_to_labels",
                 "readstat_variable_names","variable_names"):
        val = getattr(meta, attr, None)
        if isinstance(val, list) and val: return val
        if isinstance(val, dict) and val: return list(val.keys())
    return []


# ─── Variable metadata ────────────────────────────────────────────────────────

def get_column_metadata_from_store(
    files_store: Dict[str, bytes],
) -> Tuple[pd.DataFrame, List[str]]:
    """Read variable metadata. Returns (DataFrame, errors). Never raises."""
    rows=[]; errors=[]
    for fname, fdata in sorted(files_store.items()):
        if not _supported_ext(fname): continue
        dom = Path(fname).stem.upper()
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES): continue

        df, meta, err = _load_file(fdata, fname)
        if err: errors.append(err)
        if df.empty: continue

        col_labels = getattr(meta,"column_labels",[]) or [] if meta else []
        var_fmts   = getattr(meta,"variable_formats",{}) or {} if meta else {}
        var_types  = (getattr(meta,"original_variable_types",[]) or
                      getattr(meta,"readstat_variable_types",[]) or []) if meta else []
        var_widths = getattr(meta,"variable_storage_width",{}) or {} if meta else {}

        for idx, col in enumerate(df.columns):
            col_up = col.upper()
            label  = str(col_labels[idx]) if idx<len(col_labels) and col_labels[idx] else ""
            fmt    = (var_fmts.get(col,"") or var_fmts.get(col_up,"")) if isinstance(var_fmts,dict) else ""
            t_raw  = str(var_types[idx]) if idx<len(var_types) and var_types[idx] else ""
            lgth   = (str(var_widths.get(col,"") or var_widths.get(col_up,"")) if isinstance(var_widths,dict) else "")
            pd_dt  = str(df[col].dtype)
            if "char" in t_raw.lower() and "date" in label.lower(): dtype="datetime"
            elif "char" in t_raw.lower(): dtype="text"
            elif any(h in str(fmt).upper() for h in ("DATE","TIME","MMDD","YYMMDD")): dtype="datetime"
            elif "float" in pd_dt or "int" in pd_dt: dtype="integer"
            else: dtype="text"
            rows.append({"domain":dom,"variable":col_up,"label":label,
                         "data_type":dtype,"length":lgth,"format":fmt})

    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["domain","variable","label","data_type","length","format"]), errors
    return df.drop_duplicates(subset=["domain","variable"]).reset_index(drop=True), errors


def get_column_metadata(lib_path: str) -> pd.DataFrame:
    store={}; lib=Path(lib_path)
    for ext in ("*.sas7bdat","*.xpt","*.csv"):
        for fp in sorted(lib.glob(ext)): store[fp.name]=fp.read_bytes()
    df,_=get_column_metadata_from_store(store); return df


# ─── Spec parsing ─────────────────────────────────────────────────────────────

def _find_codelist_tab(spec: Dict[str, pd.DataFrame]) -> Optional[pd.DataFrame]:
    if not spec: return None
    for key in spec:
        kl = str(key).strip().lower().replace(" ","").replace("_","")
        if kl in ("codelist","codelists","codlst","codes"): return spec[key]
    return None


def _get_active_domains_from_toc(spec: Dict[str, pd.DataFrame]) -> List[str]:
    toc=None
    for key in spec:
        if str(key).strip().lower()=="toc": toc=spec[key]; break
    if toc is None or toc.empty: return []
    toc=toc.copy()
    toc.columns=[str(c).strip().lower().replace(" ","_") for c in toc.columns]
    ds_col=next((c for c in toc.columns if c in ("dataset","domain")),None)
    act_col=next((c for c in toc.columns if c=="active"),None)
    if not ds_col: return []
    if act_col:
        mask=toc[act_col].astype(str).str.strip().str.upper()=="Y"
        return toc[mask][ds_col].dropna().str.strip().str.upper().tolist()
    return toc[ds_col].dropna().str.strip().str.upper().tolist()


def _get_codelist_from_spec(spec: Dict[str, pd.DataFrame]) -> Dict[str, List[dict]]:
    """
    Parse Codelist tab. Includes ALL values regardless of Active column.
    Active=N at codelist level means 'not used in study', NOT 'invalid CT value'.
    """
    cl_df=_find_codelist_tab(spec)
    if cl_df is None or cl_df.empty: return {}
    cl_df=cl_df.copy()
    cl_df.columns=[str(c).strip().lower().replace(" ","_") for c in cl_df.columns]

    name_col   = next((c for c in cl_df.columns if c=="codelist_name"), None)
    value_col  = next((c for c in cl_df.columns if c=="codelist_value"), None)
    if not value_col:
        value_col = next((c for c in cl_df.columns
                          if "codelist_value" in c and "decode" not in c
                          and c!="codelist_value_code"), None)
    decode_col = next((c for c in cl_df.columns if c=="codelist_value_decode"), None)
    vcode_col  = next((c for c in cl_df.columns if c=="codelist_value_code"), None)
    cl_code_col= next((c for c in cl_df.columns if c=="codelist_code"), None)
    ext_col    = next((c for c in cl_df.columns if "extensible" in c), None)
    source_col = next((c for c in cl_df.columns if c in ("codelist_source","source")), None)
    std_col    = next((c for c in cl_df.columns if c=="standard"), None)
    active_col = next((c for c in cl_df.columns if c=="active"), None)

    if not name_col or not value_col: return {}

    result: Dict[str,List[dict]] = {}
    for _,row in cl_df.iterrows():
        cl_name=str(row.get(name_col,"")).strip().upper()
        val=str(row.get(value_col,"")).strip()
        if not cl_name or not val or val.lower()=="nan": continue
        source=str(row.get(source_col,"")).strip() if source_col else ""
        entry={
            "value":     val,
            "decode":    str(row.get(decode_col,"")).strip()   if decode_col  else "",
            "vcode":     str(row.get(vcode_col,"")).strip()    if vcode_col   else "",
            "cl_code":   str(row.get(cl_code_col,"")).strip()  if cl_code_col else "",
            "active":    str(row.get(active_col,"")).strip()   if active_col  else "",
            "extensible":str(row.get(ext_col,"")).strip()      if ext_col     else "",
            "source":    source,
            "standard":  str(row.get(std_col,"")).strip()      if std_col     else "",
        }
        result.setdefault(cl_name,[]).append(entry)
    return result


def _get_codelist_map_from_spec(spec: Dict[str,pd.DataFrame]) -> Dict[tuple,str]:
    """Build {(DOMAIN, VARIABLE) -> CODELIST_NAME}. Filters: TOC Active=Y, mapping_action≠DROP."""
    if not spec: return {}
    active_domains=set(_get_active_domains_from_toc(spec))
    SKIP={"toc","codelist","codelists","computation","valuelist","maintenance","study","standard","ig"}
    try:
        from core.spec_loader import EXCLUDE_DOMAINS; EXCLUDE=set(EXCLUDE_DOMAINS)
    except ImportError:
        EXCLUDE={"TA","TE","TI","TV","TS","TD","TM"}
    result={}
    for sheet,df in spec.items():
        if sheet.strip().lower() in SKIP: continue
        if not isinstance(df,pd.DataFrame) or df.empty: continue
        dom=sheet.upper()
        if active_domains and dom not in active_domains: continue
        if dom in EXCLUDE: continue
        var_col=next((c for c in df.columns if c.lower()=="variable"),None)
        if not var_col: continue
        ma_col=next((c for c in df.columns if c.lower() in ("mapping_action","mappingaction","action")),None)
        cl_col=next((c for c in df.columns if c.lower() in ("codelist","codelist_name","codelist_ref","hasnodet","hasnodeterministic")),None)
        if cl_col is None and len(df.columns)>20: cl_col=df.columns[20]
        if not cl_col: continue
        for _,row in df.iterrows():
            var=str(row.get(var_col,"")).strip().upper()
            cl=str(row.get(cl_col,"")).strip()
            if not var or not cl or cl.lower() in ("nan","","none"): continue
            if ma_col:
                ma=str(row.get(ma_col,"")).strip().upper()
                if ma in ("DROP",""): continue
            result[(dom,var)]=cl.upper()
    return result


def _get_spec_variable_meta(spec:Dict) -> Dict[tuple,dict]:
    SKIP={"toc","codelist","codelists","computation","valuelist","maintenance","study","standard","ig"}
    out={}
    for sheet,df in spec.items():
        if sheet.strip().lower() in SKIP: continue
        if not isinstance(df,pd.DataFrame) or df.empty: continue
        dom=sheet.upper()
        var_col=next((c for c in df.columns if c.lower()=="variable"),None)
        label_col=next((c for c in df.columns if c.lower() in ("label","variable_label")),None)
        type_col=next((c for c in df.columns if c.lower() in ("sas_type","type","sastype")),None)
        len_col=next((c for c in df.columns if c.lower() in ("sas_length","length","saslength")),None)
        if not var_col: continue
        for _,row in df.iterrows():
            var=str(row.get(var_col,"")).strip().upper()
            if not var: continue
            out[(dom,var)]={"label":str(row.get(label_col,"")).strip() if label_col else "",
                            "sas_type":str(row.get(type_col,"")).strip() if type_col else "",
                            "sas_length":str(row.get(len_col,"")).strip() if len_col else ""}
    return out


# ─── CT Comparison ────────────────────────────────────────────────────────────

def compare_data_vs_codelist(
    files_store: Dict[str,bytes],
    spec: Dict[str,pd.DataFrame],
    max_unique_per_var: int = MAX_CT_UNIQUE_PER_VAR,
) -> pd.DataFrame:
    """
    Compare actual SDTM variable values against Codelist tab (column F = Codelist_Value).

    FIXES:
    - Active=N values ARE included (Active is codelist-level, not value-level)
    - Blank/empty SAS values SKIPPED (SAS missing value becomes '' after str())
    - Original case preserved for display; case-insensitive matching against CT
    - mismatch_type column: BLANK_VALUE / NOT_IN_CT / CASE_MISMATCH
    - MedDRA codelists excluded
    - Max 50 unique values per variable
    """
    if not spec or not files_store: return pd.DataFrame()
    cl_map=_get_codelist_map_from_spec(spec)
    cl_lookup=_get_codelist_from_spec(spec)
    if not cl_map: return pd.DataFrame()

    dom_store={}
    for fname,fdata in files_store.items():
        if _supported_ext(fname):
            dom_store[Path(fname).stem.upper()]=(fname,fdata)

    domain_vars: Dict[str,List[str]]=defaultdict(list)
    for (dom,var) in cl_map: domain_vars[dom].append(var)

    rows=[]
    for dom,vars_list in sorted(domain_vars.items()):
        if dom not in dom_store: continue
        fname,fdata=dom_store[dom]
        df_dom,_,load_err=_load_file(fdata,fname)
        if df_dom.empty:
            if load_err: log.debug("CT load: %s",load_err)
            continue

        for var in vars_list:
            if var not in df_dom.columns: continue
            cl_name=cl_map.get((dom,var),"")
            ct_entries=cl_lookup.get(cl_name,[])
            if not ct_entries: continue

            src=ct_entries[0].get("source","") if ct_entries else ""
            if _is_meddra_codelist(cl_name,src): continue

            # Build lookup from ALL entries (no active filter)
            allowed: Dict[str,dict]={e["value"].upper():e for e in ct_entries}

            col_raw=df_dom[var]
            # Convert to string, strip whitespace
            col_str=col_raw.fillna('').astype(str).str.strip()
            # FIX: filter blank/empty strings (SAS missing becomes '' or NaN)
            _excl={"","nan","NaN",".",".  ","<NA>","None"}
            col_str=col_str[~col_str.isin(_excl)]
            if col_str.empty: continue

            unique_vals=sorted({str(v) for v in col_str.unique()})
            truncated=len(unique_vals)>max_unique_per_var
            if truncated: unique_vals=unique_vals[:max_unique_per_var]

            for val in unique_vals:
                val_upper=val.upper()
                val_lower=val.lower()
                n_obs=int((col_str==val).sum())

                if val_upper in allowed:
                    # Exact case-insensitive match
                    entry=allowed[val_upper]
                    mismatch_type=""
                    status="PASS"
                elif any(k.upper()==val_upper for k in allowed):
                    # Should not happen since allowed keys are already upper
                    entry=next(v for k,v in allowed.items() if k.upper()==val_upper)
                    mismatch_type="CASE_MISMATCH"
                    status="MISMATCH"
                else:
                    entry={}
                    mismatch_type="NOT_IN_CT"
                    status="MISMATCH"

                rows.append({
                    "domain":       dom,
                    "variable":     var,
                    "codelist":     cl_name,
                    "value":        val,          # original case from data
                    "n_obs":        n_obs,
                    "in_ct":        "YES" if status=="PASS" else "NO",
                    "ct_decode":    entry.get("decode",""),
                    "ct_vcode":     entry.get("vcode",""),
                    "ct_standard":  entry.get("standard",""),
                    "ct_source":    entry.get("source",""),
                    "mismatch_type":mismatch_type,
                    "status":       status,
                    "note":         f"First {max_unique_per_var} of {col_str.nunique()} values" if truncated else "",
                })

    if not rows: return pd.DataFrame()
    return (pd.DataFrame(rows)
            .sort_values(["domain","variable","status","value"])
            .reset_index(drop=True))


# ─── VLM ──────────────────────────────────────────────────────────────────────

def build_vlm_from_spec_and_data(
    files_store: Dict[str,bytes],
    spec: Dict[str,pd.DataFrame],
) -> pd.DataFrame:
    if not spec: return pd.DataFrame()
    cl_map=_get_codelist_map_from_spec(spec)
    cl_lookup=_get_codelist_from_spec(spec)
    spec_meta=_get_spec_variable_meta(spec)
    if not cl_map: return pd.DataFrame()

    dom_store={}
    for fname,fdata in files_store.items():
        if _supported_ext(fname): dom_store[Path(fname).stem.upper()]=(fname,fdata)

    domain_vars: Dict[str,List[str]]=defaultdict(list)
    for (dom,var) in cl_map: domain_vars[dom].append(var)

    domain_data: Dict[str,pd.DataFrame]={}
    for dom in domain_vars:
        if dom not in dom_store: continue
        fname,fdata=dom_store[dom]
        df_d,_,_=_load_file(fdata,fname)
        if not df_d.empty: domain_data[dom]=df_d

    rows=[]
    for (dom,var),cl_name in sorted(cl_map.items()):
        sm=spec_meta.get((dom,var),{})
        label=sm.get("label",""); sas_type=sm.get("sas_type",""); sas_length=sm.get("sas_length","")
        ct_entries=cl_lookup.get(cl_name,[])
        src=ct_entries[0].get("source","") if ct_entries else ""
        is_meddra=_is_meddra_codelist(cl_name,src)
        ct_vals_all=sorted({e["value"] for e in ct_entries})
        ct_ext=ct_entries[0]["extensible"] if ct_entries else ""
        ct_src=ct_entries[0]["source"]     if ct_entries else ""
        ct_std=ct_entries[0]["standard"]   if ct_entries else ""
        n=len(ct_vals_all)
        ct_vals_display=("; ".join(ct_vals_all) if n<=MAX_SAMPLE_DISPLAY
                         else "; ".join(ct_vals_all[:MAX_SAMPLE_DISPLAY])+f" ... (+{n-MAX_SAMPLE_DISPLAY} more)")

        actual_max_len=""; n_distinct=""; has_decimals=""
        sample_vals=""; mismatch_vals=""; mismatch_count=""
        ct_status="NO DATA"; actual_data_type="text"

        df_dom=domain_data.get(dom)
        if df_dom is not None and var in df_dom.columns:
            col_data=df_dom[var].dropna()
            col_str=col_data.fillna('').astype(str).str.strip()
            _excl2={"","nan","NaN",".",".  ","<NA>","None"}
            col_str=col_str[~col_str.isin(_excl2)]
            n_uniq=col_str.nunique(); n_distinct=str(n_uniq)
            uniq_vals=sorted({str(v) for v in col_str.unique()})
            sample_vals=("; ".join(uniq_vals) if n_uniq<=MAX_SAMPLE_DISPLAY
                         else "; ".join(uniq_vals[:5])+f" ... (+{n_uniq-5} more)")
            if sas_type.upper() in ("CHAR","C","CHARACTER","TEXT"):
                actual_max_len=str(col_str.str.len().max()) if not col_str.empty else "0"
                has_decimals="N/A"; actual_data_type="text"
            else:
                try:
                    numeric=pd.to_numeric(col_data,errors="coerce").dropna()
                    if not numeric.empty:
                        actual_max_len=str(int(numeric.abs().max()))
                        dec=numeric[numeric!=numeric.round()]
                        if len(dec)>0:
                            max_dp=int(numeric.apply(lambda x: len(str(x).split(".")[-1]) if "." in str(x) else 0).max())
                            has_decimals=f"Y (max {max_dp} dp)"; actual_data_type="float"
                        else:
                            has_decimals="N"; actual_data_type="integer"
                except Exception: pass
            if is_meddra:
                ct_status="SKIPPED (MedDRA)"
            elif ct_entries:
                allowed_upper={e["value"].upper() for e in ct_entries}
                check_vals=uniq_vals[:MAX_CT_UNIQUE_PER_VAR]
                mismatches=[v for v in check_vals if v.upper() not in allowed_upper]
                mismatch_count=str(len(mismatches))
                mismatch_vals="; ".join(mismatches[:10])
                suffix=f" (first {MAX_CT_UNIQUE_PER_VAR} checked)" if n_uniq>MAX_CT_UNIQUE_PER_VAR else ""
                ct_status="PASS" if not mismatches else f"MISMATCH ({len(mismatches)} values){suffix}"
            else:
                ct_status="NO CT VALUES IN SPEC"

        rows.append({
            "domain":dom,"variable":var,"label":label,"sas_type":sas_type,
            "sas_length":sas_length,"spec_codelist":cl_name,
            "is_meddra":"YES" if is_meddra else "","actual_data_type":actual_data_type,
            "actual_max_length":actual_max_len,"n_distinct_values":n_distinct,
            "has_decimals":has_decimals,"sample_values":sample_vals,
            "ct_values_allowed":ct_vals_display,"n_ct_values":str(n),
            "ct_extensible":ct_ext,"ct_source":ct_src,"ct_standard":ct_std,
            "ct_mismatch_values":mismatch_vals,"ct_mismatch_count":mismatch_count,
            "ct_status":ct_status,
        })
    return pd.DataFrame(rows)


# ─── Value Level (FIXED: PARMCD → PARAMCD) ───────────────────────────────────

def get_value_level_from_store(
    files_store: Dict[str,bytes],
    columns_df: Optional[pd.DataFrame]=None,
    mode: str="SDTM",
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Extract value-level from TESTCD/QNAM (SDTM) or PARAMCD (ADaM) columns.
    Scans file headers directly — does NOT need columns_df.
    Returns (DataFrame, list_of_errors_per_domain).
    FIXED: PARMCD → PARAMCD
    """
    mode=mode.upper()
    EMPTY=(pd.DataFrame(columns=["dataset","variable","result_variable",
                                   "value","where_clause","data_type"]), [])
    if not files_store: return EMPTY

    dom_store={}
    for fname,fdata in files_store.items():
        if _supported_ext(fname):
            dom_store[Path(fname).stem.upper()]=(fname,fdata)

    # FIXED: PARMCD → PARAMCD
    pat_sdtm=re.compile(r"TESTCD|QNAM|PARAMCD",re.IGNORECASE)
    pat_adam=re.compile(r"^PARAMCD$",re.IGNORECASE)

    rows=[]; domain_errors=[]
    for dom,(fname,fdata) in sorted(dom_store.items()):
        if any(dom.startswith(p.upper()) for p in EXCLUDE_DOMAIN_PREFIXES): continue
        try:
            if fname.lower().endswith(".csv"):
                df_hdr=pd.read_csv(io.BytesIO(fdata),nrows=0)
                col_names=[c.upper() for c in df_hdr.columns]
                df_full=None  # load later if needed
            else:
                df_full,_,err=_load_file(fdata,fname)
                if df_full.empty:
                    if err: domain_errors.append(err)
                    continue
                col_names=list(df_full.columns)
        except Exception as exc:
            domain_errors.append(f"[{dom}] header read: {type(exc).__name__}: {exc}")
            continue

        if mode=="ADAM":
            testcd_cols=[(c,"AVAL",f"{dom}.{c}.") for c in col_names if pat_adam.match(c)]
        else:
            testcd_cols=[]
            for c in col_names:
                if pat_sdtm.search(c):
                    if "TESTCD" in c.upper():
                        orres=dom+"ORRES"
                    elif "QNAM" in c.upper():
                        orres="QVAL"
                    else:  # PARAMCD in SDTM-like context
                        orres="AVAL"
                    testcd_cols.append((c,orres,f"{dom}.{c}."))

        if not testcd_cols: continue

        try:
            if fname.lower().endswith(".csv"):
                df_full=pd.read_csv(io.BytesIO(fdata))
                df_full.columns=[c.upper() for c in df_full.columns]
        except Exception as exc:
            domain_errors.append(f"[{dom}] data load: {type(exc).__name__}: {exc}")
            continue

        for (col,orres,where_prefix) in testcd_cols:
            if col not in df_full.columns: continue
            for val in df_full[col].dropna().unique():
                vs=str(val).strip()
                if not vs or vs.lower()=="nan" or vs==".": continue
                rows.append({
                    "dataset":dom,"variable":col,"result_variable":orres,
                    "value":vs,"where_clause":where_prefix+vs,"data_type":_infer_dtype(vs),
                })

    if not rows: return EMPTY
    return (pd.DataFrame(rows).drop_duplicates(subset=["dataset","variable","value"]).reset_index(drop=True),
            domain_errors)


def build_where_clause_table(value_level:pd.DataFrame,mode:str="SDTM")->pd.DataFrame:
    if value_level is None or value_level.empty:
        return pd.DataFrame(columns=["id","dataset","variable","comparator","value","where_clause"])
    wh=value_level[["dataset","variable","value","where_clause"]].copy()
    wh["comparator"]="EQ"; wh["id"]=wh["where_clause"]
    if "result_variable" in value_level.columns:
        wh["result_variable"]=value_level["result_variable"].values
    return wh[["id","dataset","variable","comparator","value","where_clause"]].reset_index(drop=True)


def _infer_dtype(val:str)->str:
    try:
        n=float(val); return "integer" if n==int(n) else "float"
    except (ValueError,TypeError): pass
    if re.match(r"^\d{4}-\d{2}-\d{2}T",val): return "Datetime"
    if re.match(r"^\d{4}-\d{2}-\d{2}$",val): return "Date"
    return "text"


def validate_ct_values(value_level:pd.DataFrame,spec:Dict)->pd.DataFrame:
    if value_level is None or value_level.empty: return pd.DataFrame()
    cl_lookup=_get_codelist_from_spec(spec)
    cl_map=_get_codelist_map_from_spec(spec)
    rows=[]
    for _,vrow in value_level.iterrows():
        ds=str(vrow["dataset"]).upper(); var=str(vrow["variable"]).upper()
        val=str(vrow["value"]).strip()
        cl_name=cl_map.get((ds,var))
        if not cl_name: continue
        allowed={e["value"].upper() for e in cl_lookup.get(cl_name,[])}
        if not allowed: continue
        in_ct=val.upper() in allowed
        rows.append({"dataset":ds,"variable":var,"value":val,"codelist":cl_name,
                     "in_ct":"YES" if in_ct else "NO","status":"PASS" if in_ct else "MISMATCH"})
    return pd.DataFrame(rows).reset_index(drop=True)


# ─── Define-XML v2.1 Generator ────────────────────────────────────────────────

def generate_define_xml(
    columns_df: pd.DataFrame,
    value_level: pd.DataFrame,
    where_clause: pd.DataFrame,
    spec: Optional[Dict] = None,
    study_name: str = "Study",
    study_description: str = "",
) -> str:
    """
    Generate CDISC Define-XML v2.1 compliant XML string.

    Based on CDISC Define-XML v2.1 specification:
    - ODM root element with xmlns attributes
    - Study/GlobalVariables
    - MetaDataVersion with OID
    - ItemGroupDef per domain
    - ItemDef per variable with DataType, Length, Label
    - ValueListDef for TESTCD value-level entries
    - WhereClauseDef for where-clause conditions
    - CodeList references
    """
    from datetime import datetime
    import xml.etree.ElementTree as ET

    now = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")

    # Namespace declarations
    NS = {
        "xmlns":     "http://www.cdisc.org/ns/odm/v1.3",
        "xmlns:def": "http://www.cdisc.org/ns/def/v2.1",
        "xmlns:xlink":"http://www.w3.org/1999/xlink",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "xsi:schemaLocation": (
            "http://www.cdisc.org/ns/odm/v1.3 "
            "http://www.cdisc.org/ns/odm/v1.3/ODM1-3-2.xsd"
        ),
    }

    lines = ['<?xml version="1.0" encoding="UTF-8"?>']
    ns_str = " ".join(f'{k}="{v}"' for k,v in NS.items())
    lines.append(f'<ODM {ns_str}')
    lines.append(f'  FileType="Snapshot" FileOID="www.define.xml/1"')
    lines.append(f'  CreationDateTime="{now}"')
    lines.append(f'  AsOfDateTime="{now}"')
    lines.append(f'  ODMVersion="1.3.2"')
    lines.append(f'  def:Context="Other">')

    # Study
    lines.append(f'  <Study OID="ST.{_xml_id(study_name)}">')
    lines.append(f'    <GlobalVariables>')
    lines.append(f'      <StudyName>{_xml_esc(study_name)}</StudyName>')
    lines.append(f'      <StudyDescription>{_xml_esc(study_description or study_name)}</StudyDescription>')
    lines.append(f'      <ProtocolName>{_xml_esc(study_name)}</ProtocolName>')
    lines.append(f'    </GlobalVariables>')

    # MetaDataVersion
    lines.append(f'  <MetaDataVersion OID="MDV.1" Name="{_xml_esc(study_name)}"')
    lines.append(f'    def:DefineVersion="2.1.0"')
    lines.append(f'    def:StandardName="SDTM"')
    lines.append(f'    def:StandardVersion="1.7">')

    # Build codelists from spec if available
    codelist_refs: Dict[str, str] = {}  # (dom, var) -> cl_name
    cl_lookup: Dict[str, list]    = {}
    if spec:
        codelist_refs = {f"{d}.{v}": cl for (d,v),cl in _get_codelist_map_from_spec(spec).items()}
        cl_lookup     = _get_codelist_from_spec(spec)

    # ValueListDef — one per TESTCD variable
    if not value_level.empty:
        vl_by_var = value_level.groupby(["dataset","variable"])
        for (dom, testcd_var), grp in vl_by_var:
            vl_oid = f"VL.{dom}.{testcd_var}"
            lines.append(f'    <def:ValueListDef OID="{vl_oid}">')
            for _, row in grp.iterrows():
                val     = _xml_esc(str(row["value"]))
                wc_oid  = f"WC.{dom}.{testcd_var}.{_xml_id(str(row['value']))}"
                item_oid= f"IT.{dom}.{testcd_var}.{_xml_id(str(row['value']))}"
                res_var = str(row.get("result_variable",""))
                lines.append(f'      <ItemRef ItemOID="{item_oid}" OrderNumber="1"')
                lines.append(f'               Mandatory="No" def:WhereClauseOID="{wc_oid}"/>')
            lines.append(f'    </def:ValueListDef>')

    # WhereClauseDef
    if not where_clause.empty:
        for _, row in where_clause.iterrows():
            wc_id   = _xml_id(str(row["where_clause"]))
            dom     = str(row["dataset"])
            var     = str(row["variable"])
            val     = _xml_esc(str(row["value"]))
            comp    = str(row.get("comparator","EQ"))
            wc_oid  = f"WC.{dom}.{var}.{wc_id}"
            lines.append(f'    <def:WhereClauseDef OID="{wc_oid}">')
            lines.append(f'      <RangeCheck Comparator="{comp}" SoftHard="Soft"')
            lines.append(f'               def:ItemOID="IT.{dom}.{var}">')
            lines.append(f'        <CheckValue>{val}</CheckValue>')
            lines.append(f'      </RangeCheck>')
            lines.append(f'    </def:WhereClauseDef>')

    # ItemGroupDef per domain
    if not columns_df.empty:
        for dom, dom_df in columns_df.groupby("domain"):
            lines.append(f'    <ItemGroupDef OID="IG.{dom}" Name="{dom}"')
            lines.append(f'      Repeating="Yes" IsReferenceData="No"')
            lines.append(f'      SASDatasetName="{dom}"')
            lines.append(f'      def:Structure="One record per {dom.lower()} per subject"')
            lines.append(f'      def:Purpose="Tabulation">')
            for idx, (_, row) in enumerate(dom_df.iterrows(), 1):
                var     = str(row["variable"])
                item_oid= f"IT.{dom}.{var}"
                # Check if this variable has value-level entries
                has_vl  = (not value_level.empty and
                           ((value_level["dataset"]==dom) & (value_level["variable"]==var)).any())
                vl_ref  = f' def:ValueListOID="VL.{dom}.{var}"' if has_vl else ""
                lines.append(f'      <ItemRef ItemOID="{item_oid}" OrderNumber="{idx}"')
                lines.append(f'               Mandatory="No"{vl_ref}/>')
            lines.append(f'    </ItemGroupDef>')

        # ItemDef per variable
        for _, row in columns_df.iterrows():
            dom     = str(row["domain"])
            var     = str(row["variable"])
            label   = _xml_esc(str(row.get("label",var)))
            dtype   = str(row.get("data_type","text"))
            length  = str(row.get("length","200"))
            fmt     = str(row.get("format",""))
            item_oid= f"IT.{dom}.{var}"
            xml_type= _map_datatype(dtype)
            length_attr = f' Length="{length}"' if length and length.isdigit() else ' Length="200"'
            cl_key  = f"{dom}.{var}"
            cl_ref  = ""
            if cl_key in codelist_refs:
                cl_name = codelist_refs[cl_key]
                cl_ref  = f'\n        <CodeListRef CodeListOID="CL.{cl_name}"/>'

            lines.append(f'    <ItemDef OID="{item_oid}" Name="{var}"')
            lines.append(f'             DataType="{xml_type}"{length_attr}')
            lines.append(f'             SASFieldName="{var}"')
            lines.append(f'             def:Label="{label}">')
            if fmt:
                lines.append(f'      <def:Origin Type="Collected"/>')
            if cl_ref:
                lines.append(f'      {cl_ref.strip()}')
            lines.append(f'    </ItemDef>')

    # CodeListDef
    for cl_name, entries in cl_lookup.items():
        if _is_meddra_codelist(cl_name, entries[0]["source"] if entries else ""):
            continue
        ext = entries[0]["extensible"] if entries else "No"
        ext_attr = "Yes" if str(ext).upper() in ("Y","YES","TRUE") else "No"
        std = entries[0]["standard"] if entries else ""
        lines.append(f'    <CodeList OID="CL.{cl_name}" Name="{cl_name}"')
        lines.append(f'             DataType="text" def:ExtendedValue="{ext_attr}">')
        if std:
            lines.append(f'      <Alias Context="nci:ExtCodeID" Name="{_xml_esc(std)}"/>')
        for e in entries:
            val    = _xml_esc(e["value"])
            decode = _xml_esc(e["decode"])
            vcode  = e["vcode"]
            lines.append(f'      <EnumeratedItem CodedValue="{val}"')
            if decode:
                lines.append(f'                     def:ExtendedValue="No">')
                lines.append(f'        <Decode><TranslatedText xml:lang="en">{decode}</TranslatedText></Decode>')
                if vcode:
                    lines.append(f'        <Alias Context="nci:ExtCodeID" Name="{_xml_esc(vcode)}"/>')
                lines.append(f'      </EnumeratedItem>')
            else:
                lines.append(f'                     def:ExtendedValue="No"/>')
        lines.append(f'    </CodeList>')

    lines.append(f'  </MetaDataVersion>')
    lines.append(f'  </Study>')
    lines.append(f'</ODM>')

    return "\n".join(lines)


def _xml_esc(s: str) -> str:
    """Escape XML special characters."""
    return (str(s)
            .replace("&","&amp;")
            .replace("<","&lt;")
            .replace(">","&gt;")
            .replace('"',"&quot;")
            .replace("'","&apos;"))


def _xml_id(s: str) -> str:
    """Convert string to valid XML ID/OID (alphanumeric + dot/underscore)."""
    return re.sub(r"[^A-Za-z0-9._\-]","_",str(s))[:64]


def _map_datatype(dt: str) -> str:
    """Map internal dtype to Define-XML DataType."""
    d = dt.lower()
    if d in ("text","char","character","varchar"): return "text"
    if d in ("integer","int"):                     return "integer"
    if d in ("float","number","double"):           return "float"
    if d in ("datetime",):                         return "datetime"
    if d in ("date",):                             return "date"
    if d in ("time",):                             return "time"
    return "text"
